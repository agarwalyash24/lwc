# indexes-of

like Array/String#indexOf but return all the indexes in an array.

``` js
var indexesOf = require('indexes-of')

var twosIndexes = indexesOf([1, 2, 3, 4, 5, 4, 3, 2, 1], 2)

console.log(twosIndexes)

// [1, 7]

```

# Haiku

* A 5 line module.
* But the tests are 40 lines.
* npm publish.

## License

MIT
