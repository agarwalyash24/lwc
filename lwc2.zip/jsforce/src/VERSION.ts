export default '2.0.0-beta.8';
