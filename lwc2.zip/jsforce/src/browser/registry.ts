import { EmptyRegistry } from '../registry/empty';

const registry = new EmptyRegistry();

export default registry;
