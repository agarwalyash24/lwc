import '../typings';
import jsforce from '../lib/core';
export * from '../lib/core';
export default jsforce;
