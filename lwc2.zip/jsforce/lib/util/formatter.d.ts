/**
 *
 */
export declare function zeroPad(num: number, digits?: number): string;
/**
 *
 */
export declare function formatDate(date: Date): string;
