import OAuth2, { OAuth2Config } from './oauth2';
export declare type JwtOAuth2Config = OAuth2Config & {
    privateKey?: string;
    privateKeyFile?: string;
    authCode?: string;
    refreshToken?: string;
    loginUrl?: string;
    username?: string;
};
export declare class JwtOAuth2 extends OAuth2 {
    constructor(config: OAuth2Config);
    jwtAuthorize(innerToken: string): Promise<any>;
}
