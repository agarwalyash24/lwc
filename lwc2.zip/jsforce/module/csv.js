import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */
import csvParse from 'csv-parse/lib/es5';
import csvParseSync from 'csv-parse/lib/es5/sync';
import csvStringify from 'csv-stringify/lib/es5';
import csvStringifySync from 'csv-stringify/lib/es5/sync';
/**
 * @private
 */

export function parseCSV(str, options) {
  return csvParseSync(str, _objectSpread(_objectSpread({}, options), {}, {
    columns: true
  }));
}
/**
 * @private
 */

export function toCSV(records, options) {
  return csvStringifySync(records, _objectSpread(_objectSpread({}, options), {}, {
    header: true
  }));
}
/**
 * @private
 */

export function parseCSVStream(options) {
  return csvParse(_objectSpread(_objectSpread({}, options), {}, {
    columns: true
  }));
}
/**
 * @private
 */

export function serializeCSVStream(options) {
  return csvStringify(_objectSpread(_objectSpread({}, options), {}, {
    header: true
  }));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9jc3YudHMiXSwibmFtZXMiOlsiY3N2UGFyc2UiLCJjc3ZQYXJzZVN5bmMiLCJjc3ZTdHJpbmdpZnkiLCJjc3ZTdHJpbmdpZnlTeW5jIiwicGFyc2VDU1YiLCJzdHIiLCJvcHRpb25zIiwiY29sdW1ucyIsInRvQ1NWIiwicmVjb3JkcyIsImhlYWRlciIsInBhcnNlQ1NWU3RyZWFtIiwic2VyaWFsaXplQ1NWU3RyZWFtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBLE9BQU9BLFFBQVAsTUFBK0MsbUJBQS9DO0FBQ0EsT0FBT0MsWUFBUCxNQUF5Qix3QkFBekI7QUFDQSxPQUFPQyxZQUFQLE1BQXVELHVCQUF2RDtBQUNBLE9BQU9DLGdCQUFQLE1BQTZCLDRCQUE3QjtBQUVBO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLFNBQVNDLFFBQVQsQ0FBa0JDLEdBQWxCLEVBQStCQyxPQUEvQixFQUE4RDtBQUNuRSxTQUFPTCxZQUFZLENBQUNJLEdBQUQsa0NBQVdDLE9BQVg7QUFBb0JDLElBQUFBLE9BQU8sRUFBRTtBQUE3QixLQUFuQjtBQUNEO0FBRUQ7QUFDQTtBQUNBOztBQUNBLE9BQU8sU0FBU0MsS0FBVCxDQUFlQyxPQUFmLEVBQWtDSCxPQUFsQyxFQUFtRTtBQUN4RSxTQUFPSCxnQkFBZ0IsQ0FBQ00sT0FBRCxrQ0FBZUgsT0FBZjtBQUF3QkksSUFBQUEsTUFBTSxFQUFFO0FBQWhDLEtBQXZCO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTQyxjQUFULENBQXdCTCxPQUF4QixFQUF3RDtBQUM3RCxTQUFPTixRQUFRLGlDQUFNTSxPQUFOO0FBQWVDLElBQUFBLE9BQU8sRUFBRTtBQUF4QixLQUFmO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTSyxrQkFBVCxDQUE0Qk4sT0FBNUIsRUFBZ0U7QUFDckUsU0FBT0osWUFBWSxpQ0FBTUksT0FBTjtBQUFlSSxJQUFBQSxNQUFNLEVBQUU7QUFBdkIsS0FBbkI7QUFDRCIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICpcbiAqL1xuaW1wb3J0IHsgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCBjc3ZQYXJzZSwgeyBPcHRpb25zIGFzIFBhcnNlT3B0cyB9IGZyb20gJ2Nzdi1wYXJzZS9saWIvZXM1JztcbmltcG9ydCBjc3ZQYXJzZVN5bmMgZnJvbSAnY3N2LXBhcnNlL2xpYi9lczUvc3luYyc7XG5pbXBvcnQgY3N2U3RyaW5naWZ5LCB7IE9wdGlvbnMgYXMgU3RyaW5naWZ5T3B0cyB9IGZyb20gJ2Nzdi1zdHJpbmdpZnkvbGliL2VzNSc7XG5pbXBvcnQgY3N2U3RyaW5naWZ5U3luYyBmcm9tICdjc3Ytc3RyaW5naWZ5L2xpYi9lczUvc3luYyc7XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ1NWKHN0cjogc3RyaW5nLCBvcHRpb25zPzogUGFyc2VPcHRzKTogT2JqZWN0W10ge1xuICByZXR1cm4gY3N2UGFyc2VTeW5jKHN0ciwgeyAuLi5vcHRpb25zLCBjb2x1bW5zOiB0cnVlIH0pO1xufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0NTVihyZWNvcmRzOiBPYmplY3RbXSwgb3B0aW9ucz86IFN0cmluZ2lmeU9wdHMpOiBzdHJpbmcge1xuICByZXR1cm4gY3N2U3RyaW5naWZ5U3luYyhyZWNvcmRzLCB7IC4uLm9wdGlvbnMsIGhlYWRlcjogdHJ1ZSB9KTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VDU1ZTdHJlYW0ob3B0aW9ucz86IFBhcnNlT3B0cyk6IFRyYW5zZm9ybSB7XG4gIHJldHVybiBjc3ZQYXJzZSh7IC4uLm9wdGlvbnMsIGNvbHVtbnM6IHRydWUgfSk7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZUNTVlN0cmVhbShvcHRpb25zPzogU3RyaW5naWZ5T3B0cyk6IFRyYW5zZm9ybSB7XG4gIHJldHVybiBjc3ZTdHJpbmdpZnkoeyAuLi5vcHRpb25zLCBoZWFkZXI6IHRydWUgfSk7XG59XG4iXX0=