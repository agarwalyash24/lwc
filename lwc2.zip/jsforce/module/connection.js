import _Symbol$toPrimitive from "@babel/runtime-corejs3/core-js-stable/symbol/to-primitive";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import "core-js/modules/es.string.replace";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";

function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }

function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[_Symbol$toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context6; _forEachInstanceProperty(_context6 = ownKeys(Object(source), true)).call(_context6, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context7; _forEachInstanceProperty(_context7 = ownKeys(Object(source))).call(_context7, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */
import { EventEmitter } from 'events';
import jsforce from './jsforce';
import Transport, { CanvasTransport, XdProxyTransport, HttpProxyTransport } from './transport';
import { getLogger } from './util/logger';
import OAuth2 from './oauth2';
import Cache from './cache';
import HttpApi from './http-api';
import SessionRefreshDelegate from './session-refresh-delegate';
import Query from './query';
import SObject from './sobject';
import QuickAction from './quick-action';
import Process from './process';
import { formatDate } from './util/formatter';

/**
 *
 */
const defaultConnectionConfig = {
  loginUrl: 'https://login.salesforce.com',
  instanceUrl: '',
  version: '50.0',
  logLevel: 'NONE',
  maxRequest: 10
};
/**
 *
 */

function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
/**
 *
 */


function parseSignedRequest(sr) {
  if (typeof sr === 'string') {
    if (sr[0] === '{') {
      // might be JSON
      return JSON.parse(sr);
    } // might be original base64-encoded signed request


    const msg = sr.split('.').pop(); // retrieve latter part

    if (!msg) {
      throw new Error('Invalid signed request');
    }

    const json = Buffer.from(msg, 'base64').toString('utf-8');
    return JSON.parse(json);
  }

  return sr;
}
/** @private **/


function parseIdUrl(url) {
  var _context;

  const [organizationId, id] = _sliceInstanceProperty(_context = url.split('/')).call(_context, -2);

  return {
    id,
    organizationId,
    url
  };
}
/**
 * Session Refresh delegate function for OAuth2 authz code flow
 * @private
 */


async function oauthRefreshFn(conn, callback) {
  try {
    if (!conn.refreshToken) {
      throw new Error('No refresh token found in the connection');
    }

    const res = await conn.oauth2.refreshToken(conn.refreshToken);
    const userInfo = parseIdUrl(res.id);

    conn._establish({
      instanceUrl: res.instance_url,
      accessToken: res.access_token,
      userInfo
    });

    callback(undefined, res.access_token, res);
  } catch (err) {
    if (err instanceof Error) {
      callback(err);
    } else {
      throw err;
    }
  }
}
/**
 * Session Refresh delegate function for username/password login
 * @private
 */


function createUsernamePasswordRefreshFn(username, password) {
  return async (conn, callback) => {
    try {
      await conn.login(username, password);

      if (!conn.accessToken) {
        throw new Error('Access token not found after login');
      }

      callback(null, conn.accessToken);
    } catch (err) {
      if (err instanceof Error) {
        callback(err);
      } else {
        throw err;
      }
    }
  };
}
/**
 * @private
 */


function toSaveResult(err) {
  return {
    success: false,
    errors: [err]
  };
}
/**
 *
 */


function raiseNoModuleError(name) {
  throw new Error(`API module '${name}' is not loaded, load 'jsforce/api/${name}' explicitly`);
}
/*
 * Constant of maximum records num in DML operation (update/delete)
 */


const MAX_DML_COUNT = 200;
/**
 *
 */

export class Connection extends EventEmitter {
  // describe: (name: string) => Promise<DescribeSObjectResult>;
  // describeGlobal: () => Promise<DescribeGlobalResult>;
  // API libs are not instantiated here so that core module to remain without dependencies to them
  // It is responsible for developers to import api libs explicitly if they are using 'jsforce/core' instead of 'jsforce'.
  get analytics() {
    return raiseNoModuleError('analytics');
  }

  get apex() {
    return raiseNoModuleError('apex');
  }

  get bulk() {
    return raiseNoModuleError('bulk');
  }

  get bulk2() {
    return raiseNoModuleError('bulk2');
  }

  get chatter() {
    return raiseNoModuleError('chatter');
  }

  get metadata() {
    return raiseNoModuleError('metadata');
  }

  get soap() {
    return raiseNoModuleError('soap');
  }

  get streaming() {
    return raiseNoModuleError('streaming');
  }

  get tooling() {
    return raiseNoModuleError('tooling');
  }
  /**
   *
   */


  constructor(config = {}) {
    super();

    _defineProperty(this, "version", void 0);

    _defineProperty(this, "loginUrl", void 0);

    _defineProperty(this, "instanceUrl", void 0);

    _defineProperty(this, "accessToken", void 0);

    _defineProperty(this, "refreshToken", void 0);

    _defineProperty(this, "userInfo", void 0);

    _defineProperty(this, "limitInfo", {});

    _defineProperty(this, "oauth2", void 0);

    _defineProperty(this, "sobjects", {});

    _defineProperty(this, "cache", void 0);

    _defineProperty(this, "_callOptions", void 0);

    _defineProperty(this, "_maxRequest", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "_logLevel", void 0);

    _defineProperty(this, "_transport", void 0);

    _defineProperty(this, "_sessionType", void 0);

    _defineProperty(this, "_refreshDelegate", void 0);

    _defineProperty(this, "describe$", void 0);

    _defineProperty(this, "describe$$", void 0);

    _defineProperty(this, "describeSObject", void 0);

    _defineProperty(this, "describeSObject$", void 0);

    _defineProperty(this, "describeSObject$$", void 0);

    _defineProperty(this, "describeGlobal$", void 0);

    _defineProperty(this, "describeGlobal$$", void 0);

    _defineProperty(this, "insert", this.create);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    _defineProperty(this, "process", new Process(this));

    const {
      loginUrl,
      instanceUrl,
      version,
      oauth2,
      maxRequest,
      logLevel,
      proxyUrl,
      httpProxy
    } = config;
    this.loginUrl = loginUrl || defaultConnectionConfig.loginUrl;
    this.instanceUrl = instanceUrl || defaultConnectionConfig.instanceUrl;
    this.version = version || defaultConnectionConfig.version;
    this.oauth2 = oauth2 instanceof OAuth2 ? oauth2 : new OAuth2(_objectSpread({
      loginUrl: this.loginUrl,
      proxyUrl,
      httpProxy
    }, oauth2));
    let refreshFn = config.refreshFn;

    if (!refreshFn && this.oauth2.clientId) {
      refreshFn = oauthRefreshFn;
    }

    if (refreshFn) {
      this._refreshDelegate = new SessionRefreshDelegate(this, refreshFn);
    }

    this._maxRequest = maxRequest || defaultConnectionConfig.maxRequest;
    this._logger = logLevel ? Connection._logger.createInstance(logLevel) : Connection._logger;
    this._logLevel = logLevel;
    this._transport = proxyUrl ? new XdProxyTransport(proxyUrl) : httpProxy ? new HttpProxyTransport(httpProxy) : new Transport();
    this._callOptions = config.callOptions;
    this.cache = new Cache();

    const describeCacheKey = type => type ? `describe.${type}` : 'describe';

    const describe = Connection.prototype.describe;
    this.describe = this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'NOCACHE'
    });
    this.describe$ = this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'HIT'
    });
    this.describe$$ = this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'IMMEDIATE'
    });
    this.describeSObject = this.describe;
    this.describeSObject$ = this.describe$;
    this.describeSObject$$ = this.describe$$;
    const describeGlobal = Connection.prototype.describeGlobal;
    this.describeGlobal = this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'NOCACHE'
    });
    this.describeGlobal$ = this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'HIT'
    });
    this.describeGlobal$$ = this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'IMMEDIATE'
    });
    const {
      accessToken,
      refreshToken,
      sessionId,
      serverUrl,
      signedRequest
    } = config;

    this._establish({
      accessToken,
      refreshToken,
      instanceUrl,
      sessionId,
      serverUrl,
      signedRequest
    });

    jsforce.emit('connection:new', this);
  }
  /* @private */


  _establish(options) {
    var _context2;

    const {
      accessToken,
      refreshToken,
      instanceUrl,
      sessionId,
      serverUrl,
      signedRequest,
      userInfo
    } = options;
    this.instanceUrl = serverUrl ? _sliceInstanceProperty(_context2 = serverUrl.split('/')).call(_context2, 0, 3).join('/') : instanceUrl || this.instanceUrl;
    this.accessToken = sessionId || accessToken || this.accessToken;
    this.refreshToken = refreshToken || this.refreshToken;

    if (this.refreshToken && !this._refreshDelegate) {
      throw new Error('Refresh token is specified without oauth2 client information or refresh function');
    }

    const signedRequestObject = signedRequest && parseSignedRequest(signedRequest);

    if (signedRequestObject) {
      this.accessToken = signedRequestObject.client.oauthToken;

      if (CanvasTransport.supported) {
        this._transport = new CanvasTransport(signedRequestObject);
      }
    }

    this.userInfo = userInfo || this.userInfo;
    this._sessionType = sessionId ? 'soap' : 'oauth2';

    this._resetInstance();
  }
  /* @priveate */


  _clearSession() {
    this.accessToken = null;
    this.refreshToken = null;
    this.instanceUrl = defaultConnectionConfig.instanceUrl;
    this.userInfo = null;
    this._sessionType = null;
  }
  /* @priveate */


  _resetInstance() {
    this.limitInfo = {};
    this.sobjects = {}; // TODO impl cache

    this.cache.clear();
    this.cache.get('describeGlobal').removeAllListeners('value');
    this.cache.get('describeGlobal').on('value', ({
      result
    }) => {
      if (result) {
        for (const so of result.sobjects) {
          this.sobject(so.name);
        }
      }
    });
    /*
    if (this.tooling) {
      this.tooling._resetInstance();
    }
    */
  }
  /**
   * Authorize (using oauth2 web server flow)
   */


  async authorize(code, params = {}) {
    const res = await this.oauth2.requestToken(code, params);
    const userInfo = parseIdUrl(res.id);

    this._establish({
      instanceUrl: res.instance_url,
      accessToken: res.access_token,
      refreshToken: res.refresh_token,
      userInfo
    });

    this._logger.debug(`<login> completed. user id = ${userInfo.id}, org id = ${userInfo.organizationId}`);

    return userInfo;
  }
  /**
   *
   */


  async login(username, password) {
    this._refreshDelegate = new SessionRefreshDelegate(this, createUsernamePasswordRefreshFn(username, password));

    if (this.oauth2 && this.oauth2.clientId && this.oauth2.clientSecret) {
      return this.loginByOAuth2(username, password);
    }

    return this.loginBySoap(username, password);
  }
  /**
   * Login by OAuth2 username & password flow
   */


  async loginByOAuth2(username, password) {
    const res = await this.oauth2.authenticate(username, password);
    const userInfo = parseIdUrl(res.id);

    this._establish({
      instanceUrl: res.instance_url,
      accessToken: res.access_token,
      userInfo
    });

    this._logger.info(`<login> completed. user id = ${userInfo.id}, org id = ${userInfo.organizationId}`);

    return userInfo;
  }
  /**
   *
   */


  async loginBySoap(username, password) {
    var _context3;

    if (!username || !password) {
      return _Promise.reject(new Error('no username password given'));
    }

    const body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header/>', '<se:Body>', '<login xmlns="urn:partner.soap.sforce.com">', `<username>${esc(username)}</username>`, `<password>${esc(password)}</password>`, '</login>', '</se:Body>', '</se:Envelope>'].join('');
    const soapLoginEndpoint = [this.loginUrl, 'services/Soap/u', this.version].join('/');
    const response = await this._transport.httpRequest({
      method: 'POST',
      url: soapLoginEndpoint,
      body,
      headers: {
        'Content-Type': 'text/xml',
        SOAPAction: '""'
      }
    });
    let m;

    if (response.statusCode >= 400) {
      m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
      const faultstring = m && m[1];
      throw new Error(faultstring || response.body);
    }

    this._logger.debug(`SOAP response = ${response.body}`);

    m = response.body.match(/<serverUrl>([^<]+)<\/serverUrl>/);
    const serverUrl = m && m[1];
    m = response.body.match(/<sessionId>([^<]+)<\/sessionId>/);
    const sessionId = m && m[1];
    m = response.body.match(/<userId>([^<]+)<\/userId>/);
    const userId = m && m[1];
    m = response.body.match(/<organizationId>([^<]+)<\/organizationId>/);
    const organizationId = m && m[1];

    if (!serverUrl || !sessionId || !userId || !organizationId) {
      throw new Error('could not extract session information from login response');
    }

    const idUrl = [this.loginUrl, 'id', organizationId, userId].join('/');
    const userInfo = {
      id: userId,
      organizationId,
      url: idUrl
    };

    this._establish({
      serverUrl: _sliceInstanceProperty(_context3 = serverUrl.split('/')).call(_context3, 0, 3).join('/'),
      sessionId,
      userInfo
    });

    this._logger.info(`<login> completed. user id = ${userId}, org id = ${organizationId}`);

    return userInfo;
  }
  /**
   * Logout the current session
   */


  async logout(revoke) {
    this._refreshDelegate = undefined;

    if (this._sessionType === 'oauth2') {
      return this.logoutByOAuth2(revoke);
    }

    return this.logoutBySoap(revoke);
  }
  /**
   * Logout the current session by revoking access token via OAuth2 session revoke
   */


  async logoutByOAuth2(revoke) {
    const token = revoke ? this.refreshToken : this.accessToken;

    if (token) {
      await this.oauth2.revokeToken(token);
    } // Destroy the session bound to this connection


    this._clearSession();

    this._resetInstance();
  }
  /**
   * Logout the session by using SOAP web service API
   */


  async logoutBySoap(revoke) {
    const body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header>', '<SessionHeader xmlns="urn:partner.soap.sforce.com">', `<sessionId>${esc(revoke ? this.refreshToken : this.accessToken)}</sessionId>`, '</SessionHeader>', '</se:Header>', '<se:Body>', '<logout xmlns="urn:partner.soap.sforce.com"/>', '</se:Body>', '</se:Envelope>'].join('');
    const response = await this._transport.httpRequest({
      method: 'POST',
      url: [this.instanceUrl, 'services/Soap/u', this.version].join('/'),
      body,
      headers: {
        'Content-Type': 'text/xml',
        SOAPAction: '""'
      }
    });

    this._logger.debug(`SOAP statusCode = ${response.statusCode}, response = ${response.body}`);

    if (response.statusCode >= 400) {
      const m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
      const faultstring = m && m[1];
      throw new Error(faultstring || response.body);
    } // Destroy the session bound to this connection


    this._clearSession();

    this._resetInstance();
  }
  /**
   * Send REST API request with given HTTP request info, with connected session information.
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  request(request, options = {}) {
    // if request is simple string, regard it as url in GET method
    let request_ = typeof request === 'string' ? {
      method: 'GET',
      url: request
    } : request; // if url is given in relative path, prepend base url or instance url before.

    request_ = _objectSpread(_objectSpread({}, request_), {}, {
      url: this._normalizeUrl(request_.url)
    });
    const httpApi = new HttpApi(this, options); // log api usage and its quota

    httpApi.on('response', response => {
      if (response.headers && response.headers['sforce-limit-info']) {
        const apiUsage = response.headers['sforce-limit-info'].match(/api-usage=(\d+)\/(\d+)/);

        if (apiUsage) {
          this.limitInfo = {
            apiUsage: {
              used: _parseInt(apiUsage[1], 10),
              limit: _parseInt(apiUsage[2], 10)
            }
          };
        }
      }
    });
    return httpApi.request(request_);
  }
  /**
   * Send HTTP GET request
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  requestGet(url, options) {
    const request = {
      method: 'GET',
      url
    };
    return this.request(request, options);
  }
  /**
   * Send HTTP POST request with JSON body, with connected session information
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  requestPost(url, body, options) {
    const request = {
      method: 'POST',
      url,
      body: _JSON$stringify(body),
      headers: {
        'content-type': 'application/json'
      }
    };
    return this.request(request, options);
  }
  /**
   * Send HTTP PUT request with JSON body, with connected session information
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  requestPut(url, body, options) {
    const request = {
      method: 'PUT',
      url,
      body: _JSON$stringify(body),
      headers: {
        'content-type': 'application/json'
      }
    };
    return this.request(request, options);
  }
  /**
   * Send HTTP PATCH request with JSON body
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  requestPatch(url, body, options) {
    const request = {
      method: 'PATCH',
      url,
      body: _JSON$stringify(body),
      headers: {
        'content-type': 'application/json'
      }
    };
    return this.request(request, options);
  }
  /**
   * Send HTTP DELETE request
   *
   * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
   * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
   * , or relative path from version root ('/sobjects/Account/describe').
   */


  requestDelete(url, options) {
    const request = {
      method: 'DELETE',
      url
    };
    return this.request(request, options);
  }
  /** @private **/


  _baseUrl() {
    return [this.instanceUrl, 'services/data', `v${this.version}`].join('/');
  }
  /**
   * Convert path to absolute url
   * @private
   */


  _normalizeUrl(url) {
    if (url[0] === '/') {
      if (_indexOfInstanceProperty(url).call(url, this.instanceUrl + '/services/') === 0) {
        return url;
      }

      if (_indexOfInstanceProperty(url).call(url, '/services/') === 0) {
        return this.instanceUrl + url;
      }

      return this._baseUrl() + url;
    }

    return url;
  }
  /**
   *
   */


  query(soql, options) {
    return new Query(this, soql, options);
  }
  /**
   * Execute search by SOSL
   *
   * @param {String} sosl - SOSL string
   * @param {Callback.<Array.<RecordResult>>} [callback] - Callback function
   * @returns {Promise.<Array.<RecordResult>>}
   */


  search(sosl) {
    var url = this._baseUrl() + '/search?q=' + encodeURIComponent(sosl);
    return this.request(url);
  }
  /**
   *
   */


  queryMore(locator, options) {
    return new Query(this, {
      locator
    }, options);
  }
  /* */


  _ensureVersion(majorVersion) {
    const versions = this.version.split('.');
    return _parseInt(versions[0], 10) >= majorVersion;
  }
  /* */


  _supports(feature) {
    switch (feature) {
      case 'sobject-collection':
        // sobject collection is available only in API ver 42.0+
        return this._ensureVersion(42);

      default:
        return false;
    }
  }
  /**
   * Retrieve specified records
   */


  async retrieve(type, ids, options = {}) {
    return _Array$isArray(ids) ? // check the version whether SObject collection API is supported (42.0)
    this._ensureVersion(42) ? this._retrieveMany(type, ids, options) : this._retrieveParallel(type, ids, options) : this._retrieveSingle(type, ids, options);
  }
  /** @private */


  async _retrieveSingle(type, id, options) {
    if (!id) {
      throw new Error('Invalid record ID. Specify valid record ID value');
    }

    let url = [this._baseUrl(), 'sobjects', type, id].join('/');
    const {
      fields,
      headers
    } = options;

    if (fields) {
      url += `?fields=${fields.join(',')}`;
    }

    return this.request({
      method: 'GET',
      url,
      headers
    });
  }
  /** @private */


  async _retrieveParallel(type, ids, options) {
    if (ids.length > this._maxRequest) {
      throw new Error('Exceeded max limit of concurrent call');
    }

    return _Promise.all(_mapInstanceProperty(ids).call(ids, id => this._retrieveSingle(type, id, options).catch(err => {
      if (options.allOrNone || err.errorCode !== 'NOT_FOUND') {
        throw err;
      }

      return null;
    })));
  }
  /** @private */


  async _retrieveMany(type, ids, options) {
    var _context4;

    if (ids.length === 0) {
      return [];
    }

    const url = [this._baseUrl(), 'composite', 'sobjects', type].join('/');

    const fields = options.fields || _mapInstanceProperty(_context4 = (await this.describe$(type)).fields).call(_context4, field => field.name);

    return this.request({
      method: 'POST',
      url,
      body: _JSON$stringify({
        ids,
        fields
      }),
      headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
        'content-type': 'application/json'
      })
    });
  }
  /**
   * Create records
   */


  /**
   * @param type
   * @param records
   * @param options
   */
  async create(type, records, options = {}) {
    const ret = _Array$isArray(records) ? // check the version whether SObject collection API is supported (42.0)
    this._ensureVersion(42) ? await this._createMany(type, records, options) : await this._createParallel(type, records, options) : await this._createSingle(type, records, options);
    return ret;
  }
  /** @private */


  async _createSingle(type, record, options) {
    const {
      Id,
      type: rtype,
      attributes
    } = record,
          rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

    const sobjectType = type || attributes && attributes.type || rtype;

    if (!sobjectType) {
      throw new Error('No SObject Type defined in record');
    }

    const url = [this._baseUrl(), 'sobjects', sobjectType].join('/');
    return this.request({
      method: 'POST',
      url,
      body: _JSON$stringify(rec),
      headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
        'content-type': 'application/json'
      })
    });
  }
  /** @private */


  async _createParallel(type, records, options) {
    if (records.length > this._maxRequest) {
      throw new Error('Exceeded max limit of concurrent call');
    }

    return _Promise.all(_mapInstanceProperty(records).call(records, record => this._createSingle(type, record, options).catch(err => {
      // be aware that allOrNone in parallel mode will not revert the other successful requests
      // it only raises error when met at least one failed request.
      if (options.allOrNone || !err.errorCode) {
        throw err;
      }

      return toSaveResult(err);
    })));
  }
  /** @private */


  async _createMany(type, records, options) {
    if (records.length === 0) {
      return _Promise.resolve([]);
    }

    if (records.length > MAX_DML_COUNT && options.allowRecursive) {
      return [...(await this._createMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options)), ...(await this._createMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options))];
    }

    const _records = _mapInstanceProperty(records).call(records, record => {
      const {
        Id,
        type: rtype,
        attributes
      } = record,
            rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

      const sobjectType = type || attributes && attributes.type || rtype;

      if (!sobjectType) {
        throw new Error('No SObject Type defined in record');
      }

      return _objectSpread({
        attributes: {
          type: sobjectType
        }
      }, rec);
    });

    const url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
    return this.request({
      method: 'POST',
      url,
      body: _JSON$stringify({
        allOrNone: options.allOrNone || false,
        records: _records
      }),
      headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
        'content-type': 'application/json'
      })
    });
  }
  /**
   * Synonym of Connection#create()
   */


  /**
   * @param type
   * @param records
   * @param options
   */
  update(type, records, options = {}) {
    return _Array$isArray(records) ? // check the version whether SObject collection API is supported (42.0)
    this._ensureVersion(42) ? this._updateMany(type, records, options) : this._updateParallel(type, records, options) : this._updateSingle(type, records, options);
  }
  /** @private */


  async _updateSingle(type, record, options) {
    const {
      Id: id,
      type: rtype,
      attributes
    } = record,
          rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

    if (!id) {
      throw new Error('Record id is not found in record.');
    }

    const sobjectType = type || attributes && attributes.type || rtype;

    if (!sobjectType) {
      throw new Error('No SObject Type defined in record');
    }

    const url = [this._baseUrl(), 'sobjects', sobjectType, id].join('/');
    return this.request({
      method: 'PATCH',
      url,
      body: _JSON$stringify(rec),
      headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
        'content-type': 'application/json'
      })
    }, {
      noContentResponse: {
        id,
        success: true,
        errors: []
      }
    });
  }
  /** @private */


  async _updateParallel(type, records, options) {
    if (records.length > this._maxRequest) {
      throw new Error('Exceeded max limit of concurrent call');
    }

    return _Promise.all(_mapInstanceProperty(records).call(records, record => this._updateSingle(type, record, options).catch(err => {
      // be aware that allOrNone in parallel mode will not revert the other successful requests
      // it only raises error when met at least one failed request.
      if (options.allOrNone || !err.errorCode) {
        throw err;
      }

      return toSaveResult(err);
    })));
  }
  /** @private */


  async _updateMany(type, records, options) {
    if (records.length === 0) {
      return [];
    }

    if (records.length > MAX_DML_COUNT && options.allowRecursive) {
      return [...(await this._updateMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options)), ...(await this._updateMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options))];
    }

    const _records = _mapInstanceProperty(records).call(records, record => {
      const {
        Id: id,
        type: rtype,
        attributes
      } = record,
            rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

      if (!id) {
        throw new Error('Record id is not found in record.');
      }

      const sobjectType = type || attributes && attributes.type || rtype;

      if (!sobjectType) {
        throw new Error('No SObject Type defined in record');
      }

      return _objectSpread({
        id,
        attributes: {
          type: sobjectType
        }
      }, rec);
    });

    const url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
    return this.request({
      method: 'PATCH',
      url,
      body: _JSON$stringify({
        allOrNone: options.allOrNone || false,
        records: _records
      }),
      headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
        'content-type': 'application/json'
      })
    });
  }
  /**
   * Upsert records
   */


  /**
   *
   * @param type
   * @param records
   * @param extIdField
   * @param options
   */
  async upsert(type, records, extIdField, options = {}) {
    const isArray = _Array$isArray(records);

    const _records = _Array$isArray(records) ? records : [records];

    if (_records.length > this._maxRequest) {
      throw new Error('Exceeded max limit of concurrent call');
    }

    const results = await _Promise.all(_mapInstanceProperty(_records).call(_records, record => {
      var _context5;

      const {
        [extIdField]: extId,
        type: rtype,
        attributes
      } = record,
            rec = _objectWithoutProperties(record, _mapInstanceProperty(_context5 = [extIdField, "type", "attributes"]).call(_context5, _toPropertyKey));

      const url = [this._baseUrl(), 'sobjects', type, extIdField, extId].join('/');
      return this.request({
        method: 'PATCH',
        url,
        body: _JSON$stringify(rec),
        headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
          'content-type': 'application/json'
        })
      }, {
        noContentResponse: {
          success: true,
          errors: []
        }
      }).catch(err => {
        // Be aware that `allOrNone` option in upsert method
        // will not revert the other successful requests.
        // It only raises error when met at least one failed request.
        if (!isArray || options.allOrNone || !err.errorCode) {
          throw err;
        }

        return toSaveResult(err);
      });
    }));
    return isArray ? results : results[0];
  }
  /**
   * Delete records
   */


  /**
   * @param type
   * @param ids
   * @param options
   */
  async destroy(type, ids, options = {}) {
    return _Array$isArray(ids) ? // check the version whether SObject collection API is supported (42.0)
    this._ensureVersion(42) ? this._destroyMany(type, ids, options) : this._destroyParallel(type, ids, options) : this._destroySingle(type, ids, options);
  }
  /** @private */


  async _destroySingle(type, id, options) {
    const url = [this._baseUrl(), 'sobjects', type, id].join('/');
    return this.request({
      method: 'DELETE',
      url,
      headers: options.headers || {}
    }, {
      noContentResponse: {
        id,
        success: true,
        errors: []
      }
    });
  }
  /** @private */


  async _destroyParallel(type, ids, options) {
    if (ids.length > this._maxRequest) {
      throw new Error('Exceeded max limit of concurrent call');
    }

    return _Promise.all(_mapInstanceProperty(ids).call(ids, id => this._destroySingle(type, id, options).catch(err => {
      // Be aware that `allOrNone` option in parallel mode
      // will not revert the other successful requests.
      // It only raises error when met at least one failed request.
      if (options.allOrNone || !err.errorCode) {
        throw err;
      }

      return toSaveResult(err);
    })));
  }
  /** @private */


  async _destroyMany(type, ids, options) {
    if (ids.length === 0) {
      return [];
    }

    if (ids.length > MAX_DML_COUNT && options.allowRecursive) {
      return [...(await this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, 0, MAX_DML_COUNT), options)), ...(await this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, MAX_DML_COUNT), options))];
    }

    let url = [this._baseUrl(), 'composite', 'sobjects?ids='].join('/') + ids.join(',');

    if (options.allOrNone) {
      url += '&allOrNone=true';
    }

    return this.request({
      method: 'DELETE',
      url,
      headers: options.headers || {}
    });
  }
  /**
   * Synonym of Connection#destroy()
   */


  /**
   * Describe SObject metadata
   */
  async describe(type) {
    const url = [this._baseUrl(), 'sobjects', type, 'describe'].join('/');
    const body = await this.request(url);
    return body;
  }
  /**
   * Describe global SObjects
   */


  async describeGlobal() {
    const url = `${this._baseUrl()}/sobjects`;
    const body = await this.request(url);
    return body;
  }
  /**
   * Get SObject instance
   */


  sobject(type) {
    const so = this.sobjects[type] || new SObject(this, type);
    this.sobjects[type] = so;
    return so;
  }
  /**
   * Get identity information of current user
   */


  async identity(options = {}) {
    let url = this.userInfo && this.userInfo.url;

    if (!url) {
      const res = await this.request({
        method: 'GET',
        url: this._baseUrl(),
        headers: options.headers
      });
      url = res.identity;
    }

    url += '?format=json';

    if (this.accessToken) {
      url += `&oauth_token=${encodeURIComponent(this.accessToken)}`;
    }

    const res = await this.request({
      method: 'GET',
      url
    });
    this.userInfo = {
      id: res.user_id,
      organizationId: res.organization_id,
      url: res.id
    };
    return res;
  }
  /**
   * List recently viewed records
   */


  async recent(type, limit) {
    /* eslint-disable no-param-reassign */
    if (typeof type === 'number') {
      limit = type;
      type = undefined;
    }

    let url;

    if (type) {
      url = [this._baseUrl(), 'sobjects', type].join('/');
      const {
        recentItems
      } = await this.request(url);
      return limit ? _sliceInstanceProperty(recentItems).call(recentItems, 0, limit) : recentItems;
    }

    url = `${this._baseUrl()}/recent`;

    if (limit) {
      url += `?limit=${limit}`;
    }

    return this.request(url);
  }
  /**
   * Retrieve updated records
   */


  async updated(type, start, end) {
    /* eslint-disable no-param-reassign */
    let url = [this._baseUrl(), 'sobjects', type, 'updated'].join('/');

    if (typeof start === 'string') {
      start = new Date(start);
    }

    start = formatDate(start);
    url += `?start=${encodeURIComponent(start)}`;

    if (typeof end === 'string') {
      end = new Date(end);
    }

    end = formatDate(end);
    url += `&end=${encodeURIComponent(end)}`;
    const body = await this.request(url);
    return body;
  }
  /**
   * Retrieve deleted records
   */


  async deleted(type, start, end) {
    /* eslint-disable no-param-reassign */
    let url = [this._baseUrl(), 'sobjects', type, 'deleted'].join('/');

    if (typeof start === 'string') {
      start = new Date(start);
    }

    start = formatDate(start);
    url += `?start=${encodeURIComponent(start)}`;

    if (typeof end === 'string') {
      end = new Date(end);
    }

    end = formatDate(end);
    url += `&end=${encodeURIComponent(end)}`;
    const body = await this.request(url);
    return body;
  }
  /**
   * Returns a list of all tabs
   */


  async tabs() {
    const url = [this._baseUrl(), 'tabs'].join('/');
    const body = await this.request(url);
    return body;
  }
  /**
   * Returns current system limit in the organization
   */


  async limits() {
    const url = [this._baseUrl(), 'limits'].join('/');
    const body = await this.request(url);
    return body;
  }
  /**
   * Returns a theme info
   */


  async theme() {
    const url = [this._baseUrl(), 'theme'].join('/');
    const body = await this.request(url);
    return body;
  }
  /**
   * Returns all registered global quick actions
   */


  async quickActions() {
    const body = await this.request('/quickActions');
    return body;
  }
  /**
   * Get reference for specified global quick action
   */


  quickAction(actionName) {
    return new QuickAction(this, `/quickActions/${actionName}`);
  }
  /**
   * Module which manages process rules and approval processes
   */


}

_defineProperty(Connection, "_logger", getLogger('connection'));

export default Connection;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9jb25uZWN0aW9uLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsImpzZm9yY2UiLCJUcmFuc3BvcnQiLCJDYW52YXNUcmFuc3BvcnQiLCJYZFByb3h5VHJhbnNwb3J0IiwiSHR0cFByb3h5VHJhbnNwb3J0IiwiZ2V0TG9nZ2VyIiwiT0F1dGgyIiwiQ2FjaGUiLCJIdHRwQXBpIiwiU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSIsIlF1ZXJ5IiwiU09iamVjdCIsIlF1aWNrQWN0aW9uIiwiUHJvY2VzcyIsImZvcm1hdERhdGUiLCJkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZyIsImxvZ2luVXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwibG9nTGV2ZWwiLCJtYXhSZXF1ZXN0IiwiZXNjIiwic3RyIiwiU3RyaW5nIiwicmVwbGFjZSIsInBhcnNlU2lnbmVkUmVxdWVzdCIsInNyIiwiSlNPTiIsInBhcnNlIiwibXNnIiwic3BsaXQiLCJwb3AiLCJFcnJvciIsImpzb24iLCJCdWZmZXIiLCJmcm9tIiwidG9TdHJpbmciLCJwYXJzZUlkVXJsIiwidXJsIiwib3JnYW5pemF0aW9uSWQiLCJpZCIsIm9hdXRoUmVmcmVzaEZuIiwiY29ubiIsImNhbGxiYWNrIiwicmVmcmVzaFRva2VuIiwicmVzIiwib2F1dGgyIiwidXNlckluZm8iLCJfZXN0YWJsaXNoIiwiaW5zdGFuY2VfdXJsIiwiYWNjZXNzVG9rZW4iLCJhY2Nlc3NfdG9rZW4iLCJ1bmRlZmluZWQiLCJlcnIiLCJjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsImxvZ2luIiwidG9TYXZlUmVzdWx0Iiwic3VjY2VzcyIsImVycm9ycyIsInJhaXNlTm9Nb2R1bGVFcnJvciIsIm5hbWUiLCJNQVhfRE1MX0NPVU5UIiwiQ29ubmVjdGlvbiIsImFuYWx5dGljcyIsImFwZXgiLCJidWxrIiwiYnVsazIiLCJjaGF0dGVyIiwibWV0YWRhdGEiLCJzb2FwIiwic3RyZWFtaW5nIiwidG9vbGluZyIsImNvbnN0cnVjdG9yIiwiY29uZmlnIiwiY3JlYXRlIiwiZGVzdHJveSIsInByb3h5VXJsIiwiaHR0cFByb3h5IiwicmVmcmVzaEZuIiwiY2xpZW50SWQiLCJfcmVmcmVzaERlbGVnYXRlIiwiX21heFJlcXVlc3QiLCJfbG9nZ2VyIiwiY3JlYXRlSW5zdGFuY2UiLCJfbG9nTGV2ZWwiLCJfdHJhbnNwb3J0IiwiX2NhbGxPcHRpb25zIiwiY2FsbE9wdGlvbnMiLCJjYWNoZSIsImRlc2NyaWJlQ2FjaGVLZXkiLCJ0eXBlIiwiZGVzY3JpYmUiLCJwcm90b3R5cGUiLCJjcmVhdGVDYWNoZWRGdW5jdGlvbiIsImtleSIsInN0cmF0ZWd5IiwiZGVzY3JpYmUkIiwiZGVzY3JpYmUkJCIsImRlc2NyaWJlU09iamVjdCIsImRlc2NyaWJlU09iamVjdCQiLCJkZXNjcmliZVNPYmplY3QkJCIsImRlc2NyaWJlR2xvYmFsIiwiZGVzY3JpYmVHbG9iYWwkIiwiZGVzY3JpYmVHbG9iYWwkJCIsInNlc3Npb25JZCIsInNlcnZlclVybCIsInNpZ25lZFJlcXVlc3QiLCJlbWl0Iiwib3B0aW9ucyIsImpvaW4iLCJzaWduZWRSZXF1ZXN0T2JqZWN0IiwiY2xpZW50Iiwib2F1dGhUb2tlbiIsInN1cHBvcnRlZCIsIl9zZXNzaW9uVHlwZSIsIl9yZXNldEluc3RhbmNlIiwiX2NsZWFyU2Vzc2lvbiIsImxpbWl0SW5mbyIsInNvYmplY3RzIiwiY2xlYXIiLCJnZXQiLCJyZW1vdmVBbGxMaXN0ZW5lcnMiLCJvbiIsInJlc3VsdCIsInNvIiwic29iamVjdCIsImF1dGhvcml6ZSIsImNvZGUiLCJwYXJhbXMiLCJyZXF1ZXN0VG9rZW4iLCJyZWZyZXNoX3Rva2VuIiwiZGVidWciLCJjbGllbnRTZWNyZXQiLCJsb2dpbkJ5T0F1dGgyIiwibG9naW5CeVNvYXAiLCJhdXRoZW50aWNhdGUiLCJpbmZvIiwicmVqZWN0IiwiYm9keSIsInNvYXBMb2dpbkVuZHBvaW50IiwicmVzcG9uc2UiLCJodHRwUmVxdWVzdCIsIm1ldGhvZCIsImhlYWRlcnMiLCJTT0FQQWN0aW9uIiwibSIsInN0YXR1c0NvZGUiLCJtYXRjaCIsImZhdWx0c3RyaW5nIiwidXNlcklkIiwiaWRVcmwiLCJsb2dvdXQiLCJyZXZva2UiLCJsb2dvdXRCeU9BdXRoMiIsImxvZ291dEJ5U29hcCIsInRva2VuIiwicmV2b2tlVG9rZW4iLCJyZXF1ZXN0IiwicmVxdWVzdF8iLCJfbm9ybWFsaXplVXJsIiwiaHR0cEFwaSIsImFwaVVzYWdlIiwidXNlZCIsImxpbWl0IiwicmVxdWVzdEdldCIsInJlcXVlc3RQb3N0IiwicmVxdWVzdFB1dCIsInJlcXVlc3RQYXRjaCIsInJlcXVlc3REZWxldGUiLCJfYmFzZVVybCIsInF1ZXJ5Iiwic29xbCIsInNlYXJjaCIsInNvc2wiLCJlbmNvZGVVUklDb21wb25lbnQiLCJxdWVyeU1vcmUiLCJsb2NhdG9yIiwiX2Vuc3VyZVZlcnNpb24iLCJtYWpvclZlcnNpb24iLCJ2ZXJzaW9ucyIsIl9zdXBwb3J0cyIsImZlYXR1cmUiLCJyZXRyaWV2ZSIsImlkcyIsIl9yZXRyaWV2ZU1hbnkiLCJfcmV0cmlldmVQYXJhbGxlbCIsIl9yZXRyaWV2ZVNpbmdsZSIsImZpZWxkcyIsImxlbmd0aCIsImFsbCIsImNhdGNoIiwiYWxsT3JOb25lIiwiZXJyb3JDb2RlIiwiZmllbGQiLCJyZWNvcmRzIiwicmV0IiwiX2NyZWF0ZU1hbnkiLCJfY3JlYXRlUGFyYWxsZWwiLCJfY3JlYXRlU2luZ2xlIiwicmVjb3JkIiwiSWQiLCJydHlwZSIsImF0dHJpYnV0ZXMiLCJyZWMiLCJzb2JqZWN0VHlwZSIsInJlc29sdmUiLCJhbGxvd1JlY3Vyc2l2ZSIsIl9yZWNvcmRzIiwidXBkYXRlIiwiX3VwZGF0ZU1hbnkiLCJfdXBkYXRlUGFyYWxsZWwiLCJfdXBkYXRlU2luZ2xlIiwibm9Db250ZW50UmVzcG9uc2UiLCJ1cHNlcnQiLCJleHRJZEZpZWxkIiwiaXNBcnJheSIsInJlc3VsdHMiLCJleHRJZCIsIl9kZXN0cm95TWFueSIsIl9kZXN0cm95UGFyYWxsZWwiLCJfZGVzdHJveVNpbmdsZSIsImlkZW50aXR5IiwidXNlcl9pZCIsIm9yZ2FuaXphdGlvbl9pZCIsInJlY2VudCIsInJlY2VudEl0ZW1zIiwidXBkYXRlZCIsInN0YXJ0IiwiZW5kIiwiRGF0ZSIsImRlbGV0ZWQiLCJ0YWJzIiwibGltaXRzIiwidGhlbWUiLCJxdWlja0FjdGlvbnMiLCJxdWlja0FjdGlvbiIsImFjdGlvbk5hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFDQSxPQUFPQyxPQUFQLE1BQW9CLFdBQXBCO0FBZ0NBLE9BQU9DLFNBQVAsSUFDRUMsZUFERixFQUVFQyxnQkFGRixFQUdFQyxrQkFIRixRQUlPLGFBSlA7QUFLQSxTQUFpQkMsU0FBakIsUUFBa0MsZUFBbEM7QUFFQSxPQUFPQyxNQUFQLE1BQXNDLFVBQXRDO0FBRUEsT0FBT0MsS0FBUCxNQUFzQyxTQUF0QztBQUNBLE9BQU9DLE9BQVAsTUFBb0IsWUFBcEI7QUFDQSxPQUFPQyxzQkFBUCxNQUVPLDRCQUZQO0FBR0EsT0FBT0MsS0FBUCxNQUFrQixTQUFsQjtBQUVBLE9BQU9DLE9BQVAsTUFBb0IsV0FBcEI7QUFDQSxPQUFPQyxXQUFQLE1BQXdCLGdCQUF4QjtBQUNBLE9BQU9DLE9BQVAsTUFBb0IsV0FBcEI7QUFDQSxTQUFTQyxVQUFULFFBQTJCLGtCQUEzQjs7QUEyQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsdUJBTUwsR0FBRztBQUNGQyxFQUFBQSxRQUFRLEVBQUUsOEJBRFI7QUFFRkMsRUFBQUEsV0FBVyxFQUFFLEVBRlg7QUFHRkMsRUFBQUEsT0FBTyxFQUFFLE1BSFA7QUFJRkMsRUFBQUEsUUFBUSxFQUFFLE1BSlI7QUFLRkMsRUFBQUEsVUFBVSxFQUFFO0FBTFYsQ0FOSjtBQWNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTQyxHQUFULENBQWFDLEdBQWIsRUFBNEM7QUFDMUMsU0FBT0MsTUFBTSxDQUFDRCxHQUFHLElBQUksRUFBUixDQUFOLENBQ0pFLE9BREksQ0FDSSxJQURKLEVBQ1UsT0FEVixFQUVKQSxPQUZJLENBRUksSUFGSixFQUVVLE1BRlYsRUFHSkEsT0FISSxDQUdJLElBSEosRUFHVSxNQUhWLEVBSUpBLE9BSkksQ0FJSSxJQUpKLEVBSVUsUUFKVixDQUFQO0FBS0Q7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNDLGtCQUFULENBQTRCQyxFQUE1QixFQUFzRTtBQUNwRSxNQUFJLE9BQU9BLEVBQVAsS0FBYyxRQUFsQixFQUE0QjtBQUMxQixRQUFJQSxFQUFFLENBQUMsQ0FBRCxDQUFGLEtBQVUsR0FBZCxFQUFtQjtBQUNqQjtBQUNBLGFBQU9DLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixFQUFYLENBQVA7QUFDRCxLQUp5QixDQUl4Qjs7O0FBQ0YsVUFBTUcsR0FBRyxHQUFHSCxFQUFFLENBQUNJLEtBQUgsQ0FBUyxHQUFULEVBQWNDLEdBQWQsRUFBWixDQUwwQixDQUtPOztBQUNqQyxRQUFJLENBQUNGLEdBQUwsRUFBVTtBQUNSLFlBQU0sSUFBSUcsS0FBSixDQUFVLHdCQUFWLENBQU47QUFDRDs7QUFDRCxVQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZTixHQUFaLEVBQWlCLFFBQWpCLEVBQTJCTyxRQUEzQixDQUFvQyxPQUFwQyxDQUFiO0FBQ0EsV0FBT1QsSUFBSSxDQUFDQyxLQUFMLENBQVdLLElBQVgsQ0FBUDtBQUNEOztBQUNELFNBQU9QLEVBQVA7QUFDRDtBQUVEOzs7QUFDQSxTQUFTVyxVQUFULENBQW9CQyxHQUFwQixFQUFpQztBQUFBOztBQUMvQixRQUFNLENBQUNDLGNBQUQsRUFBaUJDLEVBQWpCLElBQXVCLGtDQUFBRixHQUFHLENBQUNSLEtBQUosQ0FBVSxHQUFWLGtCQUFxQixDQUFDLENBQXRCLENBQTdCOztBQUNBLFNBQU87QUFBRVUsSUFBQUEsRUFBRjtBQUFNRCxJQUFBQSxjQUFOO0FBQXNCRCxJQUFBQTtBQUF0QixHQUFQO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsZUFBZUcsY0FBZixDQUNFQyxJQURGLEVBRUVDLFFBRkYsRUFHRTtBQUNBLE1BQUk7QUFDRixRQUFJLENBQUNELElBQUksQ0FBQ0UsWUFBVixFQUF3QjtBQUN0QixZQUFNLElBQUlaLEtBQUosQ0FBVSwwQ0FBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTWEsR0FBRyxHQUFHLE1BQU1ILElBQUksQ0FBQ0ksTUFBTCxDQUFZRixZQUFaLENBQXlCRixJQUFJLENBQUNFLFlBQTlCLENBQWxCO0FBQ0EsVUFBTUcsUUFBUSxHQUFHVixVQUFVLENBQUNRLEdBQUcsQ0FBQ0wsRUFBTCxDQUEzQjs7QUFDQUUsSUFBQUEsSUFBSSxDQUFDTSxVQUFMLENBQWdCO0FBQ2QvQixNQUFBQSxXQUFXLEVBQUU0QixHQUFHLENBQUNJLFlBREg7QUFFZEMsTUFBQUEsV0FBVyxFQUFFTCxHQUFHLENBQUNNLFlBRkg7QUFHZEosTUFBQUE7QUFIYyxLQUFoQjs7QUFLQUosSUFBQUEsUUFBUSxDQUFDUyxTQUFELEVBQVlQLEdBQUcsQ0FBQ00sWUFBaEIsRUFBOEJOLEdBQTlCLENBQVI7QUFDRCxHQVpELENBWUUsT0FBT1EsR0FBUCxFQUFZO0FBQ1osUUFBSUEsR0FBRyxZQUFZckIsS0FBbkIsRUFBMEI7QUFDeEJXLE1BQUFBLFFBQVEsQ0FBQ1UsR0FBRCxDQUFSO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7QUFDRjtBQUVEO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxTQUFTQywrQkFBVCxDQUNFQyxRQURGLEVBRUVDLFFBRkYsRUFHRTtBQUNBLFNBQU8sT0FDTGQsSUFESyxFQUVMQyxRQUZLLEtBR0Y7QUFDSCxRQUFJO0FBQ0YsWUFBTUQsSUFBSSxDQUFDZSxLQUFMLENBQVdGLFFBQVgsRUFBcUJDLFFBQXJCLENBQU47O0FBQ0EsVUFBSSxDQUFDZCxJQUFJLENBQUNRLFdBQVYsRUFBdUI7QUFDckIsY0FBTSxJQUFJbEIsS0FBSixDQUFVLG9DQUFWLENBQU47QUFDRDs7QUFDRFcsTUFBQUEsUUFBUSxDQUFDLElBQUQsRUFBT0QsSUFBSSxDQUFDUSxXQUFaLENBQVI7QUFDRCxLQU5ELENBTUUsT0FBT0csR0FBUCxFQUFZO0FBQ1osVUFBSUEsR0FBRyxZQUFZckIsS0FBbkIsRUFBMEI7QUFDeEJXLFFBQUFBLFFBQVEsQ0FBQ1UsR0FBRCxDQUFSO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTUEsR0FBTjtBQUNEO0FBQ0Y7QUFDRixHQWpCRDtBQWtCRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU0ssWUFBVCxDQUFzQkwsR0FBdEIsRUFBa0Q7QUFDaEQsU0FBTztBQUNMTSxJQUFBQSxPQUFPLEVBQUUsS0FESjtBQUVMQyxJQUFBQSxNQUFNLEVBQUUsQ0FBQ1AsR0FBRDtBQUZILEdBQVA7QUFJRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1Esa0JBQVQsQ0FBNEJDLElBQTVCLEVBQWlEO0FBQy9DLFFBQU0sSUFBSTlCLEtBQUosQ0FDSCxlQUFjOEIsSUFBSyxzQ0FBcUNBLElBQUssY0FEMUQsQ0FBTjtBQUdEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxNQUFNQyxhQUFhLEdBQUcsR0FBdEI7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNQyxVQUFOLFNBQW9EakUsWUFBcEQsQ0FBaUU7QUFxQnRFO0FBUUE7QUFJQTtBQUNBO0FBQ0EsTUFBSWtFLFNBQUosR0FBOEI7QUFDNUIsV0FBT0osa0JBQWtCLENBQUMsV0FBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlLLElBQUosR0FBb0I7QUFDbEIsV0FBT0wsa0JBQWtCLENBQUMsTUFBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlNLElBQUosR0FBb0I7QUFDbEIsV0FBT04sa0JBQWtCLENBQUMsTUFBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlPLEtBQUosR0FBdUI7QUFDckIsV0FBT1Asa0JBQWtCLENBQUMsT0FBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlRLE9BQUosR0FBMEI7QUFDeEIsV0FBT1Isa0JBQWtCLENBQUMsU0FBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlTLFFBQUosR0FBNEI7QUFDMUIsV0FBT1Qsa0JBQWtCLENBQUMsVUFBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlVLElBQUosR0FBdUI7QUFDckIsV0FBT1Ysa0JBQWtCLENBQUMsTUFBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlXLFNBQUosR0FBOEI7QUFDNUIsV0FBT1gsa0JBQWtCLENBQUMsV0FBRCxDQUF6QjtBQUNEOztBQUVELE1BQUlZLE9BQUosR0FBMEI7QUFDeEIsV0FBT1osa0JBQWtCLENBQUMsU0FBRCxDQUF6QjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRWEsRUFBQUEsV0FBVyxDQUFDQyxNQUEyQixHQUFHLEVBQS9CLEVBQW1DO0FBQzVDOztBQUQ0Qzs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQSx1Q0FqRXZCLEVBaUV1Qjs7QUFBQTs7QUFBQSxzQ0EvRFMsRUErRFQ7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsb0NBcXVCckMsS0FBS0MsTUFydUJnQzs7QUFBQSxvQ0FvakNyQyxLQUFLQyxPQXBqQ2dDOztBQUFBLGlDQXlqQ3hDLEtBQUtBLE9BempDbUM7O0FBQUEscUNBMHVDcEMsSUFBSWhFLE9BQUosQ0FBWSxJQUFaLENBMXVDb0M7O0FBRTVDLFVBQU07QUFDSkcsTUFBQUEsUUFESTtBQUVKQyxNQUFBQSxXQUZJO0FBR0pDLE1BQUFBLE9BSEk7QUFJSjRCLE1BQUFBLE1BSkk7QUFLSjFCLE1BQUFBLFVBTEk7QUFNSkQsTUFBQUEsUUFOSTtBQU9KMkQsTUFBQUEsUUFQSTtBQVFKQyxNQUFBQTtBQVJJLFFBU0ZKLE1BVEo7QUFVQSxTQUFLM0QsUUFBTCxHQUFnQkEsUUFBUSxJQUFJRCx1QkFBdUIsQ0FBQ0MsUUFBcEQ7QUFDQSxTQUFLQyxXQUFMLEdBQW1CQSxXQUFXLElBQUlGLHVCQUF1QixDQUFDRSxXQUExRDtBQUNBLFNBQUtDLE9BQUwsR0FBZUEsT0FBTyxJQUFJSCx1QkFBdUIsQ0FBQ0csT0FBbEQ7QUFDQSxTQUFLNEIsTUFBTCxHQUNFQSxNQUFNLFlBQVl4QyxNQUFsQixHQUNJd0MsTUFESixHQUVJLElBQUl4QyxNQUFKO0FBQ0VVLE1BQUFBLFFBQVEsRUFBRSxLQUFLQSxRQURqQjtBQUVFOEQsTUFBQUEsUUFGRjtBQUdFQyxNQUFBQTtBQUhGLE9BSUtqQyxNQUpMLEVBSE47QUFTQSxRQUFJa0MsU0FBUyxHQUFHTCxNQUFNLENBQUNLLFNBQXZCOztBQUNBLFFBQUksQ0FBQ0EsU0FBRCxJQUFjLEtBQUtsQyxNQUFMLENBQVltQyxRQUE5QixFQUF3QztBQUN0Q0QsTUFBQUEsU0FBUyxHQUFHdkMsY0FBWjtBQUNEOztBQUNELFFBQUl1QyxTQUFKLEVBQWU7QUFDYixXQUFLRSxnQkFBTCxHQUF3QixJQUFJekUsc0JBQUosQ0FBMkIsSUFBM0IsRUFBaUN1RSxTQUFqQyxDQUF4QjtBQUNEOztBQUNELFNBQUtHLFdBQUwsR0FBbUIvRCxVQUFVLElBQUlMLHVCQUF1QixDQUFDSyxVQUF6RDtBQUNBLFNBQUtnRSxPQUFMLEdBQWVqRSxRQUFRLEdBQ25CNkMsVUFBVSxDQUFDb0IsT0FBWCxDQUFtQkMsY0FBbkIsQ0FBa0NsRSxRQUFsQyxDQURtQixHQUVuQjZDLFVBQVUsQ0FBQ29CLE9BRmY7QUFHQSxTQUFLRSxTQUFMLEdBQWlCbkUsUUFBakI7QUFDQSxTQUFLb0UsVUFBTCxHQUFrQlQsUUFBUSxHQUN0QixJQUFJM0UsZ0JBQUosQ0FBcUIyRSxRQUFyQixDQURzQixHQUV0QkMsU0FBUyxHQUNULElBQUkzRSxrQkFBSixDQUF1QjJFLFNBQXZCLENBRFMsR0FFVCxJQUFJOUUsU0FBSixFQUpKO0FBS0EsU0FBS3VGLFlBQUwsR0FBb0JiLE1BQU0sQ0FBQ2MsV0FBM0I7QUFDQSxTQUFLQyxLQUFMLEdBQWEsSUFBSW5GLEtBQUosRUFBYjs7QUFDQSxVQUFNb0YsZ0JBQWdCLEdBQUlDLElBQUQsSUFDdkJBLElBQUksR0FBSSxZQUFXQSxJQUFLLEVBQXBCLEdBQXdCLFVBRDlCOztBQUVBLFVBQU1DLFFBQVEsR0FBRzdCLFVBQVUsQ0FBQzhCLFNBQVgsQ0FBcUJELFFBQXRDO0FBQ0EsU0FBS0EsUUFBTCxHQUFnQixLQUFLSCxLQUFMLENBQVdLLG9CQUFYLENBQWdDRixRQUFoQyxFQUEwQyxJQUExQyxFQUFnRDtBQUM5REcsTUFBQUEsR0FBRyxFQUFFTCxnQkFEeUQ7QUFFOURNLE1BQUFBLFFBQVEsRUFBRTtBQUZvRCxLQUFoRCxDQUFoQjtBQUlBLFNBQUtDLFNBQUwsR0FBaUIsS0FBS1IsS0FBTCxDQUFXSyxvQkFBWCxDQUFnQ0YsUUFBaEMsRUFBMEMsSUFBMUMsRUFBZ0Q7QUFDL0RHLE1BQUFBLEdBQUcsRUFBRUwsZ0JBRDBEO0FBRS9ETSxNQUFBQSxRQUFRLEVBQUU7QUFGcUQsS0FBaEQsQ0FBakI7QUFJQSxTQUFLRSxVQUFMLEdBQWtCLEtBQUtULEtBQUwsQ0FBV0ssb0JBQVgsQ0FBZ0NGLFFBQWhDLEVBQTBDLElBQTFDLEVBQWdEO0FBQ2hFRyxNQUFBQSxHQUFHLEVBQUVMLGdCQUQyRDtBQUVoRU0sTUFBQUEsUUFBUSxFQUFFO0FBRnNELEtBQWhELENBQWxCO0FBSUEsU0FBS0csZUFBTCxHQUF1QixLQUFLUCxRQUE1QjtBQUNBLFNBQUtRLGdCQUFMLEdBQXdCLEtBQUtILFNBQTdCO0FBQ0EsU0FBS0ksaUJBQUwsR0FBeUIsS0FBS0gsVUFBOUI7QUFDQSxVQUFNSSxjQUFjLEdBQUd2QyxVQUFVLENBQUM4QixTQUFYLENBQXFCUyxjQUE1QztBQUNBLFNBQUtBLGNBQUwsR0FBc0IsS0FBS2IsS0FBTCxDQUFXSyxvQkFBWCxDQUNwQlEsY0FEb0IsRUFFcEIsSUFGb0IsRUFHcEI7QUFBRVAsTUFBQUEsR0FBRyxFQUFFLGdCQUFQO0FBQXlCQyxNQUFBQSxRQUFRLEVBQUU7QUFBbkMsS0FIb0IsQ0FBdEI7QUFLQSxTQUFLTyxlQUFMLEdBQXVCLEtBQUtkLEtBQUwsQ0FBV0ssb0JBQVgsQ0FDckJRLGNBRHFCLEVBRXJCLElBRnFCLEVBR3JCO0FBQUVQLE1BQUFBLEdBQUcsRUFBRSxnQkFBUDtBQUF5QkMsTUFBQUEsUUFBUSxFQUFFO0FBQW5DLEtBSHFCLENBQXZCO0FBS0EsU0FBS1EsZ0JBQUwsR0FBd0IsS0FBS2YsS0FBTCxDQUFXSyxvQkFBWCxDQUN0QlEsY0FEc0IsRUFFdEIsSUFGc0IsRUFHdEI7QUFBRVAsTUFBQUEsR0FBRyxFQUFFLGdCQUFQO0FBQXlCQyxNQUFBQSxRQUFRLEVBQUU7QUFBbkMsS0FIc0IsQ0FBeEI7QUFLQSxVQUFNO0FBQ0ovQyxNQUFBQSxXQURJO0FBRUpOLE1BQUFBLFlBRkk7QUFHSjhELE1BQUFBLFNBSEk7QUFJSkMsTUFBQUEsU0FKSTtBQUtKQyxNQUFBQTtBQUxJLFFBTUZqQyxNQU5KOztBQU9BLFNBQUszQixVQUFMLENBQWdCO0FBQ2RFLE1BQUFBLFdBRGM7QUFFZE4sTUFBQUEsWUFGYztBQUdkM0IsTUFBQUEsV0FIYztBQUlkeUYsTUFBQUEsU0FKYztBQUtkQyxNQUFBQSxTQUxjO0FBTWRDLE1BQUFBO0FBTmMsS0FBaEI7O0FBU0E1RyxJQUFBQSxPQUFPLENBQUM2RyxJQUFSLENBQWEsZ0JBQWIsRUFBK0IsSUFBL0I7QUFDRDtBQUVEOzs7QUFDQTdELEVBQUFBLFVBQVUsQ0FBQzhELE9BQUQsRUFBc0M7QUFBQTs7QUFDOUMsVUFBTTtBQUNKNUQsTUFBQUEsV0FESTtBQUVKTixNQUFBQSxZQUZJO0FBR0ozQixNQUFBQSxXQUhJO0FBSUp5RixNQUFBQSxTQUpJO0FBS0pDLE1BQUFBLFNBTEk7QUFNSkMsTUFBQUEsYUFOSTtBQU9KN0QsTUFBQUE7QUFQSSxRQVFGK0QsT0FSSjtBQVNBLFNBQUs3RixXQUFMLEdBQW1CMEYsU0FBUyxHQUN4QixtQ0FBQUEsU0FBUyxDQUFDN0UsS0FBVixDQUFnQixHQUFoQixtQkFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUIsRUFBaUNpRixJQUFqQyxDQUFzQyxHQUF0QyxDQUR3QixHQUV4QjlGLFdBQVcsSUFBSSxLQUFLQSxXQUZ4QjtBQUdBLFNBQUtpQyxXQUFMLEdBQW1Cd0QsU0FBUyxJQUFJeEQsV0FBYixJQUE0QixLQUFLQSxXQUFwRDtBQUNBLFNBQUtOLFlBQUwsR0FBb0JBLFlBQVksSUFBSSxLQUFLQSxZQUF6Qzs7QUFDQSxRQUFJLEtBQUtBLFlBQUwsSUFBcUIsQ0FBQyxLQUFLc0MsZ0JBQS9CLEVBQWlEO0FBQy9DLFlBQU0sSUFBSWxELEtBQUosQ0FDSixrRkFESSxDQUFOO0FBR0Q7O0FBQ0QsVUFBTWdGLG1CQUFtQixHQUN2QkosYUFBYSxJQUFJbkYsa0JBQWtCLENBQUNtRixhQUFELENBRHJDOztBQUVBLFFBQUlJLG1CQUFKLEVBQXlCO0FBQ3ZCLFdBQUs5RCxXQUFMLEdBQW1COEQsbUJBQW1CLENBQUNDLE1BQXBCLENBQTJCQyxVQUE5Qzs7QUFDQSxVQUFJaEgsZUFBZSxDQUFDaUgsU0FBcEIsRUFBK0I7QUFDN0IsYUFBSzVCLFVBQUwsR0FBa0IsSUFBSXJGLGVBQUosQ0FBb0I4RyxtQkFBcEIsQ0FBbEI7QUFDRDtBQUNGOztBQUNELFNBQUtqRSxRQUFMLEdBQWdCQSxRQUFRLElBQUksS0FBS0EsUUFBakM7QUFDQSxTQUFLcUUsWUFBTCxHQUFvQlYsU0FBUyxHQUFHLE1BQUgsR0FBWSxRQUF6Qzs7QUFDQSxTQUFLVyxjQUFMO0FBQ0Q7QUFFRDs7O0FBQ0FDLEVBQUFBLGFBQWEsR0FBRztBQUNkLFNBQUtwRSxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsU0FBS04sWUFBTCxHQUFvQixJQUFwQjtBQUNBLFNBQUszQixXQUFMLEdBQW1CRix1QkFBdUIsQ0FBQ0UsV0FBM0M7QUFDQSxTQUFLOEIsUUFBTCxHQUFnQixJQUFoQjtBQUNBLFNBQUtxRSxZQUFMLEdBQW9CLElBQXBCO0FBQ0Q7QUFFRDs7O0FBQ0FDLEVBQUFBLGNBQWMsR0FBRztBQUNmLFNBQUtFLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCLEVBQWhCLENBRmUsQ0FHZjs7QUFDQSxTQUFLOUIsS0FBTCxDQUFXK0IsS0FBWDtBQUNBLFNBQUsvQixLQUFMLENBQVdnQyxHQUFYLENBQWUsZ0JBQWYsRUFBaUNDLGtCQUFqQyxDQUFvRCxPQUFwRDtBQUNBLFNBQUtqQyxLQUFMLENBQVdnQyxHQUFYLENBQWUsZ0JBQWYsRUFBaUNFLEVBQWpDLENBQW9DLE9BQXBDLEVBQTZDLENBQUM7QUFBRUMsTUFBQUE7QUFBRixLQUFELEtBQWdCO0FBQzNELFVBQUlBLE1BQUosRUFBWTtBQUNWLGFBQUssTUFBTUMsRUFBWCxJQUFpQkQsTUFBTSxDQUFDTCxRQUF4QixFQUFrQztBQUNoQyxlQUFLTyxPQUFMLENBQWFELEVBQUUsQ0FBQ2hFLElBQWhCO0FBQ0Q7QUFDRjtBQUNGLEtBTkQ7QUFPQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0c7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1rRSxTQUFOLENBQ0VDLElBREYsRUFFRUMsTUFBa0MsR0FBRyxFQUZ2QyxFQUdxQjtBQUNuQixVQUFNckYsR0FBRyxHQUFHLE1BQU0sS0FBS0MsTUFBTCxDQUFZcUYsWUFBWixDQUF5QkYsSUFBekIsRUFBK0JDLE1BQS9CLENBQWxCO0FBQ0EsVUFBTW5GLFFBQVEsR0FBR1YsVUFBVSxDQUFDUSxHQUFHLENBQUNMLEVBQUwsQ0FBM0I7O0FBQ0EsU0FBS1EsVUFBTCxDQUFnQjtBQUNkL0IsTUFBQUEsV0FBVyxFQUFFNEIsR0FBRyxDQUFDSSxZQURIO0FBRWRDLE1BQUFBLFdBQVcsRUFBRUwsR0FBRyxDQUFDTSxZQUZIO0FBR2RQLE1BQUFBLFlBQVksRUFBRUMsR0FBRyxDQUFDdUYsYUFISjtBQUlkckYsTUFBQUE7QUFKYyxLQUFoQjs7QUFNQSxTQUFLcUMsT0FBTCxDQUFhaUQsS0FBYixDQUNHLGdDQUErQnRGLFFBQVEsQ0FBQ1AsRUFBRyxjQUFhTyxRQUFRLENBQUNSLGNBQWUsRUFEbkY7O0FBR0EsV0FBT1EsUUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNVSxLQUFOLENBQVlGLFFBQVosRUFBOEJDLFFBQTlCLEVBQW1FO0FBQ2pFLFNBQUswQixnQkFBTCxHQUF3QixJQUFJekUsc0JBQUosQ0FDdEIsSUFEc0IsRUFFdEI2QywrQkFBK0IsQ0FBQ0MsUUFBRCxFQUFXQyxRQUFYLENBRlQsQ0FBeEI7O0FBSUEsUUFBSSxLQUFLVixNQUFMLElBQWUsS0FBS0EsTUFBTCxDQUFZbUMsUUFBM0IsSUFBdUMsS0FBS25DLE1BQUwsQ0FBWXdGLFlBQXZELEVBQXFFO0FBQ25FLGFBQU8sS0FBS0MsYUFBTCxDQUFtQmhGLFFBQW5CLEVBQTZCQyxRQUE3QixDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLZ0YsV0FBTCxDQUFpQmpGLFFBQWpCLEVBQTJCQyxRQUEzQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU0rRSxhQUFOLENBQW9CaEYsUUFBcEIsRUFBc0NDLFFBQXRDLEVBQTJFO0FBQ3pFLFVBQU1YLEdBQUcsR0FBRyxNQUFNLEtBQUtDLE1BQUwsQ0FBWTJGLFlBQVosQ0FBeUJsRixRQUF6QixFQUFtQ0MsUUFBbkMsQ0FBbEI7QUFDQSxVQUFNVCxRQUFRLEdBQUdWLFVBQVUsQ0FBQ1EsR0FBRyxDQUFDTCxFQUFMLENBQTNCOztBQUNBLFNBQUtRLFVBQUwsQ0FBZ0I7QUFDZC9CLE1BQUFBLFdBQVcsRUFBRTRCLEdBQUcsQ0FBQ0ksWUFESDtBQUVkQyxNQUFBQSxXQUFXLEVBQUVMLEdBQUcsQ0FBQ00sWUFGSDtBQUdkSixNQUFBQTtBQUhjLEtBQWhCOztBQUtBLFNBQUtxQyxPQUFMLENBQWFzRCxJQUFiLENBQ0csZ0NBQStCM0YsUUFBUSxDQUFDUCxFQUFHLGNBQWFPLFFBQVEsQ0FBQ1IsY0FBZSxFQURuRjs7QUFHQSxXQUFPUSxRQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU15RixXQUFOLENBQWtCakYsUUFBbEIsRUFBb0NDLFFBQXBDLEVBQXlFO0FBQUE7O0FBQ3ZFLFFBQUksQ0FBQ0QsUUFBRCxJQUFhLENBQUNDLFFBQWxCLEVBQTRCO0FBQzFCLGFBQU8sU0FBUW1GLE1BQVIsQ0FBZSxJQUFJM0csS0FBSixDQUFVLDRCQUFWLENBQWYsQ0FBUDtBQUNEOztBQUNELFVBQU00RyxJQUFJLEdBQUcsQ0FDWCxvRUFEVyxFQUVYLGNBRlcsRUFHWCxXQUhXLEVBSVgsNkNBSlcsRUFLVixhQUFZdkgsR0FBRyxDQUFDa0MsUUFBRCxDQUFXLGFBTGhCLEVBTVYsYUFBWWxDLEdBQUcsQ0FBQ21DLFFBQUQsQ0FBVyxhQU5oQixFQU9YLFVBUFcsRUFRWCxZQVJXLEVBU1gsZ0JBVFcsRUFVWHVELElBVlcsQ0FVTixFQVZNLENBQWI7QUFZQSxVQUFNOEIsaUJBQWlCLEdBQUcsQ0FDeEIsS0FBSzdILFFBRG1CLEVBRXhCLGlCQUZ3QixFQUd4QixLQUFLRSxPQUhtQixFQUl4QjZGLElBSndCLENBSW5CLEdBSm1CLENBQTFCO0FBS0EsVUFBTStCLFFBQVEsR0FBRyxNQUFNLEtBQUt2RCxVQUFMLENBQWdCd0QsV0FBaEIsQ0FBNEI7QUFDakRDLE1BQUFBLE1BQU0sRUFBRSxNQUR5QztBQUVqRDFHLE1BQUFBLEdBQUcsRUFBRXVHLGlCQUY0QztBQUdqREQsTUFBQUEsSUFIaUQ7QUFJakRLLE1BQUFBLE9BQU8sRUFBRTtBQUNQLHdCQUFnQixVQURUO0FBRVBDLFFBQUFBLFVBQVUsRUFBRTtBQUZMO0FBSndDLEtBQTVCLENBQXZCO0FBU0EsUUFBSUMsQ0FBSjs7QUFDQSxRQUFJTCxRQUFRLENBQUNNLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDOUJELE1BQUFBLENBQUMsR0FBR0wsUUFBUSxDQUFDRixJQUFULENBQWNTLEtBQWQsQ0FBb0IscUNBQXBCLENBQUo7QUFDQSxZQUFNQyxXQUFXLEdBQUdILENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBMUI7QUFDQSxZQUFNLElBQUluSCxLQUFKLENBQVVzSCxXQUFXLElBQUlSLFFBQVEsQ0FBQ0YsSUFBbEMsQ0FBTjtBQUNEOztBQUNELFNBQUt4RCxPQUFMLENBQWFpRCxLQUFiLENBQW9CLG1CQUFrQlMsUUFBUSxDQUFDRixJQUFLLEVBQXBEOztBQUNBTyxJQUFBQSxDQUFDLEdBQUdMLFFBQVEsQ0FBQ0YsSUFBVCxDQUFjUyxLQUFkLENBQW9CLGlDQUFwQixDQUFKO0FBQ0EsVUFBTTFDLFNBQVMsR0FBR3dDLENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBeEI7QUFDQUEsSUFBQUEsQ0FBQyxHQUFHTCxRQUFRLENBQUNGLElBQVQsQ0FBY1MsS0FBZCxDQUFvQixpQ0FBcEIsQ0FBSjtBQUNBLFVBQU0zQyxTQUFTLEdBQUd5QyxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFELENBQXhCO0FBQ0FBLElBQUFBLENBQUMsR0FBR0wsUUFBUSxDQUFDRixJQUFULENBQWNTLEtBQWQsQ0FBb0IsMkJBQXBCLENBQUo7QUFDQSxVQUFNRSxNQUFNLEdBQUdKLENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBckI7QUFDQUEsSUFBQUEsQ0FBQyxHQUFHTCxRQUFRLENBQUNGLElBQVQsQ0FBY1MsS0FBZCxDQUFvQiwyQ0FBcEIsQ0FBSjtBQUNBLFVBQU05RyxjQUFjLEdBQUc0RyxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFELENBQTdCOztBQUNBLFFBQUksQ0FBQ3hDLFNBQUQsSUFBYyxDQUFDRCxTQUFmLElBQTRCLENBQUM2QyxNQUE3QixJQUF1QyxDQUFDaEgsY0FBNUMsRUFBNEQ7QUFDMUQsWUFBTSxJQUFJUCxLQUFKLENBQ0osMkRBREksQ0FBTjtBQUdEOztBQUNELFVBQU13SCxLQUFLLEdBQUcsQ0FBQyxLQUFLeEksUUFBTixFQUFnQixJQUFoQixFQUFzQnVCLGNBQXRCLEVBQXNDZ0gsTUFBdEMsRUFBOEN4QyxJQUE5QyxDQUFtRCxHQUFuRCxDQUFkO0FBQ0EsVUFBTWhFLFFBQVEsR0FBRztBQUFFUCxNQUFBQSxFQUFFLEVBQUUrRyxNQUFOO0FBQWNoSCxNQUFBQSxjQUFkO0FBQThCRCxNQUFBQSxHQUFHLEVBQUVrSDtBQUFuQyxLQUFqQjs7QUFDQSxTQUFLeEcsVUFBTCxDQUFnQjtBQUNkMkQsTUFBQUEsU0FBUyxFQUFFLG1DQUFBQSxTQUFTLENBQUM3RSxLQUFWLENBQWdCLEdBQWhCLG1CQUEyQixDQUEzQixFQUE4QixDQUE5QixFQUFpQ2lGLElBQWpDLENBQXNDLEdBQXRDLENBREc7QUFFZEwsTUFBQUEsU0FGYztBQUdkM0QsTUFBQUE7QUFIYyxLQUFoQjs7QUFLQSxTQUFLcUMsT0FBTCxDQUFhc0QsSUFBYixDQUNHLGdDQUErQmEsTUFBTyxjQUFhaEgsY0FBZSxFQURyRTs7QUFHQSxXQUFPUSxRQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU0wRyxNQUFOLENBQWFDLE1BQWIsRUFBOEM7QUFDNUMsU0FBS3hFLGdCQUFMLEdBQXdCOUIsU0FBeEI7O0FBQ0EsUUFBSSxLQUFLZ0UsWUFBTCxLQUFzQixRQUExQixFQUFvQztBQUNsQyxhQUFPLEtBQUt1QyxjQUFMLENBQW9CRCxNQUFwQixDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLRSxZQUFMLENBQWtCRixNQUFsQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1DLGNBQU4sQ0FBcUJELE1BQXJCLEVBQXNEO0FBQ3BELFVBQU1HLEtBQUssR0FBR0gsTUFBTSxHQUFHLEtBQUs5RyxZQUFSLEdBQXVCLEtBQUtNLFdBQWhEOztBQUNBLFFBQUkyRyxLQUFKLEVBQVc7QUFDVCxZQUFNLEtBQUsvRyxNQUFMLENBQVlnSCxXQUFaLENBQXdCRCxLQUF4QixDQUFOO0FBQ0QsS0FKbUQsQ0FLcEQ7OztBQUNBLFNBQUt2QyxhQUFMOztBQUNBLFNBQUtELGNBQUw7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTXVDLFlBQU4sQ0FBbUJGLE1BQW5CLEVBQW9EO0FBQ2xELFVBQU1kLElBQUksR0FBRyxDQUNYLG9FQURXLEVBRVgsYUFGVyxFQUdYLHFEQUhXLEVBSVYsY0FBYXZILEdBQUcsQ0FDZnFJLE1BQU0sR0FBRyxLQUFLOUcsWUFBUixHQUF1QixLQUFLTSxXQURuQixDQUVmLGNBTlMsRUFPWCxrQkFQVyxFQVFYLGNBUlcsRUFTWCxXQVRXLEVBVVgsK0NBVlcsRUFXWCxZQVhXLEVBWVgsZ0JBWlcsRUFhWDZELElBYlcsQ0FhTixFQWJNLENBQWI7QUFjQSxVQUFNK0IsUUFBUSxHQUFHLE1BQU0sS0FBS3ZELFVBQUwsQ0FBZ0J3RCxXQUFoQixDQUE0QjtBQUNqREMsTUFBQUEsTUFBTSxFQUFFLE1BRHlDO0FBRWpEMUcsTUFBQUEsR0FBRyxFQUFFLENBQUMsS0FBS3JCLFdBQU4sRUFBbUIsaUJBQW5CLEVBQXNDLEtBQUtDLE9BQTNDLEVBQW9ENkYsSUFBcEQsQ0FBeUQsR0FBekQsQ0FGNEM7QUFHakQ2QixNQUFBQSxJQUhpRDtBQUlqREssTUFBQUEsT0FBTyxFQUFFO0FBQ1Asd0JBQWdCLFVBRFQ7QUFFUEMsUUFBQUEsVUFBVSxFQUFFO0FBRkw7QUFKd0MsS0FBNUIsQ0FBdkI7O0FBU0EsU0FBSzlELE9BQUwsQ0FBYWlELEtBQWIsQ0FDRyxxQkFBb0JTLFFBQVEsQ0FBQ00sVUFBVyxnQkFBZU4sUUFBUSxDQUFDRixJQUFLLEVBRHhFOztBQUdBLFFBQUlFLFFBQVEsQ0FBQ00sVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM5QixZQUFNRCxDQUFDLEdBQUdMLFFBQVEsQ0FBQ0YsSUFBVCxDQUFjUyxLQUFkLENBQW9CLHFDQUFwQixDQUFWO0FBQ0EsWUFBTUMsV0FBVyxHQUFHSCxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFELENBQTFCO0FBQ0EsWUFBTSxJQUFJbkgsS0FBSixDQUFVc0gsV0FBVyxJQUFJUixRQUFRLENBQUNGLElBQWxDLENBQU47QUFDRCxLQS9CaUQsQ0FnQ2xEOzs7QUFDQSxTQUFLdEIsYUFBTDs7QUFDQSxTQUFLRCxjQUFMO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UwQyxFQUFBQSxPQUFPLENBQ0xBLE9BREssRUFFTGpELE9BQWUsR0FBRyxFQUZiLEVBR2E7QUFDbEI7QUFDQSxRQUFJa0QsUUFBcUIsR0FDdkIsT0FBT0QsT0FBUCxLQUFtQixRQUFuQixHQUE4QjtBQUFFZixNQUFBQSxNQUFNLEVBQUUsS0FBVjtBQUFpQjFHLE1BQUFBLEdBQUcsRUFBRXlIO0FBQXRCLEtBQTlCLEdBQWdFQSxPQURsRSxDQUZrQixDQUlsQjs7QUFDQUMsSUFBQUEsUUFBUSxtQ0FDSEEsUUFERztBQUVOMUgsTUFBQUEsR0FBRyxFQUFFLEtBQUsySCxhQUFMLENBQW1CRCxRQUFRLENBQUMxSCxHQUE1QjtBQUZDLE1BQVI7QUFJQSxVQUFNNEgsT0FBTyxHQUFHLElBQUkxSixPQUFKLENBQVksSUFBWixFQUFrQnNHLE9BQWxCLENBQWhCLENBVGtCLENBVWxCOztBQUNBb0QsSUFBQUEsT0FBTyxDQUFDdEMsRUFBUixDQUFXLFVBQVgsRUFBd0JrQixRQUFELElBQTRCO0FBQ2pELFVBQUlBLFFBQVEsQ0FBQ0csT0FBVCxJQUFvQkgsUUFBUSxDQUFDRyxPQUFULENBQWlCLG1CQUFqQixDQUF4QixFQUErRDtBQUM3RCxjQUFNa0IsUUFBUSxHQUFHckIsUUFBUSxDQUFDRyxPQUFULENBQWlCLG1CQUFqQixFQUFzQ0ksS0FBdEMsQ0FDZix3QkFEZSxDQUFqQjs7QUFHQSxZQUFJYyxRQUFKLEVBQWM7QUFDWixlQUFLNUMsU0FBTCxHQUFpQjtBQUNmNEMsWUFBQUEsUUFBUSxFQUFFO0FBQ1JDLGNBQUFBLElBQUksRUFBRSxVQUFTRCxRQUFRLENBQUMsQ0FBRCxDQUFqQixFQUFzQixFQUF0QixDQURFO0FBRVJFLGNBQUFBLEtBQUssRUFBRSxVQUFTRixRQUFRLENBQUMsQ0FBRCxDQUFqQixFQUFzQixFQUF0QjtBQUZDO0FBREssV0FBakI7QUFNRDtBQUNGO0FBQ0YsS0FkRDtBQWVBLFdBQU9ELE9BQU8sQ0FBQ0gsT0FBUixDQUFtQkMsUUFBbkIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFTSxFQUFBQSxVQUFVLENBQWNoSSxHQUFkLEVBQTJCd0UsT0FBM0IsRUFBNkM7QUFDckQsVUFBTWlELE9BQW9CLEdBQUc7QUFBRWYsTUFBQUEsTUFBTSxFQUFFLEtBQVY7QUFBaUIxRyxNQUFBQTtBQUFqQixLQUE3QjtBQUNBLFdBQU8sS0FBS3lILE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCakQsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFeUQsRUFBQUEsV0FBVyxDQUFjakksR0FBZCxFQUEyQnNHLElBQTNCLEVBQXlDOUIsT0FBekMsRUFBMkQ7QUFDcEUsVUFBTWlELE9BQW9CLEdBQUc7QUFDM0JmLE1BQUFBLE1BQU0sRUFBRSxNQURtQjtBQUUzQjFHLE1BQUFBLEdBRjJCO0FBRzNCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlQSxJQUFmLENBSHFCO0FBSTNCSyxNQUFBQSxPQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBN0I7QUFNQSxXQUFPLEtBQUtjLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCakQsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMEQsRUFBQUEsVUFBVSxDQUFJbEksR0FBSixFQUFpQnNHLElBQWpCLEVBQStCOUIsT0FBL0IsRUFBaUQ7QUFDekQsVUFBTWlELE9BQW9CLEdBQUc7QUFDM0JmLE1BQUFBLE1BQU0sRUFBRSxLQURtQjtBQUUzQjFHLE1BQUFBLEdBRjJCO0FBRzNCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlQSxJQUFmLENBSHFCO0FBSTNCSyxNQUFBQSxPQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBN0I7QUFNQSxXQUFPLEtBQUtjLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCakQsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMkQsRUFBQUEsWUFBWSxDQUFjbkksR0FBZCxFQUEyQnNHLElBQTNCLEVBQXlDOUIsT0FBekMsRUFBMkQ7QUFDckUsVUFBTWlELE9BQW9CLEdBQUc7QUFDM0JmLE1BQUFBLE1BQU0sRUFBRSxPQURtQjtBQUUzQjFHLE1BQUFBLEdBRjJCO0FBRzNCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlQSxJQUFmLENBSHFCO0FBSTNCSyxNQUFBQSxPQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBN0I7QUFNQSxXQUFPLEtBQUtjLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCakQsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFNEQsRUFBQUEsYUFBYSxDQUFJcEksR0FBSixFQUFpQndFLE9BQWpCLEVBQW1DO0FBQzlDLFVBQU1pRCxPQUFvQixHQUFHO0FBQUVmLE1BQUFBLE1BQU0sRUFBRSxRQUFWO0FBQW9CMUcsTUFBQUE7QUFBcEIsS0FBN0I7QUFDQSxXQUFPLEtBQUt5SCxPQUFMLENBQWdCQSxPQUFoQixFQUF5QmpELE9BQXpCLENBQVA7QUFDRDtBQUVEOzs7QUFDQTZELEVBQUFBLFFBQVEsR0FBRztBQUNULFdBQU8sQ0FBQyxLQUFLMUosV0FBTixFQUFtQixlQUFuQixFQUFxQyxJQUFHLEtBQUtDLE9BQVEsRUFBckQsRUFBd0Q2RixJQUF4RCxDQUE2RCxHQUE3RCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VrRCxFQUFBQSxhQUFhLENBQUMzSCxHQUFELEVBQWM7QUFDekIsUUFBSUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBQWYsRUFBb0I7QUFDbEIsVUFBSSx5QkFBQUEsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBUyxLQUFLckIsV0FBTCxHQUFtQixZQUE1QixDQUFILEtBQWlELENBQXJELEVBQXdEO0FBQ3RELGVBQU9xQixHQUFQO0FBQ0Q7O0FBQ0QsVUFBSSx5QkFBQUEsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBUyxZQUFULENBQUgsS0FBOEIsQ0FBbEMsRUFBcUM7QUFDbkMsZUFBTyxLQUFLckIsV0FBTCxHQUFtQnFCLEdBQTFCO0FBQ0Q7O0FBQ0QsYUFBTyxLQUFLcUksUUFBTCxLQUFrQnJJLEdBQXpCO0FBQ0Q7O0FBQ0QsV0FBT0EsR0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRXNJLEVBQUFBLEtBQUssQ0FDSEMsSUFERyxFQUVIL0QsT0FGRyxFQUcwQztBQUM3QyxXQUFPLElBQUlwRyxLQUFKLENBQWdELElBQWhELEVBQXNEbUssSUFBdEQsRUFBNEQvRCxPQUE1RCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VnRSxFQUFBQSxNQUFNLENBQUNDLElBQUQsRUFBZTtBQUNuQixRQUFJekksR0FBRyxHQUFHLEtBQUtxSSxRQUFMLEtBQWtCLFlBQWxCLEdBQWlDSyxrQkFBa0IsQ0FBQ0QsSUFBRCxDQUE3RDtBQUNBLFdBQU8sS0FBS2hCLE9BQUwsQ0FBMkJ6SCxHQUEzQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFMkksRUFBQUEsU0FBUyxDQUFDQyxPQUFELEVBQWtCcEUsT0FBbEIsRUFBMEM7QUFDakQsV0FBTyxJQUFJcEcsS0FBSixDQUNMLElBREssRUFFTDtBQUFFd0ssTUFBQUE7QUFBRixLQUZLLEVBR0xwRSxPQUhLLENBQVA7QUFLRDtBQUVEOzs7QUFDQXFFLEVBQUFBLGNBQWMsQ0FBQ0MsWUFBRCxFQUF1QjtBQUNuQyxVQUFNQyxRQUFRLEdBQUcsS0FBS25LLE9BQUwsQ0FBYVksS0FBYixDQUFtQixHQUFuQixDQUFqQjtBQUNBLFdBQU8sVUFBU3VKLFFBQVEsQ0FBQyxDQUFELENBQWpCLEVBQXNCLEVBQXRCLEtBQTZCRCxZQUFwQztBQUNEO0FBRUQ7OztBQUNBRSxFQUFBQSxTQUFTLENBQUNDLE9BQUQsRUFBa0I7QUFDekIsWUFBUUEsT0FBUjtBQUNFLFdBQUssb0JBQUw7QUFBMkI7QUFDekIsZUFBTyxLQUFLSixjQUFMLENBQW9CLEVBQXBCLENBQVA7O0FBQ0Y7QUFDRSxlQUFPLEtBQVA7QUFKSjtBQU1EO0FBRUQ7QUFDRjtBQUNBOzs7QUFnQkUsUUFBTUssUUFBTixDQUNFNUYsSUFERixFQUVFNkYsR0FGRixFQUdFM0UsT0FBd0IsR0FBRyxFQUg3QixFQUlFO0FBQ0EsV0FBTyxlQUFjMkUsR0FBZCxJQUNIO0FBQ0EsU0FBS04sY0FBTCxDQUFvQixFQUFwQixJQUNFLEtBQUtPLGFBQUwsQ0FBbUI5RixJQUFuQixFQUF5QjZGLEdBQXpCLEVBQThCM0UsT0FBOUIsQ0FERixHQUVFLEtBQUs2RSxpQkFBTCxDQUF1Qi9GLElBQXZCLEVBQTZCNkYsR0FBN0IsRUFBa0MzRSxPQUFsQyxDQUpDLEdBS0gsS0FBSzhFLGVBQUwsQ0FBcUJoRyxJQUFyQixFQUEyQjZGLEdBQTNCLEVBQWdDM0UsT0FBaEMsQ0FMSjtBQU1EO0FBRUQ7OztBQUNBLFFBQU04RSxlQUFOLENBQXNCaEcsSUFBdEIsRUFBb0NwRCxFQUFwQyxFQUFnRHNFLE9BQWhELEVBQTBFO0FBQ3hFLFFBQUksQ0FBQ3RFLEVBQUwsRUFBUztBQUNQLFlBQU0sSUFBSVIsS0FBSixDQUFVLGtEQUFWLENBQU47QUFDRDs7QUFDRCxRQUFJTSxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCL0UsSUFBOUIsRUFBb0NwRCxFQUFwQyxFQUF3Q3VFLElBQXhDLENBQTZDLEdBQTdDLENBQVY7QUFDQSxVQUFNO0FBQUU4RSxNQUFBQSxNQUFGO0FBQVU1QyxNQUFBQTtBQUFWLFFBQXNCbkMsT0FBNUI7O0FBQ0EsUUFBSStFLE1BQUosRUFBWTtBQUNWdkosTUFBQUEsR0FBRyxJQUFLLFdBQVV1SixNQUFNLENBQUM5RSxJQUFQLENBQVksR0FBWixDQUFpQixFQUFuQztBQUNEOztBQUNELFdBQU8sS0FBS2dELE9BQUwsQ0FBYTtBQUFFZixNQUFBQSxNQUFNLEVBQUUsS0FBVjtBQUFpQjFHLE1BQUFBLEdBQWpCO0FBQXNCMkcsTUFBQUE7QUFBdEIsS0FBYixDQUFQO0FBQ0Q7QUFFRDs7O0FBQ0EsUUFBTTBDLGlCQUFOLENBQ0UvRixJQURGLEVBRUU2RixHQUZGLEVBR0UzRSxPQUhGLEVBSUU7QUFDQSxRQUFJMkUsR0FBRyxDQUFDSyxNQUFKLEdBQWEsS0FBSzNHLFdBQXRCLEVBQW1DO0FBQ2pDLFlBQU0sSUFBSW5ELEtBQUosQ0FBVSx1Q0FBVixDQUFOO0FBQ0Q7O0FBQ0QsV0FBTyxTQUFRK0osR0FBUixDQUNMLHFCQUFBTixHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFNakosRUFBRCxJQUNOLEtBQUtvSixlQUFMLENBQXFCaEcsSUFBckIsRUFBMkJwRCxFQUEzQixFQUErQnNFLE9BQS9CLEVBQXdDa0YsS0FBeEMsQ0FBK0MzSSxHQUFELElBQVM7QUFDckQsVUFBSXlELE9BQU8sQ0FBQ21GLFNBQVIsSUFBcUI1SSxHQUFHLENBQUM2SSxTQUFKLEtBQWtCLFdBQTNDLEVBQXdEO0FBQ3RELGNBQU03SSxHQUFOO0FBQ0Q7O0FBQ0QsYUFBTyxJQUFQO0FBQ0QsS0FMRCxDQURDLENBREUsQ0FBUDtBQVVEO0FBRUQ7OztBQUNBLFFBQU1xSSxhQUFOLENBQW9COUYsSUFBcEIsRUFBa0M2RixHQUFsQyxFQUFpRDNFLE9BQWpELEVBQTJFO0FBQUE7O0FBQ3pFLFFBQUkyRSxHQUFHLENBQUNLLE1BQUosS0FBZSxDQUFuQixFQUFzQjtBQUNwQixhQUFPLEVBQVA7QUFDRDs7QUFDRCxVQUFNeEosR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixXQUFsQixFQUErQixVQUEvQixFQUEyQy9FLElBQTNDLEVBQWlEbUIsSUFBakQsQ0FBc0QsR0FBdEQsQ0FBWjs7QUFDQSxVQUFNOEUsTUFBTSxHQUNWL0UsT0FBTyxDQUFDK0UsTUFBUixJQUNBLGtDQUFDLE1BQU0sS0FBSzNGLFNBQUwsQ0FBZU4sSUFBZixDQUFQLEVBQTZCaUcsTUFBN0Isa0JBQXlDTSxLQUFELElBQVdBLEtBQUssQ0FBQ3JJLElBQXpELENBRkY7O0FBR0EsV0FBTyxLQUFLaUcsT0FBTCxDQUFhO0FBQ2xCZixNQUFBQSxNQUFNLEVBQUUsTUFEVTtBQUVsQjFHLE1BQUFBLEdBRmtCO0FBR2xCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQUU2QyxRQUFBQSxHQUFGO0FBQU9JLFFBQUFBO0FBQVAsT0FBZixDQUhZO0FBSWxCNUMsTUFBQUEsT0FBTyxrQ0FDRG5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCx3QkFBZ0I7QUFGWDtBQUpXLEtBQWIsQ0FBUDtBQVNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFxQkU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNFLFFBQU1yRSxNQUFOLENBQ0VnQixJQURGLEVBRUV3RyxPQUZGLEVBR0V0RixPQUFtQixHQUFHLEVBSHhCLEVBSUU7QUFDQSxVQUFNdUYsR0FBRyxHQUFHLGVBQWNELE9BQWQsSUFDUjtBQUNBLFNBQUtqQixjQUFMLENBQW9CLEVBQXBCLElBQ0UsTUFBTSxLQUFLbUIsV0FBTCxDQUFpQjFHLElBQWpCLEVBQXVCd0csT0FBdkIsRUFBZ0N0RixPQUFoQyxDQURSLEdBRUUsTUFBTSxLQUFLeUYsZUFBTCxDQUFxQjNHLElBQXJCLEVBQTJCd0csT0FBM0IsRUFBb0N0RixPQUFwQyxDQUpBLEdBS1IsTUFBTSxLQUFLMEYsYUFBTCxDQUFtQjVHLElBQW5CLEVBQXlCd0csT0FBekIsRUFBa0N0RixPQUFsQyxDQUxWO0FBTUEsV0FBT3VGLEdBQVA7QUFDRDtBQUVEOzs7QUFDQSxRQUFNRyxhQUFOLENBQW9CNUcsSUFBcEIsRUFBa0M2RyxNQUFsQyxFQUFrRDNGLE9BQWxELEVBQXVFO0FBQ3JFLFVBQU07QUFBRTRGLE1BQUFBLEVBQUY7QUFBTTlHLE1BQUFBLElBQUksRUFBRStHLEtBQVo7QUFBbUJDLE1BQUFBO0FBQW5CLFFBQTBDSCxNQUFoRDtBQUFBLFVBQXdDSSxHQUF4Qyw0QkFBZ0RKLE1BQWhEOztBQUNBLFVBQU1LLFdBQVcsR0FBR2xILElBQUksSUFBS2dILFVBQVUsSUFBSUEsVUFBVSxDQUFDaEgsSUFBbEMsSUFBMkMrRyxLQUEvRDs7QUFDQSxRQUFJLENBQUNHLFdBQUwsRUFBa0I7QUFDaEIsWUFBTSxJQUFJOUssS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDs7QUFDRCxVQUFNTSxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCbUMsV0FBOUIsRUFBMkMvRixJQUEzQyxDQUFnRCxHQUFoRCxDQUFaO0FBQ0EsV0FBTyxLQUFLZ0QsT0FBTCxDQUFhO0FBQ2xCZixNQUFBQSxNQUFNLEVBQUUsTUFEVTtBQUVsQjFHLE1BQUFBLEdBRmtCO0FBR2xCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlaUUsR0FBZixDQUhZO0FBSWxCNUQsTUFBQUEsT0FBTyxrQ0FDRG5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCx3QkFBZ0I7QUFGWDtBQUpXLEtBQWIsQ0FBUDtBQVNEO0FBRUQ7OztBQUNBLFFBQU1zRCxlQUFOLENBQXNCM0csSUFBdEIsRUFBb0N3RyxPQUFwQyxFQUF1RHRGLE9BQXZELEVBQTRFO0FBQzFFLFFBQUlzRixPQUFPLENBQUNOLE1BQVIsR0FBaUIsS0FBSzNHLFdBQTFCLEVBQXVDO0FBQ3JDLFlBQU0sSUFBSW5ELEtBQUosQ0FBVSx1Q0FBVixDQUFOO0FBQ0Q7O0FBQ0QsV0FBTyxTQUFRK0osR0FBUixDQUNMLHFCQUFBSyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFNSyxNQUFELElBQ1YsS0FBS0QsYUFBTCxDQUFtQjVHLElBQW5CLEVBQXlCNkcsTUFBekIsRUFBaUMzRixPQUFqQyxFQUEwQ2tGLEtBQTFDLENBQWlEM0ksR0FBRCxJQUFTO0FBQ3ZEO0FBQ0E7QUFDQSxVQUFJeUQsT0FBTyxDQUFDbUYsU0FBUixJQUFxQixDQUFDNUksR0FBRyxDQUFDNkksU0FBOUIsRUFBeUM7QUFDdkMsY0FBTTdJLEdBQU47QUFDRDs7QUFDRCxhQUFPSyxZQUFZLENBQUNMLEdBQUQsQ0FBbkI7QUFDRCxLQVBELENBREssQ0FERixDQUFQO0FBWUQ7QUFFRDs7O0FBQ0EsUUFBTWlKLFdBQU4sQ0FDRTFHLElBREYsRUFFRXdHLE9BRkYsRUFHRXRGLE9BSEYsRUFJeUI7QUFDdkIsUUFBSXNGLE9BQU8sQ0FBQ04sTUFBUixLQUFtQixDQUF2QixFQUEwQjtBQUN4QixhQUFPLFNBQVFpQixPQUFSLENBQWdCLEVBQWhCLENBQVA7QUFDRDs7QUFDRCxRQUFJWCxPQUFPLENBQUNOLE1BQVIsR0FBaUIvSCxhQUFqQixJQUFrQytDLE9BQU8sQ0FBQ2tHLGNBQTlDLEVBQThEO0FBQzVELGFBQU8sQ0FDTCxJQUFJLE1BQU0sS0FBS1YsV0FBTCxDQUNSMUcsSUFEUSxFQUVSLHVCQUFBd0csT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBTyxDQUFQLEVBQVVySSxhQUFWLENBRkMsRUFHUitDLE9BSFEsQ0FBVixDQURLLEVBTUwsSUFBSSxNQUFNLEtBQUt3RixXQUFMLENBQ1IxRyxJQURRLEVBRVIsdUJBQUF3RyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFPckksYUFBUCxDQUZDLEVBR1IrQyxPQUhRLENBQVYsQ0FOSyxDQUFQO0FBWUQ7O0FBQ0QsVUFBTW1HLFFBQVEsR0FBRyxxQkFBQWIsT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBTUssTUFBRCxJQUFZO0FBQ3ZDLFlBQU07QUFBRUMsUUFBQUEsRUFBRjtBQUFNOUcsUUFBQUEsSUFBSSxFQUFFK0csS0FBWjtBQUFtQkMsUUFBQUE7QUFBbkIsVUFBMENILE1BQWhEO0FBQUEsWUFBd0NJLEdBQXhDLDRCQUFnREosTUFBaEQ7O0FBQ0EsWUFBTUssV0FBVyxHQUFHbEgsSUFBSSxJQUFLZ0gsVUFBVSxJQUFJQSxVQUFVLENBQUNoSCxJQUFsQyxJQUEyQytHLEtBQS9EOztBQUNBLFVBQUksQ0FBQ0csV0FBTCxFQUFrQjtBQUNoQixjQUFNLElBQUk5SyxLQUFKLENBQVUsbUNBQVYsQ0FBTjtBQUNEOztBQUNEO0FBQVM0SyxRQUFBQSxVQUFVLEVBQUU7QUFBRWhILFVBQUFBLElBQUksRUFBRWtIO0FBQVI7QUFBckIsU0FBK0NELEdBQS9DO0FBQ0QsS0FQdUIsQ0FBeEI7O0FBUUEsVUFBTXZLLEdBQUcsR0FBRyxDQUFDLEtBQUtxSSxRQUFMLEVBQUQsRUFBa0IsV0FBbEIsRUFBK0IsVUFBL0IsRUFBMkM1RCxJQUEzQyxDQUFnRCxHQUFoRCxDQUFaO0FBQ0EsV0FBTyxLQUFLZ0QsT0FBTCxDQUFhO0FBQ2xCZixNQUFBQSxNQUFNLEVBQUUsTUFEVTtBQUVsQjFHLE1BQUFBLEdBRmtCO0FBR2xCc0csTUFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQ25CcUQsUUFBQUEsU0FBUyxFQUFFbkYsT0FBTyxDQUFDbUYsU0FBUixJQUFxQixLQURiO0FBRW5CRyxRQUFBQSxPQUFPLEVBQUVhO0FBRlUsT0FBZixDQUhZO0FBT2xCaEUsTUFBQUEsT0FBTyxrQ0FDRG5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCx3QkFBZ0I7QUFGWDtBQVBXLEtBQWIsQ0FBUDtBQVlEO0FBRUQ7QUFDRjtBQUNBOzs7QUEwQkU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNFaUUsRUFBQUEsTUFBTSxDQUNKdEgsSUFESSxFQUVKd0csT0FGSSxFQUdKdEYsT0FBbUIsR0FBRyxFQUhsQixFQUlnQztBQUNwQyxXQUFPLGVBQWNzRixPQUFkLElBQ0g7QUFDQSxTQUFLakIsY0FBTCxDQUFvQixFQUFwQixJQUNFLEtBQUtnQyxXQUFMLENBQWlCdkgsSUFBakIsRUFBdUJ3RyxPQUF2QixFQUFnQ3RGLE9BQWhDLENBREYsR0FFRSxLQUFLc0csZUFBTCxDQUFxQnhILElBQXJCLEVBQTJCd0csT0FBM0IsRUFBb0N0RixPQUFwQyxDQUpDLEdBS0gsS0FBS3VHLGFBQUwsQ0FBbUJ6SCxJQUFuQixFQUF5QndHLE9BQXpCLEVBQWtDdEYsT0FBbEMsQ0FMSjtBQU1EO0FBRUQ7OztBQUNBLFFBQU11RyxhQUFOLENBQ0V6SCxJQURGLEVBRUU2RyxNQUZGLEVBR0UzRixPQUhGLEVBSXVCO0FBQ3JCLFVBQU07QUFBRTRGLE1BQUFBLEVBQUUsRUFBRWxLLEVBQU47QUFBVW9ELE1BQUFBLElBQUksRUFBRStHLEtBQWhCO0FBQXVCQyxNQUFBQTtBQUF2QixRQUE4Q0gsTUFBcEQ7QUFBQSxVQUE0Q0ksR0FBNUMsNEJBQW9ESixNQUFwRDs7QUFDQSxRQUFJLENBQUNqSyxFQUFMLEVBQVM7QUFDUCxZQUFNLElBQUlSLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTThLLFdBQVcsR0FBR2xILElBQUksSUFBS2dILFVBQVUsSUFBSUEsVUFBVSxDQUFDaEgsSUFBbEMsSUFBMkMrRyxLQUEvRDs7QUFDQSxRQUFJLENBQUNHLFdBQUwsRUFBa0I7QUFDaEIsWUFBTSxJQUFJOUssS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDs7QUFDRCxVQUFNTSxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCbUMsV0FBOUIsRUFBMkN0SyxFQUEzQyxFQUErQ3VFLElBQS9DLENBQW9ELEdBQXBELENBQVo7QUFDQSxXQUFPLEtBQUtnRCxPQUFMLENBQ0w7QUFDRWYsTUFBQUEsTUFBTSxFQUFFLE9BRFY7QUFFRTFHLE1BQUFBLEdBRkY7QUFHRXNHLE1BQUFBLElBQUksRUFBRSxnQkFBZWlFLEdBQWYsQ0FIUjtBQUlFNUQsTUFBQUEsT0FBTyxrQ0FDRG5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCx3QkFBZ0I7QUFGWDtBQUpULEtBREssRUFVTDtBQUNFcUUsTUFBQUEsaUJBQWlCLEVBQUU7QUFBRTlLLFFBQUFBLEVBQUY7QUFBTW1CLFFBQUFBLE9BQU8sRUFBRSxJQUFmO0FBQXFCQyxRQUFBQSxNQUFNLEVBQUU7QUFBN0I7QUFEckIsS0FWSyxDQUFQO0FBY0Q7QUFFRDs7O0FBQ0EsUUFBTXdKLGVBQU4sQ0FBc0J4SCxJQUF0QixFQUFvQ3dHLE9BQXBDLEVBQXVEdEYsT0FBdkQsRUFBNEU7QUFDMUUsUUFBSXNGLE9BQU8sQ0FBQ04sTUFBUixHQUFpQixLQUFLM0csV0FBMUIsRUFBdUM7QUFDckMsWUFBTSxJQUFJbkQsS0FBSixDQUFVLHVDQUFWLENBQU47QUFDRDs7QUFDRCxXQUFPLFNBQVErSixHQUFSLENBQ0wscUJBQUFLLE9BQU8sTUFBUCxDQUFBQSxPQUFPLEVBQU1LLE1BQUQsSUFDVixLQUFLWSxhQUFMLENBQW1CekgsSUFBbkIsRUFBeUI2RyxNQUF6QixFQUFpQzNGLE9BQWpDLEVBQTBDa0YsS0FBMUMsQ0FBaUQzSSxHQUFELElBQVM7QUFDdkQ7QUFDQTtBQUNBLFVBQUl5RCxPQUFPLENBQUNtRixTQUFSLElBQXFCLENBQUM1SSxHQUFHLENBQUM2SSxTQUE5QixFQUF5QztBQUN2QyxjQUFNN0ksR0FBTjtBQUNEOztBQUNELGFBQU9LLFlBQVksQ0FBQ0wsR0FBRCxDQUFuQjtBQUNELEtBUEQsQ0FESyxDQURGLENBQVA7QUFZRDtBQUVEOzs7QUFDQSxRQUFNOEosV0FBTixDQUNFdkgsSUFERixFQUVFd0csT0FGRixFQUdFdEYsT0FIRixFQUl5QjtBQUN2QixRQUFJc0YsT0FBTyxDQUFDTixNQUFSLEtBQW1CLENBQXZCLEVBQTBCO0FBQ3hCLGFBQU8sRUFBUDtBQUNEOztBQUNELFFBQUlNLE9BQU8sQ0FBQ04sTUFBUixHQUFpQi9ILGFBQWpCLElBQWtDK0MsT0FBTyxDQUFDa0csY0FBOUMsRUFBOEQ7QUFDNUQsYUFBTyxDQUNMLElBQUksTUFBTSxLQUFLRyxXQUFMLENBQ1J2SCxJQURRLEVBRVIsdUJBQUF3RyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFPLENBQVAsRUFBVXJJLGFBQVYsQ0FGQyxFQUdSK0MsT0FIUSxDQUFWLENBREssRUFNTCxJQUFJLE1BQU0sS0FBS3FHLFdBQUwsQ0FDUnZILElBRFEsRUFFUix1QkFBQXdHLE9BQU8sTUFBUCxDQUFBQSxPQUFPLEVBQU9ySSxhQUFQLENBRkMsRUFHUitDLE9BSFEsQ0FBVixDQU5LLENBQVA7QUFZRDs7QUFDRCxVQUFNbUcsUUFBUSxHQUFHLHFCQUFBYixPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFNSyxNQUFELElBQVk7QUFDdkMsWUFBTTtBQUFFQyxRQUFBQSxFQUFFLEVBQUVsSyxFQUFOO0FBQVVvRCxRQUFBQSxJQUFJLEVBQUUrRyxLQUFoQjtBQUF1QkMsUUFBQUE7QUFBdkIsVUFBOENILE1BQXBEO0FBQUEsWUFBNENJLEdBQTVDLDRCQUFvREosTUFBcEQ7O0FBQ0EsVUFBSSxDQUFDakssRUFBTCxFQUFTO0FBQ1AsY0FBTSxJQUFJUixLQUFKLENBQVUsbUNBQVYsQ0FBTjtBQUNEOztBQUNELFlBQU04SyxXQUFXLEdBQUdsSCxJQUFJLElBQUtnSCxVQUFVLElBQUlBLFVBQVUsQ0FBQ2hILElBQWxDLElBQTJDK0csS0FBL0Q7O0FBQ0EsVUFBSSxDQUFDRyxXQUFMLEVBQWtCO0FBQ2hCLGNBQU0sSUFBSTlLLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0Q7QUFBU1EsUUFBQUEsRUFBVDtBQUFhb0ssUUFBQUEsVUFBVSxFQUFFO0FBQUVoSCxVQUFBQSxJQUFJLEVBQUVrSDtBQUFSO0FBQXpCLFNBQW1ERCxHQUFuRDtBQUNELEtBVnVCLENBQXhCOztBQVdBLFVBQU12SyxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFdBQWxCLEVBQStCLFVBQS9CLEVBQTJDNUQsSUFBM0MsQ0FBZ0QsR0FBaEQsQ0FBWjtBQUNBLFdBQU8sS0FBS2dELE9BQUwsQ0FBYTtBQUNsQmYsTUFBQUEsTUFBTSxFQUFFLE9BRFU7QUFFbEIxRyxNQUFBQSxHQUZrQjtBQUdsQnNHLE1BQUFBLElBQUksRUFBRSxnQkFBZTtBQUNuQnFELFFBQUFBLFNBQVMsRUFBRW5GLE9BQU8sQ0FBQ21GLFNBQVIsSUFBcUIsS0FEYjtBQUVuQkcsUUFBQUEsT0FBTyxFQUFFYTtBQUZVLE9BQWYsQ0FIWTtBQU9sQmhFLE1BQUFBLE9BQU8sa0NBQ0RuQyxPQUFPLENBQUNtQyxPQUFSLElBQW1CLEVBRGxCO0FBRUwsd0JBQWdCO0FBRlg7QUFQVyxLQUFiLENBQVA7QUFZRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBK0JFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0UsUUFBTXNFLE1BQU4sQ0FDRTNILElBREYsRUFFRXdHLE9BRkYsRUFHRW9CLFVBSEYsRUFJRTFHLE9BQW1CLEdBQUcsRUFKeEIsRUFLc0M7QUFDcEMsVUFBTTJHLE9BQU8sR0FBRyxlQUFjckIsT0FBZCxDQUFoQjs7QUFDQSxVQUFNYSxRQUFRLEdBQUcsZUFBY2IsT0FBZCxJQUF5QkEsT0FBekIsR0FBbUMsQ0FBQ0EsT0FBRCxDQUFwRDs7QUFDQSxRQUFJYSxRQUFRLENBQUNuQixNQUFULEdBQWtCLEtBQUszRyxXQUEzQixFQUF3QztBQUN0QyxZQUFNLElBQUluRCxLQUFKLENBQVUsdUNBQVYsQ0FBTjtBQUNEOztBQUNELFVBQU0wTCxPQUFPLEdBQUcsTUFBTSxTQUFRM0IsR0FBUixDQUNwQixxQkFBQWtCLFFBQVEsTUFBUixDQUFBQSxRQUFRLEVBQU1SLE1BQUQsSUFBWTtBQUFBOztBQUN2QixZQUFNO0FBQUUsU0FBQ2UsVUFBRCxHQUFjRyxLQUFoQjtBQUF1Qi9ILFFBQUFBLElBQUksRUFBRStHLEtBQTdCO0FBQW9DQyxRQUFBQTtBQUFwQyxVQUEyREgsTUFBakU7QUFBQSxZQUF5REksR0FBekQsNEJBQWlFSixNQUFqRSxvQ0FBU2UsVUFBVDs7QUFDQSxZQUFNbEwsR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4Qi9FLElBQTlCLEVBQW9DNEgsVUFBcEMsRUFBZ0RHLEtBQWhELEVBQXVENUcsSUFBdkQsQ0FDVixHQURVLENBQVo7QUFHQSxhQUFPLEtBQUtnRCxPQUFMLENBQ0w7QUFDRWYsUUFBQUEsTUFBTSxFQUFFLE9BRFY7QUFFRTFHLFFBQUFBLEdBRkY7QUFHRXNHLFFBQUFBLElBQUksRUFBRSxnQkFBZWlFLEdBQWYsQ0FIUjtBQUlFNUQsUUFBQUEsT0FBTyxrQ0FDRG5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCwwQkFBZ0I7QUFGWDtBQUpULE9BREssRUFVTDtBQUNFcUUsUUFBQUEsaUJBQWlCLEVBQUU7QUFBRTNKLFVBQUFBLE9BQU8sRUFBRSxJQUFYO0FBQWlCQyxVQUFBQSxNQUFNLEVBQUU7QUFBekI7QUFEckIsT0FWSyxFQWFMb0ksS0FiSyxDQWFFM0ksR0FBRCxJQUFTO0FBQ2Y7QUFDQTtBQUNBO0FBQ0EsWUFBSSxDQUFDb0ssT0FBRCxJQUFZM0csT0FBTyxDQUFDbUYsU0FBcEIsSUFBaUMsQ0FBQzVJLEdBQUcsQ0FBQzZJLFNBQTFDLEVBQXFEO0FBQ25ELGdCQUFNN0ksR0FBTjtBQUNEOztBQUNELGVBQU9LLFlBQVksQ0FBQ0wsR0FBRCxDQUFuQjtBQUNELE9BckJNLENBQVA7QUFzQkQsS0EzQk8sQ0FEWSxDQUF0QjtBQThCQSxXQUFPb0ssT0FBTyxHQUFHQyxPQUFILEdBQWFBLE9BQU8sQ0FBQyxDQUFELENBQWxDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQWdCRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0UsUUFBTTdJLE9BQU4sQ0FDRWUsSUFERixFQUVFNkYsR0FGRixFQUdFM0UsT0FBbUIsR0FBRyxFQUh4QixFQUlzQztBQUNwQyxXQUFPLGVBQWMyRSxHQUFkLElBQ0g7QUFDQSxTQUFLTixjQUFMLENBQW9CLEVBQXBCLElBQ0UsS0FBS3lDLFlBQUwsQ0FBa0JoSSxJQUFsQixFQUF3QjZGLEdBQXhCLEVBQTZCM0UsT0FBN0IsQ0FERixHQUVFLEtBQUsrRyxnQkFBTCxDQUFzQmpJLElBQXRCLEVBQTRCNkYsR0FBNUIsRUFBaUMzRSxPQUFqQyxDQUpDLEdBS0gsS0FBS2dILGNBQUwsQ0FBb0JsSSxJQUFwQixFQUEwQjZGLEdBQTFCLEVBQStCM0UsT0FBL0IsQ0FMSjtBQU1EO0FBRUQ7OztBQUNBLFFBQU1nSCxjQUFOLENBQ0VsSSxJQURGLEVBRUVwRCxFQUZGLEVBR0VzRSxPQUhGLEVBSXVCO0FBQ3JCLFVBQU14RSxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCL0UsSUFBOUIsRUFBb0NwRCxFQUFwQyxFQUF3Q3VFLElBQXhDLENBQTZDLEdBQTdDLENBQVo7QUFDQSxXQUFPLEtBQUtnRCxPQUFMLENBQ0w7QUFDRWYsTUFBQUEsTUFBTSxFQUFFLFFBRFY7QUFFRTFHLE1BQUFBLEdBRkY7QUFHRTJHLE1BQUFBLE9BQU8sRUFBRW5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUI7QUFIOUIsS0FESyxFQU1MO0FBQ0VxRSxNQUFBQSxpQkFBaUIsRUFBRTtBQUFFOUssUUFBQUEsRUFBRjtBQUFNbUIsUUFBQUEsT0FBTyxFQUFFLElBQWY7QUFBcUJDLFFBQUFBLE1BQU0sRUFBRTtBQUE3QjtBQURyQixLQU5LLENBQVA7QUFVRDtBQUVEOzs7QUFDQSxRQUFNaUssZ0JBQU4sQ0FBdUJqSSxJQUF2QixFQUFxQzZGLEdBQXJDLEVBQW9EM0UsT0FBcEQsRUFBeUU7QUFDdkUsUUFBSTJFLEdBQUcsQ0FBQ0ssTUFBSixHQUFhLEtBQUszRyxXQUF0QixFQUFtQztBQUNqQyxZQUFNLElBQUluRCxLQUFKLENBQVUsdUNBQVYsQ0FBTjtBQUNEOztBQUNELFdBQU8sU0FBUStKLEdBQVIsQ0FDTCxxQkFBQU4sR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBTWpKLEVBQUQsSUFDTixLQUFLc0wsY0FBTCxDQUFvQmxJLElBQXBCLEVBQTBCcEQsRUFBMUIsRUFBOEJzRSxPQUE5QixFQUF1Q2tGLEtBQXZDLENBQThDM0ksR0FBRCxJQUFTO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBLFVBQUl5RCxPQUFPLENBQUNtRixTQUFSLElBQXFCLENBQUM1SSxHQUFHLENBQUM2SSxTQUE5QixFQUF5QztBQUN2QyxjQUFNN0ksR0FBTjtBQUNEOztBQUNELGFBQU9LLFlBQVksQ0FBQ0wsR0FBRCxDQUFuQjtBQUNELEtBUkQsQ0FEQyxDQURFLENBQVA7QUFhRDtBQUVEOzs7QUFDQSxRQUFNdUssWUFBTixDQUNFaEksSUFERixFQUVFNkYsR0FGRixFQUdFM0UsT0FIRixFQUl5QjtBQUN2QixRQUFJMkUsR0FBRyxDQUFDSyxNQUFKLEtBQWUsQ0FBbkIsRUFBc0I7QUFDcEIsYUFBTyxFQUFQO0FBQ0Q7O0FBQ0QsUUFBSUwsR0FBRyxDQUFDSyxNQUFKLEdBQWEvSCxhQUFiLElBQThCK0MsT0FBTyxDQUFDa0csY0FBMUMsRUFBMEQ7QUFDeEQsYUFBTyxDQUNMLElBQUksTUFBTSxLQUFLWSxZQUFMLENBQ1JoSSxJQURRLEVBRVIsdUJBQUE2RixHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFPLENBQVAsRUFBVTFILGFBQVYsQ0FGSyxFQUdSK0MsT0FIUSxDQUFWLENBREssRUFNTCxJQUFJLE1BQU0sS0FBSzhHLFlBQUwsQ0FBa0JoSSxJQUFsQixFQUF3Qix1QkFBQTZGLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQU8xSCxhQUFQLENBQTNCLEVBQWtEK0MsT0FBbEQsQ0FBVixDQU5LLENBQVA7QUFRRDs7QUFDRCxRQUFJeEUsR0FBRyxHQUNMLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixXQUFsQixFQUErQixlQUEvQixFQUFnRDVELElBQWhELENBQXFELEdBQXJELElBQTREMEUsR0FBRyxDQUFDMUUsSUFBSixDQUFTLEdBQVQsQ0FEOUQ7O0FBRUEsUUFBSUQsT0FBTyxDQUFDbUYsU0FBWixFQUF1QjtBQUNyQjNKLE1BQUFBLEdBQUcsSUFBSSxpQkFBUDtBQUNEOztBQUNELFdBQU8sS0FBS3lILE9BQUwsQ0FBYTtBQUNsQmYsTUFBQUEsTUFBTSxFQUFFLFFBRFU7QUFFbEIxRyxNQUFBQSxHQUZrQjtBQUdsQjJHLE1BQUFBLE9BQU8sRUFBRW5DLE9BQU8sQ0FBQ21DLE9BQVIsSUFBbUI7QUFIVixLQUFiLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBUUU7QUFDRjtBQUNBO0FBQ0UsUUFBTXBELFFBQU4sQ0FBZUQsSUFBZixFQUE2RDtBQUMzRCxVQUFNdEQsR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4Qi9FLElBQTlCLEVBQW9DLFVBQXBDLEVBQWdEbUIsSUFBaEQsQ0FBcUQsR0FBckQsQ0FBWjtBQUNBLFVBQU02QixJQUFJLEdBQUcsTUFBTSxLQUFLbUIsT0FBTCxDQUFhekgsR0FBYixDQUFuQjtBQUNBLFdBQU9zRyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1yQyxjQUFOLEdBQXVCO0FBQ3JCLFVBQU1qRSxHQUFHLEdBQUksR0FBRSxLQUFLcUksUUFBTCxFQUFnQixXQUEvQjtBQUNBLFVBQU0vQixJQUFJLEdBQUcsTUFBTSxLQUFLbUIsT0FBTCxDQUFhekgsR0FBYixDQUFuQjtBQUNBLFdBQU9zRyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUdFYixFQUFBQSxPQUFPLENBQTRCbkMsSUFBNUIsRUFBNkQ7QUFDbEUsVUFBTWtDLEVBQUUsR0FDTCxLQUFLTixRQUFMLENBQWM1QixJQUFkLENBQUQsSUFDQSxJQUFJakYsT0FBSixDQUFZLElBQVosRUFBa0JpRixJQUFsQixDQUZGO0FBR0EsU0FBSzRCLFFBQUwsQ0FBYzVCLElBQWQsSUFBMkJrQyxFQUEzQjtBQUNBLFdBQU9BLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTWlHLFFBQU4sQ0FBZWpILE9BQWlELEdBQUcsRUFBbkUsRUFBdUU7QUFDckUsUUFBSXhFLEdBQUcsR0FBRyxLQUFLUyxRQUFMLElBQWlCLEtBQUtBLFFBQUwsQ0FBY1QsR0FBekM7O0FBQ0EsUUFBSSxDQUFDQSxHQUFMLEVBQVU7QUFDUixZQUFNTyxHQUFHLEdBQUcsTUFBTSxLQUFLa0gsT0FBTCxDQUFtQztBQUNuRGYsUUFBQUEsTUFBTSxFQUFFLEtBRDJDO0FBRW5EMUcsUUFBQUEsR0FBRyxFQUFFLEtBQUtxSSxRQUFMLEVBRjhDO0FBR25EMUIsUUFBQUEsT0FBTyxFQUFFbkMsT0FBTyxDQUFDbUM7QUFIa0MsT0FBbkMsQ0FBbEI7QUFLQTNHLE1BQUFBLEdBQUcsR0FBR08sR0FBRyxDQUFDa0wsUUFBVjtBQUNEOztBQUNEekwsSUFBQUEsR0FBRyxJQUFJLGNBQVA7O0FBQ0EsUUFBSSxLQUFLWSxXQUFULEVBQXNCO0FBQ3BCWixNQUFBQSxHQUFHLElBQUssZ0JBQWUwSSxrQkFBa0IsQ0FBQyxLQUFLOUgsV0FBTixDQUFtQixFQUE1RDtBQUNEOztBQUNELFVBQU1MLEdBQUcsR0FBRyxNQUFNLEtBQUtrSCxPQUFMLENBQTJCO0FBQUVmLE1BQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCMUcsTUFBQUE7QUFBakIsS0FBM0IsQ0FBbEI7QUFDQSxTQUFLUyxRQUFMLEdBQWdCO0FBQ2RQLE1BQUFBLEVBQUUsRUFBRUssR0FBRyxDQUFDbUwsT0FETTtBQUVkekwsTUFBQUEsY0FBYyxFQUFFTSxHQUFHLENBQUNvTCxlQUZOO0FBR2QzTCxNQUFBQSxHQUFHLEVBQUVPLEdBQUcsQ0FBQ0w7QUFISyxLQUFoQjtBQUtBLFdBQU9LLEdBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTXFMLE1BQU4sQ0FBYXRJLElBQWIsRUFBcUN5RSxLQUFyQyxFQUFxRDtBQUNuRDtBQUNBLFFBQUksT0FBT3pFLElBQVAsS0FBZ0IsUUFBcEIsRUFBOEI7QUFDNUJ5RSxNQUFBQSxLQUFLLEdBQUd6RSxJQUFSO0FBQ0FBLE1BQUFBLElBQUksR0FBR3hDLFNBQVA7QUFDRDs7QUFDRCxRQUFJZCxHQUFKOztBQUNBLFFBQUlzRCxJQUFKLEVBQVU7QUFDUnRELE1BQUFBLEdBQUcsR0FBRyxDQUFDLEtBQUtxSSxRQUFMLEVBQUQsRUFBa0IsVUFBbEIsRUFBOEIvRSxJQUE5QixFQUFvQ21CLElBQXBDLENBQXlDLEdBQXpDLENBQU47QUFDQSxZQUFNO0FBQUVvSCxRQUFBQTtBQUFGLFVBQWtCLE1BQU0sS0FBS3BFLE9BQUwsQ0FDNUJ6SCxHQUQ0QixDQUE5QjtBQUdBLGFBQU8rSCxLQUFLLEdBQUcsdUJBQUE4RCxXQUFXLE1BQVgsQ0FBQUEsV0FBVyxFQUFPLENBQVAsRUFBVTlELEtBQVYsQ0FBZCxHQUFpQzhELFdBQTdDO0FBQ0Q7O0FBQ0Q3TCxJQUFBQSxHQUFHLEdBQUksR0FBRSxLQUFLcUksUUFBTCxFQUFnQixTQUF6Qjs7QUFDQSxRQUFJTixLQUFKLEVBQVc7QUFDVC9ILE1BQUFBLEdBQUcsSUFBSyxVQUFTK0gsS0FBTSxFQUF2QjtBQUNEOztBQUNELFdBQU8sS0FBS04sT0FBTCxDQUF1QnpILEdBQXZCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTThMLE9BQU4sQ0FDRXhJLElBREYsRUFFRXlJLEtBRkYsRUFHRUMsR0FIRixFQUkwQjtBQUN4QjtBQUNBLFFBQUloTSxHQUFHLEdBQUcsQ0FBQyxLQUFLcUksUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCL0UsSUFBOUIsRUFBb0MsU0FBcEMsRUFBK0NtQixJQUEvQyxDQUFvRCxHQUFwRCxDQUFWOztBQUNBLFFBQUksT0FBT3NILEtBQVAsS0FBaUIsUUFBckIsRUFBK0I7QUFDN0JBLE1BQUFBLEtBQUssR0FBRyxJQUFJRSxJQUFKLENBQVNGLEtBQVQsQ0FBUjtBQUNEOztBQUNEQSxJQUFBQSxLQUFLLEdBQUd2TixVQUFVLENBQUN1TixLQUFELENBQWxCO0FBQ0EvTCxJQUFBQSxHQUFHLElBQUssVUFBUzBJLGtCQUFrQixDQUFDcUQsS0FBRCxDQUFRLEVBQTNDOztBQUNBLFFBQUksT0FBT0MsR0FBUCxLQUFlLFFBQW5CLEVBQTZCO0FBQzNCQSxNQUFBQSxHQUFHLEdBQUcsSUFBSUMsSUFBSixDQUFTRCxHQUFULENBQU47QUFDRDs7QUFDREEsSUFBQUEsR0FBRyxHQUFHeE4sVUFBVSxDQUFDd04sR0FBRCxDQUFoQjtBQUNBaE0sSUFBQUEsR0FBRyxJQUFLLFFBQU8wSSxrQkFBa0IsQ0FBQ3NELEdBQUQsQ0FBTSxFQUF2QztBQUNBLFVBQU0xRixJQUFJLEdBQUcsTUFBTSxLQUFLbUIsT0FBTCxDQUFhekgsR0FBYixDQUFuQjtBQUNBLFdBQU9zRyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU00RixPQUFOLENBQ0U1SSxJQURGLEVBRUV5SSxLQUZGLEVBR0VDLEdBSEYsRUFJMEI7QUFDeEI7QUFDQSxRQUFJaE0sR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4Qi9FLElBQTlCLEVBQW9DLFNBQXBDLEVBQStDbUIsSUFBL0MsQ0FBb0QsR0FBcEQsQ0FBVjs7QUFDQSxRQUFJLE9BQU9zSCxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzdCQSxNQUFBQSxLQUFLLEdBQUcsSUFBSUUsSUFBSixDQUFTRixLQUFULENBQVI7QUFDRDs7QUFDREEsSUFBQUEsS0FBSyxHQUFHdk4sVUFBVSxDQUFDdU4sS0FBRCxDQUFsQjtBQUNBL0wsSUFBQUEsR0FBRyxJQUFLLFVBQVMwSSxrQkFBa0IsQ0FBQ3FELEtBQUQsQ0FBUSxFQUEzQzs7QUFFQSxRQUFJLE9BQU9DLEdBQVAsS0FBZSxRQUFuQixFQUE2QjtBQUMzQkEsTUFBQUEsR0FBRyxHQUFHLElBQUlDLElBQUosQ0FBU0QsR0FBVCxDQUFOO0FBQ0Q7O0FBQ0RBLElBQUFBLEdBQUcsR0FBR3hOLFVBQVUsQ0FBQ3dOLEdBQUQsQ0FBaEI7QUFDQWhNLElBQUFBLEdBQUcsSUFBSyxRQUFPMEksa0JBQWtCLENBQUNzRCxHQUFELENBQU0sRUFBdkM7QUFDQSxVQUFNMUYsSUFBSSxHQUFHLE1BQU0sS0FBS21CLE9BQUwsQ0FBYXpILEdBQWIsQ0FBbkI7QUFDQSxXQUFPc0csSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNNkYsSUFBTixHQUFxQztBQUNuQyxVQUFNbk0sR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixNQUFsQixFQUEwQjVELElBQTFCLENBQStCLEdBQS9CLENBQVo7QUFDQSxVQUFNNkIsSUFBSSxHQUFHLE1BQU0sS0FBS21CLE9BQUwsQ0FBYXpILEdBQWIsQ0FBbkI7QUFDQSxXQUFPc0csSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNOEYsTUFBTixHQUFnRDtBQUM5QyxVQUFNcE0sR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixRQUFsQixFQUE0QjVELElBQTVCLENBQWlDLEdBQWpDLENBQVo7QUFDQSxVQUFNNkIsSUFBSSxHQUFHLE1BQU0sS0FBS21CLE9BQUwsQ0FBYXpILEdBQWIsQ0FBbkI7QUFDQSxXQUFPc0csSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNK0YsS0FBTixHQUFzQztBQUNwQyxVQUFNck0sR0FBRyxHQUFHLENBQUMsS0FBS3FJLFFBQUwsRUFBRCxFQUFrQixPQUFsQixFQUEyQjVELElBQTNCLENBQWdDLEdBQWhDLENBQVo7QUFDQSxVQUFNNkIsSUFBSSxHQUFHLE1BQU0sS0FBS21CLE9BQUwsQ0FBYXpILEdBQWIsQ0FBbkI7QUFDQSxXQUFPc0csSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNZ0csWUFBTixHQUEyRDtBQUN6RCxVQUFNaEcsSUFBSSxHQUFHLE1BQU0sS0FBS21CLE9BQUwsQ0FBYSxlQUFiLENBQW5CO0FBQ0EsV0FBT25CLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VpRyxFQUFBQSxXQUFXLENBQUNDLFVBQUQsRUFBcUM7QUFDOUMsV0FBTyxJQUFJbE8sV0FBSixDQUFnQixJQUFoQixFQUF1QixpQkFBZ0JrTyxVQUFXLEVBQWxELENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBbnpDd0U7O2dCQUEzRDlLLFUsYUFDTTNELFNBQVMsQ0FBQyxZQUFELEM7O0FBc3pDNUIsZUFBZTJELFVBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQganNmb3JjZSBmcm9tICcuL2pzZm9yY2UnO1xuaW1wb3J0IHtcbiAgSHR0cFJlcXVlc3QsXG4gIEh0dHBSZXNwb25zZSxcbiAgQ2FsbGJhY2ssXG4gIFJlY29yZCxcbiAgU2F2ZVJlc3VsdCxcbiAgVXBzZXJ0UmVzdWx0LFxuICBEZXNjcmliZUdsb2JhbFJlc3VsdCxcbiAgRGVzY3JpYmVTT2JqZWN0UmVzdWx0LFxuICBEZXNjcmliZVRhYixcbiAgRGVzY3JpYmVUaGVtZSxcbiAgRGVzY3JpYmVRdWlja0FjdGlvblJlc3VsdCxcbiAgVXBkYXRlZFJlc3VsdCxcbiAgRGVsZXRlZFJlc3VsdCxcbiAgU2VhcmNoUmVzdWx0LFxuICBPcmdhbml6YXRpb25MaW1pdHNJbmZvLFxuICBPcHRpb25hbCxcbiAgU2lnbmVkUmVxdWVzdE9iamVjdCxcbiAgU2F2ZUVycm9yLFxuICBEbWxPcHRpb25zLFxuICBSZXRyaWV2ZU9wdGlvbnMsXG4gIFNjaGVtYSxcbiAgU09iamVjdE5hbWVzLFxuICBTT2JqZWN0SW5wdXRSZWNvcmQsXG4gIFNPYmplY3RVcGRhdGVSZWNvcmQsXG4gIFNPYmplY3RGaWVsZE5hbWVzLFxuICBVc2VySW5mbyxcbiAgSWRlbnRpdHlJbmZvLFxuICBMaW1pdEluZm8sXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgU3RyZWFtUHJvbWlzZSB9IGZyb20gJy4vdXRpbC9wcm9taXNlJztcbmltcG9ydCBUcmFuc3BvcnQsIHtcbiAgQ2FudmFzVHJhbnNwb3J0LFxuICBYZFByb3h5VHJhbnNwb3J0LFxuICBIdHRwUHJveHlUcmFuc3BvcnQsXG59IGZyb20gJy4vdHJhbnNwb3J0JztcbmltcG9ydCB7IExvZ2dlciwgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQgeyBMb2dMZXZlbENvbmZpZyB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IE9BdXRoMiwgeyBUb2tlblJlc3BvbnNlIH0gZnJvbSAnLi9vYXV0aDInO1xuaW1wb3J0IHsgT0F1dGgyQ29uZmlnIH0gZnJvbSAnLi9vYXV0aDInO1xuaW1wb3J0IENhY2hlLCB7IENhY2hlZEZ1bmN0aW9uIH0gZnJvbSAnLi9jYWNoZSc7XG5pbXBvcnQgSHR0cEFwaSBmcm9tICcuL2h0dHAtYXBpJztcbmltcG9ydCBTZXNzaW9uUmVmcmVzaERlbGVnYXRlLCB7XG4gIFNlc3Npb25SZWZyZXNoRnVuYyxcbn0gZnJvbSAnLi9zZXNzaW9uLXJlZnJlc2gtZGVsZWdhdGUnO1xuaW1wb3J0IFF1ZXJ5IGZyb20gJy4vcXVlcnknO1xuaW1wb3J0IHsgUXVlcnlPcHRpb25zIH0gZnJvbSAnLi9xdWVyeSc7XG5pbXBvcnQgU09iamVjdCBmcm9tICcuL3NvYmplY3QnO1xuaW1wb3J0IFF1aWNrQWN0aW9uIGZyb20gJy4vcXVpY2stYWN0aW9uJztcbmltcG9ydCBQcm9jZXNzIGZyb20gJy4vcHJvY2Vzcyc7XG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi91dGlsL2Zvcm1hdHRlcic7XG5pbXBvcnQgQW5hbHl0aWNzIGZyb20gJy4vYXBpL2FuYWx5dGljcyc7XG5pbXBvcnQgQXBleCBmcm9tICcuL2FwaS9hcGV4JztcbmltcG9ydCB7IEJ1bGssIEJ1bGtWMiB9IGZyb20gJy4vYXBpL2J1bGsnO1xuaW1wb3J0IENoYXR0ZXIgZnJvbSAnLi9hcGkvY2hhdHRlcic7XG5pbXBvcnQgTWV0YWRhdGEgZnJvbSAnLi9hcGkvbWV0YWRhdGEnO1xuaW1wb3J0IFNvYXBBcGkgZnJvbSAnLi9hcGkvc29hcCc7XG5pbXBvcnQgU3RyZWFtaW5nIGZyb20gJy4vYXBpL3N0cmVhbWluZyc7XG5pbXBvcnQgVG9vbGluZyBmcm9tICcuL2FwaS90b29saW5nJztcbmltcG9ydCB7IEp3dE9BdXRoMkNvbmZpZywgSnd0T0F1dGgyIH0gZnJvbSAnLi9qd3RPQXV0aDInO1xuXG4vKipcbiAqIHR5cGUgZGVmaW5pdGlvbnNcbiAqL1xuZXhwb3J0IHR5cGUgQ29ubmVjdGlvbkNvbmZpZzxTIGV4dGVuZHMgU2NoZW1hID0gU2NoZW1hPiA9IHtcbiAgdmVyc2lvbj86IHN0cmluZztcbiAgbG9naW5Vcmw/OiBzdHJpbmc7XG4gIGFjY2Vzc1Rva2VuPzogc3RyaW5nO1xuICByZWZyZXNoVG9rZW4/OiBzdHJpbmc7XG4gIGluc3RhbmNlVXJsPzogc3RyaW5nO1xuICBzZXNzaW9uSWQ/OiBzdHJpbmc7XG4gIHNlcnZlclVybD86IHN0cmluZztcbiAgc2lnbmVkUmVxdWVzdD86IHN0cmluZztcbiAgb2F1dGgyPzogT0F1dGgyIHwgT0F1dGgyQ29uZmlnO1xuICBqd3RPQXV0aDI/OiBKd3RPQXV0aDIgfCBKd3RPQXV0aDJDb25maWc7XG4gIG1heFJlcXVlc3Q/OiBudW1iZXI7XG4gIHByb3h5VXJsPzogc3RyaW5nO1xuICBodHRwUHJveHk/OiBzdHJpbmc7XG4gIGxvZ0xldmVsPzogTG9nTGV2ZWxDb25maWc7XG4gIGNhbGxPcHRpb25zPzogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH07XG4gIHJlZnJlc2hGbj86IFNlc3Npb25SZWZyZXNoRnVuYzxTPjtcbn07XG5cbmV4cG9ydCB0eXBlIENvbm5lY3Rpb25Fc3RhYmxpc2hPcHRpb25zID0ge1xuICBhY2Nlc3NUb2tlbj86IE9wdGlvbmFsPHN0cmluZz47XG4gIHJlZnJlc2hUb2tlbj86IE9wdGlvbmFsPHN0cmluZz47XG4gIGluc3RhbmNlVXJsPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2Vzc2lvbklkPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2VydmVyVXJsPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2lnbmVkUmVxdWVzdD86IE9wdGlvbmFsPHN0cmluZyB8IFNpZ25lZFJlcXVlc3RPYmplY3Q+O1xuICB1c2VySW5mbz86IE9wdGlvbmFsPFVzZXJJbmZvPjtcbn07XG5cbi8qKlxuICpcbiAqL1xuY29uc3QgZGVmYXVsdENvbm5lY3Rpb25Db25maWc6IHtcbiAgbG9naW5Vcmw6IHN0cmluZztcbiAgaW5zdGFuY2VVcmw6IHN0cmluZztcbiAgdmVyc2lvbjogc3RyaW5nO1xuICBsb2dMZXZlbDogTG9nTGV2ZWxDb25maWc7XG4gIG1heFJlcXVlc3Q6IG51bWJlcjtcbn0gPSB7XG4gIGxvZ2luVXJsOiAnaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbScsXG4gIGluc3RhbmNlVXJsOiAnJyxcbiAgdmVyc2lvbjogJzUwLjAnLFxuICBsb2dMZXZlbDogJ05PTkUnLFxuICBtYXhSZXF1ZXN0OiAxMCxcbn07XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZXNjKHN0cjogT3B0aW9uYWw8c3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiBTdHJpbmcoc3RyIHx8ICcnKVxuICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAucmVwbGFjZSgvXCIvZywgJyZxdW90OycpO1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHBhcnNlU2lnbmVkUmVxdWVzdChzcjogc3RyaW5nIHwgT2JqZWN0KTogU2lnbmVkUmVxdWVzdE9iamVjdCB7XG4gIGlmICh0eXBlb2Ygc3IgPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKHNyWzBdID09PSAneycpIHtcbiAgICAgIC8vIG1pZ2h0IGJlIEpTT05cbiAgICAgIHJldHVybiBKU09OLnBhcnNlKHNyKTtcbiAgICB9IC8vIG1pZ2h0IGJlIG9yaWdpbmFsIGJhc2U2NC1lbmNvZGVkIHNpZ25lZCByZXF1ZXN0XG4gICAgY29uc3QgbXNnID0gc3Iuc3BsaXQoJy4nKS5wb3AoKTsgLy8gcmV0cmlldmUgbGF0dGVyIHBhcnRcbiAgICBpZiAoIW1zZykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHNpZ25lZCByZXF1ZXN0Jyk7XG4gICAgfVxuICAgIGNvbnN0IGpzb24gPSBCdWZmZXIuZnJvbShtc2csICdiYXNlNjQnKS50b1N0cmluZygndXRmLTgnKTtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShqc29uKTtcbiAgfVxuICByZXR1cm4gc3IgYXMgU2lnbmVkUmVxdWVzdE9iamVjdDtcbn1cblxuLyoqIEBwcml2YXRlICoqL1xuZnVuY3Rpb24gcGFyc2VJZFVybCh1cmw6IHN0cmluZykge1xuICBjb25zdCBbb3JnYW5pemF0aW9uSWQsIGlkXSA9IHVybC5zcGxpdCgnLycpLnNsaWNlKC0yKTtcbiAgcmV0dXJuIHsgaWQsIG9yZ2FuaXphdGlvbklkLCB1cmwgfTtcbn1cblxuLyoqXG4gKiBTZXNzaW9uIFJlZnJlc2ggZGVsZWdhdGUgZnVuY3Rpb24gZm9yIE9BdXRoMiBhdXRoeiBjb2RlIGZsb3dcbiAqIEBwcml2YXRlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIG9hdXRoUmVmcmVzaEZuPFMgZXh0ZW5kcyBTY2hlbWE+KFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikge1xuICB0cnkge1xuICAgIGlmICghY29ubi5yZWZyZXNoVG9rZW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gcmVmcmVzaCB0b2tlbiBmb3VuZCBpbiB0aGUgY29ubmVjdGlvbicpO1xuICAgIH1cbiAgICBjb25zdCByZXMgPSBhd2FpdCBjb25uLm9hdXRoMi5yZWZyZXNoVG9rZW4oY29ubi5yZWZyZXNoVG9rZW4pO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gcGFyc2VJZFVybChyZXMuaWQpO1xuICAgIGNvbm4uX2VzdGFibGlzaCh7XG4gICAgICBpbnN0YW5jZVVybDogcmVzLmluc3RhbmNlX3VybCxcbiAgICAgIGFjY2Vzc1Rva2VuOiByZXMuYWNjZXNzX3Rva2VuLFxuICAgICAgdXNlckluZm8sXG4gICAgfSk7XG4gICAgY2FsbGJhY2sodW5kZWZpbmVkLCByZXMuYWNjZXNzX3Rva2VuLCByZXMpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBTZXNzaW9uIFJlZnJlc2ggZGVsZWdhdGUgZnVuY3Rpb24gZm9yIHVzZXJuYW1lL3Bhc3N3b3JkIGxvZ2luXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuPFMgZXh0ZW5kcyBTY2hlbWE+KFxuICB1c2VybmFtZTogc3RyaW5nLFxuICBwYXNzd29yZDogc3RyaW5nLFxuKSB7XG4gIHJldHVybiBhc3luYyAoXG4gICAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbiAgKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNvbm4ubG9naW4odXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgIGlmICghY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FjY2VzcyB0b2tlbiBub3QgZm91bmQgYWZ0ZXIgbG9naW4nKTtcbiAgICAgIH1cbiAgICAgIGNhbGxiYWNrKG51bGwsIGNvbm4uYWNjZXNzVG9rZW4pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIHRvU2F2ZVJlc3VsdChlcnI6IFNhdmVFcnJvcik6IFNhdmVSZXN1bHQge1xuICByZXR1cm4ge1xuICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgIGVycm9yczogW2Vycl0sXG4gIH07XG59XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gcmFpc2VOb01vZHVsZUVycm9yKG5hbWU6IHN0cmluZyk6IG5ldmVyIHtcbiAgdGhyb3cgbmV3IEVycm9yKFxuICAgIGBBUEkgbW9kdWxlICcke25hbWV9JyBpcyBub3QgbG9hZGVkLCBsb2FkICdqc2ZvcmNlL2FwaS8ke25hbWV9JyBleHBsaWNpdGx5YCxcbiAgKTtcbn1cblxuLypcbiAqIENvbnN0YW50IG9mIG1heGltdW0gcmVjb3JkcyBudW0gaW4gRE1MIG9wZXJhdGlvbiAodXBkYXRlL2RlbGV0ZSlcbiAqL1xuY29uc3QgTUFYX0RNTF9DT1VOVCA9IDIwMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQ29ubmVjdGlvbjxTIGV4dGVuZHMgU2NoZW1hID0gU2NoZW1hPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHN0YXRpYyBfbG9nZ2VyID0gZ2V0TG9nZ2VyKCdjb25uZWN0aW9uJyk7XG5cbiAgdmVyc2lvbjogc3RyaW5nO1xuICBsb2dpblVybDogc3RyaW5nO1xuICBpbnN0YW5jZVVybDogc3RyaW5nO1xuICBhY2Nlc3NUb2tlbjogT3B0aW9uYWw8c3RyaW5nPjtcbiAgcmVmcmVzaFRva2VuOiBPcHRpb25hbDxzdHJpbmc+O1xuICB1c2VySW5mbzogT3B0aW9uYWw8VXNlckluZm8+O1xuICBsaW1pdEluZm86IExpbWl0SW5mbyA9IHt9O1xuICBvYXV0aDI6IE9BdXRoMjtcbiAgc29iamVjdHM6IHsgW04gaW4gU09iamVjdE5hbWVzPFM+XT86IFNPYmplY3Q8UywgTj4gfSA9IHt9O1xuICBjYWNoZTogQ2FjaGU7XG4gIF9jYWxsT3B0aW9uczogT3B0aW9uYWw8eyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH0+O1xuICBfbWF4UmVxdWVzdDogbnVtYmVyO1xuICBfbG9nZ2VyOiBMb2dnZXI7XG4gIF9sb2dMZXZlbDogT3B0aW9uYWw8TG9nTGV2ZWxDb25maWc+O1xuICBfdHJhbnNwb3J0OiBUcmFuc3BvcnQ7XG4gIF9zZXNzaW9uVHlwZTogT3B0aW9uYWw8J3NvYXAnIHwgJ29hdXRoMic+O1xuICBfcmVmcmVzaERlbGVnYXRlOiBPcHRpb25hbDxTZXNzaW9uUmVmcmVzaERlbGVnYXRlPFM+PjtcblxuICAvLyBkZXNjcmliZTogKG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICBkZXNjcmliZSQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IFByb21pc2U8RGVzY3JpYmVTT2JqZWN0UmVzdWx0Pj47XG4gIGRlc2NyaWJlJCQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IERlc2NyaWJlU09iamVjdFJlc3VsdD47XG4gIGRlc2NyaWJlU09iamVjdDogKG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICBkZXNjcmliZVNPYmplY3QkOiBDYWNoZWRGdW5jdGlvbjxcbiAgICAobmFtZTogc3RyaW5nKSA9PiBQcm9taXNlPERlc2NyaWJlU09iamVjdFJlc3VsdD5cbiAgPjtcbiAgZGVzY3JpYmVTT2JqZWN0JCQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IERlc2NyaWJlU09iamVjdFJlc3VsdD47XG4gIC8vIGRlc2NyaWJlR2xvYmFsOiAoKSA9PiBQcm9taXNlPERlc2NyaWJlR2xvYmFsUmVzdWx0PjtcbiAgZGVzY3JpYmVHbG9iYWwkOiBDYWNoZWRGdW5jdGlvbjwoKSA9PiBQcm9taXNlPERlc2NyaWJlR2xvYmFsUmVzdWx0Pj47XG4gIGRlc2NyaWJlR2xvYmFsJCQ6IENhY2hlZEZ1bmN0aW9uPCgpID0+IERlc2NyaWJlR2xvYmFsUmVzdWx0PjtcblxuICAvLyBBUEkgbGlicyBhcmUgbm90IGluc3RhbnRpYXRlZCBoZXJlIHNvIHRoYXQgY29yZSBtb2R1bGUgdG8gcmVtYWluIHdpdGhvdXQgZGVwZW5kZW5jaWVzIHRvIHRoZW1cbiAgLy8gSXQgaXMgcmVzcG9uc2libGUgZm9yIGRldmVsb3BlcnMgdG8gaW1wb3J0IGFwaSBsaWJzIGV4cGxpY2l0bHkgaWYgdGhleSBhcmUgdXNpbmcgJ2pzZm9yY2UvY29yZScgaW5zdGVhZCBvZiAnanNmb3JjZScuXG4gIGdldCBhbmFseXRpY3MoKTogQW5hbHl0aWNzPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdhbmFseXRpY3MnKTtcbiAgfVxuXG4gIGdldCBhcGV4KCk6IEFwZXg8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2FwZXgnKTtcbiAgfVxuXG4gIGdldCBidWxrKCk6IEJ1bGs8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2J1bGsnKTtcbiAgfVxuXG4gIGdldCBidWxrMigpOiBCdWxrVjI8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2J1bGsyJyk7XG4gIH1cblxuICBnZXQgY2hhdHRlcigpOiBDaGF0dGVyPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdjaGF0dGVyJyk7XG4gIH1cblxuICBnZXQgbWV0YWRhdGEoKTogTWV0YWRhdGE8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ21ldGFkYXRhJyk7XG4gIH1cblxuICBnZXQgc29hcCgpOiBTb2FwQXBpPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdzb2FwJyk7XG4gIH1cblxuICBnZXQgc3RyZWFtaW5nKCk6IFN0cmVhbWluZzxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcignc3RyZWFtaW5nJyk7XG4gIH1cblxuICBnZXQgdG9vbGluZygpOiBUb29saW5nPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCd0b29saW5nJyk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbmZpZzogQ29ubmVjdGlvbkNvbmZpZzxTPiA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICBjb25zdCB7XG4gICAgICBsb2dpblVybCxcbiAgICAgIGluc3RhbmNlVXJsLFxuICAgICAgdmVyc2lvbixcbiAgICAgIG9hdXRoMixcbiAgICAgIG1heFJlcXVlc3QsXG4gICAgICBsb2dMZXZlbCxcbiAgICAgIHByb3h5VXJsLFxuICAgICAgaHR0cFByb3h5LFxuICAgIH0gPSBjb25maWc7XG4gICAgdGhpcy5sb2dpblVybCA9IGxvZ2luVXJsIHx8IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLmxvZ2luVXJsO1xuICAgIHRoaXMuaW5zdGFuY2VVcmwgPSBpbnN0YW5jZVVybCB8fCBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy5pbnN0YW5jZVVybDtcbiAgICB0aGlzLnZlcnNpb24gPSB2ZXJzaW9uIHx8IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLnZlcnNpb247XG4gICAgdGhpcy5vYXV0aDIgPVxuICAgICAgb2F1dGgyIGluc3RhbmNlb2YgT0F1dGgyXG4gICAgICAgID8gb2F1dGgyXG4gICAgICAgIDogbmV3IE9BdXRoMih7XG4gICAgICAgICAgICBsb2dpblVybDogdGhpcy5sb2dpblVybCxcbiAgICAgICAgICAgIHByb3h5VXJsLFxuICAgICAgICAgICAgaHR0cFByb3h5LFxuICAgICAgICAgICAgLi4ub2F1dGgyLFxuICAgICAgICAgIH0pO1xuICAgIGxldCByZWZyZXNoRm4gPSBjb25maWcucmVmcmVzaEZuO1xuICAgIGlmICghcmVmcmVzaEZuICYmIHRoaXMub2F1dGgyLmNsaWVudElkKSB7XG4gICAgICByZWZyZXNoRm4gPSBvYXV0aFJlZnJlc2hGbjtcbiAgICB9XG4gICAgaWYgKHJlZnJlc2hGbikge1xuICAgICAgdGhpcy5fcmVmcmVzaERlbGVnYXRlID0gbmV3IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUodGhpcywgcmVmcmVzaEZuKTtcbiAgICB9XG4gICAgdGhpcy5fbWF4UmVxdWVzdCA9IG1heFJlcXVlc3QgfHwgZGVmYXVsdENvbm5lY3Rpb25Db25maWcubWF4UmVxdWVzdDtcbiAgICB0aGlzLl9sb2dnZXIgPSBsb2dMZXZlbFxuICAgICAgPyBDb25uZWN0aW9uLl9sb2dnZXIuY3JlYXRlSW5zdGFuY2UobG9nTGV2ZWwpXG4gICAgICA6IENvbm5lY3Rpb24uX2xvZ2dlcjtcbiAgICB0aGlzLl9sb2dMZXZlbCA9IGxvZ0xldmVsO1xuICAgIHRoaXMuX3RyYW5zcG9ydCA9IHByb3h5VXJsXG4gICAgICA/IG5ldyBYZFByb3h5VHJhbnNwb3J0KHByb3h5VXJsKVxuICAgICAgOiBodHRwUHJveHlcbiAgICAgID8gbmV3IEh0dHBQcm94eVRyYW5zcG9ydChodHRwUHJveHkpXG4gICAgICA6IG5ldyBUcmFuc3BvcnQoKTtcbiAgICB0aGlzLl9jYWxsT3B0aW9ucyA9IGNvbmZpZy5jYWxsT3B0aW9ucztcbiAgICB0aGlzLmNhY2hlID0gbmV3IENhY2hlKCk7XG4gICAgY29uc3QgZGVzY3JpYmVDYWNoZUtleSA9ICh0eXBlPzogc3RyaW5nKSA9PlxuICAgICAgdHlwZSA/IGBkZXNjcmliZS4ke3R5cGV9YCA6ICdkZXNjcmliZSc7XG4gICAgY29uc3QgZGVzY3JpYmUgPSBDb25uZWN0aW9uLnByb3RvdHlwZS5kZXNjcmliZTtcbiAgICB0aGlzLmRlc2NyaWJlID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihkZXNjcmliZSwgdGhpcywge1xuICAgICAga2V5OiBkZXNjcmliZUNhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdOT0NBQ0hFJyxcbiAgICB9KTtcbiAgICB0aGlzLmRlc2NyaWJlJCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oZGVzY3JpYmUsIHRoaXMsIHtcbiAgICAgIGtleTogZGVzY3JpYmVDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnSElUJyxcbiAgICB9KTtcbiAgICB0aGlzLmRlc2NyaWJlJCQgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlLCB0aGlzLCB7XG4gICAgICBrZXk6IGRlc2NyaWJlQ2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ0lNTUVESUFURScsXG4gICAgfSkgYXMgYW55O1xuICAgIHRoaXMuZGVzY3JpYmVTT2JqZWN0ID0gdGhpcy5kZXNjcmliZTtcbiAgICB0aGlzLmRlc2NyaWJlU09iamVjdCQgPSB0aGlzLmRlc2NyaWJlJDtcbiAgICB0aGlzLmRlc2NyaWJlU09iamVjdCQkID0gdGhpcy5kZXNjcmliZSQkO1xuICAgIGNvbnN0IGRlc2NyaWJlR2xvYmFsID0gQ29ubmVjdGlvbi5wcm90b3R5cGUuZGVzY3JpYmVHbG9iYWw7XG4gICAgdGhpcy5kZXNjcmliZUdsb2JhbCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oXG4gICAgICBkZXNjcmliZUdsb2JhbCxcbiAgICAgIHRoaXMsXG4gICAgICB7IGtleTogJ2Rlc2NyaWJlR2xvYmFsJywgc3RyYXRlZ3k6ICdOT0NBQ0hFJyB9LFxuICAgICk7XG4gICAgdGhpcy5kZXNjcmliZUdsb2JhbCQgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKFxuICAgICAgZGVzY3JpYmVHbG9iYWwsXG4gICAgICB0aGlzLFxuICAgICAgeyBrZXk6ICdkZXNjcmliZUdsb2JhbCcsIHN0cmF0ZWd5OiAnSElUJyB9LFxuICAgICk7XG4gICAgdGhpcy5kZXNjcmliZUdsb2JhbCQkID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihcbiAgICAgIGRlc2NyaWJlR2xvYmFsLFxuICAgICAgdGhpcyxcbiAgICAgIHsga2V5OiAnZGVzY3JpYmVHbG9iYWwnLCBzdHJhdGVneTogJ0lNTUVESUFURScgfSxcbiAgICApIGFzIGFueTtcbiAgICBjb25zdCB7XG4gICAgICBhY2Nlc3NUb2tlbixcbiAgICAgIHJlZnJlc2hUb2tlbixcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIHNlcnZlclVybCxcbiAgICAgIHNpZ25lZFJlcXVlc3QsXG4gICAgfSA9IGNvbmZpZztcbiAgICB0aGlzLl9lc3RhYmxpc2goe1xuICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICByZWZyZXNoVG9rZW4sXG4gICAgICBpbnN0YW5jZVVybCxcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIHNlcnZlclVybCxcbiAgICAgIHNpZ25lZFJlcXVlc3QsXG4gICAgfSk7XG5cbiAgICBqc2ZvcmNlLmVtaXQoJ2Nvbm5lY3Rpb246bmV3JywgdGhpcyk7XG4gIH1cblxuICAvKiBAcHJpdmF0ZSAqL1xuICBfZXN0YWJsaXNoKG9wdGlvbnM6IENvbm5lY3Rpb25Fc3RhYmxpc2hPcHRpb25zKSB7XG4gICAgY29uc3Qge1xuICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICByZWZyZXNoVG9rZW4sXG4gICAgICBpbnN0YW5jZVVybCxcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIHNlcnZlclVybCxcbiAgICAgIHNpZ25lZFJlcXVlc3QsXG4gICAgICB1c2VySW5mbyxcbiAgICB9ID0gb3B0aW9ucztcbiAgICB0aGlzLmluc3RhbmNlVXJsID0gc2VydmVyVXJsXG4gICAgICA/IHNlcnZlclVybC5zcGxpdCgnLycpLnNsaWNlKDAsIDMpLmpvaW4oJy8nKVxuICAgICAgOiBpbnN0YW5jZVVybCB8fCB0aGlzLmluc3RhbmNlVXJsO1xuICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBzZXNzaW9uSWQgfHwgYWNjZXNzVG9rZW4gfHwgdGhpcy5hY2Nlc3NUb2tlbjtcbiAgICB0aGlzLnJlZnJlc2hUb2tlbiA9IHJlZnJlc2hUb2tlbiB8fCB0aGlzLnJlZnJlc2hUb2tlbjtcbiAgICBpZiAodGhpcy5yZWZyZXNoVG9rZW4gJiYgIXRoaXMuX3JlZnJlc2hEZWxlZ2F0ZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnUmVmcmVzaCB0b2tlbiBpcyBzcGVjaWZpZWQgd2l0aG91dCBvYXV0aDIgY2xpZW50IGluZm9ybWF0aW9uIG9yIHJlZnJlc2ggZnVuY3Rpb24nLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3Qgc2lnbmVkUmVxdWVzdE9iamVjdCA9XG4gICAgICBzaWduZWRSZXF1ZXN0ICYmIHBhcnNlU2lnbmVkUmVxdWVzdChzaWduZWRSZXF1ZXN0KTtcbiAgICBpZiAoc2lnbmVkUmVxdWVzdE9iamVjdCkge1xuICAgICAgdGhpcy5hY2Nlc3NUb2tlbiA9IHNpZ25lZFJlcXVlc3RPYmplY3QuY2xpZW50Lm9hdXRoVG9rZW47XG4gICAgICBpZiAoQ2FudmFzVHJhbnNwb3J0LnN1cHBvcnRlZCkge1xuICAgICAgICB0aGlzLl90cmFuc3BvcnQgPSBuZXcgQ2FudmFzVHJhbnNwb3J0KHNpZ25lZFJlcXVlc3RPYmplY3QpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLnVzZXJJbmZvID0gdXNlckluZm8gfHwgdGhpcy51c2VySW5mbztcbiAgICB0aGlzLl9zZXNzaW9uVHlwZSA9IHNlc3Npb25JZCA/ICdzb2FwJyA6ICdvYXV0aDInO1xuICAgIHRoaXMuX3Jlc2V0SW5zdGFuY2UoKTtcbiAgfVxuXG4gIC8qIEBwcml2ZWF0ZSAqL1xuICBfY2xlYXJTZXNzaW9uKCkge1xuICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBudWxsO1xuICAgIHRoaXMucmVmcmVzaFRva2VuID0gbnVsbDtcbiAgICB0aGlzLmluc3RhbmNlVXJsID0gZGVmYXVsdENvbm5lY3Rpb25Db25maWcuaW5zdGFuY2VVcmw7XG4gICAgdGhpcy51c2VySW5mbyA9IG51bGw7XG4gICAgdGhpcy5fc2Vzc2lvblR5cGUgPSBudWxsO1xuICB9XG5cbiAgLyogQHByaXZlYXRlICovXG4gIF9yZXNldEluc3RhbmNlKCkge1xuICAgIHRoaXMubGltaXRJbmZvID0ge307XG4gICAgdGhpcy5zb2JqZWN0cyA9IHt9O1xuICAgIC8vIFRPRE8gaW1wbCBjYWNoZVxuICAgIHRoaXMuY2FjaGUuY2xlYXIoKTtcbiAgICB0aGlzLmNhY2hlLmdldCgnZGVzY3JpYmVHbG9iYWwnKS5yZW1vdmVBbGxMaXN0ZW5lcnMoJ3ZhbHVlJyk7XG4gICAgdGhpcy5jYWNoZS5nZXQoJ2Rlc2NyaWJlR2xvYmFsJykub24oJ3ZhbHVlJywgKHsgcmVzdWx0IH0pID0+IHtcbiAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgZm9yIChjb25zdCBzbyBvZiByZXN1bHQuc29iamVjdHMpIHtcbiAgICAgICAgICB0aGlzLnNvYmplY3Qoc28ubmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICAvKlxuICAgIGlmICh0aGlzLnRvb2xpbmcpIHtcbiAgICAgIHRoaXMudG9vbGluZy5fcmVzZXRJbnN0YW5jZSgpO1xuICAgIH1cbiAgICAqL1xuICB9XG5cbiAgLyoqXG4gICAqIEF1dGhvcml6ZSAodXNpbmcgb2F1dGgyIHdlYiBzZXJ2ZXIgZmxvdylcbiAgICovXG4gIGFzeW5jIGF1dGhvcml6ZShcbiAgICBjb2RlOiBzdHJpbmcsXG4gICAgcGFyYW1zOiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9LFxuICApOiBQcm9taXNlPFVzZXJJbmZvPiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5vYXV0aDIucmVxdWVzdFRva2VuKGNvZGUsIHBhcmFtcyk7XG4gICAgY29uc3QgdXNlckluZm8gPSBwYXJzZUlkVXJsKHJlcy5pZCk7XG4gICAgdGhpcy5fZXN0YWJsaXNoKHtcbiAgICAgIGluc3RhbmNlVXJsOiByZXMuaW5zdGFuY2VfdXJsLFxuICAgICAgYWNjZXNzVG9rZW46IHJlcy5hY2Nlc3NfdG9rZW4sXG4gICAgICByZWZyZXNoVG9rZW46IHJlcy5yZWZyZXNoX3Rva2VuLFxuICAgICAgdXNlckluZm8sXG4gICAgfSk7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgYDxsb2dpbj4gY29tcGxldGVkLiB1c2VyIGlkID0gJHt1c2VySW5mby5pZH0sIG9yZyBpZCA9ICR7dXNlckluZm8ub3JnYW5pemF0aW9uSWR9YCxcbiAgICApO1xuICAgIHJldHVybiB1c2VySW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgbG9naW4odXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8VXNlckluZm8+IHtcbiAgICB0aGlzLl9yZWZyZXNoRGVsZWdhdGUgPSBuZXcgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZShcbiAgICAgIHRoaXMsXG4gICAgICBjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuKHVzZXJuYW1lLCBwYXNzd29yZCksXG4gICAgKTtcbiAgICBpZiAodGhpcy5vYXV0aDIgJiYgdGhpcy5vYXV0aDIuY2xpZW50SWQgJiYgdGhpcy5vYXV0aDIuY2xpZW50U2VjcmV0KSB7XG4gICAgICByZXR1cm4gdGhpcy5sb2dpbkJ5T0F1dGgyKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmxvZ2luQnlTb2FwKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gIH1cblxuICAvKipcbiAgICogTG9naW4gYnkgT0F1dGgyIHVzZXJuYW1lICYgcGFzc3dvcmQgZmxvd1xuICAgKi9cbiAgYXN5bmMgbG9naW5CeU9BdXRoMih1c2VybmFtZTogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxVc2VySW5mbz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMub2F1dGgyLmF1dGhlbnRpY2F0ZSh1c2VybmFtZSwgcGFzc3dvcmQpO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gcGFyc2VJZFVybChyZXMuaWQpO1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBpbnN0YW5jZVVybDogcmVzLmluc3RhbmNlX3VybCxcbiAgICAgIGFjY2Vzc1Rva2VuOiByZXMuYWNjZXNzX3Rva2VuLFxuICAgICAgdXNlckluZm8sXG4gICAgfSk7XG4gICAgdGhpcy5fbG9nZ2VyLmluZm8oXG4gICAgICBgPGxvZ2luPiBjb21wbGV0ZWQuIHVzZXIgaWQgPSAke3VzZXJJbmZvLmlkfSwgb3JnIGlkID0gJHt1c2VySW5mby5vcmdhbml6YXRpb25JZH1gLFxuICAgICk7XG4gICAgcmV0dXJuIHVzZXJJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBsb2dpbkJ5U29hcCh1c2VybmFtZTogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxVc2VySW5mbz4ge1xuICAgIGlmICghdXNlcm5hbWUgfHwgIXBhc3N3b3JkKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKCdubyB1c2VybmFtZSBwYXNzd29yZCBnaXZlbicpKTtcbiAgICB9XG4gICAgY29uc3QgYm9keSA9IFtcbiAgICAgICc8c2U6RW52ZWxvcGUgeG1sbnM6c2U9XCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlL1wiPicsXG4gICAgICAnPHNlOkhlYWRlci8+JyxcbiAgICAgICc8c2U6Qm9keT4nLFxuICAgICAgJzxsb2dpbiB4bWxucz1cInVybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbVwiPicsXG4gICAgICBgPHVzZXJuYW1lPiR7ZXNjKHVzZXJuYW1lKX08L3VzZXJuYW1lPmAsXG4gICAgICBgPHBhc3N3b3JkPiR7ZXNjKHBhc3N3b3JkKX08L3Bhc3N3b3JkPmAsXG4gICAgICAnPC9sb2dpbj4nLFxuICAgICAgJzwvc2U6Qm9keT4nLFxuICAgICAgJzwvc2U6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuXG4gICAgY29uc3Qgc29hcExvZ2luRW5kcG9pbnQgPSBbXG4gICAgICB0aGlzLmxvZ2luVXJsLFxuICAgICAgJ3NlcnZpY2VzL1NvYXAvdScsXG4gICAgICB0aGlzLnZlcnNpb24sXG4gICAgXS5qb2luKCcvJyk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLl90cmFuc3BvcnQuaHR0cFJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHNvYXBMb2dpbkVuZHBvaW50LFxuICAgICAgYm9keSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3htbCcsXG4gICAgICAgIFNPQVBBY3Rpb246ICdcIlwiJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgbGV0IG07XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPj0gNDAwKSB7XG4gICAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPGZhdWx0c3RyaW5nPihbXjxdKyk8XFwvZmF1bHRzdHJpbmc+Lyk7XG4gICAgICBjb25zdCBmYXVsdHN0cmluZyA9IG0gJiYgbVsxXTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihmYXVsdHN0cmluZyB8fCByZXNwb25zZS5ib2R5KTtcbiAgICB9XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBTT0FQIHJlc3BvbnNlID0gJHtyZXNwb25zZS5ib2R5fWApO1xuICAgIG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88c2VydmVyVXJsPihbXjxdKyk8XFwvc2VydmVyVXJsPi8pO1xuICAgIGNvbnN0IHNlcnZlclVybCA9IG0gJiYgbVsxXTtcbiAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPHNlc3Npb25JZD4oW148XSspPFxcL3Nlc3Npb25JZD4vKTtcbiAgICBjb25zdCBzZXNzaW9uSWQgPSBtICYmIG1bMV07XG4gICAgbSA9IHJlc3BvbnNlLmJvZHkubWF0Y2goLzx1c2VySWQ+KFtePF0rKTxcXC91c2VySWQ+Lyk7XG4gICAgY29uc3QgdXNlcklkID0gbSAmJiBtWzFdO1xuICAgIG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88b3JnYW5pemF0aW9uSWQ+KFtePF0rKTxcXC9vcmdhbml6YXRpb25JZD4vKTtcbiAgICBjb25zdCBvcmdhbml6YXRpb25JZCA9IG0gJiYgbVsxXTtcbiAgICBpZiAoIXNlcnZlclVybCB8fCAhc2Vzc2lvbklkIHx8ICF1c2VySWQgfHwgIW9yZ2FuaXphdGlvbklkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdjb3VsZCBub3QgZXh0cmFjdCBzZXNzaW9uIGluZm9ybWF0aW9uIGZyb20gbG9naW4gcmVzcG9uc2UnLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgaWRVcmwgPSBbdGhpcy5sb2dpblVybCwgJ2lkJywgb3JnYW5pemF0aW9uSWQsIHVzZXJJZF0uam9pbignLycpO1xuICAgIGNvbnN0IHVzZXJJbmZvID0geyBpZDogdXNlcklkLCBvcmdhbml6YXRpb25JZCwgdXJsOiBpZFVybCB9O1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBzZXJ2ZXJVcmw6IHNlcnZlclVybC5zcGxpdCgnLycpLnNsaWNlKDAsIDMpLmpvaW4oJy8nKSxcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5pbmZvKFxuICAgICAgYDxsb2dpbj4gY29tcGxldGVkLiB1c2VyIGlkID0gJHt1c2VySWR9LCBvcmcgaWQgPSAke29yZ2FuaXphdGlvbklkfWAsXG4gICAgKTtcbiAgICByZXR1cm4gdXNlckluZm87XG4gIH1cblxuICAvKipcbiAgICogTG9nb3V0IHRoZSBjdXJyZW50IHNlc3Npb25cbiAgICovXG4gIGFzeW5jIGxvZ291dChyZXZva2U/OiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5fcmVmcmVzaERlbGVnYXRlID0gdW5kZWZpbmVkO1xuICAgIGlmICh0aGlzLl9zZXNzaW9uVHlwZSA9PT0gJ29hdXRoMicpIHtcbiAgICAgIHJldHVybiB0aGlzLmxvZ291dEJ5T0F1dGgyKHJldm9rZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmxvZ291dEJ5U29hcChyZXZva2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ291dCB0aGUgY3VycmVudCBzZXNzaW9uIGJ5IHJldm9raW5nIGFjY2VzcyB0b2tlbiB2aWEgT0F1dGgyIHNlc3Npb24gcmV2b2tlXG4gICAqL1xuICBhc3luYyBsb2dvdXRCeU9BdXRoMihyZXZva2U/OiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdG9rZW4gPSByZXZva2UgPyB0aGlzLnJlZnJlc2hUb2tlbiA6IHRoaXMuYWNjZXNzVG9rZW47XG4gICAgaWYgKHRva2VuKSB7XG4gICAgICBhd2FpdCB0aGlzLm9hdXRoMi5yZXZva2VUb2tlbih0b2tlbik7XG4gICAgfVxuICAgIC8vIERlc3Ryb3kgdGhlIHNlc3Npb24gYm91bmQgdG8gdGhpcyBjb25uZWN0aW9uXG4gICAgdGhpcy5fY2xlYXJTZXNzaW9uKCk7XG4gICAgdGhpcy5fcmVzZXRJbnN0YW5jZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ291dCB0aGUgc2Vzc2lvbiBieSB1c2luZyBTT0FQIHdlYiBzZXJ2aWNlIEFQSVxuICAgKi9cbiAgYXN5bmMgbG9nb3V0QnlTb2FwKHJldm9rZT86IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBib2R5ID0gW1xuICAgICAgJzxzZTpFbnZlbG9wZSB4bWxuczpzZT1cImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3NvYXAvZW52ZWxvcGUvXCI+JyxcbiAgICAgICc8c2U6SGVhZGVyPicsXG4gICAgICAnPFNlc3Npb25IZWFkZXIgeG1sbnM9XCJ1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb21cIj4nLFxuICAgICAgYDxzZXNzaW9uSWQ+JHtlc2MoXG4gICAgICAgIHJldm9rZSA/IHRoaXMucmVmcmVzaFRva2VuIDogdGhpcy5hY2Nlc3NUb2tlbixcbiAgICAgICl9PC9zZXNzaW9uSWQ+YCxcbiAgICAgICc8L1Nlc3Npb25IZWFkZXI+JyxcbiAgICAgICc8L3NlOkhlYWRlcj4nLFxuICAgICAgJzxzZTpCb2R5PicsXG4gICAgICAnPGxvZ291dCB4bWxucz1cInVybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbVwiLz4nLFxuICAgICAgJzwvc2U6Qm9keT4nLFxuICAgICAgJzwvc2U6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fdHJhbnNwb3J0Lmh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiBbdGhpcy5pbnN0YW5jZVVybCwgJ3NlcnZpY2VzL1NvYXAvdScsIHRoaXMudmVyc2lvbl0uam9pbignLycpLFxuICAgICAgYm9keSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3htbCcsXG4gICAgICAgIFNPQVBBY3Rpb246ICdcIlwiJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgYFNPQVAgc3RhdHVzQ29kZSA9ICR7cmVzcG9uc2Uuc3RhdHVzQ29kZX0sIHJlc3BvbnNlID0gJHtyZXNwb25zZS5ib2R5fWAsXG4gICAgKTtcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIGNvbnN0IG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88ZmF1bHRzdHJpbmc+KFtePF0rKTxcXC9mYXVsdHN0cmluZz4vKTtcbiAgICAgIGNvbnN0IGZhdWx0c3RyaW5nID0gbSAmJiBtWzFdO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGZhdWx0c3RyaW5nIHx8IHJlc3BvbnNlLmJvZHkpO1xuICAgIH1cbiAgICAvLyBEZXN0cm95IHRoZSBzZXNzaW9uIGJvdW5kIHRvIHRoaXMgY29ubmVjdGlvblxuICAgIHRoaXMuX2NsZWFyU2Vzc2lvbigpO1xuICAgIHRoaXMuX3Jlc2V0SW5zdGFuY2UoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kIFJFU1QgQVBJIHJlcXVlc3Qgd2l0aCBnaXZlbiBIVFRQIHJlcXVlc3QgaW5mbywgd2l0aCBjb25uZWN0ZWQgc2Vzc2lvbiBpbmZvcm1hdGlvbi5cbiAgICpcbiAgICogRW5kcG9pbnQgVVJMIGNhbiBiZSBhYnNvbHV0ZSBVUkwgKCdodHRwczovL25hMS5zYWxlc2ZvcmNlLmNvbS9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIHJlbGF0aXZlIHBhdGggZnJvbSByb290ICgnL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgb3IgcmVsYXRpdmUgcGF0aCBmcm9tIHZlcnNpb24gcm9vdCAoJy9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJykuXG4gICAqL1xuICByZXF1ZXN0PFIgPSB1bmtub3duPihcbiAgICByZXF1ZXN0OiBzdHJpbmcgfCBIdHRwUmVxdWVzdCxcbiAgICBvcHRpb25zOiBPYmplY3QgPSB7fSxcbiAgKTogU3RyZWFtUHJvbWlzZTxSPiB7XG4gICAgLy8gaWYgcmVxdWVzdCBpcyBzaW1wbGUgc3RyaW5nLCByZWdhcmQgaXQgYXMgdXJsIGluIEdFVCBtZXRob2RcbiAgICBsZXQgcmVxdWVzdF86IEh0dHBSZXF1ZXN0ID1cbiAgICAgIHR5cGVvZiByZXF1ZXN0ID09PSAnc3RyaW5nJyA/IHsgbWV0aG9kOiAnR0VUJywgdXJsOiByZXF1ZXN0IH0gOiByZXF1ZXN0O1xuICAgIC8vIGlmIHVybCBpcyBnaXZlbiBpbiByZWxhdGl2ZSBwYXRoLCBwcmVwZW5kIGJhc2UgdXJsIG9yIGluc3RhbmNlIHVybCBiZWZvcmUuXG4gICAgcmVxdWVzdF8gPSB7XG4gICAgICAuLi5yZXF1ZXN0XyxcbiAgICAgIHVybDogdGhpcy5fbm9ybWFsaXplVXJsKHJlcXVlc3RfLnVybCksXG4gICAgfTtcbiAgICBjb25zdCBodHRwQXBpID0gbmV3IEh0dHBBcGkodGhpcywgb3B0aW9ucyk7XG4gICAgLy8gbG9nIGFwaSB1c2FnZSBhbmQgaXRzIHF1b3RhXG4gICAgaHR0cEFwaS5vbigncmVzcG9uc2UnLCAocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKHJlc3BvbnNlLmhlYWRlcnMgJiYgcmVzcG9uc2UuaGVhZGVyc1snc2ZvcmNlLWxpbWl0LWluZm8nXSkge1xuICAgICAgICBjb25zdCBhcGlVc2FnZSA9IHJlc3BvbnNlLmhlYWRlcnNbJ3Nmb3JjZS1saW1pdC1pbmZvJ10ubWF0Y2goXG4gICAgICAgICAgL2FwaS11c2FnZT0oXFxkKylcXC8oXFxkKykvLFxuICAgICAgICApO1xuICAgICAgICBpZiAoYXBpVXNhZ2UpIHtcbiAgICAgICAgICB0aGlzLmxpbWl0SW5mbyA9IHtcbiAgICAgICAgICAgIGFwaVVzYWdlOiB7XG4gICAgICAgICAgICAgIHVzZWQ6IHBhcnNlSW50KGFwaVVzYWdlWzFdLCAxMCksXG4gICAgICAgICAgICAgIGxpbWl0OiBwYXJzZUludChhcGlVc2FnZVsyXSwgMTApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGh0dHBBcGkucmVxdWVzdDxSPihyZXF1ZXN0Xyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIEdFVCByZXF1ZXN0XG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdEdldDxSID0gdW5rbm93bj4odXJsOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHsgbWV0aG9kOiAnR0VUJywgdXJsIH07XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSPihyZXF1ZXN0LCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kIEhUVFAgUE9TVCByZXF1ZXN0IHdpdGggSlNPTiBib2R5LCB3aXRoIGNvbm5lY3RlZCBzZXNzaW9uIGluZm9ybWF0aW9uXG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdFBvc3Q8UiA9IHVua25vd24+KHVybDogc3RyaW5nLCBib2R5OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSksXG4gICAgICBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIFBVVCByZXF1ZXN0IHdpdGggSlNPTiBib2R5LCB3aXRoIGNvbm5lY3RlZCBzZXNzaW9uIGluZm9ybWF0aW9uXG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdFB1dDxSPih1cmw6IHN0cmluZywgYm9keTogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7XG4gICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSksXG4gICAgICBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIFBBVENIIHJlcXVlc3Qgd2l0aCBKU09OIGJvZHlcbiAgICpcbiAgICogRW5kcG9pbnQgVVJMIGNhbiBiZSBhYnNvbHV0ZSBVUkwgKCdodHRwczovL25hMS5zYWxlc2ZvcmNlLmNvbS9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIHJlbGF0aXZlIHBhdGggZnJvbSByb290ICgnL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgb3IgcmVsYXRpdmUgcGF0aCBmcm9tIHZlcnNpb24gcm9vdCAoJy9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJykuXG4gICAqL1xuICByZXF1ZXN0UGF0Y2g8UiA9IHVua25vd24+KHVybDogc3RyaW5nLCBib2R5OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHtcbiAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpLFxuICAgICAgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFI+KHJlcXVlc3QsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgSFRUUCBERUxFVEUgcmVxdWVzdFxuICAgKlxuICAgKiBFbmRwb2ludCBVUkwgY2FuIGJlIGFic29sdXRlIFVSTCAoJ2h0dHBzOi8vbmExLnNhbGVzZm9yY2UuY29tL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgcmVsYXRpdmUgcGF0aCBmcm9tIHJvb3QgKCcvc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCBvciByZWxhdGl2ZSBwYXRoIGZyb20gdmVyc2lvbiByb290ICgnL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKS5cbiAgICovXG4gIHJlcXVlc3REZWxldGU8Uj4odXJsOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHsgbWV0aG9kOiAnREVMRVRFJywgdXJsIH07XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSPihyZXF1ZXN0LCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqKi9cbiAgX2Jhc2VVcmwoKSB7XG4gICAgcmV0dXJuIFt0aGlzLmluc3RhbmNlVXJsLCAnc2VydmljZXMvZGF0YScsIGB2JHt0aGlzLnZlcnNpb259YF0uam9pbignLycpO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbnZlcnQgcGF0aCB0byBhYnNvbHV0ZSB1cmxcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ub3JtYWxpemVVcmwodXJsOiBzdHJpbmcpIHtcbiAgICBpZiAodXJsWzBdID09PSAnLycpIHtcbiAgICAgIGlmICh1cmwuaW5kZXhPZih0aGlzLmluc3RhbmNlVXJsICsgJy9zZXJ2aWNlcy8nKSA9PT0gMCkge1xuICAgICAgICByZXR1cm4gdXJsO1xuICAgICAgfVxuICAgICAgaWYgKHVybC5pbmRleE9mKCcvc2VydmljZXMvJykgPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5zdGFuY2VVcmwgKyB1cmw7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fYmFzZVVybCgpICsgdXJsO1xuICAgIH1cbiAgICByZXR1cm4gdXJsO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBxdWVyeTxUIGV4dGVuZHMgUmVjb3JkPihcbiAgICBzb3FsOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IFBhcnRpYWw8UXVlcnlPcHRpb25zPixcbiAgKTogUXVlcnk8UywgU09iamVjdE5hbWVzPFM+LCBULCAnUXVlcnlSZXN1bHQnPiB7XG4gICAgcmV0dXJuIG5ldyBRdWVyeTxTLCBTT2JqZWN0TmFtZXM8Uz4sIFQsICdRdWVyeVJlc3VsdCc+KHRoaXMsIHNvcWwsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgc2VhcmNoIGJ5IFNPU0xcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNvc2wgLSBTT1NMIHN0cmluZ1xuICAgKiBAcGFyYW0ge0NhbGxiYWNrLjxBcnJheS48UmVjb3JkUmVzdWx0Pj59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7UHJvbWlzZS48QXJyYXkuPFJlY29yZFJlc3VsdD4+fVxuICAgKi9cbiAgc2VhcmNoKHNvc2w6IHN0cmluZykge1xuICAgIHZhciB1cmwgPSB0aGlzLl9iYXNlVXJsKCkgKyAnL3NlYXJjaD9xPScgKyBlbmNvZGVVUklDb21wb25lbnQoc29zbCk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxTZWFyY2hSZXN1bHQ+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIHF1ZXJ5TW9yZShsb2NhdG9yOiBzdHJpbmcsIG9wdGlvbnM/OiBRdWVyeU9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5PFMsIFNPYmplY3ROYW1lczxTPiwgUmVjb3JkLCAnUXVlcnlSZXN1bHQnPihcbiAgICAgIHRoaXMsXG4gICAgICB7IGxvY2F0b3IgfSxcbiAgICAgIG9wdGlvbnMsXG4gICAgKTtcbiAgfVxuXG4gIC8qICovXG4gIF9lbnN1cmVWZXJzaW9uKG1ham9yVmVyc2lvbjogbnVtYmVyKSB7XG4gICAgY29uc3QgdmVyc2lvbnMgPSB0aGlzLnZlcnNpb24uc3BsaXQoJy4nKTtcbiAgICByZXR1cm4gcGFyc2VJbnQodmVyc2lvbnNbMF0sIDEwKSA+PSBtYWpvclZlcnNpb247XG4gIH1cblxuICAvKiAqL1xuICBfc3VwcG9ydHMoZmVhdHVyZTogc3RyaW5nKSB7XG4gICAgc3dpdGNoIChmZWF0dXJlKSB7XG4gICAgICBjYXNlICdzb2JqZWN0LWNvbGxlY3Rpb24nOiAvLyBzb2JqZWN0IGNvbGxlY3Rpb24gaXMgYXZhaWxhYmxlIG9ubHkgaW4gQVBJIHZlciA0Mi4wK1xuICAgICAgICByZXR1cm4gdGhpcy5fZW5zdXJlVmVyc2lvbig0Mik7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHNwZWNpZmllZCByZWNvcmRzXG4gICAqL1xuICByZXRyaWV2ZTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBSZXRyaWV2ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8UmVjb3JkPjtcbiAgcmV0cmlldmU8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM/OiBSZXRyaWV2ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8UmVjb3JkW10+O1xuICByZXRyaWV2ZTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IFJldHJpZXZlT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxSZWNvcmQgfCBSZWNvcmRbXT47XG4gIGFzeW5jIHJldHJpZXZlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM6IFJldHJpZXZlT3B0aW9ucyA9IHt9LFxuICApIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShpZHMpXG4gICAgICA/IC8vIGNoZWNrIHRoZSB2ZXJzaW9uIHdoZXRoZXIgU09iamVjdCBjb2xsZWN0aW9uIEFQSSBpcyBzdXBwb3J0ZWQgKDQyLjApXG4gICAgICAgIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gdGhpcy5fcmV0cmlldmVNYW55KHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgICAgOiB0aGlzLl9yZXRyaWV2ZVBhcmFsbGVsKHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fcmV0cmlldmVTaW5nbGUodHlwZSwgaWRzLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfcmV0cmlldmVTaW5nbGUodHlwZTogc3RyaW5nLCBpZDogc3RyaW5nLCBvcHRpb25zOiBSZXRyaWV2ZU9wdGlvbnMpIHtcbiAgICBpZiAoIWlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgcmVjb3JkIElELiBTcGVjaWZ5IHZhbGlkIHJlY29yZCBJRCB2YWx1ZScpO1xuICAgIH1cbiAgICBsZXQgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgaWRdLmpvaW4oJy8nKTtcbiAgICBjb25zdCB7IGZpZWxkcywgaGVhZGVycyB9ID0gb3B0aW9ucztcbiAgICBpZiAoZmllbGRzKSB7XG4gICAgICB1cmwgKz0gYD9maWVsZHM9JHtmaWVsZHMuam9pbignLCcpfWA7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoeyBtZXRob2Q6ICdHRVQnLCB1cmwsIGhlYWRlcnMgfSk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3JldHJpZXZlUGFyYWxsZWwoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9uczogUmV0cmlldmVPcHRpb25zLFxuICApIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICBpZHMubWFwKChpZCkgPT5cbiAgICAgICAgdGhpcy5fcmV0cmlldmVTaW5nbGUodHlwZSwgaWQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgZXJyLmVycm9yQ29kZSAhPT0gJ05PVF9GT1VORCcpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9yZXRyaWV2ZU1hbnkodHlwZTogc3RyaW5nLCBpZHM6IHN0cmluZ1tdLCBvcHRpb25zOiBSZXRyaWV2ZU9wdGlvbnMpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnY29tcG9zaXRlJywgJ3NvYmplY3RzJywgdHlwZV0uam9pbignLycpO1xuICAgIGNvbnN0IGZpZWxkcyA9XG4gICAgICBvcHRpb25zLmZpZWxkcyB8fFxuICAgICAgKGF3YWl0IHRoaXMuZGVzY3JpYmUkKHR5cGUpKS5maWVsZHMubWFwKChmaWVsZCkgPT4gZmllbGQubmFtZSk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgaWRzLCBmaWVsZHMgfSksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgcmVjb3Jkc1xuICAgKi9cbiAgY3JlYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj5cbiAgPih0eXBlOiBOLCByZWNvcmQ6IElucHV0UmVjb3JkLCBvcHRpb25zPzogRG1sT3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIGNyZWF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBJbnB1dFJlY29yZCB8IElucHV0UmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIC8qKlxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcGFyYW0gcmVjb3Jkc1xuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgYXN5bmMgY3JlYXRlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmRzOiBSZWNvcmQgfCBSZWNvcmRbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICkge1xuICAgIGNvbnN0IHJldCA9IEFycmF5LmlzQXJyYXkocmVjb3JkcylcbiAgICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDIuMClcbiAgICAgICAgdGhpcy5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyBhd2FpdCB0aGlzLl9jcmVhdGVNYW55KHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpXG4gICAgICAgIDogYXdhaXQgdGhpcy5fY3JlYXRlUGFyYWxsZWwodHlwZSwgcmVjb3Jkcywgb3B0aW9ucylcbiAgICAgIDogYXdhaXQgdGhpcy5fY3JlYXRlU2luZ2xlKHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpO1xuICAgIHJldHVybiByZXQ7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2NyZWF0ZVNpbmdsZSh0eXBlOiBzdHJpbmcsIHJlY29yZDogUmVjb3JkLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgY29uc3QgeyBJZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgIGNvbnN0IHNvYmplY3RUeXBlID0gdHlwZSB8fCAoYXR0cmlidXRlcyAmJiBhdHRyaWJ1dGVzLnR5cGUpIHx8IHJ0eXBlO1xuICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gU09iamVjdCBUeXBlIGRlZmluZWQgaW4gcmVjb3JkJyk7XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHNvYmplY3RUeXBlXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlYyksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfY3JlYXRlUGFyYWxsZWwodHlwZTogc3RyaW5nLCByZWNvcmRzOiBSZWNvcmRbXSwgb3B0aW9uczogRG1sT3B0aW9ucykge1xuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICByZWNvcmRzLm1hcCgocmVjb3JkKSA9PlxuICAgICAgICB0aGlzLl9jcmVhdGVTaW5nbGUodHlwZSwgcmVjb3JkLCBvcHRpb25zKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgLy8gYmUgYXdhcmUgdGhhdCBhbGxPck5vbmUgaW4gcGFyYWxsZWwgbW9kZSB3aWxsIG5vdCByZXZlcnQgdGhlIG90aGVyIHN1Y2Nlc3NmdWwgcmVxdWVzdHNcbiAgICAgICAgICAvLyBpdCBvbmx5IHJhaXNlcyBlcnJvciB3aGVuIG1ldCBhdCBsZWFzdCBvbmUgZmFpbGVkIHJlcXVlc3QuXG4gICAgICAgICAgaWYgKG9wdGlvbnMuYWxsT3JOb25lIHx8ICFlcnIuZXJyb3JDb2RlKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0b1NhdmVSZXN1bHQoZXJyKTtcbiAgICAgICAgfSksXG4gICAgICApLFxuICAgICk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2NyZWF0ZU1hbnkoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZHM6IFJlY29yZFtdLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPiB7XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKFtdKTtcbiAgICB9XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID4gTUFYX0RNTF9DT1VOVCAmJiBvcHRpb25zLmFsbG93UmVjdXJzaXZlKSB7XG4gICAgICByZXR1cm4gW1xuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fY3JlYXRlTWFueShcbiAgICAgICAgICB0eXBlLFxuICAgICAgICAgIHJlY29yZHMuc2xpY2UoMCwgTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgKSksXG4gICAgICAgIC4uLihhd2FpdCB0aGlzLl9jcmVhdGVNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgcmVjb3Jkcy5zbGljZShNQVhfRE1MX0NPVU5UKSxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApKSxcbiAgICAgIF07XG4gICAgfVxuICAgIGNvbnN0IF9yZWNvcmRzID0gcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT4ge1xuICAgICAgY29uc3QgeyBJZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgICAgY29uc3Qgc29iamVjdFR5cGUgPSB0eXBlIHx8IChhdHRyaWJ1dGVzICYmIGF0dHJpYnV0ZXMudHlwZSkgfHwgcnR5cGU7XG4gICAgICBpZiAoIXNvYmplY3RUeXBlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gU09iamVjdCBUeXBlIGRlZmluZWQgaW4gcmVjb3JkJyk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBhdHRyaWJ1dGVzOiB7IHR5cGU6IHNvYmplY3RUeXBlIH0sIC4uLnJlYyB9O1xuICAgIH0pO1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdjb21wb3NpdGUnLCAnc29iamVjdHMnXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgYWxsT3JOb25lOiBvcHRpb25zLmFsbE9yTm9uZSB8fCBmYWxzZSxcbiAgICAgICAgcmVjb3JkczogX3JlY29yZHMsXG4gICAgICB9KSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uKG9wdGlvbnMuaGVhZGVycyB8fCB7fSksXG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQ29ubmVjdGlvbiNjcmVhdGUoKVxuICAgKi9cbiAgaW5zZXJ0ID0gdGhpcy5jcmVhdGU7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSByZWNvcmRzXG4gICAqL1xuICB1cGRhdGU8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBVcGRhdGVSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+ID0gU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogVXBkYXRlUmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgVXBkYXRlUmVjb3JkIGV4dGVuZHMgU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPiA9IFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj5cbiAgPih0eXBlOiBOLCByZWNvcmQ6IFVwZGF0ZVJlY29yZCwgb3B0aW9ucz86IERtbE9wdGlvbnMpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICB1cGRhdGU8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBVcGRhdGVSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+ID0gU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogVXBkYXRlUmVjb3JkIHwgVXBkYXRlUmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIC8qKlxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcGFyYW0gcmVjb3Jkc1xuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgdXBkYXRlPE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogUmVjb3JkIHwgUmVjb3JkW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyA9IHt9LFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+IHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShyZWNvcmRzKVxuICAgICAgPyAvLyBjaGVjayB0aGUgdmVyc2lvbiB3aGV0aGVyIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgaXMgc3VwcG9ydGVkICg0Mi4wKVxuICAgICAgICB0aGlzLl9lbnN1cmVWZXJzaW9uKDQyKVxuICAgICAgICA/IHRoaXMuX3VwZGF0ZU1hbnkodHlwZSwgcmVjb3Jkcywgb3B0aW9ucylcbiAgICAgICAgOiB0aGlzLl91cGRhdGVQYXJhbGxlbCh0eXBlLCByZWNvcmRzLCBvcHRpb25zKVxuICAgICAgOiB0aGlzLl91cGRhdGVTaW5nbGUodHlwZSwgcmVjb3Jkcywgb3B0aW9ucyk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3VwZGF0ZVNpbmdsZShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcmVjb3JkOiBSZWNvcmQsXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0PiB7XG4gICAgY29uc3QgeyBJZDogaWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICBpZiAoIWlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlY29yZCBpZCBpcyBub3QgZm91bmQgaW4gcmVjb3JkLicpO1xuICAgIH1cbiAgICBjb25zdCBzb2JqZWN0VHlwZSA9IHR5cGUgfHwgKGF0dHJpYnV0ZXMgJiYgYXR0cmlidXRlcy50eXBlKSB8fCBydHlwZTtcbiAgICBpZiAoIXNvYmplY3RUeXBlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIFNPYmplY3QgVHlwZSBkZWZpbmVkIGluIHJlY29yZCcpO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCBzb2JqZWN0VHlwZSwgaWRdLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KFxuICAgICAge1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIHVybCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVjKSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBub0NvbnRlbnRSZXNwb25zZTogeyBpZCwgc3VjY2VzczogdHJ1ZSwgZXJyb3JzOiBbXSB9LFxuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF91cGRhdGVQYXJhbGxlbCh0eXBlOiBzdHJpbmcsIHJlY29yZHM6IFJlY29yZFtdLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID4gdGhpcy5fbWF4UmVxdWVzdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeGNlZWRlZCBtYXggbGltaXQgb2YgY29uY3VycmVudCBjYWxsJyk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLmFsbChcbiAgICAgIHJlY29yZHMubWFwKChyZWNvcmQpID0+XG4gICAgICAgIHRoaXMuX3VwZGF0ZVNpbmdsZSh0eXBlLCByZWNvcmQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBiZSBhd2FyZSB0aGF0IGFsbE9yTm9uZSBpbiBwYXJhbGxlbCBtb2RlIHdpbGwgbm90IHJldmVydCB0aGUgb3RoZXIgc3VjY2Vzc2Z1bCByZXF1ZXN0c1xuICAgICAgICAgIC8vIGl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfdXBkYXRlTWFueShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcmVjb3JkczogUmVjb3JkW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+IHtcbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID4gTUFYX0RNTF9DT1VOVCAmJiBvcHRpb25zLmFsbG93UmVjdXJzaXZlKSB7XG4gICAgICByZXR1cm4gW1xuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fdXBkYXRlTWFueShcbiAgICAgICAgICB0eXBlLFxuICAgICAgICAgIHJlY29yZHMuc2xpY2UoMCwgTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgKSksXG4gICAgICAgIC4uLihhd2FpdCB0aGlzLl91cGRhdGVNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgcmVjb3Jkcy5zbGljZShNQVhfRE1MX0NPVU5UKSxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApKSxcbiAgICAgIF07XG4gICAgfVxuICAgIGNvbnN0IF9yZWNvcmRzID0gcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT4ge1xuICAgICAgY29uc3QgeyBJZDogaWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICAgIGlmICghaWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdSZWNvcmQgaWQgaXMgbm90IGZvdW5kIGluIHJlY29yZC4nKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNvYmplY3RUeXBlID0gdHlwZSB8fCAoYXR0cmlidXRlcyAmJiBhdHRyaWJ1dGVzLnR5cGUpIHx8IHJ0eXBlO1xuICAgICAgaWYgKCFzb2JqZWN0VHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIFNPYmplY3QgVHlwZSBkZWZpbmVkIGluIHJlY29yZCcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgaWQsIGF0dHJpYnV0ZXM6IHsgdHlwZTogc29iamVjdFR5cGUgfSwgLi4ucmVjIH07XG4gICAgfSk7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ2NvbXBvc2l0ZScsICdzb2JqZWN0cyddLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgYWxsT3JOb25lOiBvcHRpb25zLmFsbE9yTm9uZSB8fCBmYWxzZSxcbiAgICAgICAgcmVjb3JkczogX3JlY29yZHMsXG4gICAgICB9KSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uKG9wdGlvbnMuaGVhZGVycyB8fCB7fSksXG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwc2VydCByZWNvcmRzXG4gICAqL1xuICB1cHNlcnQ8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPixcbiAgICBGaWVsZE5hbWVzIGV4dGVuZHMgU09iamVjdEZpZWxkTmFtZXM8UywgTj4gPSBTT2JqZWN0RmllbGROYW1lczxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogSW5wdXRSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdFtdPjtcbiAgdXBzZXJ0PFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4sXG4gICAgRmllbGROYW1lcyBleHRlbmRzIFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+ID0gU09iamVjdEZpZWxkTmFtZXM8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZDogSW5wdXRSZWNvcmQsXG4gICAgZXh0SWRGaWVsZDogRmllbGROYW1lcyxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxVcHNlcnRSZXN1bHQ+O1xuICB1cHNlcnQ8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPixcbiAgICBGaWVsZE5hbWVzIGV4dGVuZHMgU09iamVjdEZpZWxkTmFtZXM8UywgTj4gPSBTT2JqZWN0RmllbGROYW1lczxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogSW5wdXRSZWNvcmQgfCBJbnB1dFJlY29yZFtdLFxuICAgIGV4dElkRmllbGQ6IEZpZWxkTmFtZXMsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0IHwgVXBzZXJ0UmVzdWx0W10+O1xuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHBhcmFtIHJlY29yZHNcbiAgICogQHBhcmFtIGV4dElkRmllbGRcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICovXG4gIGFzeW5jIHVwc2VydChcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcmVjb3JkczogUmVjb3JkIHwgUmVjb3JkW10sXG4gICAgZXh0SWRGaWVsZDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMgPSB7fSxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPiB7XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkocmVjb3Jkcyk7XG4gICAgY29uc3QgX3JlY29yZHMgPSBBcnJheS5pc0FycmF5KHJlY29yZHMpID8gcmVjb3JkcyA6IFtyZWNvcmRzXTtcbiAgICBpZiAoX3JlY29yZHMubGVuZ3RoID4gdGhpcy5fbWF4UmVxdWVzdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeGNlZWRlZCBtYXggbGltaXQgb2YgY29uY3VycmVudCBjYWxsJyk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIF9yZWNvcmRzLm1hcCgocmVjb3JkKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgW2V4dElkRmllbGRdOiBleHRJZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgICAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlLCBleHRJZEZpZWxkLCBleHRJZF0uam9pbihcbiAgICAgICAgICAnLycsXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8U2F2ZVJlc3VsdD4oXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVjKSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgLi4uKG9wdGlvbnMuaGVhZGVycyB8fCB7fSksXG4gICAgICAgICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgbm9Db250ZW50UmVzcG9uc2U6IHsgc3VjY2VzczogdHJ1ZSwgZXJyb3JzOiBbXSB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIC8vIEJlIGF3YXJlIHRoYXQgYGFsbE9yTm9uZWAgb3B0aW9uIGluIHVwc2VydCBtZXRob2RcbiAgICAgICAgICAvLyB3aWxsIG5vdCByZXZlcnQgdGhlIG90aGVyIHN1Y2Nlc3NmdWwgcmVxdWVzdHMuXG4gICAgICAgICAgLy8gSXQgb25seSByYWlzZXMgZXJyb3Igd2hlbiBtZXQgYXQgbGVhc3Qgb25lIGZhaWxlZCByZXF1ZXN0LlxuICAgICAgICAgIGlmICghaXNBcnJheSB8fCBvcHRpb25zLmFsbE9yTm9uZSB8fCAhZXJyLmVycm9yQ29kZSkge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdG9TYXZlUmVzdWx0KGVycik7XG4gICAgICAgIH0pO1xuICAgICAgfSksXG4gICAgKTtcbiAgICByZXR1cm4gaXNBcnJheSA/IHJlc3VsdHMgOiByZXN1bHRzWzBdO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSByZWNvcmRzXG4gICAqL1xuICBkZXN0cm95PE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KFxuICAgIHR5cGU6IE4sXG4gICAgaWRzOiBzdHJpbmdbXSxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICBkZXN0cm95PE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KFxuICAgIHR5cGU6IE4sXG4gICAgaWQ6IHN0cmluZyxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgZGVzdHJveTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIC8qKlxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcGFyYW0gaWRzXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqL1xuICBhc3luYyBkZXN0cm95KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMgPSB7fSxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPiB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoaWRzKVxuICAgICAgPyAvLyBjaGVjayB0aGUgdmVyc2lvbiB3aGV0aGVyIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgaXMgc3VwcG9ydGVkICg0Mi4wKVxuICAgICAgICB0aGlzLl9lbnN1cmVWZXJzaW9uKDQyKVxuICAgICAgICA/IHRoaXMuX2Rlc3Ryb3lNYW55KHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgICAgOiB0aGlzLl9kZXN0cm95UGFyYWxsZWwodHlwZSwgaWRzLCBvcHRpb25zKVxuICAgICAgOiB0aGlzLl9kZXN0cm95U2luZ2xlKHR5cGUsIGlkcywgb3B0aW9ucyk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2Rlc3Ryb3lTaW5nbGUoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGlkOiBzdHJpbmcsXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgaWRdLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KFxuICAgICAge1xuICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgICB1cmwsXG4gICAgICAgIGhlYWRlcnM6IG9wdGlvbnMuaGVhZGVycyB8fCB7fSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5vQ29udGVudFJlc3BvbnNlOiB7IGlkLCBzdWNjZXNzOiB0cnVlLCBlcnJvcnM6IFtdIH0sXG4gICAgICB9LFxuICAgICk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2Rlc3Ryb3lQYXJhbGxlbCh0eXBlOiBzdHJpbmcsIGlkczogc3RyaW5nW10sIG9wdGlvbnM6IERtbE9wdGlvbnMpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICBpZHMubWFwKChpZCkgPT5cbiAgICAgICAgdGhpcy5fZGVzdHJveVNpbmdsZSh0eXBlLCBpZCwgb3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIC8vIEJlIGF3YXJlIHRoYXQgYGFsbE9yTm9uZWAgb3B0aW9uIGluIHBhcmFsbGVsIG1vZGVcbiAgICAgICAgICAvLyB3aWxsIG5vdCByZXZlcnQgdGhlIG90aGVyIHN1Y2Nlc3NmdWwgcmVxdWVzdHMuXG4gICAgICAgICAgLy8gSXQgb25seSByYWlzZXMgZXJyb3Igd2hlbiBtZXQgYXQgbGVhc3Qgb25lIGZhaWxlZCByZXF1ZXN0LlxuICAgICAgICAgIGlmIChvcHRpb25zLmFsbE9yTm9uZSB8fCAhZXJyLmVycm9yQ29kZSkge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdG9TYXZlUmVzdWx0KGVycik7XG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9kZXN0cm95TWFueShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgaWRzOiBzdHJpbmdbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT4ge1xuICAgIGlmIChpZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChpZHMubGVuZ3RoID4gTUFYX0RNTF9DT1VOVCAmJiBvcHRpb25zLmFsbG93UmVjdXJzaXZlKSB7XG4gICAgICByZXR1cm4gW1xuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fZGVzdHJveU1hbnkoXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICBpZHMuc2xpY2UoMCwgTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgKSksXG4gICAgICAgIC4uLihhd2FpdCB0aGlzLl9kZXN0cm95TWFueSh0eXBlLCBpZHMuc2xpY2UoTUFYX0RNTF9DT1VOVCksIG9wdGlvbnMpKSxcbiAgICAgIF07XG4gICAgfVxuICAgIGxldCB1cmwgPVxuICAgICAgW3RoaXMuX2Jhc2VVcmwoKSwgJ2NvbXBvc2l0ZScsICdzb2JqZWN0cz9pZHM9J10uam9pbignLycpICsgaWRzLmpvaW4oJywnKTtcbiAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUpIHtcbiAgICAgIHVybCArPSAnJmFsbE9yTm9uZT10cnVlJztcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVyczogb3B0aW9ucy5oZWFkZXJzIHx8IHt9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQ29ubmVjdGlvbiNkZXN0cm95KClcbiAgICovXG4gIGRlbGV0ZSA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBDb25uZWN0aW9uI2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsID0gdGhpcy5kZXN0cm95O1xuXG4gIC8qKlxuICAgKiBEZXNjcmliZSBTT2JqZWN0IG1ldGFkYXRhXG4gICAqL1xuICBhc3luYyBkZXNjcmliZSh0eXBlOiBzdHJpbmcpOiBQcm9taXNlPERlc2NyaWJlU09iamVjdFJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsICdkZXNjcmliZSddLmpvaW4oJy8nKTtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgRGVzY3JpYmVTT2JqZWN0UmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIGdsb2JhbCBTT2JqZWN0c1xuICAgKi9cbiAgYXN5bmMgZGVzY3JpYmVHbG9iYWwoKSB7XG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5fYmFzZVVybCgpfS9zb2JqZWN0c2A7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlR2xvYmFsUmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBTT2JqZWN0IGluc3RhbmNlXG4gICAqL1xuICBzb2JqZWN0PE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KHR5cGU6IE4pOiBTT2JqZWN0PFMsIE4+O1xuICBzb2JqZWN0PE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KHR5cGU6IHN0cmluZyk6IFNPYmplY3Q8UywgTj47XG4gIHNvYmplY3Q8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4odHlwZTogTiB8IHN0cmluZyk6IFNPYmplY3Q8UywgTj4ge1xuICAgIGNvbnN0IHNvID1cbiAgICAgICh0aGlzLnNvYmplY3RzW3R5cGUgYXMgTl0gYXMgU09iamVjdDxTLCBOPiB8IHVuZGVmaW5lZCkgfHxcbiAgICAgIG5ldyBTT2JqZWN0KHRoaXMsIHR5cGUgYXMgTik7XG4gICAgdGhpcy5zb2JqZWN0c1t0eXBlIGFzIE5dID0gc287XG4gICAgcmV0dXJuIHNvO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBpZGVudGl0eSBpbmZvcm1hdGlvbiBvZiBjdXJyZW50IHVzZXJcbiAgICovXG4gIGFzeW5jIGlkZW50aXR5KG9wdGlvbnM6IHsgaGVhZGVycz86IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9IH0gPSB7fSkge1xuICAgIGxldCB1cmwgPSB0aGlzLnVzZXJJbmZvICYmIHRoaXMudXNlckluZm8udXJsO1xuICAgIGlmICghdXJsKSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3Q8eyBpZGVudGl0eTogc3RyaW5nIH0+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgdXJsOiB0aGlzLl9iYXNlVXJsKCksXG4gICAgICAgIGhlYWRlcnM6IG9wdGlvbnMuaGVhZGVycyxcbiAgICAgIH0pO1xuICAgICAgdXJsID0gcmVzLmlkZW50aXR5O1xuICAgIH1cbiAgICB1cmwgKz0gJz9mb3JtYXQ9anNvbic7XG4gICAgaWYgKHRoaXMuYWNjZXNzVG9rZW4pIHtcbiAgICAgIHVybCArPSBgJm9hdXRoX3Rva2VuPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHRoaXMuYWNjZXNzVG9rZW4pfWA7XG4gICAgfVxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdDxJZGVudGl0eUluZm8+KHsgbWV0aG9kOiAnR0VUJywgdXJsIH0pO1xuICAgIHRoaXMudXNlckluZm8gPSB7XG4gICAgICBpZDogcmVzLnVzZXJfaWQsXG4gICAgICBvcmdhbml6YXRpb25JZDogcmVzLm9yZ2FuaXphdGlvbl9pZCxcbiAgICAgIHVybDogcmVzLmlkLFxuICAgIH07XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuXG4gIC8qKlxuICAgKiBMaXN0IHJlY2VudGx5IHZpZXdlZCByZWNvcmRzXG4gICAqL1xuICBhc3luYyByZWNlbnQodHlwZT86IHN0cmluZyB8IG51bWJlciwgbGltaXQ/OiBudW1iZXIpIHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1wYXJhbS1yZWFzc2lnbiAqL1xuICAgIGlmICh0eXBlb2YgdHlwZSA9PT0gJ251bWJlcicpIHtcbiAgICAgIGxpbWl0ID0gdHlwZTtcbiAgICAgIHR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGxldCB1cmw7XG4gICAgaWYgKHR5cGUpIHtcbiAgICAgIHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGVdLmpvaW4oJy8nKTtcbiAgICAgIGNvbnN0IHsgcmVjZW50SXRlbXMgfSA9IGF3YWl0IHRoaXMucmVxdWVzdDx7IHJlY2VudEl0ZW1zOiBSZWNvcmRbXSB9PihcbiAgICAgICAgdXJsLFxuICAgICAgKTtcbiAgICAgIHJldHVybiBsaW1pdCA/IHJlY2VudEl0ZW1zLnNsaWNlKDAsIGxpbWl0KSA6IHJlY2VudEl0ZW1zO1xuICAgIH1cbiAgICB1cmwgPSBgJHt0aGlzLl9iYXNlVXJsKCl9L3JlY2VudGA7XG4gICAgaWYgKGxpbWl0KSB7XG4gICAgICB1cmwgKz0gYD9saW1pdD0ke2xpbWl0fWA7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8UmVjb3JkW10+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgdXBkYXRlZCByZWNvcmRzXG4gICAqL1xuICBhc3luYyB1cGRhdGVkKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBzdGFydDogc3RyaW5nIHwgRGF0ZSxcbiAgICBlbmQ6IHN0cmluZyB8IERhdGUsXG4gICk6IFByb21pc2U8VXBkYXRlZFJlc3VsdD4ge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgbGV0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsICd1cGRhdGVkJ10uam9pbignLycpO1xuICAgIGlmICh0eXBlb2Ygc3RhcnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBzdGFydCA9IG5ldyBEYXRlKHN0YXJ0KTtcbiAgICB9XG4gICAgc3RhcnQgPSBmb3JtYXREYXRlKHN0YXJ0KTtcbiAgICB1cmwgKz0gYD9zdGFydD0ke2VuY29kZVVSSUNvbXBvbmVudChzdGFydCl9YDtcbiAgICBpZiAodHlwZW9mIGVuZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuZCA9IG5ldyBEYXRlKGVuZCk7XG4gICAgfVxuICAgIGVuZCA9IGZvcm1hdERhdGUoZW5kKTtcbiAgICB1cmwgKz0gYCZlbmQ9JHtlbmNvZGVVUklDb21wb25lbnQoZW5kKX1gO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBVcGRhdGVkUmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIGRlbGV0ZWQgcmVjb3Jkc1xuICAgKi9cbiAgYXN5bmMgZGVsZXRlZChcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgc3RhcnQ6IHN0cmluZyB8IERhdGUsXG4gICAgZW5kOiBzdHJpbmcgfCBEYXRlLFxuICApOiBQcm9taXNlPERlbGV0ZWRSZXN1bHQ+IHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1wYXJhbS1yZWFzc2lnbiAqL1xuICAgIGxldCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlLCAnZGVsZXRlZCddLmpvaW4oJy8nKTtcbiAgICBpZiAodHlwZW9mIHN0YXJ0ID09PSAnc3RyaW5nJykge1xuICAgICAgc3RhcnQgPSBuZXcgRGF0ZShzdGFydCk7XG4gICAgfVxuICAgIHN0YXJ0ID0gZm9ybWF0RGF0ZShzdGFydCk7XG4gICAgdXJsICs9IGA/c3RhcnQ9JHtlbmNvZGVVUklDb21wb25lbnQoc3RhcnQpfWA7XG5cbiAgICBpZiAodHlwZW9mIGVuZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuZCA9IG5ldyBEYXRlKGVuZCk7XG4gICAgfVxuICAgIGVuZCA9IGZvcm1hdERhdGUoZW5kKTtcbiAgICB1cmwgKz0gYCZlbmQ9JHtlbmNvZGVVUklDb21wb25lbnQoZW5kKX1gO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZWxldGVkUmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBsaXN0IG9mIGFsbCB0YWJzXG4gICAqL1xuICBhc3luYyB0YWJzKCk6IFByb21pc2U8RGVzY3JpYmVUYWJbXT4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICd0YWJzJ10uam9pbignLycpO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZVRhYltdO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgY3VycmVudCBzeXN0ZW0gbGltaXQgaW4gdGhlIG9yZ2FuaXphdGlvblxuICAgKi9cbiAgYXN5bmMgbGltaXRzKCk6IFByb21pc2U8T3JnYW5pemF0aW9uTGltaXRzSW5mbz4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdsaW1pdHMnXS5qb2luKCcvJyk7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIE9yZ2FuaXphdGlvbkxpbWl0c0luZm87XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIHRoZW1lIGluZm9cbiAgICovXG4gIGFzeW5jIHRoZW1lKCk6IFByb21pc2U8RGVzY3JpYmVUaGVtZT4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICd0aGVtZSddLmpvaW4oJy8nKTtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgRGVzY3JpYmVUaGVtZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFsbCByZWdpc3RlcmVkIGdsb2JhbCBxdWljayBhY3Rpb25zXG4gICAqL1xuICBhc3luYyBxdWlja0FjdGlvbnMoKTogUHJvbWlzZTxEZXNjcmliZVF1aWNrQWN0aW9uUmVzdWx0W10+IHtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KCcvcXVpY2tBY3Rpb25zJyk7XG4gICAgcmV0dXJuIGJvZHkgYXMgRGVzY3JpYmVRdWlja0FjdGlvblJlc3VsdFtdO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZWZlcmVuY2UgZm9yIHNwZWNpZmllZCBnbG9iYWwgcXVpY2sgYWN0aW9uXG4gICAqL1xuICBxdWlja0FjdGlvbihhY3Rpb25OYW1lOiBzdHJpbmcpOiBRdWlja0FjdGlvbjxTPiB7XG4gICAgcmV0dXJuIG5ldyBRdWlja0FjdGlvbih0aGlzLCBgL3F1aWNrQWN0aW9ucy8ke2FjdGlvbk5hbWV9YCk7XG4gIH1cblxuICAvKipcbiAgICogTW9kdWxlIHdoaWNoIG1hbmFnZXMgcHJvY2VzcyBydWxlcyBhbmQgYXBwcm92YWwgcHJvY2Vzc2VzXG4gICAqL1xuICBwcm9jZXNzID0gbmV3IFByb2Nlc3ModGhpcyk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbm5lY3Rpb247XG4iXX0=