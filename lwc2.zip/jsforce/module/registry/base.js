import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import Connection from '../connection';

/**
 *
 */
export class BaseRegistry {
  constructor() {
    _defineProperty(this, "_registryConfig", {});
  }

  _saveConfig() {
    throw new Error('_saveConfig must be implemented in subclass');
  }

  _getClients() {
    return this._registryConfig.clients || (this._registryConfig.clients = {});
  }

  _getConnections() {
    return this._registryConfig.connections || (this._registryConfig.connections = {});
  }

  async getConnectionNames() {
    return _Object$keys(this._getConnections());
  }

  async getConnection(name) {
    const config = await this.getConnectionConfig(name);
    return config ? new Connection(config) : null;
  }

  async getConnectionConfig(name) {
    if (!name) {
      name = this._registryConfig['default'];
    }

    const connections = this._getConnections();

    const connConfig = name ? connections[name] : undefined;

    if (!connConfig) {
      return null;
    }

    const {
      client
    } = connConfig,
          connConfig_ = _objectWithoutProperties(connConfig, ["client"]);

    if (client) {
      return _objectSpread(_objectSpread({}, connConfig_), {}, {
        oauth2: _objectSpread({}, await this.getClientConfig(client))
      });
    }

    return connConfig_;
  }

  async saveConnectionConfig(name, connConfig) {
    const connections = this._getConnections();

    const {
      oauth2
    } = connConfig,
          connConfig_ = _objectWithoutProperties(connConfig, ["oauth2"]);

    let persistConnConfig = connConfig_;

    if (oauth2) {
      const clientName = this._findClientName(oauth2);

      if (clientName) {
        persistConnConfig = _objectSpread(_objectSpread({}, persistConnConfig), {}, {
          client: clientName
        });
      }

      delete connConfig.oauth2;
    }

    connections[name] = persistConnConfig;

    this._saveConfig();
  }

  _findClientName({
    clientId,
    loginUrl
  }) {
    const clients = this._getClients();

    for (const name of _Object$keys(clients)) {
      const client = clients[name];

      if (client.clientId === clientId && (client.loginUrl || 'https://login.salesforce.com') === loginUrl) {
        return name;
      }
    }

    return null;
  }

  async setDefaultConnection(name) {
    this._registryConfig['default'] = name;

    this._saveConfig();
  }

  async removeConnectionConfig(name) {
    const connections = this._getConnections();

    delete connections[name];

    this._saveConfig();
  }

  async getClientConfig(name) {
    const clients = this._getClients();

    const clientConfig = clients[name];
    return clientConfig && _objectSpread({}, clientConfig);
  }

  async getClientNames() {
    return _Object$keys(this._getClients());
  }

  async registerClientConfig(name, clientConfig) {
    const clients = this._getClients();

    clients[name] = clientConfig;

    this._saveConfig();
  }

}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWdpc3RyeS9iYXNlLnRzIl0sIm5hbWVzIjpbIkNvbm5lY3Rpb24iLCJCYXNlUmVnaXN0cnkiLCJfc2F2ZUNvbmZpZyIsIkVycm9yIiwiX2dldENsaWVudHMiLCJfcmVnaXN0cnlDb25maWciLCJjbGllbnRzIiwiX2dldENvbm5lY3Rpb25zIiwiY29ubmVjdGlvbnMiLCJnZXRDb25uZWN0aW9uTmFtZXMiLCJnZXRDb25uZWN0aW9uIiwibmFtZSIsImNvbmZpZyIsImdldENvbm5lY3Rpb25Db25maWciLCJjb25uQ29uZmlnIiwidW5kZWZpbmVkIiwiY2xpZW50IiwiY29ubkNvbmZpZ18iLCJvYXV0aDIiLCJnZXRDbGllbnRDb25maWciLCJzYXZlQ29ubmVjdGlvbkNvbmZpZyIsInBlcnNpc3RDb25uQ29uZmlnIiwiY2xpZW50TmFtZSIsIl9maW5kQ2xpZW50TmFtZSIsImNsaWVudElkIiwibG9naW5VcmwiLCJzZXREZWZhdWx0Q29ubmVjdGlvbiIsInJlbW92ZUNvbm5lY3Rpb25Db25maWciLCJjbGllbnRDb25maWciLCJnZXRDbGllbnROYW1lcyIsInJlZ2lzdGVyQ2xpZW50Q29uZmlnIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLFVBQVAsTUFBdUIsZUFBdkI7O0FBVUE7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQyxZQUFOLENBQXVDO0FBQUE7QUFBQSw2Q0FDVixFQURVO0FBQUE7O0FBRzVDQyxFQUFBQSxXQUFXLEdBQUc7QUFDWixVQUFNLElBQUlDLEtBQUosQ0FBVSw2Q0FBVixDQUFOO0FBQ0Q7O0FBRURDLEVBQUFBLFdBQVcsR0FBRztBQUNaLFdBQU8sS0FBS0MsZUFBTCxDQUFxQkMsT0FBckIsS0FBaUMsS0FBS0QsZUFBTCxDQUFxQkMsT0FBckIsR0FBK0IsRUFBaEUsQ0FBUDtBQUNEOztBQUVEQyxFQUFBQSxlQUFlLEdBQUc7QUFDaEIsV0FDRSxLQUFLRixlQUFMLENBQXFCRyxXQUFyQixLQUNDLEtBQUtILGVBQUwsQ0FBcUJHLFdBQXJCLEdBQW1DLEVBRHBDLENBREY7QUFJRDs7QUFFRCxRQUFNQyxrQkFBTixHQUEyQjtBQUN6QixXQUFPLGFBQVksS0FBS0YsZUFBTCxFQUFaLENBQVA7QUFDRDs7QUFFRCxRQUFNRyxhQUFOLENBQStDQyxJQUEvQyxFQUE2RDtBQUMzRCxVQUFNQyxNQUFNLEdBQUcsTUFBTSxLQUFLQyxtQkFBTCxDQUF5QkYsSUFBekIsQ0FBckI7QUFDQSxXQUFPQyxNQUFNLEdBQUcsSUFBSVosVUFBSixDQUFrQlksTUFBbEIsQ0FBSCxHQUErQixJQUE1QztBQUNEOztBQUVELFFBQU1DLG1CQUFOLENBQTBCRixJQUExQixFQUF5QztBQUN2QyxRQUFJLENBQUNBLElBQUwsRUFBVztBQUNUQSxNQUFBQSxJQUFJLEdBQUcsS0FBS04sZUFBTCxDQUFxQixTQUFyQixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTUcsV0FBVyxHQUFHLEtBQUtELGVBQUwsRUFBcEI7O0FBQ0EsVUFBTU8sVUFBVSxHQUFHSCxJQUFJLEdBQUdILFdBQVcsQ0FBQ0csSUFBRCxDQUFkLEdBQXVCSSxTQUE5Qzs7QUFDQSxRQUFJLENBQUNELFVBQUwsRUFBaUI7QUFDZixhQUFPLElBQVA7QUFDRDs7QUFDRCxVQUFNO0FBQUVFLE1BQUFBO0FBQUYsUUFBNkJGLFVBQW5DO0FBQUEsVUFBbUJHLFdBQW5CLDRCQUFtQ0gsVUFBbkM7O0FBQ0EsUUFBSUUsTUFBSixFQUFZO0FBQ1YsNkNBQ0tDLFdBREw7QUFFRUMsUUFBQUEsTUFBTSxvQkFBUSxNQUFNLEtBQUtDLGVBQUwsQ0FBcUJILE1BQXJCLENBQWQ7QUFGUjtBQUlEOztBQUNELFdBQU9DLFdBQVA7QUFDRDs7QUFFRCxRQUFNRyxvQkFBTixDQUEyQlQsSUFBM0IsRUFBeUNHLFVBQXpDLEVBQXVFO0FBQ3JFLFVBQU1OLFdBQVcsR0FBRyxLQUFLRCxlQUFMLEVBQXBCOztBQUNBLFVBQU07QUFBRVcsTUFBQUE7QUFBRixRQUE2QkosVUFBbkM7QUFBQSxVQUFtQkcsV0FBbkIsNEJBQW1DSCxVQUFuQzs7QUFDQSxRQUFJTyxpQkFBMEMsR0FBR0osV0FBakQ7O0FBQ0EsUUFBSUMsTUFBSixFQUFZO0FBQ1YsWUFBTUksVUFBVSxHQUFHLEtBQUtDLGVBQUwsQ0FBcUJMLE1BQXJCLENBQW5COztBQUNBLFVBQUlJLFVBQUosRUFBZ0I7QUFDZEQsUUFBQUEsaUJBQWlCLG1DQUFRQSxpQkFBUjtBQUEyQkwsVUFBQUEsTUFBTSxFQUFFTTtBQUFuQyxVQUFqQjtBQUNEOztBQUNELGFBQU9SLFVBQVUsQ0FBQ0ksTUFBbEI7QUFDRDs7QUFDRFYsSUFBQUEsV0FBVyxDQUFDRyxJQUFELENBQVgsR0FBb0JVLGlCQUFwQjs7QUFDQSxTQUFLbkIsV0FBTDtBQUNEOztBQUVEcUIsRUFBQUEsZUFBZSxDQUFDO0FBQUVDLElBQUFBLFFBQUY7QUFBWUMsSUFBQUE7QUFBWixHQUFELEVBQXVDO0FBQ3BELFVBQU1uQixPQUFPLEdBQUcsS0FBS0YsV0FBTCxFQUFoQjs7QUFDQSxTQUFLLE1BQU1PLElBQVgsSUFBbUIsYUFBWUwsT0FBWixDQUFuQixFQUF5QztBQUN2QyxZQUFNVSxNQUFNLEdBQUdWLE9BQU8sQ0FBQ0ssSUFBRCxDQUF0Qjs7QUFDQSxVQUNFSyxNQUFNLENBQUNRLFFBQVAsS0FBb0JBLFFBQXBCLElBQ0EsQ0FBQ1IsTUFBTSxDQUFDUyxRQUFQLElBQW1CLDhCQUFwQixNQUF3REEsUUFGMUQsRUFHRTtBQUNBLGVBQU9kLElBQVA7QUFDRDtBQUNGOztBQUNELFdBQU8sSUFBUDtBQUNEOztBQUVELFFBQU1lLG9CQUFOLENBQTJCZixJQUEzQixFQUF5QztBQUN2QyxTQUFLTixlQUFMLENBQXFCLFNBQXJCLElBQWtDTSxJQUFsQzs7QUFDQSxTQUFLVCxXQUFMO0FBQ0Q7O0FBRUQsUUFBTXlCLHNCQUFOLENBQTZCaEIsSUFBN0IsRUFBMkM7QUFDekMsVUFBTUgsV0FBVyxHQUFHLEtBQUtELGVBQUwsRUFBcEI7O0FBQ0EsV0FBT0MsV0FBVyxDQUFDRyxJQUFELENBQWxCOztBQUNBLFNBQUtULFdBQUw7QUFDRDs7QUFFRCxRQUFNaUIsZUFBTixDQUFzQlIsSUFBdEIsRUFBb0M7QUFDbEMsVUFBTUwsT0FBTyxHQUFHLEtBQUtGLFdBQUwsRUFBaEI7O0FBQ0EsVUFBTXdCLFlBQVksR0FBR3RCLE9BQU8sQ0FBQ0ssSUFBRCxDQUE1QjtBQUNBLFdBQU9pQixZQUFZLHNCQUFTQSxZQUFULENBQW5CO0FBQ0Q7O0FBRUQsUUFBTUMsY0FBTixHQUF1QjtBQUNyQixXQUFPLGFBQVksS0FBS3pCLFdBQUwsRUFBWixDQUFQO0FBQ0Q7O0FBRUQsUUFBTTBCLG9CQUFOLENBQTJCbkIsSUFBM0IsRUFBeUNpQixZQUF6QyxFQUFxRTtBQUNuRSxVQUFNdEIsT0FBTyxHQUFHLEtBQUtGLFdBQUwsRUFBaEI7O0FBQ0FFLElBQUFBLE9BQU8sQ0FBQ0ssSUFBRCxDQUFQLEdBQWdCaUIsWUFBaEI7O0FBQ0EsU0FBSzFCLFdBQUw7QUFDRDs7QUFwRzJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQge1xuICBSZWdpc3RyeUNvbmZpZyxcbiAgUmVnaXN0cnksXG4gIENvbm5lY3Rpb25Db25maWcsXG4gIFBlcnNpc3RDb25uZWN0aW9uQ29uZmlnLFxuICBDbGllbnRDb25maWcsXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBjbGFzcyBCYXNlUmVnaXN0cnkgaW1wbGVtZW50cyBSZWdpc3RyeSB7XG4gIF9yZWdpc3RyeUNvbmZpZzogUmVnaXN0cnlDb25maWcgPSB7fTtcblxuICBfc2F2ZUNvbmZpZygpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ19zYXZlQ29uZmlnIG11c3QgYmUgaW1wbGVtZW50ZWQgaW4gc3ViY2xhc3MnKTtcbiAgfVxuXG4gIF9nZXRDbGllbnRzKCkge1xuICAgIHJldHVybiB0aGlzLl9yZWdpc3RyeUNvbmZpZy5jbGllbnRzIHx8ICh0aGlzLl9yZWdpc3RyeUNvbmZpZy5jbGllbnRzID0ge30pO1xuICB9XG5cbiAgX2dldENvbm5lY3Rpb25zKCkge1xuICAgIHJldHVybiAoXG4gICAgICB0aGlzLl9yZWdpc3RyeUNvbmZpZy5jb25uZWN0aW9ucyB8fFxuICAgICAgKHRoaXMuX3JlZ2lzdHJ5Q29uZmlnLmNvbm5lY3Rpb25zID0ge30pXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGdldENvbm5lY3Rpb25OYW1lcygpIHtcbiAgICByZXR1cm4gT2JqZWN0LmtleXModGhpcy5fZ2V0Q29ubmVjdGlvbnMoKSk7XG4gIH1cblxuICBhc3luYyBnZXRDb25uZWN0aW9uPFMgZXh0ZW5kcyBTY2hlbWEgPSBTY2hlbWE+KG5hbWU6IHN0cmluZykge1xuICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IHRoaXMuZ2V0Q29ubmVjdGlvbkNvbmZpZyhuYW1lKTtcbiAgICByZXR1cm4gY29uZmlnID8gbmV3IENvbm5lY3Rpb248Uz4oY29uZmlnKSA6IG51bGw7XG4gIH1cblxuICBhc3luYyBnZXRDb25uZWN0aW9uQ29uZmlnKG5hbWU/OiBzdHJpbmcpIHtcbiAgICBpZiAoIW5hbWUpIHtcbiAgICAgIG5hbWUgPSB0aGlzLl9yZWdpc3RyeUNvbmZpZ1snZGVmYXVsdCddO1xuICAgIH1cbiAgICBjb25zdCBjb25uZWN0aW9ucyA9IHRoaXMuX2dldENvbm5lY3Rpb25zKCk7XG4gICAgY29uc3QgY29ubkNvbmZpZyA9IG5hbWUgPyBjb25uZWN0aW9uc1tuYW1lXSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoIWNvbm5Db25maWcpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB7IGNsaWVudCwgLi4uY29ubkNvbmZpZ18gfSA9IGNvbm5Db25maWc7XG4gICAgaWYgKGNsaWVudCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uY29ubkNvbmZpZ18sXG4gICAgICAgIG9hdXRoMjogeyAuLi4oYXdhaXQgdGhpcy5nZXRDbGllbnRDb25maWcoY2xpZW50KSkgfSxcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBjb25uQ29uZmlnXztcbiAgfVxuXG4gIGFzeW5jIHNhdmVDb25uZWN0aW9uQ29uZmlnKG5hbWU6IHN0cmluZywgY29ubkNvbmZpZzogQ29ubmVjdGlvbkNvbmZpZykge1xuICAgIGNvbnN0IGNvbm5lY3Rpb25zID0gdGhpcy5fZ2V0Q29ubmVjdGlvbnMoKTtcbiAgICBjb25zdCB7IG9hdXRoMiwgLi4uY29ubkNvbmZpZ18gfSA9IGNvbm5Db25maWc7XG4gICAgbGV0IHBlcnNpc3RDb25uQ29uZmlnOiBQZXJzaXN0Q29ubmVjdGlvbkNvbmZpZyA9IGNvbm5Db25maWdfO1xuICAgIGlmIChvYXV0aDIpIHtcbiAgICAgIGNvbnN0IGNsaWVudE5hbWUgPSB0aGlzLl9maW5kQ2xpZW50TmFtZShvYXV0aDIpO1xuICAgICAgaWYgKGNsaWVudE5hbWUpIHtcbiAgICAgICAgcGVyc2lzdENvbm5Db25maWcgPSB7IC4uLnBlcnNpc3RDb25uQ29uZmlnLCBjbGllbnQ6IGNsaWVudE5hbWUgfTtcbiAgICAgIH1cbiAgICAgIGRlbGV0ZSBjb25uQ29uZmlnLm9hdXRoMjtcbiAgICB9XG4gICAgY29ubmVjdGlvbnNbbmFtZV0gPSBwZXJzaXN0Q29ubkNvbmZpZztcbiAgICB0aGlzLl9zYXZlQ29uZmlnKCk7XG4gIH1cblxuICBfZmluZENsaWVudE5hbWUoeyBjbGllbnRJZCwgbG9naW5VcmwgfTogQ2xpZW50Q29uZmlnKSB7XG4gICAgY29uc3QgY2xpZW50cyA9IHRoaXMuX2dldENsaWVudHMoKTtcbiAgICBmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoY2xpZW50cykpIHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNsaWVudHNbbmFtZV07XG4gICAgICBpZiAoXG4gICAgICAgIGNsaWVudC5jbGllbnRJZCA9PT0gY2xpZW50SWQgJiZcbiAgICAgICAgKGNsaWVudC5sb2dpblVybCB8fCAnaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbScpID09PSBsb2dpblVybFxuICAgICAgKSB7XG4gICAgICAgIHJldHVybiBuYW1lO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGFzeW5jIHNldERlZmF1bHRDb25uZWN0aW9uKG5hbWU6IHN0cmluZykge1xuICAgIHRoaXMuX3JlZ2lzdHJ5Q29uZmlnWydkZWZhdWx0J10gPSBuYW1lO1xuICAgIHRoaXMuX3NhdmVDb25maWcoKTtcbiAgfVxuXG4gIGFzeW5jIHJlbW92ZUNvbm5lY3Rpb25Db25maWcobmFtZTogc3RyaW5nKSB7XG4gICAgY29uc3QgY29ubmVjdGlvbnMgPSB0aGlzLl9nZXRDb25uZWN0aW9ucygpO1xuICAgIGRlbGV0ZSBjb25uZWN0aW9uc1tuYW1lXTtcbiAgICB0aGlzLl9zYXZlQ29uZmlnKCk7XG4gIH1cblxuICBhc3luYyBnZXRDbGllbnRDb25maWcobmFtZTogc3RyaW5nKSB7XG4gICAgY29uc3QgY2xpZW50cyA9IHRoaXMuX2dldENsaWVudHMoKTtcbiAgICBjb25zdCBjbGllbnRDb25maWcgPSBjbGllbnRzW25hbWVdO1xuICAgIHJldHVybiBjbGllbnRDb25maWcgJiYgeyAuLi5jbGllbnRDb25maWcgfTtcbiAgfVxuXG4gIGFzeW5jIGdldENsaWVudE5hbWVzKCkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLl9nZXRDbGllbnRzKCkpO1xuICB9XG5cbiAgYXN5bmMgcmVnaXN0ZXJDbGllbnRDb25maWcobmFtZTogc3RyaW5nLCBjbGllbnRDb25maWc6IENsaWVudENvbmZpZykge1xuICAgIGNvbnN0IGNsaWVudHMgPSB0aGlzLl9nZXRDbGllbnRzKCk7XG4gICAgY2xpZW50c1tuYW1lXSA9IGNsaWVudENvbmZpZztcbiAgICB0aGlzLl9zYXZlQ29uZmlnKCk7XG4gIH1cbn1cbiJdfQ==