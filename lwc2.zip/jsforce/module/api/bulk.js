import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import "core-js/modules/es.string.replace";
import _WeakMap from "@babel/runtime-corejs3/core-js-stable/weak-map";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _classPrivateFieldGet from "@babel/runtime-corejs3/helpers/classPrivateFieldGet";
import _classPrivateFieldSet from "@babel/runtime-corejs3/helpers/classPrivateFieldSet";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _trimInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/trim";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source), true)).call(_context4, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context5; _forEachInstanceProperty(_context5 = ownKeys(Object(source))).call(_context5, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Bulk API related operations
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Writable } from 'stream';
import joinStreams from 'multistream';
import { Serializable, Parsable } from '../record-stream';
import HttpApi from '../http-api';
import { registerModule } from '../jsforce';
import { concatStreamsAsDuplex } from '../util/stream';
import { isFunction, isObject } from '../util/function';
/*--------------------------------------------*/

/**
 * Class for Bulk API Job
 */
export class Job extends EventEmitter {
  /**
   *
   */
  constructor(bulk, type, operation, options, jobId) {
    super();

    _defineProperty(this, "type", void 0);

    _defineProperty(this, "operation", void 0);

    _defineProperty(this, "options", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "state", void 0);

    _defineProperty(this, "_bulk", void 0);

    _defineProperty(this, "_batches", void 0);

    _defineProperty(this, "_jobInfo", void 0);

    _defineProperty(this, "_error", void 0);

    this._bulk = bulk;
    this.type = type;
    this.operation = operation;
    this.options = options || {};
    this.id = jobId !== null && jobId !== void 0 ? jobId : null;
    this.state = this.id ? 'Open' : 'Unknown';
    this._batches = {}; // default error handler to keep the latest error

    this.on('error', error => this._error = error);
  }
  /**
   * Return latest jobInfo from cache
   */


  info() {
    // if cache is not available, check the latest
    if (!this._jobInfo) {
      this._jobInfo = this.check();
    }

    return this._jobInfo;
  }
  /**
   * Open new job and get jobinfo
   */


  open() {
    const bulk = this._bulk;
    const options = this.options; // if sobject type / operation is not provided

    if (!this.type || !this.operation) {
      throw new Error('type / operation is required to open a new job');
    } // if not requested opening job


    if (!this._jobInfo) {
      var _context;

      let operation = this.operation.toLowerCase();

      if (operation === 'harddelete') {
        operation = 'hardDelete';
      }

      if (operation === 'queryall') {
        operation = 'queryAll';
      }

      const body = _trimInstanceProperty(_context = `
<?xml version="1.0" encoding="UTF-8"?>
<jobInfo  xmlns="http://www.force.com/2009/06/asyncapi/dataload">
  <operation>${operation}</operation>
  <object>${this.type}</object>
  ${options.extIdField ? `<externalIdFieldName>${options.extIdField}</externalIdFieldName>` : ''}
  ${options.concurrencyMode ? `<concurrencyMode>${options.concurrencyMode}</concurrencyMode>` : ''}
  ${options.assignmentRuleId ? `<assignmentRuleId>${options.assignmentRuleId}</assignmentRuleId>` : ''}
  <contentType>CSV</contentType>
</jobInfo>
      `).call(_context);

      this._jobInfo = (async () => {
        try {
          const res = await bulk._request({
            method: 'POST',
            path: '/job',
            body,
            headers: {
              'Content-Type': 'application/xml; charset=utf-8'
            },
            responseType: 'application/xml'
          });
          this.emit('open', res.jobInfo);
          this.id = res.jobInfo.id;
          this.state = res.jobInfo.state;
          return res.jobInfo;
        } catch (err) {
          this.emit('error', err);
          throw err;
        }
      })();
    }

    return this._jobInfo;
  }
  /**
   * Create a new batch instance in the job
   */


  createBatch() {
    const batch = new Batch(this);
    batch.on('queue', () => {
      this._batches[batch.id] = batch;
    });
    return batch;
  }
  /**
   * Get a batch instance specified by given batch ID
   */


  batch(batchId) {
    let batch = this._batches[batchId];

    if (!batch) {
      batch = new Batch(this, batchId);
      this._batches[batchId] = batch;
    }

    return batch;
  }
  /**
   * Check the latest job status from server
   */


  check() {
    const bulk = this._bulk;
    const logger = bulk._logger;

    this._jobInfo = (async () => {
      const jobId = await this.ready();
      const res = await bulk._request({
        method: 'GET',
        path: '/job/' + jobId,
        responseType: 'application/xml'
      });
      logger.debug(res.jobInfo);
      this.id = res.jobInfo.id;
      this.type = res.jobInfo.object;
      this.operation = res.jobInfo.operation;
      this.state = res.jobInfo.state;
      return res.jobInfo;
    })();

    return this._jobInfo;
  }
  /**
   * Wait till the job is assigned to server
   */


  ready() {
    return this.id ? _Promise.resolve(this.id) : this.open().then(({
      id
    }) => id);
  }
  /**
   * List all registered batch info in job
   */


  async list() {
    const bulk = this._bulk;
    const logger = bulk._logger;
    const jobId = await this.ready();
    const res = await bulk._request({
      method: 'GET',
      path: '/job/' + jobId + '/batch',
      responseType: 'application/xml'
    });
    logger.debug(res.batchInfoList.batchInfo);
    const batchInfoList = _Array$isArray(res.batchInfoList.batchInfo) ? res.batchInfoList.batchInfo : [res.batchInfoList.batchInfo];
    return batchInfoList;
  }
  /**
   * Close opened job
   */


  async close() {
    if (!this.id) {
      return;
    }

    try {
      const jobInfo = await this._changeState('Closed');
      this.id = null;
      this.emit('close', jobInfo);
      return jobInfo;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  /**
   * Set the status to abort
   */


  async abort() {
    if (!this.id) {
      return;
    }

    try {
      const jobInfo = await this._changeState('Aborted');
      this.id = null;
      this.emit('abort', jobInfo);
      return jobInfo;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  /**
   * @private
   */


  async _changeState(state) {
    const bulk = this._bulk;
    const logger = bulk._logger;

    this._jobInfo = (async () => {
      var _context2;

      const jobId = await this.ready();

      const body = _trimInstanceProperty(_context2 = ` 
<?xml version="1.0" encoding="UTF-8"?>
  <jobInfo xmlns="http://www.force.com/2009/06/asyncapi/dataload">
  <state>${state}</state>
</jobInfo>
      `).call(_context2);

      const res = await bulk._request({
        method: 'POST',
        path: '/job/' + jobId,
        body: body,
        headers: {
          'Content-Type': 'application/xml; charset=utf-8'
        },
        responseType: 'application/xml'
      });
      logger.debug(res.jobInfo);
      this.state = res.jobInfo.state;
      return res.jobInfo;
    })();

    return this._jobInfo;
  }

}
/*--------------------------------------------*/

class PollingTimeoutError extends Error {
  /**
   *
   */
  constructor(message, jobId, batchId) {
    super(message);

    _defineProperty(this, "jobId", void 0);

    _defineProperty(this, "batchId", void 0);

    this.name = 'PollingTimeout';
    this.jobId = jobId;
    this.batchId = batchId;
  }

}

class JobPollingTimeoutError extends Error {
  /**
   *
   */
  constructor(message, jobId) {
    super(message);

    _defineProperty(this, "jobId", void 0);

    this.name = 'JobPollingTimeout';
    this.jobId = jobId;
  }

}
/*--------------------------------------------*/

/**
 * Batch (extends Writable)
 */


export class Batch extends Writable {
  /**
   *
   */
  constructor(job, id) {
    super({
      objectMode: true
    });

    _defineProperty(this, "job", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "_bulk", void 0);

    _defineProperty(this, "_uploadStream", void 0);

    _defineProperty(this, "_downloadStream", void 0);

    _defineProperty(this, "_dataStream", void 0);

    _defineProperty(this, "_result", void 0);

    _defineProperty(this, "_error", void 0);

    _defineProperty(this, "run", this.execute);

    _defineProperty(this, "exec", this.execute);

    this.job = job;
    this.id = id;
    this._bulk = job._bulk; // default error handler to keep the latest error

    this.on('error', error => this._error = error); //
    // setup data streams
    //

    const converterOptions = {
      nullValue: '#N/A'
    };
    const uploadStream = this._uploadStream = new Serializable();
    const uploadDataStream = uploadStream.stream('csv', converterOptions);
    const downloadStream = this._downloadStream = new Parsable();
    const downloadDataStream = downloadStream.stream('csv', converterOptions);
    this.on('finish', () => uploadStream.end());
    uploadDataStream.once('readable', async () => {
      try {
        // ensure the job is opened in server or job id is already assigned
        await this.job.ready(); // pipe upload data to batch API request stream

        uploadDataStream.pipe(this._createRequestStream());
      } catch (err) {
        this.emit('error', err);
      }
    }); // duplex data stream, opened access to API programmers by Batch#stream()

    this._dataStream = concatStreamsAsDuplex(uploadDataStream, downloadDataStream);
  }
  /**
   * Connect batch API and create stream instance of request/response
   *
   * @private
   */


  _createRequestStream() {
    const bulk = this._bulk;
    const logger = bulk._logger;

    const req = bulk._request({
      method: 'POST',
      path: '/job/' + this.job.id + '/batch',
      headers: {
        'Content-Type': 'text/csv'
      },
      responseType: 'application/xml'
    });

    (async () => {
      try {
        const res = await req;
        logger.debug(res.batchInfo);
        this.id = res.batchInfo.id;
        this.emit('queue', res.batchInfo);
      } catch (err) {
        this.emit('error', err);
      }
    })();

    return req.stream();
  }
  /**
   * Implementation of Writable
   */


  _write(record_, enc, cb) {
    const {
      Id,
      type,
      attributes
    } = record_,
          rrec = _objectWithoutProperties(record_, ["Id", "type", "attributes"]);

    let record;

    switch (this.job.operation) {
      case 'insert':
        record = rrec;
        break;

      case 'delete':
      case 'hardDelete':
        record = {
          Id
        };
        break;

      default:
        record = _objectSpread({
          Id
        }, rrec);
    }

    this._uploadStream.write(record, enc, cb);
  }
  /**
   * Returns duplex stream which accepts CSV data input and batch result output
   */


  stream() {
    return this._dataStream;
  }
  /**
   * Execute batch operation
   */


  execute(input) {
    // if batch is already executed
    if (this._result) {
      throw new Error('Batch already executed.');
    }

    this._result = new _Promise((resolve, reject) => {
      this.once('response', resolve);
      this.once('error', reject);
    });

    if (isObject(input) && 'pipe' in input && isFunction(input.pipe)) {
      // if input has stream.Readable interface
      input.pipe(this._dataStream);
    } else {
      if (_Array$isArray(input)) {
        for (const record of input) {
          for (const key of _Object$keys(record)) {
            if (typeof record[key] === 'boolean') {
              record[key] = String(record[key]);
            }
          }

          this.write(record);
        }

        this.end();
      } else if (typeof input === 'string') {
        this._dataStream.write(input, 'utf8');

        this._dataStream.end();
      }
    } // return Batch instance for chaining


    return this;
  }

  /**
   * Promise/A+ interface
   * Delegate to promise, return promise instance for batch result
   */
  then(onResolved, onReject) {
    if (!this._result) {
      this.execute();
    }

    return this._result.then(onResolved, onReject);
  }
  /**
   * Check the latest batch status in server
   */


  async check() {
    const bulk = this._bulk;
    const logger = bulk._logger;
    const jobId = this.job.id;
    const batchId = this.id;

    if (!jobId || !batchId) {
      throw new Error('Batch not started.');
    }

    const res = await bulk._request({
      method: 'GET',
      path: '/job/' + jobId + '/batch/' + batchId,
      responseType: 'application/xml'
    });
    logger.debug(res.batchInfo);
    return res.batchInfo;
  }
  /**
   * Polling the batch result and retrieve
   */


  poll(interval, timeout) {
    const jobId = this.job.id;
    const batchId = this.id;

    if (!jobId || !batchId) {
      throw new Error('Batch not started.');
    }

    const startTime = new Date().getTime();

    const poll = async () => {
      const now = new Date().getTime();

      if (startTime + timeout < now) {
        const err = new PollingTimeoutError('Polling time out. Job Id = ' + jobId + ' , batch Id = ' + batchId, jobId, batchId);
        this.emit('error', err);
        return;
      }

      let res;

      try {
        res = await this.check();
      } catch (err) {
        this.emit('error', err);
        return;
      }

      if (res.state === 'Failed') {
        if (_parseInt(res.numberRecordsProcessed, 10) > 0) {
          this.retrieve();
        } else {
          this.emit('error', new Error(res.stateMessage));
        }
      } else if (res.state === 'Completed') {
        this.retrieve();
      } else {
        this.emit('progress', res);

        _setTimeout(poll, interval);
      }
    };

    _setTimeout(poll, interval);
  }
  /**
   * Retrieve batch result
   */


  async retrieve() {
    const bulk = this._bulk;
    const jobId = this.job.id;
    const job = this.job;
    const batchId = this.id;

    if (!jobId || !batchId) {
      throw new Error('Batch not started.');
    }

    try {
      const resp = await bulk._request({
        method: 'GET',
        path: '/job/' + jobId + '/batch/' + batchId + '/result'
      });
      let results;

      if (job.operation === 'query' || job.operation === 'queryAll') {
        var _context3;

        const res = resp;
        let resultId = res['result-list'].result;
        results = _mapInstanceProperty(_context3 = _Array$isArray(resultId) ? resultId : [resultId]).call(_context3, id => ({
          id,
          batchId,
          jobId
        }));
      } else {
        const res = resp;
        results = _mapInstanceProperty(res).call(res, ret => ({
          id: ret.Id || null,
          success: ret.Success === 'true',
          errors: ret.Error ? [ret.Error] : []
        }));
      }

      this.emit('response', results);
      return results;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  /**
   * Fetch query result as a record stream
   * @param {String} resultId - Result id
   * @returns {RecordStream} - Record stream, convertible to CSV data stream
   */


  result(resultId) {
    const jobId = this.job.id;
    const batchId = this.id;

    if (!jobId || !batchId) {
      throw new Error('Batch not started.');
    }

    const resultStream = new Parsable();
    const resultDataStream = resultStream.stream('csv');

    this._bulk._request({
      method: 'GET',
      path: '/job/' + jobId + '/batch/' + batchId + '/result/' + resultId,
      responseType: 'application/octet-stream'
    }).stream().pipe(resultDataStream);

    return resultStream;
  }

}
/*--------------------------------------------*/

/**
 *
 */

class BulkApi extends HttpApi {
  beforeSend(request) {
    var _this$_conn$accessTok;

    request.headers = _objectSpread(_objectSpread({}, request.headers), {}, {
      'X-SFDC-SESSION': (_this$_conn$accessTok = this._conn.accessToken) !== null && _this$_conn$accessTok !== void 0 ? _this$_conn$accessTok : ''
    });
  }

  isSessionExpired(response) {
    return response.statusCode === 400 && /<exceptionCode>InvalidSessionId<\/exceptionCode>/.test(response.body);
  }

  hasErrorInResponseBody(body) {
    return !!body.error;
  }

  parseError(body) {
    return {
      errorCode: body.error.exceptionCode,
      message: body.error.exceptionMessage
    };
  }

}

class BulkApiV2 extends HttpApi {
  hasErrorInResponseBody(body) {
    return _Array$isArray(body) && typeof body[0] === 'object' && 'errorCode' in body[0];
  }

  isSessionExpired(response) {
    return response.statusCode === 401 && /INVALID_SESSION_ID/.test(response.body);
  }

  parseError(body) {
    return {
      errorCode: body[0].errorCode,
      message: body[0].message
    };
  }

}
/*--------------------------------------------*/

/**
 * Class for Bulk API
 *
 * @class
 */


export class Bulk {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   * @type {Number}
   */

  /**
   *
   */
  constructor(conn) {
    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    this._conn = conn;
    this._logger = conn._logger;
  }
  /**
   *
   */


  _request(request_) {
    const conn = this._conn;

    const {
      path,
      responseType
    } = request_,
          rreq = _objectWithoutProperties(request_, ["path", "responseType"]);

    const baseUrl = [conn.instanceUrl, 'services/async', conn.version].join('/');

    const request = _objectSpread(_objectSpread({}, rreq), {}, {
      url: baseUrl + path
    });

    return new BulkApi(this._conn, {
      responseType
    }).request(request);
  }
  /**
   * Create and start bulkload job and batch
   */


  load(type, operation, optionsOrInput, input) {
    let options = {};

    if (typeof optionsOrInput === 'string' || _Array$isArray(optionsOrInput) || isObject(optionsOrInput) && 'pipe' in optionsOrInput && typeof optionsOrInput.pipe === 'function') {
      // when options is not plain hash object, it is omitted
      input = optionsOrInput;
    } else {
      options = optionsOrInput;
    }

    const job = this.createJob(type, operation, options);
    const batch = job.createBatch();

    const cleanup = () => job.close();

    const cleanupOnError = err => {
      if (err.name !== 'PollingTimeout') {
        cleanup();
      }
    };

    batch.on('response', cleanup);
    batch.on('error', cleanupOnError);
    batch.on('queue', () => {
      batch === null || batch === void 0 ? void 0 : batch.poll(this.pollInterval, this.pollTimeout);
    });
    return batch.execute(input);
  }
  /**
   * Execute bulk query and get record stream
   */


  query(soql) {
    const m = soql.replace(/\([\s\S]+\)/g, '').match(/FROM\s+(\w+)/i);

    if (!m) {
      throw new Error('No sobject type found in query, maybe caused by invalid SOQL.');
    }

    const type = m[1];
    const recordStream = new Parsable();
    const dataStream = recordStream.stream('csv');

    (async () => {
      try {
        const results = await this.load(type, 'query', soql);

        const streams = _mapInstanceProperty(results).call(results, result => this.job(result.jobId).batch(result.batchId).result(result.id).stream());

        joinStreams(streams).pipe(dataStream);
      } catch (err) {
        recordStream.emit('error', err);
      }
    })();

    return recordStream;
  }
  /**
   * Create a new job instance
   */


  createJob(type, operation, options = {}) {
    return new Job(this, type, operation, options);
  }
  /**
   * Get a job instance specified by given job ID
   *
   * @param {String} jobId - Job ID
   * @returns {Bulk~Job}
   */


  job(jobId) {
    return new Job(this, null, null, null, jobId);
  }

}

var _connection = new _WeakMap();

export class BulkV2 {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   * @type {Number}
   */
  constructor(connection) {
    _connection.set(this, {
      writable: true,
      value: void 0
    });

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    _classPrivateFieldSet(this, _connection, connection);
  }
  /**
   * Create a new job instance
   */


  createJob(options) {
    return new IngestJobV2({
      connection: _classPrivateFieldGet(this, _connection),
      jobInfo: options,
      pollingOptions: this
    });
  }

  job(options) {
    return new IngestJobV2({
      connection: _classPrivateFieldGet(this, _connection),
      jobInfo: options,
      pollingOptions: this
    });
  }
  /**
   * Create, upload, and start bulkload job
   */


  async loadAndWaitForResults(options) {
    const job = this.createJob(options);

    try {
      await job.open();
      await job.uploadData(options.input);
      await job.close();
      await job.poll(options.pollInterval, options.pollTimeout);
      return await job.getAllResults();
    } catch (err) {
      if (err.name !== 'JobPollingTimeoutError') {
        // fires off one last attempt to clean up and ignores the result | error
        job.delete().catch(ignored => ignored);
      }

      throw err;
    }
  }
  /**
   * Execute bulk query and get record stream
   */


  async query(soql, options) {
    const queryJob = new QueryJobV2({
      connection: _classPrivateFieldGet(this, _connection),
      operation: 'query',
      query: soql,
      pollingOptions: this
    });

    try {
      await queryJob.open();
      await queryJob.poll(options === null || options === void 0 ? void 0 : options.pollInterval, options === null || options === void 0 ? void 0 : options.pollTimeout);
      return await queryJob.getResults();
    } catch (err) {
      if (err.name !== 'JobPollingTimeoutError') {
        // fires off one last attempt to clean up and ignores the result | error
        queryJob.delete().catch(ignored => ignored);
      }

      throw err;
    }
  }

}

var _connection2 = new _WeakMap();

var _operation = new _WeakMap();

var _query = new _WeakMap();

var _pollingOptions = new _WeakMap();

var _queryResults = new _WeakMap();

var _error = new _WeakMap();

export class QueryJobV2 extends EventEmitter {
  constructor(options) {
    super();

    _connection2.set(this, {
      writable: true,
      value: void 0
    });

    _operation.set(this, {
      writable: true,
      value: void 0
    });

    _query.set(this, {
      writable: true,
      value: void 0
    });

    _pollingOptions.set(this, {
      writable: true,
      value: void 0
    });

    _queryResults.set(this, {
      writable: true,
      value: void 0
    });

    _error.set(this, {
      writable: true,
      value: void 0
    });

    _defineProperty(this, "jobInfo", void 0);

    _classPrivateFieldSet(this, _connection2, options.connection);

    _classPrivateFieldSet(this, _operation, options.operation);

    _classPrivateFieldSet(this, _query, options.query);

    _classPrivateFieldSet(this, _pollingOptions, options.pollingOptions); // default error handler to keep the latest error


    this.on('error', error => _classPrivateFieldSet(this, _error, error));
  }

  async open() {
    try {
      this.jobInfo = await this.createQueryRequest({
        method: 'POST',
        path: '',
        body: _JSON$stringify({
          operation: _classPrivateFieldGet(this, _operation),
          query: _classPrivateFieldGet(this, _query)
        }),
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        responseType: 'application/json'
      });
      this.emit('open');
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  /**
   * Set the status to abort
   */


  async abort() {
    try {
      var _this$jobInfo;

      const state = 'Aborted';
      this.jobInfo = await this.createQueryRequest({
        method: 'PATCH',
        path: `/${(_this$jobInfo = this.jobInfo) === null || _this$jobInfo === void 0 ? void 0 : _this$jobInfo.id}`,
        body: _JSON$stringify({
          state
        }),
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        responseType: 'application/json'
      });
      this.emit('aborted');
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async poll(interval = _classPrivateFieldGet(this, _pollingOptions).pollInterval, timeout = _classPrivateFieldGet(this, _pollingOptions).pollTimeout) {
    const jobId = getJobIdOrError(this.jobInfo);

    const startTime = _Date$now();

    while (startTime + timeout > _Date$now()) {
      try {
        const res = await this.check();

        switch (res.state) {
          case 'Open':
            throw new Error('Job has not been started');

          case 'Aborted':
            throw new Error('Job has been aborted');

          case 'UploadComplete':
          case 'InProgress':
            await delay(interval);
            break;

          case 'Failed':
            this.emit('failed');
            return;

          case 'JobComplete':
            this.emit('jobcomplete');
            return;
        }
      } catch (err) {
        this.emit('error', err);
        throw err;
      }
    }

    const timeoutError = new JobPollingTimeoutError(`Polling time out. Job Id = ${jobId}`, jobId);
    this.emit('error', timeoutError);
    throw timeoutError;
  }
  /**
   * Check the latest batch status in server
   */


  async check() {
    try {
      const jobInfo = await this.createQueryRequest({
        method: 'GET',
        path: `/${getJobIdOrError(this.jobInfo)}`,
        responseType: 'application/json'
      });
      this.jobInfo = jobInfo;
      return jobInfo;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async getResults() {
    try {
      if (_classPrivateFieldGet(this, _queryResults)) {
        return _classPrivateFieldGet(this, _queryResults);
      }

      const results = await this.createQueryRequest({
        method: 'GET',
        path: `/${getJobIdOrError(this.jobInfo)}/results`,
        responseType: 'text/csv'
      });

      _classPrivateFieldSet(this, _queryResults, results !== null && results !== void 0 ? results : []);

      return _classPrivateFieldGet(this, _queryResults);
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async delete() {
    return this.createQueryRequest({
      method: 'DELETE',
      path: `/${getJobIdOrError(this.jobInfo)}`
    });
  }

  createQueryRequest(request) {
    const {
      path,
      responseType
    } = request;
    const baseUrl = [_classPrivateFieldGet(this, _connection2).instanceUrl, 'services/data', `v${_classPrivateFieldGet(this, _connection2).version}`, 'jobs/query'].join('/');
    return new BulkApiV2(_classPrivateFieldGet(this, _connection2), {
      responseType
    }).request(_objectSpread(_objectSpread({}, request), {}, {
      url: baseUrl + path
    }));
  }

}
/**
 * Class for Bulk API V2 Ingest Job
 */

var _connection3 = new _WeakMap();

var _pollingOptions2 = new _WeakMap();

var _jobData = new _WeakMap();

var _bulkJobSuccessfulResults = new _WeakMap();

var _bulkJobFailedResults = new _WeakMap();

var _bulkJobUnprocessedRecords = new _WeakMap();

var _error2 = new _WeakMap();

export class IngestJobV2 extends EventEmitter {
  /**
   *
   */
  constructor(options) {
    super();

    _connection3.set(this, {
      writable: true,
      value: void 0
    });

    _pollingOptions2.set(this, {
      writable: true,
      value: void 0
    });

    _jobData.set(this, {
      writable: true,
      value: void 0
    });

    _bulkJobSuccessfulResults.set(this, {
      writable: true,
      value: void 0
    });

    _bulkJobFailedResults.set(this, {
      writable: true,
      value: void 0
    });

    _bulkJobUnprocessedRecords.set(this, {
      writable: true,
      value: void 0
    });

    _error2.set(this, {
      writable: true,
      value: void 0
    });

    _defineProperty(this, "jobInfo", void 0);

    _classPrivateFieldSet(this, _connection3, options.connection);

    _classPrivateFieldSet(this, _pollingOptions2, options.pollingOptions);

    this.jobInfo = options.jobInfo;

    _classPrivateFieldSet(this, _jobData, new JobDataV2({
      createRequest: request => this.createIngestRequest(request),
      job: this
    })); // default error handler to keep the latest error


    this.on('error', error => _classPrivateFieldSet(this, _error2, error));
  }

  get id() {
    return this.jobInfo.id;
  }

  async open() {
    try {
      var _this$jobInfo2, _this$jobInfo3, _this$jobInfo4, _this$jobInfo5;

      this.jobInfo = await this.createIngestRequest({
        method: 'POST',
        path: '',
        body: _JSON$stringify({
          assignmentRuleId: (_this$jobInfo2 = this.jobInfo) === null || _this$jobInfo2 === void 0 ? void 0 : _this$jobInfo2.assignmentRuleId,
          externalIdFieldName: (_this$jobInfo3 = this.jobInfo) === null || _this$jobInfo3 === void 0 ? void 0 : _this$jobInfo3.externalIdFieldName,
          object: (_this$jobInfo4 = this.jobInfo) === null || _this$jobInfo4 === void 0 ? void 0 : _this$jobInfo4.object,
          operation: (_this$jobInfo5 = this.jobInfo) === null || _this$jobInfo5 === void 0 ? void 0 : _this$jobInfo5.operation
        }),
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        responseType: 'application/json'
      });
      this.emit('open');
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async uploadData(input) {
    await _classPrivateFieldGet(this, _jobData).execute(input);
  }

  async getAllResults() {
    const [successfulResults, failedResults, unprocessedRecords] = await _Promise.all([this.getSuccessfulResults(), this.getFailedResults(), this.getUnprocessedRecords()]);
    return {
      successfulResults,
      failedResults,
      unprocessedRecords
    };
  }
  /**
   * Close opened job
   */


  async close() {
    try {
      const state = 'UploadComplete';
      this.jobInfo = await this.createIngestRequest({
        method: 'PATCH',
        path: `/${this.jobInfo.id}`,
        body: _JSON$stringify({
          state
        }),
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        responseType: 'application/json'
      });
      this.emit('uploadcomplete');
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }
  /**
   * Set the status to abort
   */


  async abort() {
    try {
      const state = 'Aborted';
      this.jobInfo = await this.createIngestRequest({
        method: 'PATCH',
        path: `/${this.jobInfo.id}`,
        body: _JSON$stringify({
          state
        }),
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        responseType: 'application/json'
      });
      this.emit('aborted');
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async poll(interval = _classPrivateFieldGet(this, _pollingOptions2).pollInterval, timeout = _classPrivateFieldGet(this, _pollingOptions2).pollTimeout) {
    const jobId = getJobIdOrError(this.jobInfo);

    const startTime = _Date$now();

    while (startTime + timeout > _Date$now()) {
      try {
        const res = await this.check();

        switch (res.state) {
          case 'Open':
            throw new Error('Job has not been started');

          case 'Aborted':
            throw new Error('Job has been aborted');

          case 'UploadComplete':
          case 'InProgress':
            await delay(interval);
            break;

          case 'Failed':
            this.emit('failed');
            return;

          case 'JobComplete':
            this.emit('jobcomplete');
            return;
        }
      } catch (err) {
        this.emit('error', err);
        throw err;
      }
    }

    const timeoutError = new JobPollingTimeoutError(`Polling time out. Job Id = ${jobId}`, jobId);
    this.emit('error', timeoutError);
    throw timeoutError;
  }
  /**
   * Check the latest batch status in server
   */


  async check() {
    try {
      const jobInfo = await this.createIngestRequest({
        method: 'GET',
        path: `/${getJobIdOrError(this.jobInfo)}`,
        responseType: 'application/json'
      });
      this.jobInfo = jobInfo;
      return jobInfo;
    } catch (err) {
      this.emit('error', err);
      throw err;
    }
  }

  async getSuccessfulResults() {
    if (_classPrivateFieldGet(this, _bulkJobSuccessfulResults)) {
      return _classPrivateFieldGet(this, _bulkJobSuccessfulResults);
    }

    const results = await this.createIngestRequest({
      method: 'GET',
      path: `/${getJobIdOrError(this.jobInfo)}/successfulResults`,
      responseType: 'text/csv'
    });

    _classPrivateFieldSet(this, _bulkJobSuccessfulResults, results !== null && results !== void 0 ? results : []);

    return _classPrivateFieldGet(this, _bulkJobSuccessfulResults);
  }

  async getFailedResults() {
    if (_classPrivateFieldGet(this, _bulkJobFailedResults)) {
      return _classPrivateFieldGet(this, _bulkJobFailedResults);
    }

    const results = await this.createIngestRequest({
      method: 'GET',
      path: `/${getJobIdOrError(this.jobInfo)}/failedResults`,
      responseType: 'text/csv'
    });

    _classPrivateFieldSet(this, _bulkJobFailedResults, results !== null && results !== void 0 ? results : []);

    return _classPrivateFieldGet(this, _bulkJobFailedResults);
  }

  async getUnprocessedRecords() {
    if (_classPrivateFieldGet(this, _bulkJobUnprocessedRecords)) {
      return _classPrivateFieldGet(this, _bulkJobUnprocessedRecords);
    }

    const results = await this.createIngestRequest({
      method: 'GET',
      path: `/${getJobIdOrError(this.jobInfo)}/unprocessedrecords`,
      responseType: 'text/csv'
    });

    _classPrivateFieldSet(this, _bulkJobUnprocessedRecords, results !== null && results !== void 0 ? results : []);

    return _classPrivateFieldGet(this, _bulkJobUnprocessedRecords);
  }

  async delete() {
    return this.createIngestRequest({
      method: 'DELETE',
      path: `/${getJobIdOrError(this.jobInfo)}`
    });
  }

  createIngestRequest(request) {
    const {
      path,
      responseType
    } = request;
    const baseUrl = [_classPrivateFieldGet(this, _connection3).instanceUrl, 'services/data', `v${_classPrivateFieldGet(this, _connection3).version}`, 'jobs/ingest'].join('/');
    return new BulkApiV2(_classPrivateFieldGet(this, _connection3), {
      responseType
    }).request(_objectSpread(_objectSpread({}, request), {}, {
      url: baseUrl + path
    }));
  }

}

var _job = new _WeakMap();

var _uploadStream = new _WeakMap();

var _downloadStream = new _WeakMap();

var _dataStream = new _WeakMap();

var _result = new _WeakMap();

class JobDataV2 extends Writable {
  /**
   *
   */
  constructor(options) {
    super({
      objectMode: true
    });

    _job.set(this, {
      writable: true,
      value: void 0
    });

    _uploadStream.set(this, {
      writable: true,
      value: void 0
    });

    _downloadStream.set(this, {
      writable: true,
      value: void 0
    });

    _dataStream.set(this, {
      writable: true,
      value: void 0
    });

    _result.set(this, {
      writable: true,
      value: void 0
    });

    const createRequest = options.createRequest;

    _classPrivateFieldSet(this, _job, options.job);

    _classPrivateFieldSet(this, _uploadStream, new Serializable());

    _classPrivateFieldSet(this, _downloadStream, new Parsable());

    const converterOptions = {
      nullValue: '#N/A'
    };

    const uploadDataStream = _classPrivateFieldGet(this, _uploadStream).stream('csv', converterOptions);

    const downloadDataStream = _classPrivateFieldGet(this, _downloadStream).stream('csv', converterOptions);

    _classPrivateFieldSet(this, _dataStream, concatStreamsAsDuplex(uploadDataStream, downloadDataStream));

    this.on('finish', () => _classPrivateFieldGet(this, _uploadStream).end());
    uploadDataStream.once('readable', () => {
      try {
        var _classPrivateFieldGet2;

        // pipe upload data to batch API request stream
        const req = createRequest({
          method: 'PUT',
          path: `/${(_classPrivateFieldGet2 = _classPrivateFieldGet(this, _job).jobInfo) === null || _classPrivateFieldGet2 === void 0 ? void 0 : _classPrivateFieldGet2.id}/batches`,
          headers: {
            'Content-Type': 'text/csv'
          },
          responseType: 'application/json'
        });

        (async () => {
          try {
            const res = await req;
            this.emit('response', res);
          } catch (err) {
            this.emit('error', err);
          }
        })();

        uploadDataStream.pipe(req.stream());
      } catch (err) {
        this.emit('error', err);
      }
    });
  }

  _write(record_, enc, cb) {
    const {
      Id,
      type,
      attributes
    } = record_,
          rrec = _objectWithoutProperties(record_, ["Id", "type", "attributes"]);

    let record;

    switch (_classPrivateFieldGet(this, _job).jobInfo.operation) {
      case 'insert':
        record = rrec;
        break;

      case 'delete':
      case 'hardDelete':
        record = {
          Id
        };
        break;

      default:
        record = _objectSpread({
          Id
        }, rrec);
    }

    _classPrivateFieldGet(this, _uploadStream).write(record, enc, cb);
  }
  /**
   * Returns duplex stream which accepts CSV data input and batch result output
   */


  stream() {
    return _classPrivateFieldGet(this, _dataStream);
  }
  /**
   * Execute batch operation
   */


  execute(input) {
    if (_classPrivateFieldGet(this, _result)) {
      throw new Error('Data can only be uploaded to a job once.');
    }

    _classPrivateFieldSet(this, _result, new _Promise((resolve, reject) => {
      this.once('response', () => resolve());
      this.once('error', reject);
    }));

    if (isObject(input) && 'pipe' in input && isFunction(input.pipe)) {
      // if input has stream.Readable interface
      input.pipe(_classPrivateFieldGet(this, _dataStream));
    } else {
      if (_Array$isArray(input)) {
        for (const record of input) {
          for (const key of _Object$keys(record)) {
            if (typeof record[key] === 'boolean') {
              record[key] = String(record[key]);
            }
          }

          this.write(record);
        }

        this.end();
      } else if (typeof input === 'string') {
        _classPrivateFieldGet(this, _dataStream).write(input, 'utf8');

        _classPrivateFieldGet(this, _dataStream).end();
      }
    }

    return this;
  }
  /**
   * Promise/A+ interface
   * Delegate to promise, return promise instance for batch result
   */


  then(onResolved, onReject) {
    if (_classPrivateFieldGet(this, _result) === undefined) {
      this.execute();
    }

    return _classPrivateFieldGet(this, _result).then(onResolved, onReject);
  }

}

function getJobIdOrError(jobInfo) {
  const jobId = jobInfo === null || jobInfo === void 0 ? void 0 : jobInfo.id;

  if (jobId === undefined) {
    throw new Error('No job id, maybe you need to call `job.open()` first.');
  }

  return jobId;
}

function delay(ms) {
  return new _Promise(resolve => _setTimeout(resolve, ms));
}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */


registerModule('bulk', conn => new Bulk(conn));
registerModule('bulk2', conn => new BulkV2(conn));
export default Bulk;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYnVsay50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJXcml0YWJsZSIsImpvaW5TdHJlYW1zIiwiU2VyaWFsaXphYmxlIiwiUGFyc2FibGUiLCJIdHRwQXBpIiwicmVnaXN0ZXJNb2R1bGUiLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJpc0Z1bmN0aW9uIiwiaXNPYmplY3QiLCJKb2IiLCJjb25zdHJ1Y3RvciIsImJ1bGsiLCJ0eXBlIiwib3BlcmF0aW9uIiwib3B0aW9ucyIsImpvYklkIiwiX2J1bGsiLCJpZCIsInN0YXRlIiwiX2JhdGNoZXMiLCJvbiIsImVycm9yIiwiX2Vycm9yIiwiaW5mbyIsIl9qb2JJbmZvIiwiY2hlY2siLCJvcGVuIiwiRXJyb3IiLCJ0b0xvd2VyQ2FzZSIsImJvZHkiLCJleHRJZEZpZWxkIiwiY29uY3VycmVuY3lNb2RlIiwiYXNzaWdubWVudFJ1bGVJZCIsInJlcyIsIl9yZXF1ZXN0IiwibWV0aG9kIiwicGF0aCIsImhlYWRlcnMiLCJyZXNwb25zZVR5cGUiLCJlbWl0Iiwiam9iSW5mbyIsImVyciIsImNyZWF0ZUJhdGNoIiwiYmF0Y2giLCJCYXRjaCIsImJhdGNoSWQiLCJsb2dnZXIiLCJfbG9nZ2VyIiwicmVhZHkiLCJkZWJ1ZyIsIm9iamVjdCIsInJlc29sdmUiLCJ0aGVuIiwibGlzdCIsImJhdGNoSW5mb0xpc3QiLCJiYXRjaEluZm8iLCJjbG9zZSIsIl9jaGFuZ2VTdGF0ZSIsImFib3J0IiwiUG9sbGluZ1RpbWVvdXRFcnJvciIsIm1lc3NhZ2UiLCJuYW1lIiwiSm9iUG9sbGluZ1RpbWVvdXRFcnJvciIsImpvYiIsIm9iamVjdE1vZGUiLCJleGVjdXRlIiwiY29udmVydGVyT3B0aW9ucyIsIm51bGxWYWx1ZSIsInVwbG9hZFN0cmVhbSIsIl91cGxvYWRTdHJlYW0iLCJ1cGxvYWREYXRhU3RyZWFtIiwic3RyZWFtIiwiZG93bmxvYWRTdHJlYW0iLCJfZG93bmxvYWRTdHJlYW0iLCJkb3dubG9hZERhdGFTdHJlYW0iLCJlbmQiLCJvbmNlIiwicGlwZSIsIl9jcmVhdGVSZXF1ZXN0U3RyZWFtIiwiX2RhdGFTdHJlYW0iLCJyZXEiLCJfd3JpdGUiLCJyZWNvcmRfIiwiZW5jIiwiY2IiLCJJZCIsImF0dHJpYnV0ZXMiLCJycmVjIiwicmVjb3JkIiwid3JpdGUiLCJpbnB1dCIsIl9yZXN1bHQiLCJyZWplY3QiLCJrZXkiLCJTdHJpbmciLCJvblJlc29sdmVkIiwib25SZWplY3QiLCJwb2xsIiwiaW50ZXJ2YWwiLCJ0aW1lb3V0Iiwic3RhcnRUaW1lIiwiRGF0ZSIsImdldFRpbWUiLCJub3ciLCJudW1iZXJSZWNvcmRzUHJvY2Vzc2VkIiwicmV0cmlldmUiLCJzdGF0ZU1lc3NhZ2UiLCJyZXNwIiwicmVzdWx0cyIsInJlc3VsdElkIiwicmVzdWx0IiwicmV0Iiwic3VjY2VzcyIsIlN1Y2Nlc3MiLCJlcnJvcnMiLCJyZXN1bHRTdHJlYW0iLCJyZXN1bHREYXRhU3RyZWFtIiwiQnVsa0FwaSIsImJlZm9yZVNlbmQiLCJyZXF1ZXN0IiwiX2Nvbm4iLCJhY2Nlc3NUb2tlbiIsImlzU2Vzc2lvbkV4cGlyZWQiLCJyZXNwb25zZSIsInN0YXR1c0NvZGUiLCJ0ZXN0IiwiaGFzRXJyb3JJblJlc3BvbnNlQm9keSIsInBhcnNlRXJyb3IiLCJlcnJvckNvZGUiLCJleGNlcHRpb25Db2RlIiwiZXhjZXB0aW9uTWVzc2FnZSIsIkJ1bGtBcGlWMiIsIkJ1bGsiLCJjb25uIiwicmVxdWVzdF8iLCJycmVxIiwiYmFzZVVybCIsImluc3RhbmNlVXJsIiwidmVyc2lvbiIsImpvaW4iLCJ1cmwiLCJsb2FkIiwib3B0aW9uc09ySW5wdXQiLCJjcmVhdGVKb2IiLCJjbGVhbnVwIiwiY2xlYW51cE9uRXJyb3IiLCJwb2xsSW50ZXJ2YWwiLCJwb2xsVGltZW91dCIsInF1ZXJ5Iiwic29xbCIsIm0iLCJyZXBsYWNlIiwibWF0Y2giLCJyZWNvcmRTdHJlYW0iLCJkYXRhU3RyZWFtIiwic3RyZWFtcyIsIkJ1bGtWMiIsImNvbm5lY3Rpb24iLCJJbmdlc3RKb2JWMiIsInBvbGxpbmdPcHRpb25zIiwibG9hZEFuZFdhaXRGb3JSZXN1bHRzIiwidXBsb2FkRGF0YSIsImdldEFsbFJlc3VsdHMiLCJkZWxldGUiLCJjYXRjaCIsImlnbm9yZWQiLCJxdWVyeUpvYiIsIlF1ZXJ5Sm9iVjIiLCJnZXRSZXN1bHRzIiwiY3JlYXRlUXVlcnlSZXF1ZXN0IiwiZ2V0Sm9iSWRPckVycm9yIiwiZGVsYXkiLCJ0aW1lb3V0RXJyb3IiLCJKb2JEYXRhVjIiLCJjcmVhdGVSZXF1ZXN0IiwiY3JlYXRlSW5nZXN0UmVxdWVzdCIsImV4dGVybmFsSWRGaWVsZE5hbWUiLCJzdWNjZXNzZnVsUmVzdWx0cyIsImZhaWxlZFJlc3VsdHMiLCJ1bnByb2Nlc3NlZFJlY29yZHMiLCJhbGwiLCJnZXRTdWNjZXNzZnVsUmVzdWx0cyIsImdldEZhaWxlZFJlc3VsdHMiLCJnZXRVbnByb2Nlc3NlZFJlY29yZHMiLCJ1bmRlZmluZWQiLCJtcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFDQSxTQUEyQkMsUUFBM0IsUUFBMkMsUUFBM0M7QUFDQSxPQUFPQyxXQUFQLE1BQXdCLGFBQXhCO0FBRUEsU0FBU0MsWUFBVCxFQUF1QkMsUUFBdkIsUUFBdUMsa0JBQXZDO0FBQ0EsT0FBT0MsT0FBUCxNQUFvQixhQUFwQjtBQUVBLFNBQVNDLGNBQVQsUUFBK0IsWUFBL0I7QUFFQSxTQUFTQyxxQkFBVCxRQUFzQyxnQkFBdEM7QUFRQSxTQUFTQyxVQUFULEVBQXFCQyxRQUFyQixRQUFxQyxrQkFBckM7QUFFQTs7QUF3TEE7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQyxHQUFOLFNBR0dWLFlBSEgsQ0FHZ0I7QUFXckI7QUFDRjtBQUNBO0FBQ0VXLEVBQUFBLFdBQVcsQ0FDVEMsSUFEUyxFQUVUQyxJQUZTLEVBR1RDLFNBSFMsRUFJVEMsT0FKUyxFQUtUQyxLQUxTLEVBTVQ7QUFDQTs7QUFEQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFFQSxTQUFLQyxLQUFMLEdBQWFMLElBQWI7QUFDQSxTQUFLQyxJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLQyxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLFNBQUtDLE9BQUwsR0FBZUEsT0FBTyxJQUFJLEVBQTFCO0FBQ0EsU0FBS0csRUFBTCxHQUFVRixLQUFWLGFBQVVBLEtBQVYsY0FBVUEsS0FBVixHQUFtQixJQUFuQjtBQUNBLFNBQUtHLEtBQUwsR0FBYSxLQUFLRCxFQUFMLEdBQVUsTUFBVixHQUFtQixTQUFoQztBQUNBLFNBQUtFLFFBQUwsR0FBZ0IsRUFBaEIsQ0FSQSxDQVNBOztBQUNBLFNBQUtDLEVBQUwsQ0FBUSxPQUFSLEVBQWtCQyxLQUFELElBQVksS0FBS0MsTUFBTCxHQUFjRCxLQUEzQztBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUUsRUFBQUEsSUFBSSxHQUFHO0FBQ0w7QUFDQSxRQUFJLENBQUMsS0FBS0MsUUFBVixFQUFvQjtBQUNsQixXQUFLQSxRQUFMLEdBQWdCLEtBQUtDLEtBQUwsRUFBaEI7QUFDRDs7QUFDRCxXQUFPLEtBQUtELFFBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VFLEVBQUFBLElBQUksR0FBcUI7QUFDdkIsVUFBTWYsSUFBSSxHQUFHLEtBQUtLLEtBQWxCO0FBQ0EsVUFBTUYsT0FBTyxHQUFHLEtBQUtBLE9BQXJCLENBRnVCLENBSXZCOztBQUNBLFFBQUksQ0FBQyxLQUFLRixJQUFOLElBQWMsQ0FBQyxLQUFLQyxTQUF4QixFQUFtQztBQUNqQyxZQUFNLElBQUljLEtBQUosQ0FBVSxnREFBVixDQUFOO0FBQ0QsS0FQc0IsQ0FTdkI7OztBQUNBLFFBQUksQ0FBQyxLQUFLSCxRQUFWLEVBQW9CO0FBQUE7O0FBQ2xCLFVBQUlYLFNBQVMsR0FBRyxLQUFLQSxTQUFMLENBQWVlLFdBQWYsRUFBaEI7O0FBQ0EsVUFBSWYsU0FBUyxLQUFLLFlBQWxCLEVBQWdDO0FBQzlCQSxRQUFBQSxTQUFTLEdBQUcsWUFBWjtBQUNEOztBQUNELFVBQUlBLFNBQVMsS0FBSyxVQUFsQixFQUE4QjtBQUM1QkEsUUFBQUEsU0FBUyxHQUFHLFVBQVo7QUFDRDs7QUFDRCxZQUFNZ0IsSUFBSSxHQUFHLGlDQUFDO0FBQ3BCO0FBQ0E7QUFDQSxlQUFlaEIsU0FBVTtBQUN6QixZQUFZLEtBQUtELElBQUs7QUFDdEIsSUFDSUUsT0FBTyxDQUFDZ0IsVUFBUixHQUNLLHdCQUF1QmhCLE9BQU8sQ0FBQ2dCLFVBQVcsd0JBRC9DLEdBRUksRUFDTDtBQUNILElBQ0loQixPQUFPLENBQUNpQixlQUFSLEdBQ0ssb0JBQW1CakIsT0FBTyxDQUFDaUIsZUFBZ0Isb0JBRGhELEdBRUksRUFDTDtBQUNILElBQ0lqQixPQUFPLENBQUNrQixnQkFBUixHQUNLLHFCQUFvQmxCLE9BQU8sQ0FBQ2tCLGdCQUFpQixxQkFEbEQsR0FFSSxFQUNMO0FBQ0g7QUFDQTtBQUNBLE9BdEJtQixnQkFBYjs7QUF3QkEsV0FBS1IsUUFBTCxHQUFnQixDQUFDLFlBQVk7QUFDM0IsWUFBSTtBQUNGLGdCQUFNUyxHQUFHLEdBQUcsTUFBTXRCLElBQUksQ0FBQ3VCLFFBQUwsQ0FBK0I7QUFDL0NDLFlBQUFBLE1BQU0sRUFBRSxNQUR1QztBQUUvQ0MsWUFBQUEsSUFBSSxFQUFFLE1BRnlDO0FBRy9DUCxZQUFBQSxJQUgrQztBQUkvQ1EsWUFBQUEsT0FBTyxFQUFFO0FBQ1AsOEJBQWdCO0FBRFQsYUFKc0M7QUFPL0NDLFlBQUFBLFlBQVksRUFBRTtBQVBpQyxXQUEvQixDQUFsQjtBQVNBLGVBQUtDLElBQUwsQ0FBVSxNQUFWLEVBQWtCTixHQUFHLENBQUNPLE9BQXRCO0FBQ0EsZUFBS3ZCLEVBQUwsR0FBVWdCLEdBQUcsQ0FBQ08sT0FBSixDQUFZdkIsRUFBdEI7QUFDQSxlQUFLQyxLQUFMLEdBQWFlLEdBQUcsQ0FBQ08sT0FBSixDQUFZdEIsS0FBekI7QUFDQSxpQkFBT2UsR0FBRyxDQUFDTyxPQUFYO0FBQ0QsU0FkRCxDQWNFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLGVBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNBLGdCQUFNQSxHQUFOO0FBQ0Q7QUFDRixPQW5CZSxHQUFoQjtBQW9CRDs7QUFDRCxXQUFPLEtBQUtqQixRQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFa0IsRUFBQUEsV0FBVyxHQUFrQjtBQUMzQixVQUFNQyxLQUFLLEdBQUcsSUFBSUMsS0FBSixDQUFVLElBQVYsQ0FBZDtBQUNBRCxJQUFBQSxLQUFLLENBQUN2QixFQUFOLENBQVMsT0FBVCxFQUFrQixNQUFNO0FBQ3RCLFdBQUtELFFBQUwsQ0FBY3dCLEtBQUssQ0FBQzFCLEVBQXBCLElBQTJCMEIsS0FBM0I7QUFDRCxLQUZEO0FBR0EsV0FBT0EsS0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUEsRUFBQUEsS0FBSyxDQUFDRSxPQUFELEVBQWlDO0FBQ3BDLFFBQUlGLEtBQUssR0FBRyxLQUFLeEIsUUFBTCxDQUFjMEIsT0FBZCxDQUFaOztBQUNBLFFBQUksQ0FBQ0YsS0FBTCxFQUFZO0FBQ1ZBLE1BQUFBLEtBQUssR0FBRyxJQUFJQyxLQUFKLENBQVUsSUFBVixFQUFnQkMsT0FBaEIsQ0FBUjtBQUNBLFdBQUsxQixRQUFMLENBQWMwQixPQUFkLElBQXlCRixLQUF6QjtBQUNEOztBQUNELFdBQU9BLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VsQixFQUFBQSxLQUFLLEdBQUc7QUFDTixVQUFNZCxJQUFJLEdBQUcsS0FBS0ssS0FBbEI7QUFDQSxVQUFNOEIsTUFBTSxHQUFHbkMsSUFBSSxDQUFDb0MsT0FBcEI7O0FBRUEsU0FBS3ZCLFFBQUwsR0FBZ0IsQ0FBQyxZQUFZO0FBQzNCLFlBQU1ULEtBQUssR0FBRyxNQUFNLEtBQUtpQyxLQUFMLEVBQXBCO0FBQ0EsWUFBTWYsR0FBRyxHQUFHLE1BQU10QixJQUFJLENBQUN1QixRQUFMLENBQStCO0FBQy9DQyxRQUFBQSxNQUFNLEVBQUUsS0FEdUM7QUFFL0NDLFFBQUFBLElBQUksRUFBRSxVQUFVckIsS0FGK0I7QUFHL0N1QixRQUFBQSxZQUFZLEVBQUU7QUFIaUMsT0FBL0IsQ0FBbEI7QUFLQVEsTUFBQUEsTUFBTSxDQUFDRyxLQUFQLENBQWFoQixHQUFHLENBQUNPLE9BQWpCO0FBQ0EsV0FBS3ZCLEVBQUwsR0FBVWdCLEdBQUcsQ0FBQ08sT0FBSixDQUFZdkIsRUFBdEI7QUFDQSxXQUFLTCxJQUFMLEdBQVlxQixHQUFHLENBQUNPLE9BQUosQ0FBWVUsTUFBeEI7QUFDQSxXQUFLckMsU0FBTCxHQUFpQm9CLEdBQUcsQ0FBQ08sT0FBSixDQUFZM0IsU0FBN0I7QUFDQSxXQUFLSyxLQUFMLEdBQWFlLEdBQUcsQ0FBQ08sT0FBSixDQUFZdEIsS0FBekI7QUFDQSxhQUFPZSxHQUFHLENBQUNPLE9BQVg7QUFDRCxLQWJlLEdBQWhCOztBQWVBLFdBQU8sS0FBS2hCLFFBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0V3QixFQUFBQSxLQUFLLEdBQW9CO0FBQ3ZCLFdBQU8sS0FBSy9CLEVBQUwsR0FDSCxTQUFRa0MsT0FBUixDQUFnQixLQUFLbEMsRUFBckIsQ0FERyxHQUVILEtBQUtTLElBQUwsR0FBWTBCLElBQVosQ0FBaUIsQ0FBQztBQUFFbkMsTUFBQUE7QUFBRixLQUFELEtBQVlBLEVBQTdCLENBRko7QUFHRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTW9DLElBQU4sR0FBYTtBQUNYLFVBQU0xQyxJQUFJLEdBQUcsS0FBS0ssS0FBbEI7QUFDQSxVQUFNOEIsTUFBTSxHQUFHbkMsSUFBSSxDQUFDb0MsT0FBcEI7QUFDQSxVQUFNaEMsS0FBSyxHQUFHLE1BQU0sS0FBS2lDLEtBQUwsRUFBcEI7QUFDQSxVQUFNZixHQUFHLEdBQUcsTUFBTXRCLElBQUksQ0FBQ3VCLFFBQUwsQ0FBcUM7QUFDckRDLE1BQUFBLE1BQU0sRUFBRSxLQUQ2QztBQUVyREMsTUFBQUEsSUFBSSxFQUFFLFVBQVVyQixLQUFWLEdBQWtCLFFBRjZCO0FBR3JEdUIsTUFBQUEsWUFBWSxFQUFFO0FBSHVDLEtBQXJDLENBQWxCO0FBS0FRLElBQUFBLE1BQU0sQ0FBQ0csS0FBUCxDQUFhaEIsR0FBRyxDQUFDcUIsYUFBSixDQUFrQkMsU0FBL0I7QUFDQSxVQUFNRCxhQUFhLEdBQUcsZUFBY3JCLEdBQUcsQ0FBQ3FCLGFBQUosQ0FBa0JDLFNBQWhDLElBQ2xCdEIsR0FBRyxDQUFDcUIsYUFBSixDQUFrQkMsU0FEQSxHQUVsQixDQUFDdEIsR0FBRyxDQUFDcUIsYUFBSixDQUFrQkMsU0FBbkIsQ0FGSjtBQUdBLFdBQU9ELGFBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTUUsS0FBTixHQUFjO0FBQ1osUUFBSSxDQUFDLEtBQUt2QyxFQUFWLEVBQWM7QUFDWjtBQUNEOztBQUNELFFBQUk7QUFDRixZQUFNdUIsT0FBTyxHQUFHLE1BQU0sS0FBS2lCLFlBQUwsQ0FBa0IsUUFBbEIsQ0FBdEI7QUFDQSxXQUFLeEMsRUFBTCxHQUFVLElBQVY7QUFDQSxXQUFLc0IsSUFBTCxDQUFVLE9BQVYsRUFBbUJDLE9BQW5CO0FBQ0EsYUFBT0EsT0FBUDtBQUNELEtBTEQsQ0FLRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixXQUFLRixJQUFMLENBQVUsT0FBVixFQUFtQkUsR0FBbkI7QUFDQSxZQUFNQSxHQUFOO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTWlCLEtBQU4sR0FBYztBQUNaLFFBQUksQ0FBQyxLQUFLekMsRUFBVixFQUFjO0FBQ1o7QUFDRDs7QUFDRCxRQUFJO0FBQ0YsWUFBTXVCLE9BQU8sR0FBRyxNQUFNLEtBQUtpQixZQUFMLENBQWtCLFNBQWxCLENBQXRCO0FBQ0EsV0FBS3hDLEVBQUwsR0FBVSxJQUFWO0FBQ0EsV0FBS3NCLElBQUwsQ0FBVSxPQUFWLEVBQW1CQyxPQUFuQjtBQUNBLGFBQU9BLE9BQVA7QUFDRCxLQUxELENBS0UsT0FBT0MsR0FBUCxFQUFZO0FBQ1osV0FBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0EsWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1nQixZQUFOLENBQW1CdkMsS0FBbkIsRUFBb0M7QUFDbEMsVUFBTVAsSUFBSSxHQUFHLEtBQUtLLEtBQWxCO0FBQ0EsVUFBTThCLE1BQU0sR0FBR25DLElBQUksQ0FBQ29DLE9BQXBCOztBQUVBLFNBQUt2QixRQUFMLEdBQWdCLENBQUMsWUFBWTtBQUFBOztBQUMzQixZQUFNVCxLQUFLLEdBQUcsTUFBTSxLQUFLaUMsS0FBTCxFQUFwQjs7QUFDQSxZQUFNbkIsSUFBSSxHQUFHLGtDQUFDO0FBQ3BCO0FBQ0E7QUFDQSxXQUFXWCxLQUFNO0FBQ2pCO0FBQ0EsT0FMbUIsaUJBQWI7O0FBTUEsWUFBTWUsR0FBRyxHQUFHLE1BQU10QixJQUFJLENBQUN1QixRQUFMLENBQStCO0FBQy9DQyxRQUFBQSxNQUFNLEVBQUUsTUFEdUM7QUFFL0NDLFFBQUFBLElBQUksRUFBRSxVQUFVckIsS0FGK0I7QUFHL0NjLFFBQUFBLElBQUksRUFBRUEsSUFIeUM7QUFJL0NRLFFBQUFBLE9BQU8sRUFBRTtBQUNQLDBCQUFnQjtBQURULFNBSnNDO0FBTy9DQyxRQUFBQSxZQUFZLEVBQUU7QUFQaUMsT0FBL0IsQ0FBbEI7QUFTQVEsTUFBQUEsTUFBTSxDQUFDRyxLQUFQLENBQWFoQixHQUFHLENBQUNPLE9BQWpCO0FBQ0EsV0FBS3RCLEtBQUwsR0FBYWUsR0FBRyxDQUFDTyxPQUFKLENBQVl0QixLQUF6QjtBQUNBLGFBQU9lLEdBQUcsQ0FBQ08sT0FBWDtBQUNELEtBcEJlLEdBQWhCOztBQXFCQSxXQUFPLEtBQUtoQixRQUFaO0FBQ0Q7O0FBOVBvQjtBQWlRdkI7O0FBQ0EsTUFBTW1DLG1CQUFOLFNBQWtDaEMsS0FBbEMsQ0FBd0M7QUFJdEM7QUFDRjtBQUNBO0FBQ0VqQixFQUFBQSxXQUFXLENBQUNrRCxPQUFELEVBQWtCN0MsS0FBbEIsRUFBaUM4QixPQUFqQyxFQUFrRDtBQUMzRCxVQUFNZSxPQUFOOztBQUQyRDs7QUFBQTs7QUFFM0QsU0FBS0MsSUFBTCxHQUFZLGdCQUFaO0FBQ0EsU0FBSzlDLEtBQUwsR0FBYUEsS0FBYjtBQUNBLFNBQUs4QixPQUFMLEdBQWVBLE9BQWY7QUFDRDs7QUFacUM7O0FBZXhDLE1BQU1pQixzQkFBTixTQUFxQ25DLEtBQXJDLENBQTJDO0FBR3pDO0FBQ0Y7QUFDQTtBQUNFakIsRUFBQUEsV0FBVyxDQUFDa0QsT0FBRCxFQUFrQjdDLEtBQWxCLEVBQWlDO0FBQzFDLFVBQU02QyxPQUFOOztBQUQwQzs7QUFFMUMsU0FBS0MsSUFBTCxHQUFZLG1CQUFaO0FBQ0EsU0FBSzlDLEtBQUwsR0FBYUEsS0FBYjtBQUNEOztBQVZ3QztBQWEzQzs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE9BQU8sTUFBTTZCLEtBQU4sU0FHRzVDLFFBSEgsQ0FHWTtBQVVqQjtBQUNGO0FBQ0E7QUFDRVUsRUFBQUEsV0FBVyxDQUFDcUQsR0FBRCxFQUFtQjlDLEVBQW5CLEVBQWdDO0FBQ3pDLFVBQU07QUFBRStDLE1BQUFBLFVBQVUsRUFBRTtBQUFkLEtBQU47O0FBRHlDOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLGlDQW1JckMsS0FBS0MsT0FuSWdDOztBQUFBLGtDQXFJcEMsS0FBS0EsT0FySStCOztBQUV6QyxTQUFLRixHQUFMLEdBQVdBLEdBQVg7QUFDQSxTQUFLOUMsRUFBTCxHQUFVQSxFQUFWO0FBQ0EsU0FBS0QsS0FBTCxHQUFhK0MsR0FBRyxDQUFDL0MsS0FBakIsQ0FKeUMsQ0FNekM7O0FBQ0EsU0FBS0ksRUFBTCxDQUFRLE9BQVIsRUFBa0JDLEtBQUQsSUFBWSxLQUFLQyxNQUFMLEdBQWNELEtBQTNDLEVBUHlDLENBU3pDO0FBQ0E7QUFDQTs7QUFDQSxVQUFNNkMsZ0JBQWdCLEdBQUc7QUFBRUMsTUFBQUEsU0FBUyxFQUFFO0FBQWIsS0FBekI7QUFDQSxVQUFNQyxZQUFZLEdBQUksS0FBS0MsYUFBTCxHQUFxQixJQUFJbkUsWUFBSixFQUEzQztBQUNBLFVBQU1vRSxnQkFBZ0IsR0FBR0YsWUFBWSxDQUFDRyxNQUFiLENBQW9CLEtBQXBCLEVBQTJCTCxnQkFBM0IsQ0FBekI7QUFDQSxVQUFNTSxjQUFjLEdBQUksS0FBS0MsZUFBTCxHQUF1QixJQUFJdEUsUUFBSixFQUEvQztBQUNBLFVBQU11RSxrQkFBa0IsR0FBR0YsY0FBYyxDQUFDRCxNQUFmLENBQXNCLEtBQXRCLEVBQTZCTCxnQkFBN0IsQ0FBM0I7QUFFQSxTQUFLOUMsRUFBTCxDQUFRLFFBQVIsRUFBa0IsTUFBTWdELFlBQVksQ0FBQ08sR0FBYixFQUF4QjtBQUNBTCxJQUFBQSxnQkFBZ0IsQ0FBQ00sSUFBakIsQ0FBc0IsVUFBdEIsRUFBa0MsWUFBWTtBQUM1QyxVQUFJO0FBQ0Y7QUFDQSxjQUFNLEtBQUtiLEdBQUwsQ0FBU2YsS0FBVCxFQUFOLENBRkUsQ0FHRjs7QUFDQXNCLFFBQUFBLGdCQUFnQixDQUFDTyxJQUFqQixDQUFzQixLQUFLQyxvQkFBTCxFQUF0QjtBQUNELE9BTEQsQ0FLRSxPQUFPckMsR0FBUCxFQUFZO0FBQ1osYUFBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0Q7QUFDRixLQVRELEVBbkJ5QyxDQThCekM7O0FBQ0EsU0FBS3NDLFdBQUwsR0FBbUJ6RSxxQkFBcUIsQ0FDdENnRSxnQkFEc0MsRUFFdENJLGtCQUZzQyxDQUF4QztBQUlEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VJLEVBQUFBLG9CQUFvQixHQUFHO0FBQ3JCLFVBQU1uRSxJQUFJLEdBQUcsS0FBS0ssS0FBbEI7QUFDQSxVQUFNOEIsTUFBTSxHQUFHbkMsSUFBSSxDQUFDb0MsT0FBcEI7O0FBQ0EsVUFBTWlDLEdBQUcsR0FBR3JFLElBQUksQ0FBQ3VCLFFBQUwsQ0FBaUM7QUFDM0NDLE1BQUFBLE1BQU0sRUFBRSxNQURtQztBQUUzQ0MsTUFBQUEsSUFBSSxFQUFFLFVBQVUsS0FBSzJCLEdBQUwsQ0FBUzlDLEVBQW5CLEdBQXdCLFFBRmE7QUFHM0NvQixNQUFBQSxPQUFPLEVBQUU7QUFDUCx3QkFBZ0I7QUFEVCxPQUhrQztBQU0zQ0MsTUFBQUEsWUFBWSxFQUFFO0FBTjZCLEtBQWpDLENBQVo7O0FBUUEsS0FBQyxZQUFZO0FBQ1gsVUFBSTtBQUNGLGNBQU1MLEdBQUcsR0FBRyxNQUFNK0MsR0FBbEI7QUFDQWxDLFFBQUFBLE1BQU0sQ0FBQ0csS0FBUCxDQUFhaEIsR0FBRyxDQUFDc0IsU0FBakI7QUFDQSxhQUFLdEMsRUFBTCxHQUFVZ0IsR0FBRyxDQUFDc0IsU0FBSixDQUFjdEMsRUFBeEI7QUFDQSxhQUFLc0IsSUFBTCxDQUFVLE9BQVYsRUFBbUJOLEdBQUcsQ0FBQ3NCLFNBQXZCO0FBQ0QsT0FMRCxDQUtFLE9BQU9kLEdBQVAsRUFBWTtBQUNaLGFBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNEO0FBQ0YsS0FURDs7QUFVQSxXQUFPdUMsR0FBRyxDQUFDVCxNQUFKLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VVLEVBQUFBLE1BQU0sQ0FBQ0MsT0FBRCxFQUFrQkMsR0FBbEIsRUFBK0JDLEVBQS9CLEVBQStDO0FBQ25ELFVBQU07QUFBRUMsTUFBQUEsRUFBRjtBQUFNekUsTUFBQUEsSUFBTjtBQUFZMEUsTUFBQUE7QUFBWixRQUFvQ0osT0FBMUM7QUFBQSxVQUFpQ0ssSUFBakMsNEJBQTBDTCxPQUExQzs7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFlBQVEsS0FBS3pCLEdBQUwsQ0FBU2xELFNBQWpCO0FBQ0UsV0FBSyxRQUFMO0FBQ0UyRSxRQUFBQSxNQUFNLEdBQUdELElBQVQ7QUFDQTs7QUFDRixXQUFLLFFBQUw7QUFDQSxXQUFLLFlBQUw7QUFDRUMsUUFBQUEsTUFBTSxHQUFHO0FBQUVILFVBQUFBO0FBQUYsU0FBVDtBQUNBOztBQUNGO0FBQ0VHLFFBQUFBLE1BQU07QUFBS0gsVUFBQUE7QUFBTCxXQUFZRSxJQUFaLENBQU47QUFUSjs7QUFXQSxTQUFLbEIsYUFBTCxDQUFtQm9CLEtBQW5CLENBQXlCRCxNQUF6QixFQUFpQ0wsR0FBakMsRUFBc0NDLEVBQXRDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFYixFQUFBQSxNQUFNLEdBQUc7QUFDUCxXQUFPLEtBQUtRLFdBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VkLEVBQUFBLE9BQU8sQ0FBQ3lCLEtBQUQsRUFBdUM7QUFDNUM7QUFDQSxRQUFJLEtBQUtDLE9BQVQsRUFBa0I7QUFDaEIsWUFBTSxJQUFJaEUsS0FBSixDQUFVLHlCQUFWLENBQU47QUFDRDs7QUFFRCxTQUFLZ0UsT0FBTCxHQUFlLGFBQVksQ0FBQ3hDLE9BQUQsRUFBVXlDLE1BQVYsS0FBcUI7QUFDOUMsV0FBS2hCLElBQUwsQ0FBVSxVQUFWLEVBQXNCekIsT0FBdEI7QUFDQSxXQUFLeUIsSUFBTCxDQUFVLE9BQVYsRUFBbUJnQixNQUFuQjtBQUNELEtBSGMsQ0FBZjs7QUFLQSxRQUFJcEYsUUFBUSxDQUFDa0YsS0FBRCxDQUFSLElBQW1CLFVBQVVBLEtBQTdCLElBQXNDbkYsVUFBVSxDQUFDbUYsS0FBSyxDQUFDYixJQUFQLENBQXBELEVBQWtFO0FBQ2hFO0FBQ0FhLE1BQUFBLEtBQUssQ0FBQ2IsSUFBTixDQUFXLEtBQUtFLFdBQWhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsVUFBSSxlQUFjVyxLQUFkLENBQUosRUFBMEI7QUFDeEIsYUFBSyxNQUFNRixNQUFYLElBQXFCRSxLQUFyQixFQUE0QjtBQUMxQixlQUFLLE1BQU1HLEdBQVgsSUFBa0IsYUFBWUwsTUFBWixDQUFsQixFQUF1QztBQUNyQyxnQkFBSSxPQUFPQSxNQUFNLENBQUNLLEdBQUQsQ0FBYixLQUF1QixTQUEzQixFQUFzQztBQUNwQ0wsY0FBQUEsTUFBTSxDQUFDSyxHQUFELENBQU4sR0FBY0MsTUFBTSxDQUFDTixNQUFNLENBQUNLLEdBQUQsQ0FBUCxDQUFwQjtBQUNEO0FBQ0Y7O0FBQ0QsZUFBS0osS0FBTCxDQUFXRCxNQUFYO0FBQ0Q7O0FBQ0QsYUFBS2IsR0FBTDtBQUNELE9BVkQsTUFVTyxJQUFJLE9BQU9lLEtBQVAsS0FBaUIsUUFBckIsRUFBK0I7QUFDcEMsYUFBS1gsV0FBTCxDQUFpQlUsS0FBakIsQ0FBdUJDLEtBQXZCLEVBQThCLE1BQTlCOztBQUNBLGFBQUtYLFdBQUwsQ0FBaUJKLEdBQWpCO0FBQ0Q7QUFDRixLQTdCMkMsQ0ErQjVDOzs7QUFDQSxXQUFPLElBQVA7QUFDRDs7QUFNRDtBQUNGO0FBQ0E7QUFDQTtBQUNFdkIsRUFBQUEsSUFBSSxDQUNGMkMsVUFERSxFQUVGQyxRQUZFLEVBR0Y7QUFDQSxRQUFJLENBQUMsS0FBS0wsT0FBVixFQUFtQjtBQUNqQixXQUFLMUIsT0FBTDtBQUNEOztBQUNELFdBQU8sS0FBSzBCLE9BQUwsQ0FBY3ZDLElBQWQsQ0FBbUIyQyxVQUFuQixFQUErQkMsUUFBL0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNdkUsS0FBTixHQUFjO0FBQ1osVUFBTWQsSUFBSSxHQUFHLEtBQUtLLEtBQWxCO0FBQ0EsVUFBTThCLE1BQU0sR0FBR25DLElBQUksQ0FBQ29DLE9BQXBCO0FBQ0EsVUFBTWhDLEtBQUssR0FBRyxLQUFLZ0QsR0FBTCxDQUFTOUMsRUFBdkI7QUFDQSxVQUFNNEIsT0FBTyxHQUFHLEtBQUs1QixFQUFyQjs7QUFFQSxRQUFJLENBQUNGLEtBQUQsSUFBVSxDQUFDOEIsT0FBZixFQUF3QjtBQUN0QixZQUFNLElBQUlsQixLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQUNEOztBQUNELFVBQU1NLEdBQUcsR0FBRyxNQUFNdEIsSUFBSSxDQUFDdUIsUUFBTCxDQUFpQztBQUNqREMsTUFBQUEsTUFBTSxFQUFFLEtBRHlDO0FBRWpEQyxNQUFBQSxJQUFJLEVBQUUsVUFBVXJCLEtBQVYsR0FBa0IsU0FBbEIsR0FBOEI4QixPQUZhO0FBR2pEUCxNQUFBQSxZQUFZLEVBQUU7QUFIbUMsS0FBakMsQ0FBbEI7QUFLQVEsSUFBQUEsTUFBTSxDQUFDRyxLQUFQLENBQWFoQixHQUFHLENBQUNzQixTQUFqQjtBQUNBLFdBQU90QixHQUFHLENBQUNzQixTQUFYO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFMEMsRUFBQUEsSUFBSSxDQUFDQyxRQUFELEVBQW1CQyxPQUFuQixFQUFvQztBQUN0QyxVQUFNcEYsS0FBSyxHQUFHLEtBQUtnRCxHQUFMLENBQVM5QyxFQUF2QjtBQUNBLFVBQU00QixPQUFPLEdBQUcsS0FBSzVCLEVBQXJCOztBQUVBLFFBQUksQ0FBQ0YsS0FBRCxJQUFVLENBQUM4QixPQUFmLEVBQXdCO0FBQ3RCLFlBQU0sSUFBSWxCLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTXlFLFNBQVMsR0FBRyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBbEI7O0FBQ0EsVUFBTUwsSUFBSSxHQUFHLFlBQVk7QUFDdkIsWUFBTU0sR0FBRyxHQUFHLElBQUlGLElBQUosR0FBV0MsT0FBWCxFQUFaOztBQUNBLFVBQUlGLFNBQVMsR0FBR0QsT0FBWixHQUFzQkksR0FBMUIsRUFBK0I7QUFDN0IsY0FBTTlELEdBQUcsR0FBRyxJQUFJa0IsbUJBQUosQ0FDVixnQ0FBZ0M1QyxLQUFoQyxHQUF3QyxnQkFBeEMsR0FBMkQ4QixPQURqRCxFQUVWOUIsS0FGVSxFQUdWOEIsT0FIVSxDQUFaO0FBS0EsYUFBS04sSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0E7QUFDRDs7QUFDRCxVQUFJUixHQUFKOztBQUNBLFVBQUk7QUFDRkEsUUFBQUEsR0FBRyxHQUFHLE1BQU0sS0FBS1IsS0FBTCxFQUFaO0FBQ0QsT0FGRCxDQUVFLE9BQU9nQixHQUFQLEVBQVk7QUFDWixhQUFLRixJQUFMLENBQVUsT0FBVixFQUFtQkUsR0FBbkI7QUFDQTtBQUNEOztBQUNELFVBQUlSLEdBQUcsQ0FBQ2YsS0FBSixLQUFjLFFBQWxCLEVBQTRCO0FBQzFCLFlBQUksVUFBU2UsR0FBRyxDQUFDdUUsc0JBQWIsRUFBcUMsRUFBckMsSUFBMkMsQ0FBL0MsRUFBa0Q7QUFDaEQsZUFBS0MsUUFBTDtBQUNELFNBRkQsTUFFTztBQUNMLGVBQUtsRSxJQUFMLENBQVUsT0FBVixFQUFtQixJQUFJWixLQUFKLENBQVVNLEdBQUcsQ0FBQ3lFLFlBQWQsQ0FBbkI7QUFDRDtBQUNGLE9BTkQsTUFNTyxJQUFJekUsR0FBRyxDQUFDZixLQUFKLEtBQWMsV0FBbEIsRUFBK0I7QUFDcEMsYUFBS3VGLFFBQUw7QUFDRCxPQUZNLE1BRUE7QUFDTCxhQUFLbEUsSUFBTCxDQUFVLFVBQVYsRUFBc0JOLEdBQXRCOztBQUNBLG9CQUFXZ0UsSUFBWCxFQUFpQkMsUUFBakI7QUFDRDtBQUNGLEtBOUJEOztBQStCQSxnQkFBV0QsSUFBWCxFQUFpQkMsUUFBakI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTU8sUUFBTixHQUFpQjtBQUNmLFVBQU05RixJQUFJLEdBQUcsS0FBS0ssS0FBbEI7QUFDQSxVQUFNRCxLQUFLLEdBQUcsS0FBS2dELEdBQUwsQ0FBUzlDLEVBQXZCO0FBQ0EsVUFBTThDLEdBQUcsR0FBRyxLQUFLQSxHQUFqQjtBQUNBLFVBQU1sQixPQUFPLEdBQUcsS0FBSzVCLEVBQXJCOztBQUVBLFFBQUksQ0FBQ0YsS0FBRCxJQUFVLENBQUM4QixPQUFmLEVBQXdCO0FBQ3RCLFlBQU0sSUFBSWxCLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0Q7O0FBRUQsUUFBSTtBQUNGLFlBQU1nRixJQUFJLEdBQUcsTUFBTWhHLElBQUksQ0FBQ3VCLFFBQUwsQ0FFakI7QUFDQUMsUUFBQUEsTUFBTSxFQUFFLEtBRFI7QUFFQUMsUUFBQUEsSUFBSSxFQUFFLFVBQVVyQixLQUFWLEdBQWtCLFNBQWxCLEdBQThCOEIsT0FBOUIsR0FBd0M7QUFGOUMsT0FGaUIsQ0FBbkI7QUFNQSxVQUFJK0QsT0FBSjs7QUFDQSxVQUFJN0MsR0FBRyxDQUFDbEQsU0FBSixLQUFrQixPQUFsQixJQUE2QmtELEdBQUcsQ0FBQ2xELFNBQUosS0FBa0IsVUFBbkQsRUFBK0Q7QUFBQTs7QUFDN0QsY0FBTW9CLEdBQUcsR0FBRzBFLElBQVo7QUFDQSxZQUFJRSxRQUFRLEdBQUc1RSxHQUFHLENBQUMsYUFBRCxDQUFILENBQW1CNkUsTUFBbEM7QUFDQUYsUUFBQUEsT0FBTyxHQUFHLGlDQUFDLGVBQWNDLFFBQWQsSUFDUEEsUUFETyxHQUVQLENBQUNBLFFBQUQsQ0FGTSxrQkFHSDVGLEVBQUQsS0FBUztBQUFFQSxVQUFBQSxFQUFGO0FBQU00QixVQUFBQSxPQUFOO0FBQWU5QixVQUFBQTtBQUFmLFNBQVQsQ0FISSxDQUFWO0FBSUQsT0FQRCxNQU9PO0FBQ0wsY0FBTWtCLEdBQUcsR0FBRzBFLElBQVo7QUFDQUMsUUFBQUEsT0FBTyxHQUFHLHFCQUFBM0UsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBTThFLEdBQUQsS0FBVTtBQUMxQjlGLFVBQUFBLEVBQUUsRUFBRThGLEdBQUcsQ0FBQzFCLEVBQUosSUFBVSxJQURZO0FBRTFCMkIsVUFBQUEsT0FBTyxFQUFFRCxHQUFHLENBQUNFLE9BQUosS0FBZ0IsTUFGQztBQUcxQkMsVUFBQUEsTUFBTSxFQUFFSCxHQUFHLENBQUNwRixLQUFKLEdBQVksQ0FBQ29GLEdBQUcsQ0FBQ3BGLEtBQUwsQ0FBWixHQUEwQjtBQUhSLFNBQVYsQ0FBTCxDQUFiO0FBS0Q7O0FBQ0QsV0FBS1ksSUFBTCxDQUFVLFVBQVYsRUFBc0JxRSxPQUF0QjtBQUNBLGFBQU9BLE9BQVA7QUFDRCxLQXpCRCxDQXlCRSxPQUFPbkUsR0FBUCxFQUFZO0FBQ1osV0FBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0EsWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXFFLEVBQUFBLE1BQU0sQ0FBQ0QsUUFBRCxFQUFtQjtBQUN2QixVQUFNOUYsS0FBSyxHQUFHLEtBQUtnRCxHQUFMLENBQVM5QyxFQUF2QjtBQUNBLFVBQU00QixPQUFPLEdBQUcsS0FBSzVCLEVBQXJCOztBQUNBLFFBQUksQ0FBQ0YsS0FBRCxJQUFVLENBQUM4QixPQUFmLEVBQXdCO0FBQ3RCLFlBQU0sSUFBSWxCLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTXdGLFlBQVksR0FBRyxJQUFJaEgsUUFBSixFQUFyQjtBQUNBLFVBQU1pSCxnQkFBZ0IsR0FBR0QsWUFBWSxDQUFDNUMsTUFBYixDQUFvQixLQUFwQixDQUF6Qjs7QUFDQSxTQUFLdkQsS0FBTCxDQUNHa0IsUUFESCxDQUNZO0FBQ1JDLE1BQUFBLE1BQU0sRUFBRSxLQURBO0FBRVJDLE1BQUFBLElBQUksRUFBRSxVQUFVckIsS0FBVixHQUFrQixTQUFsQixHQUE4QjhCLE9BQTlCLEdBQXdDLFVBQXhDLEdBQXFEZ0UsUUFGbkQ7QUFHUnZFLE1BQUFBLFlBQVksRUFBRTtBQUhOLEtBRFosRUFNR2lDLE1BTkgsR0FPR00sSUFQSCxDQU9RdUMsZ0JBUFI7O0FBUUEsV0FBT0QsWUFBUDtBQUNEOztBQXRTZ0I7QUF5U25COztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNRSxPQUFOLFNBQXdDakgsT0FBeEMsQ0FBbUQ7QUFDakRrSCxFQUFBQSxVQUFVLENBQUNDLE9BQUQsRUFBdUI7QUFBQTs7QUFDL0JBLElBQUFBLE9BQU8sQ0FBQ2xGLE9BQVIsbUNBQ0trRixPQUFPLENBQUNsRixPQURiO0FBRUUsaURBQWtCLEtBQUttRixLQUFMLENBQVdDLFdBQTdCLHlFQUE0QztBQUY5QztBQUlEOztBQUVEQyxFQUFBQSxnQkFBZ0IsQ0FBQ0MsUUFBRCxFQUF5QjtBQUN2QyxXQUNFQSxRQUFRLENBQUNDLFVBQVQsS0FBd0IsR0FBeEIsSUFDQSxtREFBbURDLElBQW5ELENBQXdERixRQUFRLENBQUM5RixJQUFqRSxDQUZGO0FBSUQ7O0FBRURpRyxFQUFBQSxzQkFBc0IsQ0FBQ2pHLElBQUQsRUFBWTtBQUNoQyxXQUFPLENBQUMsQ0FBQ0EsSUFBSSxDQUFDUixLQUFkO0FBQ0Q7O0FBRUQwRyxFQUFBQSxVQUFVLENBQUNsRyxJQUFELEVBQVk7QUFDcEIsV0FBTztBQUNMbUcsTUFBQUEsU0FBUyxFQUFFbkcsSUFBSSxDQUFDUixLQUFMLENBQVc0RyxhQURqQjtBQUVMckUsTUFBQUEsT0FBTyxFQUFFL0IsSUFBSSxDQUFDUixLQUFMLENBQVc2RztBQUZmLEtBQVA7QUFJRDs7QUF4QmdEOztBQTJCbkQsTUFBTUMsU0FBTixTQUEwQy9ILE9BQTFDLENBQXFEO0FBQ25EMEgsRUFBQUEsc0JBQXNCLENBQUNqRyxJQUFELEVBQVk7QUFDaEMsV0FDRSxlQUFjQSxJQUFkLEtBQ0EsT0FBT0EsSUFBSSxDQUFDLENBQUQsQ0FBWCxLQUFtQixRQURuQixJQUVBLGVBQWVBLElBQUksQ0FBQyxDQUFELENBSHJCO0FBS0Q7O0FBRUQ2RixFQUFBQSxnQkFBZ0IsQ0FBQ0MsUUFBRCxFQUFrQztBQUNoRCxXQUNFQSxRQUFRLENBQUNDLFVBQVQsS0FBd0IsR0FBeEIsSUFBK0IscUJBQXFCQyxJQUFyQixDQUEwQkYsUUFBUSxDQUFDOUYsSUFBbkMsQ0FEakM7QUFHRDs7QUFFRGtHLEVBQUFBLFVBQVUsQ0FBQ2xHLElBQUQsRUFBWTtBQUNwQixXQUFPO0FBQ0xtRyxNQUFBQSxTQUFTLEVBQUVuRyxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFtRyxTQURkO0FBRUxwRSxNQUFBQSxPQUFPLEVBQUUvQixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVErQjtBQUZaLEtBQVA7QUFJRDs7QUFwQmtEO0FBdUJyRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxPQUFPLE1BQU13RSxJQUFOLENBQTZCO0FBSWxDO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDRTFILEVBQUFBLFdBQVcsQ0FBQzJILElBQUQsRUFBc0I7QUFBQTs7QUFBQTs7QUFBQSwwQ0FYbEIsSUFXa0I7O0FBQUEseUNBTG5CLEtBS21COztBQUMvQixTQUFLYixLQUFMLEdBQWFhLElBQWI7QUFDQSxTQUFLdEYsT0FBTCxHQUFlc0YsSUFBSSxDQUFDdEYsT0FBcEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0ViLEVBQUFBLFFBQVEsQ0FBSW9HLFFBQUosRUFBMkI7QUFDakMsVUFBTUQsSUFBSSxHQUFHLEtBQUtiLEtBQWxCOztBQUNBLFVBQU07QUFBRXBGLE1BQUFBLElBQUY7QUFBUUUsTUFBQUE7QUFBUixRQUFrQ2dHLFFBQXhDO0FBQUEsVUFBK0JDLElBQS9CLDRCQUF3Q0QsUUFBeEM7O0FBQ0EsVUFBTUUsT0FBTyxHQUFHLENBQUNILElBQUksQ0FBQ0ksV0FBTixFQUFtQixnQkFBbkIsRUFBcUNKLElBQUksQ0FBQ0ssT0FBMUMsRUFBbURDLElBQW5ELENBQ2QsR0FEYyxDQUFoQjs7QUFHQSxVQUFNcEIsT0FBTyxtQ0FDUmdCLElBRFE7QUFFWEssTUFBQUEsR0FBRyxFQUFFSixPQUFPLEdBQUdwRztBQUZKLE1BQWI7O0FBSUEsV0FBTyxJQUFJaUYsT0FBSixDQUFZLEtBQUtHLEtBQWpCLEVBQXdCO0FBQUVsRixNQUFBQTtBQUFGLEtBQXhCLEVBQTBDaUYsT0FBMUMsQ0FBcURBLE9BQXJELENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBWUVzQixFQUFBQSxJQUFJLENBQ0ZqSSxJQURFLEVBRUZDLFNBRkUsRUFHRmlJLGNBSEUsRUFJRnBELEtBSkUsRUFLRjtBQUNBLFFBQUk1RSxPQUFvQixHQUFHLEVBQTNCOztBQUNBLFFBQ0UsT0FBT2dJLGNBQVAsS0FBMEIsUUFBMUIsSUFDQSxlQUFjQSxjQUFkLENBREEsSUFFQ3RJLFFBQVEsQ0FBQ3NJLGNBQUQsQ0FBUixJQUNDLFVBQVVBLGNBRFgsSUFFQyxPQUFPQSxjQUFjLENBQUNqRSxJQUF0QixLQUErQixVQUxuQyxFQU1FO0FBQ0E7QUFDQWEsTUFBQUEsS0FBSyxHQUFHb0QsY0FBUjtBQUNELEtBVEQsTUFTTztBQUNMaEksTUFBQUEsT0FBTyxHQUFHZ0ksY0FBVjtBQUNEOztBQUNELFVBQU0vRSxHQUFHLEdBQUcsS0FBS2dGLFNBQUwsQ0FBZW5JLElBQWYsRUFBcUJDLFNBQXJCLEVBQWdDQyxPQUFoQyxDQUFaO0FBQ0EsVUFBTTZCLEtBQUssR0FBR29CLEdBQUcsQ0FBQ3JCLFdBQUosRUFBZDs7QUFDQSxVQUFNc0csT0FBTyxHQUFHLE1BQU1qRixHQUFHLENBQUNQLEtBQUosRUFBdEI7O0FBQ0EsVUFBTXlGLGNBQWMsR0FBSXhHLEdBQUQsSUFBZ0I7QUFDckMsVUFBSUEsR0FBRyxDQUFDb0IsSUFBSixLQUFhLGdCQUFqQixFQUFtQztBQUNqQ21GLFFBQUFBLE9BQU87QUFDUjtBQUNGLEtBSkQ7O0FBS0FyRyxJQUFBQSxLQUFLLENBQUN2QixFQUFOLENBQVMsVUFBVCxFQUFxQjRILE9BQXJCO0FBQ0FyRyxJQUFBQSxLQUFLLENBQUN2QixFQUFOLENBQVMsT0FBVCxFQUFrQjZILGNBQWxCO0FBQ0F0RyxJQUFBQSxLQUFLLENBQUN2QixFQUFOLENBQVMsT0FBVCxFQUFrQixNQUFNO0FBQ3RCdUIsTUFBQUEsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCxZQUFBQSxLQUFLLENBQUVzRCxJQUFQLENBQVksS0FBS2lELFlBQWpCLEVBQStCLEtBQUtDLFdBQXBDO0FBQ0QsS0FGRDtBQUdBLFdBQU94RyxLQUFLLENBQUNzQixPQUFOLENBQWN5QixLQUFkLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UwRCxFQUFBQSxLQUFLLENBQUNDLElBQUQsRUFBZTtBQUNsQixVQUFNQyxDQUFDLEdBQUdELElBQUksQ0FBQ0UsT0FBTCxDQUFhLGNBQWIsRUFBNkIsRUFBN0IsRUFBaUNDLEtBQWpDLENBQXVDLGVBQXZDLENBQVY7O0FBQ0EsUUFBSSxDQUFDRixDQUFMLEVBQVE7QUFDTixZQUFNLElBQUkzSCxLQUFKLENBQ0osK0RBREksQ0FBTjtBQUdEOztBQUNELFVBQU1mLElBQUksR0FBRzBJLENBQUMsQ0FBQyxDQUFELENBQWQ7QUFDQSxVQUFNRyxZQUFZLEdBQUcsSUFBSXRKLFFBQUosRUFBckI7QUFDQSxVQUFNdUosVUFBVSxHQUFHRCxZQUFZLENBQUNsRixNQUFiLENBQW9CLEtBQXBCLENBQW5COztBQUNBLEtBQUMsWUFBWTtBQUNYLFVBQUk7QUFDRixjQUFNcUMsT0FBTyxHQUFHLE1BQU0sS0FBS2lDLElBQUwsQ0FBVWpJLElBQVYsRUFBZ0IsT0FBaEIsRUFBeUJ5SSxJQUF6QixDQUF0Qjs7QUFDQSxjQUFNTSxPQUFPLEdBQUcscUJBQUEvQyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFNRSxNQUFELElBQzFCLEtBQUsvQyxHQUFMLENBQVMrQyxNQUFNLENBQUMvRixLQUFoQixFQUNHNEIsS0FESCxDQUNTbUUsTUFBTSxDQUFDakUsT0FEaEIsRUFFR2lFLE1BRkgsQ0FFVUEsTUFBTSxDQUFDN0YsRUFGakIsRUFHR3NELE1BSEgsRUFEcUIsQ0FBdkI7O0FBTUF0RSxRQUFBQSxXQUFXLENBQUMwSixPQUFELENBQVgsQ0FBcUI5RSxJQUFyQixDQUEwQjZFLFVBQTFCO0FBQ0QsT0FURCxDQVNFLE9BQU9qSCxHQUFQLEVBQVk7QUFDWmdILFFBQUFBLFlBQVksQ0FBQ2xILElBQWIsQ0FBa0IsT0FBbEIsRUFBMkJFLEdBQTNCO0FBQ0Q7QUFDRixLQWJEOztBQWNBLFdBQU9nSCxZQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFVixFQUFBQSxTQUFTLENBQ1BuSSxJQURPLEVBRVBDLFNBRk8sRUFHUEMsT0FBb0IsR0FBRyxFQUhoQixFQUlQO0FBQ0EsV0FBTyxJQUFJTCxHQUFKLENBQVEsSUFBUixFQUFjRyxJQUFkLEVBQW9CQyxTQUFwQixFQUErQkMsT0FBL0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWlELEVBQUFBLEdBQUcsQ0FBNEJoRCxLQUE1QixFQUEyQztBQUM1QyxXQUFPLElBQUlOLEdBQUosQ0FBZ0IsSUFBaEIsRUFBc0IsSUFBdEIsRUFBNEIsSUFBNUIsRUFBa0MsSUFBbEMsRUFBd0NNLEtBQXhDLENBQVA7QUFDRDs7QUF6SWlDOzs7O0FBNElwQyxPQUFPLE1BQU02SSxNQUFOLENBQStCO0FBR3BDO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDQTtBQUdFbEosRUFBQUEsV0FBVyxDQUFDbUosVUFBRCxFQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBLDBDQVJ4QixJQVF3Qjs7QUFBQSx5Q0FGekIsS0FFeUI7O0FBQ3JDLDZDQUFtQkEsVUFBbkI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VkLEVBQUFBLFNBQVMsQ0FDUGpJLE9BRE8sRUFFYztBQUNyQixXQUFPLElBQUlnSixXQUFKLENBQWdCO0FBQ3JCRCxNQUFBQSxVQUFVLHdCQUFFLElBQUYsY0FEVztBQUVyQnJILE1BQUFBLE9BQU8sRUFBRTFCLE9BRlk7QUFHckJpSixNQUFBQSxjQUFjLEVBQUU7QUFISyxLQUFoQixDQUFQO0FBS0Q7O0FBRURoRyxFQUFBQSxHQUFHLENBQ0RqRCxPQURDLEVBRW9CO0FBQ3JCLFdBQU8sSUFBSWdKLFdBQUosQ0FBZ0I7QUFDckJELE1BQUFBLFVBQVUsd0JBQUUsSUFBRixjQURXO0FBRXJCckgsTUFBQUEsT0FBTyxFQUFFMUIsT0FGWTtBQUdyQmlKLE1BQUFBLGNBQWMsRUFBRTtBQUhLLEtBQWhCLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTUMscUJBQU4sQ0FDRWxKLE9BREYsRUFLa0M7QUFDaEMsVUFBTWlELEdBQUcsR0FBRyxLQUFLZ0YsU0FBTCxDQUFlakksT0FBZixDQUFaOztBQUNBLFFBQUk7QUFDRixZQUFNaUQsR0FBRyxDQUFDckMsSUFBSixFQUFOO0FBQ0EsWUFBTXFDLEdBQUcsQ0FBQ2tHLFVBQUosQ0FBZW5KLE9BQU8sQ0FBQzRFLEtBQXZCLENBQU47QUFDQSxZQUFNM0IsR0FBRyxDQUFDUCxLQUFKLEVBQU47QUFDQSxZQUFNTyxHQUFHLENBQUNrQyxJQUFKLENBQVNuRixPQUFPLENBQUNvSSxZQUFqQixFQUErQnBJLE9BQU8sQ0FBQ3FJLFdBQXZDLENBQU47QUFDQSxhQUFPLE1BQU1wRixHQUFHLENBQUNtRyxhQUFKLEVBQWI7QUFDRCxLQU5ELENBTUUsT0FBT3pILEdBQVAsRUFBWTtBQUNaLFVBQUlBLEdBQUcsQ0FBQ29CLElBQUosS0FBYSx3QkFBakIsRUFBMkM7QUFDekM7QUFDQUUsUUFBQUEsR0FBRyxDQUFDb0csTUFBSixHQUFhQyxLQUFiLENBQW9CQyxPQUFELElBQWFBLE9BQWhDO0FBQ0Q7O0FBQ0QsWUFBTTVILEdBQU47QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNMkcsS0FBTixDQUNFQyxJQURGLEVBRUV2SSxPQUZGLEVBR3FCO0FBQ25CLFVBQU13SixRQUFRLEdBQUcsSUFBSUMsVUFBSixDQUFlO0FBQzlCVixNQUFBQSxVQUFVLHdCQUFFLElBQUYsY0FEb0I7QUFFOUJoSixNQUFBQSxTQUFTLEVBQUUsT0FGbUI7QUFHOUJ1SSxNQUFBQSxLQUFLLEVBQUVDLElBSHVCO0FBSTlCVSxNQUFBQSxjQUFjLEVBQUU7QUFKYyxLQUFmLENBQWpCOztBQU1BLFFBQUk7QUFDRixZQUFNTyxRQUFRLENBQUM1SSxJQUFULEVBQU47QUFDQSxZQUFNNEksUUFBUSxDQUFDckUsSUFBVCxDQUFjbkYsT0FBZCxhQUFjQSxPQUFkLHVCQUFjQSxPQUFPLENBQUVvSSxZQUF2QixFQUFxQ3BJLE9BQXJDLGFBQXFDQSxPQUFyQyx1QkFBcUNBLE9BQU8sQ0FBRXFJLFdBQTlDLENBQU47QUFDQSxhQUFPLE1BQU1tQixRQUFRLENBQUNFLFVBQVQsRUFBYjtBQUNELEtBSkQsQ0FJRSxPQUFPL0gsR0FBUCxFQUFZO0FBQ1osVUFBSUEsR0FBRyxDQUFDb0IsSUFBSixLQUFhLHdCQUFqQixFQUEyQztBQUN6QztBQUNBeUcsUUFBQUEsUUFBUSxDQUFDSCxNQUFULEdBQWtCQyxLQUFsQixDQUF5QkMsT0FBRCxJQUFhQSxPQUFyQztBQUNEOztBQUNELFlBQU01SCxHQUFOO0FBQ0Q7QUFDRjs7QUExRm1DOzs7Ozs7Ozs7Ozs7OztBQTZGdEMsT0FBTyxNQUFNOEgsVUFBTixTQUEyQ3hLLFlBQTNDLENBQXdEO0FBUzdEVyxFQUFBQSxXQUFXLENBQUNJLE9BQUQsRUFBc0M7QUFDL0M7O0FBRCtDO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUUvQyw4Q0FBbUJBLE9BQU8sQ0FBQytJLFVBQTNCOztBQUNBLDRDQUFrQi9JLE9BQU8sQ0FBQ0QsU0FBMUI7O0FBQ0Esd0NBQWNDLE9BQU8sQ0FBQ3NJLEtBQXRCOztBQUNBLGlEQUF1QnRJLE9BQU8sQ0FBQ2lKLGNBQS9CLEVBTCtDLENBTS9DOzs7QUFDQSxTQUFLM0ksRUFBTCxDQUFRLE9BQVIsRUFBa0JDLEtBQUQsMEJBQVksSUFBWixVQUEwQkEsS0FBMUIsQ0FBakI7QUFDRDs7QUFFRCxRQUFNSyxJQUFOLEdBQTRCO0FBQzFCLFFBQUk7QUFDRixXQUFLYyxPQUFMLEdBQWUsTUFBTSxLQUFLaUksa0JBQUwsQ0FBbUM7QUFDdER0SSxRQUFBQSxNQUFNLEVBQUUsTUFEOEM7QUFFdERDLFFBQUFBLElBQUksRUFBRSxFQUZnRDtBQUd0RFAsUUFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQ25CaEIsVUFBQUEsU0FBUyx3QkFBRSxJQUFGLGFBRFU7QUFFbkJ1SSxVQUFBQSxLQUFLLHdCQUFFLElBQUY7QUFGYyxTQUFmLENBSGdEO0FBT3REL0csUUFBQUEsT0FBTyxFQUFFO0FBQ1AsMEJBQWdCO0FBRFQsU0FQNkM7QUFVdERDLFFBQUFBLFlBQVksRUFBRTtBQVZ3QyxPQUFuQyxDQUFyQjtBQVlBLFdBQUtDLElBQUwsQ0FBVSxNQUFWO0FBQ0QsS0FkRCxDQWNFLE9BQU9FLEdBQVAsRUFBWTtBQUNaLFdBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNBLFlBQU1BLEdBQU47QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNaUIsS0FBTixHQUE2QjtBQUMzQixRQUFJO0FBQUE7O0FBQ0YsWUFBTXhDLEtBQWlCLEdBQUcsU0FBMUI7QUFDQSxXQUFLc0IsT0FBTCxHQUFlLE1BQU0sS0FBS2lJLGtCQUFMLENBQW1DO0FBQ3REdEksUUFBQUEsTUFBTSxFQUFFLE9BRDhDO0FBRXREQyxRQUFBQSxJQUFJLEVBQUcsSUFBRCxpQkFBSSxLQUFLSSxPQUFULGtEQUFJLGNBQWN2QixFQUFHLEVBRjJCO0FBR3REWSxRQUFBQSxJQUFJLEVBQUUsZ0JBQWU7QUFBRVgsVUFBQUE7QUFBRixTQUFmLENBSGdEO0FBSXREbUIsUUFBQUEsT0FBTyxFQUFFO0FBQUUsMEJBQWdCO0FBQWxCLFNBSjZDO0FBS3REQyxRQUFBQSxZQUFZLEVBQUU7QUFMd0MsT0FBbkMsQ0FBckI7QUFPQSxXQUFLQyxJQUFMLENBQVUsU0FBVjtBQUNELEtBVkQsQ0FVRSxPQUFPRSxHQUFQLEVBQVk7QUFDWixXQUFLRixJQUFMLENBQVUsT0FBVixFQUFtQkUsR0FBbkI7QUFDQSxZQUFNQSxHQUFOO0FBQ0Q7QUFDRjs7QUFFRCxRQUFNd0QsSUFBTixDQUNFQyxRQUFnQixHQUFHLDZDQUFxQmdELFlBRDFDLEVBRUUvQyxPQUFlLEdBQUcsNkNBQXFCZ0QsV0FGekMsRUFHaUI7QUFDZixVQUFNcEksS0FBSyxHQUFHMkosZUFBZSxDQUFDLEtBQUtsSSxPQUFOLENBQTdCOztBQUNBLFVBQU00RCxTQUFTLEdBQUcsV0FBbEI7O0FBRUEsV0FBT0EsU0FBUyxHQUFHRCxPQUFaLEdBQXNCLFdBQTdCLEVBQXlDO0FBQ3ZDLFVBQUk7QUFDRixjQUFNbEUsR0FBRyxHQUFHLE1BQU0sS0FBS1IsS0FBTCxFQUFsQjs7QUFDQSxnQkFBUVEsR0FBRyxDQUFDZixLQUFaO0FBQ0UsZUFBSyxNQUFMO0FBQ0Usa0JBQU0sSUFBSVMsS0FBSixDQUFVLDBCQUFWLENBQU47O0FBQ0YsZUFBSyxTQUFMO0FBQ0Usa0JBQU0sSUFBSUEsS0FBSixDQUFVLHNCQUFWLENBQU47O0FBQ0YsZUFBSyxnQkFBTDtBQUNBLGVBQUssWUFBTDtBQUNFLGtCQUFNZ0osS0FBSyxDQUFDekUsUUFBRCxDQUFYO0FBQ0E7O0FBQ0YsZUFBSyxRQUFMO0FBQ0UsaUJBQUszRCxJQUFMLENBQVUsUUFBVjtBQUNBOztBQUNGLGVBQUssYUFBTDtBQUNFLGlCQUFLQSxJQUFMLENBQVUsYUFBVjtBQUNBO0FBZEo7QUFnQkQsT0FsQkQsQ0FrQkUsT0FBT0UsR0FBUCxFQUFZO0FBQ1osYUFBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0EsY0FBTUEsR0FBTjtBQUNEO0FBQ0Y7O0FBRUQsVUFBTW1JLFlBQVksR0FBRyxJQUFJOUcsc0JBQUosQ0FDbEIsOEJBQTZCL0MsS0FBTSxFQURqQixFQUVuQkEsS0FGbUIsQ0FBckI7QUFJQSxTQUFLd0IsSUFBTCxDQUFVLE9BQVYsRUFBbUJxSSxZQUFuQjtBQUNBLFVBQU1BLFlBQU47QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTW5KLEtBQU4sR0FBa0M7QUFDaEMsUUFBSTtBQUNGLFlBQU1lLE9BQU8sR0FBRyxNQUFNLEtBQUtpSSxrQkFBTCxDQUFtQztBQUN2RHRJLFFBQUFBLE1BQU0sRUFBRSxLQUQrQztBQUV2REMsUUFBQUEsSUFBSSxFQUFHLElBQUdzSSxlQUFlLENBQUMsS0FBS2xJLE9BQU4sQ0FBZSxFQUZlO0FBR3ZERixRQUFBQSxZQUFZLEVBQUU7QUFIeUMsT0FBbkMsQ0FBdEI7QUFLQSxXQUFLRSxPQUFMLEdBQWVBLE9BQWY7QUFDQSxhQUFPQSxPQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLFdBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNBLFlBQU1BLEdBQU47QUFDRDtBQUNGOztBQUVELFFBQU0rSCxVQUFOLEdBQXNDO0FBQ3BDLFFBQUk7QUFDRixnQ0FBSSxJQUFKLGtCQUF3QjtBQUN0QixxQ0FBTyxJQUFQO0FBQ0Q7O0FBRUQsWUFBTTVELE9BQU8sR0FBRyxNQUFNLEtBQUs2RCxrQkFBTCxDQUE4QztBQUNsRXRJLFFBQUFBLE1BQU0sRUFBRSxLQUQwRDtBQUVsRUMsUUFBQUEsSUFBSSxFQUFHLElBQUdzSSxlQUFlLENBQUMsS0FBS2xJLE9BQU4sQ0FBZSxVQUYwQjtBQUdsRUYsUUFBQUEsWUFBWSxFQUFFO0FBSG9ELE9BQTlDLENBQXRCOztBQU1BLGlEQUFxQnNFLE9BQXJCLGFBQXFCQSxPQUFyQixjQUFxQkEsT0FBckIsR0FBZ0MsRUFBaEM7O0FBRUEsbUNBQU8sSUFBUDtBQUNELEtBZEQsQ0FjRSxPQUFPbkUsR0FBUCxFQUFZO0FBQ1osV0FBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0EsWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7O0FBRUQsUUFBTTBILE1BQU4sR0FBOEI7QUFDNUIsV0FBTyxLQUFLTSxrQkFBTCxDQUE4QjtBQUNuQ3RJLE1BQUFBLE1BQU0sRUFBRSxRQUQyQjtBQUVuQ0MsTUFBQUEsSUFBSSxFQUFHLElBQUdzSSxlQUFlLENBQUMsS0FBS2xJLE9BQU4sQ0FBZTtBQUZMLEtBQTlCLENBQVA7QUFJRDs7QUFFT2lJLEVBQUFBLGtCQUFSLENBQThCbEQsT0FBOUIsRUFBb0Q7QUFDbEQsVUFBTTtBQUFFbkYsTUFBQUEsSUFBRjtBQUFRRSxNQUFBQTtBQUFSLFFBQXlCaUYsT0FBL0I7QUFDQSxVQUFNaUIsT0FBTyxHQUFHLENBQ2QsMENBQWlCQyxXQURILEVBRWQsZUFGYyxFQUdiLElBQUcsMENBQWlCQyxPQUFRLEVBSGYsRUFJZCxZQUpjLEVBS2RDLElBTGMsQ0FLVCxHQUxTLENBQWhCO0FBT0EsV0FBTyxJQUFJUixTQUFKLHVCQUFjLElBQWQsaUJBQWdDO0FBQUU3RixNQUFBQTtBQUFGLEtBQWhDLEVBQWtEaUYsT0FBbEQsaUNBQ0ZBLE9BREU7QUFFTHFCLE1BQUFBLEdBQUcsRUFBRUosT0FBTyxHQUFHcEc7QUFGVixPQUFQO0FBSUQ7O0FBL0o0RDtBQWtLL0Q7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsT0FBTyxNQUFNMEgsV0FBTixTQUdHL0osWUFISCxDQUdnQjtBQVVyQjtBQUNGO0FBQ0E7QUFDRVcsRUFBQUEsV0FBVyxDQUFDSSxPQUFELEVBQXVDO0FBQ2hEOztBQURnRDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTs7QUFHaEQsOENBQW1CQSxPQUFPLENBQUMrSSxVQUEzQjs7QUFDQSxrREFBdUIvSSxPQUFPLENBQUNpSixjQUEvQjs7QUFDQSxTQUFLdkgsT0FBTCxHQUFlMUIsT0FBTyxDQUFDMEIsT0FBdkI7O0FBQ0EsMENBQWdCLElBQUlxSSxTQUFKLENBQXNCO0FBQ3BDQyxNQUFBQSxhQUFhLEVBQUd2RCxPQUFELElBQWEsS0FBS3dELG1CQUFMLENBQXlCeEQsT0FBekIsQ0FEUTtBQUVwQ3hELE1BQUFBLEdBQUcsRUFBRTtBQUYrQixLQUF0QixDQUFoQixFQU5nRCxDQVVoRDs7O0FBQ0EsU0FBSzNDLEVBQUwsQ0FBUSxPQUFSLEVBQWtCQyxLQUFELDBCQUFZLElBQVosV0FBMEJBLEtBQTFCLENBQWpCO0FBQ0Q7O0FBRUQsTUFBSUosRUFBSixHQUFTO0FBQ1AsV0FBTyxLQUFLdUIsT0FBTCxDQUFhdkIsRUFBcEI7QUFDRDs7QUFFRCxRQUFNUyxJQUFOLEdBQTRCO0FBQzFCLFFBQUk7QUFBQTs7QUFDRixXQUFLYyxPQUFMLEdBQWUsTUFBTSxLQUFLdUksbUJBQUwsQ0FBb0M7QUFDdkQ1SSxRQUFBQSxNQUFNLEVBQUUsTUFEK0M7QUFFdkRDLFFBQUFBLElBQUksRUFBRSxFQUZpRDtBQUd2RFAsUUFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQ25CRyxVQUFBQSxnQkFBZ0Isb0JBQUUsS0FBS1EsT0FBUCxtREFBRSxlQUFjUixnQkFEYjtBQUVuQmdKLFVBQUFBLG1CQUFtQixvQkFBRSxLQUFLeEksT0FBUCxtREFBRSxlQUFjd0ksbUJBRmhCO0FBR25COUgsVUFBQUEsTUFBTSxvQkFBRSxLQUFLVixPQUFQLG1EQUFFLGVBQWNVLE1BSEg7QUFJbkJyQyxVQUFBQSxTQUFTLG9CQUFFLEtBQUsyQixPQUFQLG1EQUFFLGVBQWMzQjtBQUpOLFNBQWYsQ0FIaUQ7QUFTdkR3QixRQUFBQSxPQUFPLEVBQUU7QUFDUCwwQkFBZ0I7QUFEVCxTQVQ4QztBQVl2REMsUUFBQUEsWUFBWSxFQUFFO0FBWnlDLE9BQXBDLENBQXJCO0FBY0EsV0FBS0MsSUFBTCxDQUFVLE1BQVY7QUFDRCxLQWhCRCxDQWdCRSxPQUFPRSxHQUFQLEVBQVk7QUFDWixXQUFLRixJQUFMLENBQVUsT0FBVixFQUFtQkUsR0FBbkI7QUFDQSxZQUFNQSxHQUFOO0FBQ0Q7QUFDRjs7QUFFRCxRQUFNd0gsVUFBTixDQUFpQnZFLEtBQWpCLEVBQXFFO0FBQ25FLFVBQU0sc0NBQWN6QixPQUFkLENBQXNCeUIsS0FBdEIsQ0FBTjtBQUNEOztBQUVELFFBQU13RSxhQUFOLEdBQXNEO0FBQ3BELFVBQU0sQ0FDSmUsaUJBREksRUFFSkMsYUFGSSxFQUdKQyxrQkFISSxJQUlGLE1BQU0sU0FBUUMsR0FBUixDQUFZLENBQ3BCLEtBQUtDLG9CQUFMLEVBRG9CLEVBRXBCLEtBQUtDLGdCQUFMLEVBRm9CLEVBR3BCLEtBQUtDLHFCQUFMLEVBSG9CLENBQVosQ0FKVjtBQVNBLFdBQU87QUFBRU4sTUFBQUEsaUJBQUY7QUFBcUJDLE1BQUFBLGFBQXJCO0FBQW9DQyxNQUFBQTtBQUFwQyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU0zSCxLQUFOLEdBQTZCO0FBQzNCLFFBQUk7QUFDRixZQUFNdEMsS0FBaUIsR0FBRyxnQkFBMUI7QUFDQSxXQUFLc0IsT0FBTCxHQUFlLE1BQU0sS0FBS3VJLG1CQUFMLENBQW9DO0FBQ3ZENUksUUFBQUEsTUFBTSxFQUFFLE9BRCtDO0FBRXZEQyxRQUFBQSxJQUFJLEVBQUcsSUFBRyxLQUFLSSxPQUFMLENBQWF2QixFQUFHLEVBRjZCO0FBR3ZEWSxRQUFBQSxJQUFJLEVBQUUsZ0JBQWU7QUFBRVgsVUFBQUE7QUFBRixTQUFmLENBSGlEO0FBSXZEbUIsUUFBQUEsT0FBTyxFQUFFO0FBQUUsMEJBQWdCO0FBQWxCLFNBSjhDO0FBS3ZEQyxRQUFBQSxZQUFZLEVBQUU7QUFMeUMsT0FBcEMsQ0FBckI7QUFPQSxXQUFLQyxJQUFMLENBQVUsZ0JBQVY7QUFDRCxLQVZELENBVUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1osV0FBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0EsWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1pQixLQUFOLEdBQTZCO0FBQzNCLFFBQUk7QUFDRixZQUFNeEMsS0FBaUIsR0FBRyxTQUExQjtBQUNBLFdBQUtzQixPQUFMLEdBQWUsTUFBTSxLQUFLdUksbUJBQUwsQ0FBb0M7QUFDdkQ1SSxRQUFBQSxNQUFNLEVBQUUsT0FEK0M7QUFFdkRDLFFBQUFBLElBQUksRUFBRyxJQUFHLEtBQUtJLE9BQUwsQ0FBYXZCLEVBQUcsRUFGNkI7QUFHdkRZLFFBQUFBLElBQUksRUFBRSxnQkFBZTtBQUFFWCxVQUFBQTtBQUFGLFNBQWYsQ0FIaUQ7QUFJdkRtQixRQUFBQSxPQUFPLEVBQUU7QUFBRSwwQkFBZ0I7QUFBbEIsU0FKOEM7QUFLdkRDLFFBQUFBLFlBQVksRUFBRTtBQUx5QyxPQUFwQyxDQUFyQjtBQU9BLFdBQUtDLElBQUwsQ0FBVSxTQUFWO0FBQ0QsS0FWRCxDQVVFLE9BQU9FLEdBQVAsRUFBWTtBQUNaLFdBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNBLFlBQU1BLEdBQU47QUFDRDtBQUNGOztBQUVELFFBQU13RCxJQUFOLENBQ0VDLFFBQWdCLEdBQUcsOENBQXFCZ0QsWUFEMUMsRUFFRS9DLE9BQWUsR0FBRyw4Q0FBcUJnRCxXQUZ6QyxFQUdpQjtBQUNmLFVBQU1wSSxLQUFLLEdBQUcySixlQUFlLENBQUMsS0FBS2xJLE9BQU4sQ0FBN0I7O0FBQ0EsVUFBTTRELFNBQVMsR0FBRyxXQUFsQjs7QUFFQSxXQUFPQSxTQUFTLEdBQUdELE9BQVosR0FBc0IsV0FBN0IsRUFBeUM7QUFDdkMsVUFBSTtBQUNGLGNBQU1sRSxHQUFHLEdBQUcsTUFBTSxLQUFLUixLQUFMLEVBQWxCOztBQUNBLGdCQUFRUSxHQUFHLENBQUNmLEtBQVo7QUFDRSxlQUFLLE1BQUw7QUFDRSxrQkFBTSxJQUFJUyxLQUFKLENBQVUsMEJBQVYsQ0FBTjs7QUFDRixlQUFLLFNBQUw7QUFDRSxrQkFBTSxJQUFJQSxLQUFKLENBQVUsc0JBQVYsQ0FBTjs7QUFDRixlQUFLLGdCQUFMO0FBQ0EsZUFBSyxZQUFMO0FBQ0Usa0JBQU1nSixLQUFLLENBQUN6RSxRQUFELENBQVg7QUFDQTs7QUFDRixlQUFLLFFBQUw7QUFDRSxpQkFBSzNELElBQUwsQ0FBVSxRQUFWO0FBQ0E7O0FBQ0YsZUFBSyxhQUFMO0FBQ0UsaUJBQUtBLElBQUwsQ0FBVSxhQUFWO0FBQ0E7QUFkSjtBQWdCRCxPQWxCRCxDQWtCRSxPQUFPRSxHQUFQLEVBQVk7QUFDWixhQUFLRixJQUFMLENBQVUsT0FBVixFQUFtQkUsR0FBbkI7QUFDQSxjQUFNQSxHQUFOO0FBQ0Q7QUFDRjs7QUFFRCxVQUFNbUksWUFBWSxHQUFHLElBQUk5RyxzQkFBSixDQUNsQiw4QkFBNkIvQyxLQUFNLEVBRGpCLEVBRW5CQSxLQUZtQixDQUFyQjtBQUlBLFNBQUt3QixJQUFMLENBQVUsT0FBVixFQUFtQnFJLFlBQW5CO0FBQ0EsVUFBTUEsWUFBTjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNbkosS0FBTixHQUFrQztBQUNoQyxRQUFJO0FBQ0YsWUFBTWUsT0FBTyxHQUFHLE1BQU0sS0FBS3VJLG1CQUFMLENBQW9DO0FBQ3hENUksUUFBQUEsTUFBTSxFQUFFLEtBRGdEO0FBRXhEQyxRQUFBQSxJQUFJLEVBQUcsSUFBR3NJLGVBQWUsQ0FBQyxLQUFLbEksT0FBTixDQUFlLEVBRmdCO0FBR3hERixRQUFBQSxZQUFZLEVBQUU7QUFIMEMsT0FBcEMsQ0FBdEI7QUFLQSxXQUFLRSxPQUFMLEdBQWVBLE9BQWY7QUFDQSxhQUFPQSxPQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLFdBQUtGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxHQUFuQjtBQUNBLFlBQU1BLEdBQU47QUFDRDtBQUNGOztBQUVELFFBQU00SSxvQkFBTixHQUF1RTtBQUNyRSw4QkFBSSxJQUFKLDhCQUFvQztBQUNsQyxtQ0FBTyxJQUFQO0FBQ0Q7O0FBRUQsVUFBTXpFLE9BQU8sR0FBRyxNQUFNLEtBQUttRSxtQkFBTCxDQUVwQjtBQUNBNUksTUFBQUEsTUFBTSxFQUFFLEtBRFI7QUFFQUMsTUFBQUEsSUFBSSxFQUFHLElBQUdzSSxlQUFlLENBQUMsS0FBS2xJLE9BQU4sQ0FBZSxvQkFGeEM7QUFHQUYsTUFBQUEsWUFBWSxFQUFFO0FBSGQsS0FGb0IsQ0FBdEI7O0FBUUEsMkRBQWlDc0UsT0FBakMsYUFBaUNBLE9BQWpDLGNBQWlDQSxPQUFqQyxHQUE0QyxFQUE1Qzs7QUFFQSxpQ0FBTyxJQUFQO0FBQ0Q7O0FBRUQsUUFBTTBFLGdCQUFOLEdBQStEO0FBQzdELDhCQUFJLElBQUosMEJBQWdDO0FBQzlCLG1DQUFPLElBQVA7QUFDRDs7QUFFRCxVQUFNMUUsT0FBTyxHQUFHLE1BQU0sS0FBS21FLG1CQUFMLENBRXBCO0FBQ0E1SSxNQUFBQSxNQUFNLEVBQUUsS0FEUjtBQUVBQyxNQUFBQSxJQUFJLEVBQUcsSUFBR3NJLGVBQWUsQ0FBQyxLQUFLbEksT0FBTixDQUFlLGdCQUZ4QztBQUdBRixNQUFBQSxZQUFZLEVBQUU7QUFIZCxLQUZvQixDQUF0Qjs7QUFRQSx1REFBNkJzRSxPQUE3QixhQUE2QkEsT0FBN0IsY0FBNkJBLE9BQTdCLEdBQXdDLEVBQXhDOztBQUVBLGlDQUFPLElBQVA7QUFDRDs7QUFFRCxRQUFNMkUscUJBQU4sR0FBeUU7QUFDdkUsOEJBQUksSUFBSiwrQkFBcUM7QUFDbkMsbUNBQU8sSUFBUDtBQUNEOztBQUVELFVBQU0zRSxPQUFPLEdBQUcsTUFBTSxLQUFLbUUsbUJBQUwsQ0FFcEI7QUFDQTVJLE1BQUFBLE1BQU0sRUFBRSxLQURSO0FBRUFDLE1BQUFBLElBQUksRUFBRyxJQUFHc0ksZUFBZSxDQUFDLEtBQUtsSSxPQUFOLENBQWUscUJBRnhDO0FBR0FGLE1BQUFBLFlBQVksRUFBRTtBQUhkLEtBRm9CLENBQXRCOztBQVFBLDREQUFrQ3NFLE9BQWxDLGFBQWtDQSxPQUFsQyxjQUFrQ0EsT0FBbEMsR0FBNkMsRUFBN0M7O0FBRUEsaUNBQU8sSUFBUDtBQUNEOztBQUVELFFBQU11RCxNQUFOLEdBQThCO0FBQzVCLFdBQU8sS0FBS1ksbUJBQUwsQ0FBK0I7QUFDcEM1SSxNQUFBQSxNQUFNLEVBQUUsUUFENEI7QUFFcENDLE1BQUFBLElBQUksRUFBRyxJQUFHc0ksZUFBZSxDQUFDLEtBQUtsSSxPQUFOLENBQWU7QUFGSixLQUEvQixDQUFQO0FBSUQ7O0FBRU91SSxFQUFBQSxtQkFBUixDQUErQnhELE9BQS9CLEVBQXFEO0FBQ25ELFVBQU07QUFBRW5GLE1BQUFBLElBQUY7QUFBUUUsTUFBQUE7QUFBUixRQUF5QmlGLE9BQS9CO0FBQ0EsVUFBTWlCLE9BQU8sR0FBRyxDQUNkLDBDQUFpQkMsV0FESCxFQUVkLGVBRmMsRUFHYixJQUFHLDBDQUFpQkMsT0FBUSxFQUhmLEVBSWQsYUFKYyxFQUtkQyxJQUxjLENBS1QsR0FMUyxDQUFoQjtBQU9BLFdBQU8sSUFBSVIsU0FBSix1QkFBYyxJQUFkLGlCQUFnQztBQUFFN0YsTUFBQUE7QUFBRixLQUFoQyxFQUFrRGlGLE9BQWxELGlDQUNGQSxPQURFO0FBRUxxQixNQUFBQSxHQUFHLEVBQUVKLE9BQU8sR0FBR3BHO0FBRlYsT0FBUDtBQUlEOztBQW5Qb0I7Ozs7Ozs7Ozs7OztBQXNQdkIsTUFBTXlJLFNBQU4sU0FHVTdLLFFBSFYsQ0FHbUI7QUFPakI7QUFDRjtBQUNBO0FBQ0VVLEVBQUFBLFdBQVcsQ0FBQ0ksT0FBRCxFQUEwQztBQUNuRCxVQUFNO0FBQUVrRCxNQUFBQSxVQUFVLEVBQUU7QUFBZCxLQUFOOztBQURtRDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFHbkQsVUFBTThHLGFBQWEsR0FBR2hLLE9BQU8sQ0FBQ2dLLGFBQTlCOztBQUVBLHNDQUFZaEssT0FBTyxDQUFDaUQsR0FBcEI7O0FBQ0EsK0NBQXFCLElBQUk3RCxZQUFKLEVBQXJCOztBQUNBLGlEQUF1QixJQUFJQyxRQUFKLEVBQXZCOztBQUVBLFVBQU0rRCxnQkFBZ0IsR0FBRztBQUFFQyxNQUFBQSxTQUFTLEVBQUU7QUFBYixLQUF6Qjs7QUFDQSxVQUFNRyxnQkFBZ0IsR0FBRywyQ0FBbUJDLE1BQW5CLENBQTBCLEtBQTFCLEVBQWlDTCxnQkFBakMsQ0FBekI7O0FBQ0EsVUFBTVEsa0JBQWtCLEdBQUcsNkNBQXFCSCxNQUFyQixDQUN6QixLQUR5QixFQUV6QkwsZ0JBRnlCLENBQTNCOztBQUtBLDZDQUFtQjVELHFCQUFxQixDQUN0Q2dFLGdCQURzQyxFQUV0Q0ksa0JBRnNDLENBQXhDOztBQUtBLFNBQUt0RCxFQUFMLENBQVEsUUFBUixFQUFrQixNQUFNLDJDQUFtQnVELEdBQW5CLEVBQXhCO0FBRUFMLElBQUFBLGdCQUFnQixDQUFDTSxJQUFqQixDQUFzQixVQUF0QixFQUFrQyxNQUFNO0FBQ3RDLFVBQUk7QUFBQTs7QUFDRjtBQUNBLGNBQU1JLEdBQUcsR0FBRzhGLGFBQWEsQ0FBQztBQUN4QjNJLFVBQUFBLE1BQU0sRUFBRSxLQURnQjtBQUV4QkMsVUFBQUEsSUFBSSxFQUFHLElBQUQsMEJBQUksa0NBQVVJLE9BQWQsMkRBQUksdUJBQW1CdkIsRUFBRyxVQUZSO0FBR3hCb0IsVUFBQUEsT0FBTyxFQUFFO0FBQ1AsNEJBQWdCO0FBRFQsV0FIZTtBQU14QkMsVUFBQUEsWUFBWSxFQUFFO0FBTlUsU0FBRCxDQUF6Qjs7QUFTQSxTQUFDLFlBQVk7QUFDWCxjQUFJO0FBQ0Ysa0JBQU1MLEdBQUcsR0FBRyxNQUFNK0MsR0FBbEI7QUFDQSxpQkFBS3pDLElBQUwsQ0FBVSxVQUFWLEVBQXNCTixHQUF0QjtBQUNELFdBSEQsQ0FHRSxPQUFPUSxHQUFQLEVBQVk7QUFDWixpQkFBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0Q7QUFDRixTQVBEOztBQVNBNkIsUUFBQUEsZ0JBQWdCLENBQUNPLElBQWpCLENBQXNCRyxHQUFHLENBQUNULE1BQUosRUFBdEI7QUFDRCxPQXJCRCxDQXFCRSxPQUFPOUIsR0FBUCxFQUFZO0FBQ1osYUFBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUJFLEdBQW5CO0FBQ0Q7QUFDRixLQXpCRDtBQTBCRDs7QUFFRHdDLEVBQUFBLE1BQU0sQ0FBQ0MsT0FBRCxFQUFrQkMsR0FBbEIsRUFBK0JDLEVBQS9CLEVBQStDO0FBQ25ELFVBQU07QUFBRUMsTUFBQUEsRUFBRjtBQUFNekUsTUFBQUEsSUFBTjtBQUFZMEUsTUFBQUE7QUFBWixRQUFvQ0osT0FBMUM7QUFBQSxVQUFpQ0ssSUFBakMsNEJBQTBDTCxPQUExQzs7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFlBQVEsa0NBQVVoRCxPQUFWLENBQWtCM0IsU0FBMUI7QUFDRSxXQUFLLFFBQUw7QUFDRTJFLFFBQUFBLE1BQU0sR0FBR0QsSUFBVDtBQUNBOztBQUNGLFdBQUssUUFBTDtBQUNBLFdBQUssWUFBTDtBQUNFQyxRQUFBQSxNQUFNLEdBQUc7QUFBRUgsVUFBQUE7QUFBRixTQUFUO0FBQ0E7O0FBQ0Y7QUFDRUcsUUFBQUEsTUFBTTtBQUFLSCxVQUFBQTtBQUFMLFdBQVlFLElBQVosQ0FBTjtBQVRKOztBQVdBLCtDQUFtQkUsS0FBbkIsQ0FBeUJELE1BQXpCLEVBQWlDTCxHQUFqQyxFQUFzQ0MsRUFBdEM7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0ViLEVBQUFBLE1BQU0sR0FBRztBQUNQLGlDQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VOLEVBQUFBLE9BQU8sQ0FBQ3lCLEtBQUQsRUFBdUM7QUFDNUMsOEJBQUksSUFBSixZQUFrQjtBQUNoQixZQUFNLElBQUkvRCxLQUFKLENBQVUsMENBQVYsQ0FBTjtBQUNEOztBQUVELHlDQUFlLGFBQWtCLENBQUN3QixPQUFELEVBQVV5QyxNQUFWLEtBQXFCO0FBQ3BELFdBQUtoQixJQUFMLENBQVUsVUFBVixFQUFzQixNQUFNekIsT0FBTyxFQUFuQztBQUNBLFdBQUt5QixJQUFMLENBQVUsT0FBVixFQUFtQmdCLE1BQW5CO0FBQ0QsS0FIYyxDQUFmOztBQUtBLFFBQUlwRixRQUFRLENBQUNrRixLQUFELENBQVIsSUFBbUIsVUFBVUEsS0FBN0IsSUFBc0NuRixVQUFVLENBQUNtRixLQUFLLENBQUNiLElBQVAsQ0FBcEQsRUFBa0U7QUFDaEU7QUFDQWEsTUFBQUEsS0FBSyxDQUFDYixJQUFOLHVCQUFXLElBQVg7QUFDRCxLQUhELE1BR087QUFDTCxVQUFJLGVBQWNhLEtBQWQsQ0FBSixFQUEwQjtBQUN4QixhQUFLLE1BQU1GLE1BQVgsSUFBcUJFLEtBQXJCLEVBQTRCO0FBQzFCLGVBQUssTUFBTUcsR0FBWCxJQUFrQixhQUFZTCxNQUFaLENBQWxCLEVBQXVDO0FBQ3JDLGdCQUFJLE9BQU9BLE1BQU0sQ0FBQ0ssR0FBRCxDQUFiLEtBQXVCLFNBQTNCLEVBQXNDO0FBQ3BDTCxjQUFBQSxNQUFNLENBQUNLLEdBQUQsQ0FBTixHQUFjQyxNQUFNLENBQUNOLE1BQU0sQ0FBQ0ssR0FBRCxDQUFQLENBQXBCO0FBQ0Q7QUFDRjs7QUFDRCxlQUFLSixLQUFMLENBQVdELE1BQVg7QUFDRDs7QUFDRCxhQUFLYixHQUFMO0FBQ0QsT0FWRCxNQVVPLElBQUksT0FBT2UsS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUNwQyxpREFBaUJELEtBQWpCLENBQXVCQyxLQUF2QixFQUE4QixNQUE5Qjs7QUFDQSxpREFBaUJmLEdBQWpCO0FBQ0Q7QUFDRjs7QUFFRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRXZCLEVBQUFBLElBQUksQ0FBQzJDLFVBQUQsRUFBeUJDLFFBQXpCLEVBQXVEO0FBQ3pELFFBQUkseUNBQWlCd0YsU0FBckIsRUFBZ0M7QUFDOUIsV0FBS3ZILE9BQUw7QUFDRDs7QUFDRCxXQUFPLHFDQUFjYixJQUFkLENBQW1CMkMsVUFBbkIsRUFBK0JDLFFBQS9CLENBQVA7QUFDRDs7QUFsSWdCOztBQXFJbkIsU0FBUzBFLGVBQVQsQ0FBeUJsSSxPQUF6QixFQUEwRTtBQUN4RSxRQUFNekIsS0FBSyxHQUFHeUIsT0FBSCxhQUFHQSxPQUFILHVCQUFHQSxPQUFPLENBQUV2QixFQUF2Qjs7QUFDQSxNQUFJRixLQUFLLEtBQUt5SyxTQUFkLEVBQXlCO0FBQ3ZCLFVBQU0sSUFBSTdKLEtBQUosQ0FBVSx1REFBVixDQUFOO0FBQ0Q7O0FBQ0QsU0FBT1osS0FBUDtBQUNEOztBQUVELFNBQVM0SixLQUFULENBQWVjLEVBQWYsRUFBMEM7QUFDeEMsU0FBTyxhQUFhdEksT0FBRCxJQUFhLFlBQVdBLE9BQVgsRUFBb0JzSSxFQUFwQixDQUF6QixDQUFQO0FBQ0Q7QUFFRDs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBcEwsY0FBYyxDQUFDLE1BQUQsRUFBVWdJLElBQUQsSUFBVSxJQUFJRCxJQUFKLENBQVNDLElBQVQsQ0FBbkIsQ0FBZDtBQUNBaEksY0FBYyxDQUFDLE9BQUQsRUFBV2dJLElBQUQsSUFBVSxJQUFJdUIsTUFBSixDQUFXdkIsSUFBWCxDQUFwQixDQUFkO0FBRUEsZUFBZUQsSUFBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBTYWxlc2ZvcmNlIEJ1bGsgQVBJIHJlbGF0ZWQgb3BlcmF0aW9uc1xuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgeyBEdXBsZXgsIFJlYWRhYmxlLCBXcml0YWJsZSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgam9pblN0cmVhbXMgZnJvbSAnbXVsdGlzdHJlYW0nO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBTZXJpYWxpemFibGUsIFBhcnNhYmxlIH0gZnJvbSAnLi4vcmVjb3JkLXN0cmVhbSc7XG5pbXBvcnQgSHR0cEFwaSBmcm9tICcuLi9odHRwLWFwaSc7XG5pbXBvcnQgeyBTdHJlYW1Qcm9taXNlIH0gZnJvbSAnLi4vdXRpbC9wcm9taXNlJztcbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQgeyBjb25jYXRTdHJlYW1zQXNEdXBsZXggfSBmcm9tICcuLi91dGlsL3N0cmVhbSc7XG5pbXBvcnQge1xuICBIdHRwTWV0aG9kcyxcbiAgSHR0cFJlcXVlc3QsXG4gIEh0dHBSZXNwb25zZSxcbiAgUmVjb3JkLFxuICBTY2hlbWEsXG59IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IGlzRnVuY3Rpb24sIGlzT2JqZWN0IH0gZnJvbSAnLi4vdXRpbC9mdW5jdGlvbic7XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBCdWxrT3BlcmF0aW9uID1cbiAgfCAnaW5zZXJ0J1xuICB8ICd1cGRhdGUnXG4gIHwgJ3Vwc2VydCdcbiAgfCAnZGVsZXRlJ1xuICB8ICdoYXJkRGVsZXRlJ1xuICB8ICdxdWVyeSdcbiAgfCAncXVlcnlBbGwnO1xuXG5leHBvcnQgdHlwZSBJbmdlc3RPcGVyYXRpb24gPSBFeGNsdWRlPEJ1bGtPcGVyYXRpb24sICdxdWVyeScgfCAncXVlcnlBbGwnPjtcblxuZXhwb3J0IHR5cGUgUXVlcnlPcGVyYXRpb24gPSBFeHRyYWN0PEJ1bGtPcGVyYXRpb24sICdxdWVyeScgfCAncXVlcnlBbGwnPjtcblxuZXhwb3J0IHR5cGUgQnVsa09wdGlvbnMgPSB7XG4gIGV4dElkRmllbGQ/OiBzdHJpbmc7XG4gIGNvbmN1cnJlbmN5TW9kZT86ICdTZXJpYWwnIHwgJ1BhcmFsbGVsJztcbiAgYXNzaWdubWVudFJ1bGVJZD86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIEpvYlN0YXRlID0gJ09wZW4nIHwgJ0Nsb3NlZCcgfCAnQWJvcnRlZCcgfCAnRmFpbGVkJyB8ICdVbmtub3duJztcblxuZXhwb3J0IHR5cGUgSm9iU3RhdGVWMiA9XG4gIHwgRXhjbHVkZTxKb2JTdGF0ZSwgJ0Nsb3NlZCcgfCAnVW5rbm93bic+XG4gIHwgJ1VwbG9hZENvbXBsZXRlJ1xuICB8ICdJblByb2dyZXNzJ1xuICB8ICdKb2JDb21wbGV0ZSc7XG5cbmV4cG9ydCB0eXBlIEpvYkluZm8gPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG9iamVjdDogc3RyaW5nO1xuICBvcGVyYXRpb246IEJ1bGtPcGVyYXRpb247XG4gIHN0YXRlOiBKb2JTdGF0ZTtcbn07XG5cbmV4cG9ydCB0eXBlIEpvYkluZm9WMiA9IHtcbiAgYXBpVmVyc2lvbjogc3RyaW5nO1xuICBhc3NpZ25tZW50UnVsZUlkPzogc3RyaW5nO1xuICBjb2x1bW5EZWxpbWl0ZXI6XG4gICAgfCAnQkFDS1FVT1RFJ1xuICAgIHwgJ0NBUkVUJ1xuICAgIHwgJ0NPTU1BJ1xuICAgIHwgJ1BJUEUnXG4gICAgfCAnU0VNSUNPTE9OJ1xuICAgIHwgJ1RBQic7XG4gIGNvbmN1cnJlbmN5TW9kZTogJ1BhcmFsbGVsJztcbiAgY29udGVudFR5cGU6ICdDU1YnO1xuICBjb250ZW50VXJsOiBzdHJpbmc7XG4gIGNyZWF0ZWRCeUlkOiBzdHJpbmc7XG4gIGNyZWF0ZWREYXRlOiBzdHJpbmc7XG4gIGV4dGVybmFsSWRGaWVsZE5hbWU/OiBzdHJpbmc7XG4gIGlkOiBzdHJpbmc7XG4gIGpvYlR5cGU6ICdCaWdPYmplY3RJbmdlc3QnIHwgJ0NsYXNzaWMnIHwgJ1YySW5nZXN0JztcbiAgbGluZUVuZGluZzogJ0xGJyB8ICdDUkxGJztcbiAgb2JqZWN0OiBzdHJpbmc7XG4gIG9wZXJhdGlvbjogQnVsa09wZXJhdGlvbjtcbiAgc3RhdGU6IEpvYlN0YXRlVjI7XG4gIHN5c3RlbU1vZHN0YW1wOiBzdHJpbmc7XG4gIG51bWJlclJlY29yZHNQcm9jZXNzZWQ/OiBudW1iZXI7XG4gIG51bWJlclJlY29yZHNGYWlsZWQ/OiBudW1iZXI7XG59O1xuXG50eXBlIEpvYkluZm9SZXNwb25zZSA9IHtcbiAgam9iSW5mbzogSm9iSW5mbztcbn07XG5cbmV4cG9ydCB0eXBlIEJhdGNoU3RhdGUgPVxuICB8ICdRdWV1ZWQnXG4gIHwgJ0luUHJvZ3Jlc3MnXG4gIHwgJ0NvbXBsZXRlZCdcbiAgfCAnRmFpbGVkJ1xuICB8ICdOb3RQcm9jZXNzZWQnO1xuXG5leHBvcnQgdHlwZSBCYXRjaEluZm8gPSB7XG4gIGlkOiBzdHJpbmc7XG4gIGpvYklkOiBzdHJpbmc7XG4gIHN0YXRlOiBCYXRjaFN0YXRlO1xuICBzdGF0ZU1lc3NhZ2U6IHN0cmluZztcbiAgbnVtYmVyUmVjb3Jkc1Byb2Nlc3NlZDogc3RyaW5nO1xuICBudW1iZXJSZWNvcmRzRmFpbGVkOiBzdHJpbmc7XG4gIHRvdGFsUHJvY2Vzc2luZ1RpbWU6IHN0cmluZztcbn07XG5cbnR5cGUgQmF0Y2hJbmZvUmVzcG9uc2UgPSB7XG4gIGJhdGNoSW5mbzogQmF0Y2hJbmZvO1xufTtcblxudHlwZSBCYXRjaEluZm9MaXN0UmVzcG9uc2UgPSB7XG4gIGJhdGNoSW5mb0xpc3Q6IHtcbiAgICBiYXRjaEluZm86IEJhdGNoSW5mbyB8IEJhdGNoSW5mb1tdO1xuICB9O1xufTtcblxuZXhwb3J0IHR5cGUgQnVsa1F1ZXJ5QmF0Y2hSZXN1bHQgPSBBcnJheTx7XG4gIGlkOiBzdHJpbmc7XG4gIGJhdGNoSWQ6IHN0cmluZztcbiAgam9iSWQ6IHN0cmluZztcbn0+O1xuXG5leHBvcnQgdHlwZSBCdWxrSW5nZXN0QmF0Y2hSZXN1bHQgPSBBcnJheTx7XG4gIGlkOiBzdHJpbmcgfCBudWxsO1xuICBzdWNjZXNzOiBib29sZWFuO1xuICBlcnJvcnM6IHN0cmluZ1tdO1xufT47XG5cbmV4cG9ydCB0eXBlIEJhdGNoUmVzdWx0PE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+ID0gT3ByIGV4dGVuZHNcbiAgfCAncXVlcnknXG4gIHwgJ3F1ZXJ5QWxsJ1xuICA/IEJ1bGtRdWVyeUJhdGNoUmVzdWx0XG4gIDogQnVsa0luZ2VzdEJhdGNoUmVzdWx0O1xuXG50eXBlIEJ1bGtJbmdlc3RSZXN1bHRSZXNwb25zZSA9IEFycmF5PHtcbiAgSWQ6IHN0cmluZztcbiAgU3VjY2Vzczogc3RyaW5nO1xuICBFcnJvcjogc3RyaW5nO1xufT47XG5cbnR5cGUgQnVsa1F1ZXJ5UmVzdWx0UmVzcG9uc2UgPSB7XG4gICdyZXN1bHQtbGlzdCc6IHtcbiAgICByZXN1bHQ6IHN0cmluZyB8IHN0cmluZ1tdO1xuICB9O1xufTtcblxudHlwZSBCdWxrUmVxdWVzdCA9IHtcbiAgbWV0aG9kOiBIdHRwTWV0aG9kcztcbiAgcGF0aDogc3RyaW5nO1xuICBib2R5Pzogc3RyaW5nO1xuICBoZWFkZXJzPzogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH07XG4gIHJlc3BvbnNlVHlwZT86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM8UyBleHRlbmRzIFNjaGVtYT4gPSBBcnJheTxcbiAge1xuICAgIHNmX19DcmVhdGVkOiAndHJ1ZScgfCAnZmFsc2UnO1xuICAgIHNmX19JZDogc3RyaW5nO1xuICB9ICYgU1xuPjtcblxuZXhwb3J0IHR5cGUgSW5nZXN0Sm9iVjJGYWlsZWRSZXN1bHRzPFMgZXh0ZW5kcyBTY2hlbWE+ID0gQXJyYXk8XG4gIHtcbiAgICBzZl9fRXJyb3I6IHN0cmluZztcbiAgICBzZl9fSWQ6IHN0cmluZztcbiAgfSAmIFNcbj47XG5cbmV4cG9ydCB0eXBlIEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFMgZXh0ZW5kcyBTY2hlbWE+ID0gQXJyYXk8Uz47XG5cbmV4cG9ydCB0eXBlIEluZ2VzdEpvYlYyUmVzdWx0czxTIGV4dGVuZHMgU2NoZW1hPiA9IHtcbiAgc3VjY2Vzc2Z1bFJlc3VsdHM6IEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM8Uz47XG4gIGZhaWxlZFJlc3VsdHM6IEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTPjtcbiAgdW5wcm9jZXNzZWRSZWNvcmRzOiBJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTPjtcbn07XG5cbnR5cGUgTmV3SW5nZXN0Sm9iT3B0aW9ucyA9IFJlcXVpcmVkPFBpY2s8Sm9iSW5mb1YyLCAnb2JqZWN0JyB8ICdvcGVyYXRpb24nPj4gJlxuICBQYXJ0aWFsPFBpY2s8Sm9iSW5mb1YyLCAnYXNzaWdubWVudFJ1bGVJZCcgfCAnZXh0ZXJuYWxJZEZpZWxkTmFtZSc+PjtcblxudHlwZSBFeGlzdGluZ0luZ2VzdEpvYk9wdGlvbnMgPSBQaWNrPEpvYkluZm9WMiwgJ2lkJz47XG5cbnR5cGUgQ3JlYXRlSW5nZXN0Sm9iVjJSZXF1ZXN0ID0gPFQ+KHJlcXVlc3Q6IEJ1bGtSZXF1ZXN0KSA9PiBTdHJlYW1Qcm9taXNlPFQ+O1xuXG50eXBlIENyZWF0ZUluZ2VzdEpvYlYyT3B0aW9uczxTIGV4dGVuZHMgU2NoZW1hPiA9IHtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcbiAgam9iSW5mbzogTmV3SW5nZXN0Sm9iT3B0aW9ucyB8IEV4aXN0aW5nSW5nZXN0Sm9iT3B0aW9ucztcbiAgcG9sbGluZ09wdGlvbnM6IEJ1bGtWMlBvbGxpbmdPcHRpb25zO1xufTtcblxudHlwZSBDcmVhdGVKb2JEYXRhVjJPcHRpb25zPFMgZXh0ZW5kcyBTY2hlbWEsIE9wciBleHRlbmRzIEluZ2VzdE9wZXJhdGlvbj4gPSB7XG4gIGpvYjogSW5nZXN0Sm9iVjI8UywgT3ByPjtcbiAgY3JlYXRlUmVxdWVzdDogQ3JlYXRlSW5nZXN0Sm9iVjJSZXF1ZXN0O1xufTtcblxudHlwZSBDcmVhdGVRdWVyeUpvYlYyT3B0aW9uczxTIGV4dGVuZHMgU2NoZW1hPiA9IHtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcbiAgb3BlcmF0aW9uOiBRdWVyeU9wZXJhdGlvbjtcbiAgcXVlcnk6IHN0cmluZztcbiAgcG9sbGluZ09wdGlvbnM6IEJ1bGtWMlBvbGxpbmdPcHRpb25zO1xufTtcblxudHlwZSBCdWxrVjJQb2xsaW5nT3B0aW9ucyA9IHtcbiAgcG9sbEludGVydmFsOiBudW1iZXI7XG4gIHBvbGxUaW1lb3V0OiBudW1iZXI7XG59O1xuXG4vKipcbiAqIENsYXNzIGZvciBCdWxrIEFQSSBKb2JcbiAqL1xuZXhwb3J0IGNsYXNzIEpvYjxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgT3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvblxuPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHR5cGU6IHN0cmluZyB8IG51bGw7XG4gIG9wZXJhdGlvbjogT3ByIHwgbnVsbDtcbiAgb3B0aW9uczogQnVsa09wdGlvbnM7XG4gIGlkOiBzdHJpbmcgfCBudWxsO1xuICBzdGF0ZTogSm9iU3RhdGU7XG4gIF9idWxrOiBCdWxrPFM+O1xuICBfYmF0Y2hlczogeyBbaWQ6IHN0cmluZ106IEJhdGNoPFMsIE9wcj4gfTtcbiAgX2pvYkluZm86IFByb21pc2U8Sm9iSW5mbz4gfCB1bmRlZmluZWQ7XG4gIF9lcnJvcjogRXJyb3IgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICBidWxrOiBCdWxrPFM+LFxuICAgIHR5cGU6IHN0cmluZyB8IG51bGwsXG4gICAgb3BlcmF0aW9uOiBPcHIgfCBudWxsLFxuICAgIG9wdGlvbnM6IEJ1bGtPcHRpb25zIHwgbnVsbCxcbiAgICBqb2JJZD86IHN0cmluZyxcbiAgKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9idWxrID0gYnVsaztcbiAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgIHRoaXMub3BlcmF0aW9uID0gb3BlcmF0aW9uO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gICAgdGhpcy5pZCA9IGpvYklkID8/IG51bGw7XG4gICAgdGhpcy5zdGF0ZSA9IHRoaXMuaWQgPyAnT3BlbicgOiAnVW5rbm93bic7XG4gICAgdGhpcy5fYmF0Y2hlcyA9IHt9O1xuICAgIC8vIGRlZmF1bHQgZXJyb3IgaGFuZGxlciB0byBrZWVwIHRoZSBsYXRlc3QgZXJyb3JcbiAgICB0aGlzLm9uKCdlcnJvcicsIChlcnJvcikgPT4gKHRoaXMuX2Vycm9yID0gZXJyb3IpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gbGF0ZXN0IGpvYkluZm8gZnJvbSBjYWNoZVxuICAgKi9cbiAgaW5mbygpIHtcbiAgICAvLyBpZiBjYWNoZSBpcyBub3QgYXZhaWxhYmxlLCBjaGVjayB0aGUgbGF0ZXN0XG4gICAgaWYgKCF0aGlzLl9qb2JJbmZvKSB7XG4gICAgICB0aGlzLl9qb2JJbmZvID0gdGhpcy5jaGVjaygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fam9iSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVuIG5ldyBqb2IgYW5kIGdldCBqb2JpbmZvXG4gICAqL1xuICBvcGVuKCk6IFByb21pc2U8Sm9iSW5mbz4ge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cbiAgICAvLyBpZiBzb2JqZWN0IHR5cGUgLyBvcGVyYXRpb24gaXMgbm90IHByb3ZpZGVkXG4gICAgaWYgKCF0aGlzLnR5cGUgfHwgIXRoaXMub3BlcmF0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3R5cGUgLyBvcGVyYXRpb24gaXMgcmVxdWlyZWQgdG8gb3BlbiBhIG5ldyBqb2InKTtcbiAgICB9XG5cbiAgICAvLyBpZiBub3QgcmVxdWVzdGVkIG9wZW5pbmcgam9iXG4gICAgaWYgKCF0aGlzLl9qb2JJbmZvKSB7XG4gICAgICBsZXQgb3BlcmF0aW9uID0gdGhpcy5vcGVyYXRpb24udG9Mb3dlckNhc2UoKTtcbiAgICAgIGlmIChvcGVyYXRpb24gPT09ICdoYXJkZGVsZXRlJykge1xuICAgICAgICBvcGVyYXRpb24gPSAnaGFyZERlbGV0ZSc7XG4gICAgICB9XG4gICAgICBpZiAob3BlcmF0aW9uID09PSAncXVlcnlhbGwnKSB7XG4gICAgICAgIG9wZXJhdGlvbiA9ICdxdWVyeUFsbCc7XG4gICAgICB9XG4gICAgICBjb25zdCBib2R5ID0gYFxuPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48am9iSW5mbyAgeG1sbnM9XCJodHRwOi8vd3d3LmZvcmNlLmNvbS8yMDA5LzA2L2FzeW5jYXBpL2RhdGFsb2FkXCI+XG4gIDxvcGVyYXRpb24+JHtvcGVyYXRpb259PC9vcGVyYXRpb24+XG4gIDxvYmplY3Q+JHt0aGlzLnR5cGV9PC9vYmplY3Q+XG4gICR7XG4gICAgb3B0aW9ucy5leHRJZEZpZWxkXG4gICAgICA/IGA8ZXh0ZXJuYWxJZEZpZWxkTmFtZT4ke29wdGlvbnMuZXh0SWRGaWVsZH08L2V4dGVybmFsSWRGaWVsZE5hbWU+YFxuICAgICAgOiAnJ1xuICB9XG4gICR7XG4gICAgb3B0aW9ucy5jb25jdXJyZW5jeU1vZGVcbiAgICAgID8gYDxjb25jdXJyZW5jeU1vZGU+JHtvcHRpb25zLmNvbmN1cnJlbmN5TW9kZX08L2NvbmN1cnJlbmN5TW9kZT5gXG4gICAgICA6ICcnXG4gIH1cbiAgJHtcbiAgICBvcHRpb25zLmFzc2lnbm1lbnRSdWxlSWRcbiAgICAgID8gYDxhc3NpZ25tZW50UnVsZUlkPiR7b3B0aW9ucy5hc3NpZ25tZW50UnVsZUlkfTwvYXNzaWdubWVudFJ1bGVJZD5gXG4gICAgICA6ICcnXG4gIH1cbiAgPGNvbnRlbnRUeXBlPkNTVjwvY29udGVudFR5cGU+XG48L2pvYkluZm8+XG4gICAgICBgLnRyaW0oKTtcblxuICAgICAgdGhpcy5fam9iSW5mbyA9IChhc3luYyAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxKb2JJbmZvUmVzcG9uc2U+KHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgcGF0aDogJy9qb2InLFxuICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi94bWw7IGNoYXJzZXQ9dXRmLTgnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGhpcy5lbWl0KCdvcGVuJywgcmVzLmpvYkluZm8pO1xuICAgICAgICAgIHRoaXMuaWQgPSByZXMuam9iSW5mby5pZDtcbiAgICAgICAgICB0aGlzLnN0YXRlID0gcmVzLmpvYkluZm8uc3RhdGU7XG4gICAgICAgICAgcmV0dXJuIHJlcy5qb2JJbmZvO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0pKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9qb2JJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBiYXRjaCBpbnN0YW5jZSBpbiB0aGUgam9iXG4gICAqL1xuICBjcmVhdGVCYXRjaCgpOiBCYXRjaDxTLCBPcHI+IHtcbiAgICBjb25zdCBiYXRjaCA9IG5ldyBCYXRjaCh0aGlzKTtcbiAgICBiYXRjaC5vbigncXVldWUnLCAoKSA9PiB7XG4gICAgICB0aGlzLl9iYXRjaGVzW2JhdGNoLmlkIV0gPSBiYXRjaDtcbiAgICB9KTtcbiAgICByZXR1cm4gYmF0Y2g7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGEgYmF0Y2ggaW5zdGFuY2Ugc3BlY2lmaWVkIGJ5IGdpdmVuIGJhdGNoIElEXG4gICAqL1xuICBiYXRjaChiYXRjaElkOiBzdHJpbmcpOiBCYXRjaDxTLCBPcHI+IHtcbiAgICBsZXQgYmF0Y2ggPSB0aGlzLl9iYXRjaGVzW2JhdGNoSWRdO1xuICAgIGlmICghYmF0Y2gpIHtcbiAgICAgIGJhdGNoID0gbmV3IEJhdGNoKHRoaXMsIGJhdGNoSWQpO1xuICAgICAgdGhpcy5fYmF0Y2hlc1tiYXRjaElkXSA9IGJhdGNoO1xuICAgIH1cbiAgICByZXR1cm4gYmF0Y2g7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIGxhdGVzdCBqb2Igc3RhdHVzIGZyb20gc2VydmVyXG4gICAqL1xuICBjaGVjaygpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG5cbiAgICB0aGlzLl9qb2JJbmZvID0gKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGpvYklkID0gYXdhaXQgdGhpcy5yZWFkeSgpO1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxKb2JJbmZvUmVzcG9uc2U+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkLFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgICAgfSk7XG4gICAgICBsb2dnZXIuZGVidWcocmVzLmpvYkluZm8pO1xuICAgICAgdGhpcy5pZCA9IHJlcy5qb2JJbmZvLmlkO1xuICAgICAgdGhpcy50eXBlID0gcmVzLmpvYkluZm8ub2JqZWN0O1xuICAgICAgdGhpcy5vcGVyYXRpb24gPSByZXMuam9iSW5mby5vcGVyYXRpb24gYXMgT3ByO1xuICAgICAgdGhpcy5zdGF0ZSA9IHJlcy5qb2JJbmZvLnN0YXRlO1xuICAgICAgcmV0dXJuIHJlcy5qb2JJbmZvO1xuICAgIH0pKCk7XG5cbiAgICByZXR1cm4gdGhpcy5fam9iSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBXYWl0IHRpbGwgdGhlIGpvYiBpcyBhc3NpZ25lZCB0byBzZXJ2ZXJcbiAgICovXG4gIHJlYWR5KCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgcmV0dXJuIHRoaXMuaWRcbiAgICAgID8gUHJvbWlzZS5yZXNvbHZlKHRoaXMuaWQpXG4gICAgICA6IHRoaXMub3BlbigpLnRoZW4oKHsgaWQgfSkgPT4gaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIExpc3QgYWxsIHJlZ2lzdGVyZWQgYmF0Y2ggaW5mbyBpbiBqb2JcbiAgICovXG4gIGFzeW5jIGxpc3QoKSB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3QgbG9nZ2VyID0gYnVsay5fbG9nZ2VyO1xuICAgIGNvbnN0IGpvYklkID0gYXdhaXQgdGhpcy5yZWFkeSgpO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGJ1bGsuX3JlcXVlc3Q8QmF0Y2hJbmZvTGlzdFJlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkICsgJy9iYXRjaCcsXG4gICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgIH0pO1xuICAgIGxvZ2dlci5kZWJ1ZyhyZXMuYmF0Y2hJbmZvTGlzdC5iYXRjaEluZm8pO1xuICAgIGNvbnN0IGJhdGNoSW5mb0xpc3QgPSBBcnJheS5pc0FycmF5KHJlcy5iYXRjaEluZm9MaXN0LmJhdGNoSW5mbylcbiAgICAgID8gcmVzLmJhdGNoSW5mb0xpc3QuYmF0Y2hJbmZvXG4gICAgICA6IFtyZXMuYmF0Y2hJbmZvTGlzdC5iYXRjaEluZm9dO1xuICAgIHJldHVybiBiYXRjaEluZm9MaXN0O1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlIG9wZW5lZCBqb2JcbiAgICovXG4gIGFzeW5jIGNsb3NlKCkge1xuICAgIGlmICghdGhpcy5pZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3Qgam9iSW5mbyA9IGF3YWl0IHRoaXMuX2NoYW5nZVN0YXRlKCdDbG9zZWQnKTtcbiAgICAgIHRoaXMuaWQgPSBudWxsO1xuICAgICAgdGhpcy5lbWl0KCdjbG9zZScsIGpvYkluZm8pO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2V0IHRoZSBzdGF0dXMgdG8gYWJvcnRcbiAgICovXG4gIGFzeW5jIGFib3J0KCkge1xuICAgIGlmICghdGhpcy5pZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3Qgam9iSW5mbyA9IGF3YWl0IHRoaXMuX2NoYW5nZVN0YXRlKCdBYm9ydGVkJyk7XG4gICAgICB0aGlzLmlkID0gbnVsbDtcbiAgICAgIHRoaXMuZW1pdCgnYWJvcnQnLCBqb2JJbmZvKTtcbiAgICAgIHJldHVybiBqb2JJbmZvO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBhc3luYyBfY2hhbmdlU3RhdGUoc3RhdGU6IEpvYlN0YXRlKSB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3QgbG9nZ2VyID0gYnVsay5fbG9nZ2VyO1xuXG4gICAgdGhpcy5fam9iSW5mbyA9IChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBqb2JJZCA9IGF3YWl0IHRoaXMucmVhZHkoKTtcbiAgICAgIGNvbnN0IGJvZHkgPSBgIFxuPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG4gIDxqb2JJbmZvIHhtbG5zPVwiaHR0cDovL3d3dy5mb3JjZS5jb20vMjAwOS8wNi9hc3luY2FwaS9kYXRhbG9hZFwiPlxuICA8c3RhdGU+JHtzdGF0ZX08L3N0YXRlPlxuPC9qb2JJbmZvPlxuICAgICAgYC50cmltKCk7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PEpvYkluZm9SZXNwb25zZT4oe1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkLFxuICAgICAgICBib2R5OiBib2R5LFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi94bWw7IGNoYXJzZXQ9dXRmLTgnLFxuICAgICAgICB9LFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgICAgfSk7XG4gICAgICBsb2dnZXIuZGVidWcocmVzLmpvYkluZm8pO1xuICAgICAgdGhpcy5zdGF0ZSA9IHJlcy5qb2JJbmZvLnN0YXRlO1xuICAgICAgcmV0dXJuIHJlcy5qb2JJbmZvO1xuICAgIH0pKCk7XG4gICAgcmV0dXJuIHRoaXMuX2pvYkluZm87XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5jbGFzcyBQb2xsaW5nVGltZW91dEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBqb2JJZDogc3RyaW5nO1xuICBiYXRjaElkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIGpvYklkOiBzdHJpbmcsIGJhdGNoSWQ6IHN0cmluZykge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdQb2xsaW5nVGltZW91dCc7XG4gICAgdGhpcy5qb2JJZCA9IGpvYklkO1xuICAgIHRoaXMuYmF0Y2hJZCA9IGJhdGNoSWQ7XG4gIH1cbn1cblxuY2xhc3MgSm9iUG9sbGluZ1RpbWVvdXRFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgam9iSWQ6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgam9iSWQ6IHN0cmluZykge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdKb2JQb2xsaW5nVGltZW91dCc7XG4gICAgdGhpcy5qb2JJZCA9IGpvYklkO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBCYXRjaCAoZXh0ZW5kcyBXcml0YWJsZSlcbiAqL1xuZXhwb3J0IGNsYXNzIEJhdGNoPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uXG4+IGV4dGVuZHMgV3JpdGFibGUge1xuICBqb2I6IEpvYjxTLCBPcHI+O1xuICBpZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBfYnVsazogQnVsazxTPjtcbiAgX3VwbG9hZFN0cmVhbTogU2VyaWFsaXphYmxlO1xuICBfZG93bmxvYWRTdHJlYW06IFBhcnNhYmxlO1xuICBfZGF0YVN0cmVhbTogRHVwbGV4O1xuICBfcmVzdWx0OiBQcm9taXNlPEJhdGNoUmVzdWx0PE9wcj4+IHwgdW5kZWZpbmVkO1xuICBfZXJyb3I6IEVycm9yIHwgdW5kZWZpbmVkO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3Ioam9iOiBKb2I8UywgT3ByPiwgaWQ/OiBzdHJpbmcpIHtcbiAgICBzdXBlcih7IG9iamVjdE1vZGU6IHRydWUgfSk7XG4gICAgdGhpcy5qb2IgPSBqb2I7XG4gICAgdGhpcy5pZCA9IGlkO1xuICAgIHRoaXMuX2J1bGsgPSBqb2IuX2J1bGs7XG5cbiAgICAvLyBkZWZhdWx0IGVycm9yIGhhbmRsZXIgdG8ga2VlcCB0aGUgbGF0ZXN0IGVycm9yXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyb3IpID0+ICh0aGlzLl9lcnJvciA9IGVycm9yKSk7XG5cbiAgICAvL1xuICAgIC8vIHNldHVwIGRhdGEgc3RyZWFtc1xuICAgIC8vXG4gICAgY29uc3QgY29udmVydGVyT3B0aW9ucyA9IHsgbnVsbFZhbHVlOiAnI04vQScgfTtcbiAgICBjb25zdCB1cGxvYWRTdHJlYW0gPSAodGhpcy5fdXBsb2FkU3RyZWFtID0gbmV3IFNlcmlhbGl6YWJsZSgpKTtcbiAgICBjb25zdCB1cGxvYWREYXRhU3RyZWFtID0gdXBsb2FkU3RyZWFtLnN0cmVhbSgnY3N2JywgY29udmVydGVyT3B0aW9ucyk7XG4gICAgY29uc3QgZG93bmxvYWRTdHJlYW0gPSAodGhpcy5fZG93bmxvYWRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKSk7XG4gICAgY29uc3QgZG93bmxvYWREYXRhU3RyZWFtID0gZG93bmxvYWRTdHJlYW0uc3RyZWFtKCdjc3YnLCBjb252ZXJ0ZXJPcHRpb25zKTtcblxuICAgIHRoaXMub24oJ2ZpbmlzaCcsICgpID0+IHVwbG9hZFN0cmVhbS5lbmQoKSk7XG4gICAgdXBsb2FkRGF0YVN0cmVhbS5vbmNlKCdyZWFkYWJsZScsIGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIGVuc3VyZSB0aGUgam9iIGlzIG9wZW5lZCBpbiBzZXJ2ZXIgb3Igam9iIGlkIGlzIGFscmVhZHkgYXNzaWduZWRcbiAgICAgICAgYXdhaXQgdGhpcy5qb2IucmVhZHkoKTtcbiAgICAgICAgLy8gcGlwZSB1cGxvYWQgZGF0YSB0byBiYXRjaCBBUEkgcmVxdWVzdCBzdHJlYW1cbiAgICAgICAgdXBsb2FkRGF0YVN0cmVhbS5waXBlKHRoaXMuX2NyZWF0ZVJlcXVlc3RTdHJlYW0oKSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBkdXBsZXggZGF0YSBzdHJlYW0sIG9wZW5lZCBhY2Nlc3MgdG8gQVBJIHByb2dyYW1tZXJzIGJ5IEJhdGNoI3N0cmVhbSgpXG4gICAgdGhpcy5fZGF0YVN0cmVhbSA9IGNvbmNhdFN0cmVhbXNBc0R1cGxleChcbiAgICAgIHVwbG9hZERhdGFTdHJlYW0sXG4gICAgICBkb3dubG9hZERhdGFTdHJlYW0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb25uZWN0IGJhdGNoIEFQSSBhbmQgY3JlYXRlIHN0cmVhbSBpbnN0YW5jZSBvZiByZXF1ZXN0L3Jlc3BvbnNlXG4gICAqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfY3JlYXRlUmVxdWVzdFN0cmVhbSgpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG4gICAgY29uc3QgcmVxID0gYnVsay5fcmVxdWVzdDxCYXRjaEluZm9SZXNwb25zZT4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBwYXRoOiAnL2pvYi8nICsgdGhpcy5qb2IuaWQgKyAnL2JhdGNoJyxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L2NzdicsXG4gICAgICB9LFxuICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24veG1sJyxcbiAgICB9KTtcbiAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcmVxO1xuICAgICAgICBsb2dnZXIuZGVidWcocmVzLmJhdGNoSW5mbyk7XG4gICAgICAgIHRoaXMuaWQgPSByZXMuYmF0Y2hJbmZvLmlkO1xuICAgICAgICB0aGlzLmVtaXQoJ3F1ZXVlJywgcmVzLmJhdGNoSW5mbyk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gcmVxLnN0cmVhbSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEltcGxlbWVudGF0aW9uIG9mIFdyaXRhYmxlXG4gICAqL1xuICBfd3JpdGUocmVjb3JkXzogUmVjb3JkLCBlbmM6IHN0cmluZywgY2I6ICgpID0+IHZvaWQpIHtcbiAgICBjb25zdCB7IElkLCB0eXBlLCBhdHRyaWJ1dGVzLCAuLi5ycmVjIH0gPSByZWNvcmRfO1xuICAgIGxldCByZWNvcmQ7XG4gICAgc3dpdGNoICh0aGlzLmpvYi5vcGVyYXRpb24pIHtcbiAgICAgIGNhc2UgJ2luc2VydCc6XG4gICAgICAgIHJlY29yZCA9IHJyZWM7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZGVsZXRlJzpcbiAgICAgIGNhc2UgJ2hhcmREZWxldGUnOlxuICAgICAgICByZWNvcmQgPSB7IElkIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmVjb3JkID0geyBJZCwgLi4ucnJlYyB9O1xuICAgIH1cbiAgICB0aGlzLl91cGxvYWRTdHJlYW0ud3JpdGUocmVjb3JkLCBlbmMsIGNiKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGR1cGxleCBzdHJlYW0gd2hpY2ggYWNjZXB0cyBDU1YgZGF0YSBpbnB1dCBhbmQgYmF0Y2ggcmVzdWx0IG91dHB1dFxuICAgKi9cbiAgc3RyZWFtKCkge1xuICAgIHJldHVybiB0aGlzLl9kYXRhU3RyZWFtO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgYmF0Y2ggb3BlcmF0aW9uXG4gICAqL1xuICBleGVjdXRlKGlucHV0Pzogc3RyaW5nIHwgUmVjb3JkW10gfCBSZWFkYWJsZSkge1xuICAgIC8vIGlmIGJhdGNoIGlzIGFscmVhZHkgZXhlY3V0ZWRcbiAgICBpZiAodGhpcy5fcmVzdWx0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIGFscmVhZHkgZXhlY3V0ZWQuJyk7XG4gICAgfVxuXG4gICAgdGhpcy5fcmVzdWx0ID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5vbmNlKCdyZXNwb25zZScsIHJlc29sdmUpO1xuICAgICAgdGhpcy5vbmNlKCdlcnJvcicsIHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBpZiAoaXNPYmplY3QoaW5wdXQpICYmICdwaXBlJyBpbiBpbnB1dCAmJiBpc0Z1bmN0aW9uKGlucHV0LnBpcGUpKSB7XG4gICAgICAvLyBpZiBpbnB1dCBoYXMgc3RyZWFtLlJlYWRhYmxlIGludGVyZmFjZVxuICAgICAgaW5wdXQucGlwZSh0aGlzLl9kYXRhU3RyZWFtKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG4gICAgICAgIGZvciAoY29uc3QgcmVjb3JkIG9mIGlucHV0KSB7XG4gICAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiByZWNvcmRba2V5XSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgIHJlY29yZFtrZXldID0gU3RyaW5nKHJlY29yZFtrZXldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy53cml0ZShyZWNvcmQpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdGhpcy5fZGF0YVN0cmVhbS53cml0ZShpbnB1dCwgJ3V0ZjgnKTtcbiAgICAgICAgdGhpcy5fZGF0YVN0cmVhbS5lbmQoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyByZXR1cm4gQmF0Y2ggaW5zdGFuY2UgZm9yIGNoYWluaW5nXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBydW4gPSB0aGlzLmV4ZWN1dGU7XG5cbiAgZXhlYyA9IHRoaXMuZXhlY3V0ZTtcblxuICAvKipcbiAgICogUHJvbWlzZS9BKyBpbnRlcmZhY2VcbiAgICogRGVsZWdhdGUgdG8gcHJvbWlzZSwgcmV0dXJuIHByb21pc2UgaW5zdGFuY2UgZm9yIGJhdGNoIHJlc3VsdFxuICAgKi9cbiAgdGhlbihcbiAgICBvblJlc29sdmVkOiAocmVzOiBCYXRjaFJlc3VsdDxPcHI+KSA9PiB2b2lkLFxuICAgIG9uUmVqZWN0OiAoZXJyOiBhbnkpID0+IHZvaWQsXG4gICkge1xuICAgIGlmICghdGhpcy5fcmVzdWx0KSB7XG4gICAgICB0aGlzLmV4ZWN1dGUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3Jlc3VsdCEudGhlbihvblJlc29sdmVkLCBvblJlamVjdCk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIGxhdGVzdCBiYXRjaCBzdGF0dXMgaW4gc2VydmVyXG4gICAqL1xuICBhc3luYyBjaGVjaygpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG4gICAgY29uc3Qgam9iSWQgPSB0aGlzLmpvYi5pZDtcbiAgICBjb25zdCBiYXRjaElkID0gdGhpcy5pZDtcblxuICAgIGlmICgham9iSWQgfHwgIWJhdGNoSWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQmF0Y2ggbm90IHN0YXJ0ZWQuJyk7XG4gICAgfVxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGJ1bGsuX3JlcXVlc3Q8QmF0Y2hJbmZvUmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQgKyAnL2JhdGNoLycgKyBiYXRjaElkLFxuICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24veG1sJyxcbiAgICB9KTtcbiAgICBsb2dnZXIuZGVidWcocmVzLmJhdGNoSW5mbyk7XG4gICAgcmV0dXJuIHJlcy5iYXRjaEluZm87XG4gIH1cblxuICAvKipcbiAgICogUG9sbGluZyB0aGUgYmF0Y2ggcmVzdWx0IGFuZCByZXRyaWV2ZVxuICAgKi9cbiAgcG9sbChpbnRlcnZhbDogbnVtYmVyLCB0aW1lb3V0OiBudW1iZXIpIHtcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuam9iLmlkO1xuICAgIGNvbnN0IGJhdGNoSWQgPSB0aGlzLmlkO1xuXG4gICAgaWYgKCFqb2JJZCB8fCAhYmF0Y2hJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXRjaCBub3Qgc3RhcnRlZC4nKTtcbiAgICB9XG4gICAgY29uc3Qgc3RhcnRUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgY29uc3QgcG9sbCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgaWYgKHN0YXJ0VGltZSArIHRpbWVvdXQgPCBub3cpIHtcbiAgICAgICAgY29uc3QgZXJyID0gbmV3IFBvbGxpbmdUaW1lb3V0RXJyb3IoXG4gICAgICAgICAgJ1BvbGxpbmcgdGltZSBvdXQuIEpvYiBJZCA9ICcgKyBqb2JJZCArICcgLCBiYXRjaCBJZCA9ICcgKyBiYXRjaElkLFxuICAgICAgICAgIGpvYklkLFxuICAgICAgICAgIGJhdGNoSWQsXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgcmVzO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmVzID0gYXdhaXQgdGhpcy5jaGVjaygpO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAocmVzLnN0YXRlID09PSAnRmFpbGVkJykge1xuICAgICAgICBpZiAocGFyc2VJbnQocmVzLm51bWJlclJlY29yZHNQcm9jZXNzZWQsIDEwKSA+IDApIHtcbiAgICAgICAgICB0aGlzLnJldHJpZXZlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIG5ldyBFcnJvcihyZXMuc3RhdGVNZXNzYWdlKSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAocmVzLnN0YXRlID09PSAnQ29tcGxldGVkJykge1xuICAgICAgICB0aGlzLnJldHJpZXZlKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmVtaXQoJ3Byb2dyZXNzJywgcmVzKTtcbiAgICAgICAgc2V0VGltZW91dChwb2xsLCBpbnRlcnZhbCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBzZXRUaW1lb3V0KHBvbGwsIGludGVydmFsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBiYXRjaCByZXN1bHRcbiAgICovXG4gIGFzeW5jIHJldHJpZXZlKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGpvYklkID0gdGhpcy5qb2IuaWQ7XG4gICAgY29uc3Qgam9iID0gdGhpcy5qb2I7XG4gICAgY29uc3QgYmF0Y2hJZCA9IHRoaXMuaWQ7XG5cbiAgICBpZiAoIWpvYklkIHx8ICFiYXRjaElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIG5vdCBzdGFydGVkLicpO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgYnVsay5fcmVxdWVzdDxcbiAgICAgICAgQnVsa0luZ2VzdFJlc3VsdFJlc3BvbnNlIHwgQnVsa1F1ZXJ5UmVzdWx0UmVzcG9uc2VcbiAgICAgID4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQgKyAnL2JhdGNoLycgKyBiYXRjaElkICsgJy9yZXN1bHQnLFxuICAgICAgfSk7XG4gICAgICBsZXQgcmVzdWx0czogQnVsa0luZ2VzdEJhdGNoUmVzdWx0IHwgQnVsa1F1ZXJ5QmF0Y2hSZXN1bHQ7XG4gICAgICBpZiAoam9iLm9wZXJhdGlvbiA9PT0gJ3F1ZXJ5JyB8fCBqb2Iub3BlcmF0aW9uID09PSAncXVlcnlBbGwnKSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IHJlc3AgYXMgQnVsa1F1ZXJ5UmVzdWx0UmVzcG9uc2U7XG4gICAgICAgIGxldCByZXN1bHRJZCA9IHJlc1sncmVzdWx0LWxpc3QnXS5yZXN1bHQ7XG4gICAgICAgIHJlc3VsdHMgPSAoQXJyYXkuaXNBcnJheShyZXN1bHRJZClcbiAgICAgICAgICA/IHJlc3VsdElkXG4gICAgICAgICAgOiBbcmVzdWx0SWRdXG4gICAgICAgICkubWFwKChpZCkgPT4gKHsgaWQsIGJhdGNoSWQsIGpvYklkIH0pKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IHJlc3AgYXMgQnVsa0luZ2VzdFJlc3VsdFJlc3BvbnNlO1xuICAgICAgICByZXN1bHRzID0gcmVzLm1hcCgocmV0KSA9PiAoe1xuICAgICAgICAgIGlkOiByZXQuSWQgfHwgbnVsbCxcbiAgICAgICAgICBzdWNjZXNzOiByZXQuU3VjY2VzcyA9PT0gJ3RydWUnLFxuICAgICAgICAgIGVycm9yczogcmV0LkVycm9yID8gW3JldC5FcnJvcl0gOiBbXSxcbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgICAgdGhpcy5lbWl0KCdyZXNwb25zZScsIHJlc3VsdHMpO1xuICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggcXVlcnkgcmVzdWx0IGFzIGEgcmVjb3JkIHN0cmVhbVxuICAgKiBAcGFyYW0ge1N0cmluZ30gcmVzdWx0SWQgLSBSZXN1bHQgaWRcbiAgICogQHJldHVybnMge1JlY29yZFN0cmVhbX0gLSBSZWNvcmQgc3RyZWFtLCBjb252ZXJ0aWJsZSB0byBDU1YgZGF0YSBzdHJlYW1cbiAgICovXG4gIHJlc3VsdChyZXN1bHRJZDogc3RyaW5nKSB7XG4gICAgY29uc3Qgam9iSWQgPSB0aGlzLmpvYi5pZDtcbiAgICBjb25zdCBiYXRjaElkID0gdGhpcy5pZDtcbiAgICBpZiAoIWpvYklkIHx8ICFiYXRjaElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIG5vdCBzdGFydGVkLicpO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcbiAgICBjb25zdCByZXN1bHREYXRhU3RyZWFtID0gcmVzdWx0U3RyZWFtLnN0cmVhbSgnY3N2Jyk7XG4gICAgdGhpcy5fYnVsa1xuICAgICAgLl9yZXF1ZXN0KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkICsgJy9iYXRjaC8nICsgYmF0Y2hJZCArICcvcmVzdWx0LycgKyByZXN1bHRJZCxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJyxcbiAgICAgIH0pXG4gICAgICAuc3RyZWFtKClcbiAgICAgIC5waXBlKHJlc3VsdERhdGFTdHJlYW0pO1xuICAgIHJldHVybiByZXN1bHRTdHJlYW07XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqXG4gKi9cbmNsYXNzIEJ1bGtBcGk8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBIdHRwQXBpPFM+IHtcbiAgYmVmb3JlU2VuZChyZXF1ZXN0OiBIdHRwUmVxdWVzdCkge1xuICAgIHJlcXVlc3QuaGVhZGVycyA9IHtcbiAgICAgIC4uLnJlcXVlc3QuaGVhZGVycyxcbiAgICAgICdYLVNGREMtU0VTU0lPTic6IHRoaXMuX2Nvbm4uYWNjZXNzVG9rZW4gPz8gJycsXG4gICAgfTtcbiAgfVxuXG4gIGlzU2Vzc2lvbkV4cGlyZWQocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIHJldHVybiAoXG4gICAgICByZXNwb25zZS5zdGF0dXNDb2RlID09PSA0MDAgJiZcbiAgICAgIC88ZXhjZXB0aW9uQ29kZT5JbnZhbGlkU2Vzc2lvbklkPFxcL2V4Y2VwdGlvbkNvZGU+Ly50ZXN0KHJlc3BvbnNlLmJvZHkpXG4gICAgKTtcbiAgfVxuXG4gIGhhc0Vycm9ySW5SZXNwb25zZUJvZHkoYm9keTogYW55KSB7XG4gICAgcmV0dXJuICEhYm9keS5lcnJvcjtcbiAgfVxuXG4gIHBhcnNlRXJyb3IoYm9keTogYW55KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGVycm9yQ29kZTogYm9keS5lcnJvci5leGNlcHRpb25Db2RlLFxuICAgICAgbWVzc2FnZTogYm9keS5lcnJvci5leGNlcHRpb25NZXNzYWdlLFxuICAgIH07XG4gIH1cbn1cblxuY2xhc3MgQnVsa0FwaVYyPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgSHR0cEFwaTxTPiB7XG4gIGhhc0Vycm9ySW5SZXNwb25zZUJvZHkoYm9keTogYW55KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIEFycmF5LmlzQXJyYXkoYm9keSkgJiZcbiAgICAgIHR5cGVvZiBib2R5WzBdID09PSAnb2JqZWN0JyAmJlxuICAgICAgJ2Vycm9yQ29kZScgaW4gYm9keVswXVxuICAgICk7XG4gIH1cblxuICBpc1Nlc3Npb25FeHBpcmVkKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpOiBib29sZWFuIHtcbiAgICByZXR1cm4gKFxuICAgICAgcmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gNDAxICYmIC9JTlZBTElEX1NFU1NJT05fSUQvLnRlc3QocmVzcG9uc2UuYm9keSlcbiAgICApO1xuICB9XG5cbiAgcGFyc2VFcnJvcihib2R5OiBhbnkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZXJyb3JDb2RlOiBib2R5WzBdLmVycm9yQ29kZSxcbiAgICAgIG1lc3NhZ2U6IGJvZHlbMF0ubWVzc2FnZSxcbiAgICB9O1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIENsYXNzIGZvciBCdWxrIEFQSVxuICpcbiAqIEBjbGFzc1xuICovXG5leHBvcnQgY2xhc3MgQnVsazxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBfbG9nZ2VyOiBMb2dnZXI7XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgaW50ZXJ2YWwgaW4gbWlsbGlzZWNvbmRzXG4gICAqL1xuICBwb2xsSW50ZXJ2YWwgPSAxMDAwO1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gICAqIEB0eXBlIHtOdW1iZXJ9XG4gICAqL1xuICBwb2xsVGltZW91dCA9IDEwMDAwO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuX2xvZ2dlciA9IGNvbm4uX2xvZ2dlcjtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgX3JlcXVlc3Q8VD4ocmVxdWVzdF86IEJ1bGtSZXF1ZXN0KSB7XG4gICAgY29uc3QgY29ubiA9IHRoaXMuX2Nvbm47XG4gICAgY29uc3QgeyBwYXRoLCByZXNwb25zZVR5cGUsIC4uLnJyZXEgfSA9IHJlcXVlc3RfO1xuICAgIGNvbnN0IGJhc2VVcmwgPSBbY29ubi5pbnN0YW5jZVVybCwgJ3NlcnZpY2VzL2FzeW5jJywgY29ubi52ZXJzaW9uXS5qb2luKFxuICAgICAgJy8nLFxuICAgICk7XG4gICAgY29uc3QgcmVxdWVzdCA9IHtcbiAgICAgIC4uLnJyZXEsXG4gICAgICB1cmw6IGJhc2VVcmwgKyBwYXRoLFxuICAgIH07XG4gICAgcmV0dXJuIG5ldyBCdWxrQXBpKHRoaXMuX2Nvbm4sIHsgcmVzcG9uc2VUeXBlIH0pLnJlcXVlc3Q8VD4ocmVxdWVzdCk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGFuZCBzdGFydCBidWxrbG9hZCBqb2IgYW5kIGJhdGNoXG4gICAqL1xuICBsb2FkPE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBvcGVyYXRpb246IE9wcixcbiAgICBpbnB1dD86IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICk6IEJhdGNoPFMsIE9wcj47XG4gIGxvYWQ8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIG9wZXJhdGlvbjogT3ByLFxuICAgIG9wdGlvbnNPcklucHV0PzogQnVsa09wdGlvbnMgfCBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nLFxuICAgIGlucHV0PzogUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgKTogQmF0Y2g8UywgT3ByPjtcbiAgbG9hZDxPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uPihcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb3BlcmF0aW9uOiBPcHIsXG4gICAgb3B0aW9uc09ySW5wdXQ/OiBCdWxrT3B0aW9ucyB8IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICAgaW5wdXQ/OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nLFxuICApIHtcbiAgICBsZXQgb3B0aW9uczogQnVsa09wdGlvbnMgPSB7fTtcbiAgICBpZiAoXG4gICAgICB0eXBlb2Ygb3B0aW9uc09ySW5wdXQgPT09ICdzdHJpbmcnIHx8XG4gICAgICBBcnJheS5pc0FycmF5KG9wdGlvbnNPcklucHV0KSB8fFxuICAgICAgKGlzT2JqZWN0KG9wdGlvbnNPcklucHV0KSAmJlxuICAgICAgICAncGlwZScgaW4gb3B0aW9uc09ySW5wdXQgJiZcbiAgICAgICAgdHlwZW9mIG9wdGlvbnNPcklucHV0LnBpcGUgPT09ICdmdW5jdGlvbicpXG4gICAgKSB7XG4gICAgICAvLyB3aGVuIG9wdGlvbnMgaXMgbm90IHBsYWluIGhhc2ggb2JqZWN0LCBpdCBpcyBvbWl0dGVkXG4gICAgICBpbnB1dCA9IG9wdGlvbnNPcklucHV0O1xuICAgIH0gZWxzZSB7XG4gICAgICBvcHRpb25zID0gb3B0aW9uc09ySW5wdXQgYXMgQnVsa09wdGlvbnM7XG4gICAgfVxuICAgIGNvbnN0IGpvYiA9IHRoaXMuY3JlYXRlSm9iKHR5cGUsIG9wZXJhdGlvbiwgb3B0aW9ucyk7XG4gICAgY29uc3QgYmF0Y2ggPSBqb2IuY3JlYXRlQmF0Y2goKTtcbiAgICBjb25zdCBjbGVhbnVwID0gKCkgPT4gam9iLmNsb3NlKCk7XG4gICAgY29uc3QgY2xlYW51cE9uRXJyb3IgPSAoZXJyOiBFcnJvcikgPT4ge1xuICAgICAgaWYgKGVyci5uYW1lICE9PSAnUG9sbGluZ1RpbWVvdXQnKSB7XG4gICAgICAgIGNsZWFudXAoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGJhdGNoLm9uKCdyZXNwb25zZScsIGNsZWFudXApO1xuICAgIGJhdGNoLm9uKCdlcnJvcicsIGNsZWFudXBPbkVycm9yKTtcbiAgICBiYXRjaC5vbigncXVldWUnLCAoKSA9PiB7XG4gICAgICBiYXRjaD8ucG9sbCh0aGlzLnBvbGxJbnRlcnZhbCwgdGhpcy5wb2xsVGltZW91dCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGJhdGNoLmV4ZWN1dGUoaW5wdXQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgYnVsayBxdWVyeSBhbmQgZ2V0IHJlY29yZCBzdHJlYW1cbiAgICovXG4gIHF1ZXJ5KHNvcWw6IHN0cmluZykge1xuICAgIGNvbnN0IG0gPSBzb3FsLnJlcGxhY2UoL1xcKFtcXHNcXFNdK1xcKS9nLCAnJykubWF0Y2goL0ZST01cXHMrKFxcdyspL2kpO1xuICAgIGlmICghbSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnTm8gc29iamVjdCB0eXBlIGZvdW5kIGluIHF1ZXJ5LCBtYXliZSBjYXVzZWQgYnkgaW52YWxpZCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCB0eXBlID0gbVsxXTtcbiAgICBjb25zdCByZWNvcmRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcbiAgICBjb25zdCBkYXRhU3RyZWFtID0gcmVjb3JkU3RyZWFtLnN0cmVhbSgnY3N2Jyk7XG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmxvYWQodHlwZSwgJ3F1ZXJ5Jywgc29xbCk7XG4gICAgICAgIGNvbnN0IHN0cmVhbXMgPSByZXN1bHRzLm1hcCgocmVzdWx0KSA9PlxuICAgICAgICAgIHRoaXMuam9iKHJlc3VsdC5qb2JJZClcbiAgICAgICAgICAgIC5iYXRjaChyZXN1bHQuYmF0Y2hJZClcbiAgICAgICAgICAgIC5yZXN1bHQocmVzdWx0LmlkKVxuICAgICAgICAgICAgLnN0cmVhbSgpLFxuICAgICAgICApO1xuICAgICAgICBqb2luU3RyZWFtcyhzdHJlYW1zKS5waXBlKGRhdGFTdHJlYW0pO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJlY29yZFN0cmVhbS5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gcmVjb3JkU3RyZWFtO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBqb2IgaW5zdGFuY2VcbiAgICovXG4gIGNyZWF0ZUpvYjxPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uPihcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb3BlcmF0aW9uOiBPcHIsXG4gICAgb3B0aW9uczogQnVsa09wdGlvbnMgPSB7fSxcbiAgKSB7XG4gICAgcmV0dXJuIG5ldyBKb2IodGhpcywgdHlwZSwgb3BlcmF0aW9uLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYSBqb2IgaW5zdGFuY2Ugc3BlY2lmaWVkIGJ5IGdpdmVuIGpvYiBJRFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gam9iSWQgLSBKb2IgSURcbiAgICogQHJldHVybnMge0J1bGt+Sm9ifVxuICAgKi9cbiAgam9iPE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+KGpvYklkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3IEpvYjxTLCBPcHI+KHRoaXMsIG51bGwsIG51bGwsIG51bGwsIGpvYklkKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgQnVsa1YyPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgI2Nvbm5lY3Rpb246IENvbm5lY3Rpb248Uz47XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgaW50ZXJ2YWwgaW4gbWlsbGlzZWNvbmRzXG4gICAqL1xuICBwb2xsSW50ZXJ2YWwgPSAxMDAwO1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gICAqIEB0eXBlIHtOdW1iZXJ9XG4gICAqL1xuICBwb2xsVGltZW91dCA9IDEwMDAwO1xuXG4gIGNvbnN0cnVjdG9yKGNvbm5lY3Rpb246IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLiNjb25uZWN0aW9uID0gY29ubmVjdGlvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgam9iIGluc3RhbmNlXG4gICAqL1xuICBjcmVhdGVKb2I8T3ByIGV4dGVuZHMgSW5nZXN0T3BlcmF0aW9uPihcbiAgICBvcHRpb25zOiBOZXdJbmdlc3RKb2JPcHRpb25zLFxuICApOiBJbmdlc3RKb2JWMjxTLCBPcHI+IHtcbiAgICByZXR1cm4gbmV3IEluZ2VzdEpvYlYyKHtcbiAgICAgIGNvbm5lY3Rpb246IHRoaXMuI2Nvbm5lY3Rpb24sXG4gICAgICBqb2JJbmZvOiBvcHRpb25zLFxuICAgICAgcG9sbGluZ09wdGlvbnM6IHRoaXMsXG4gICAgfSk7XG4gIH1cblxuICBqb2I8T3ByIGV4dGVuZHMgSW5nZXN0T3BlcmF0aW9uPihcbiAgICBvcHRpb25zOiBFeGlzdGluZ0luZ2VzdEpvYk9wdGlvbnMsXG4gICk6IEluZ2VzdEpvYlYyPFMsIE9wcj4ge1xuICAgIHJldHVybiBuZXcgSW5nZXN0Sm9iVjIoe1xuICAgICAgY29ubmVjdGlvbjogdGhpcy4jY29ubmVjdGlvbixcbiAgICAgIGpvYkluZm86IG9wdGlvbnMsXG4gICAgICBwb2xsaW5nT3B0aW9uczogdGhpcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUsIHVwbG9hZCwgYW5kIHN0YXJ0IGJ1bGtsb2FkIGpvYlxuICAgKi9cbiAgYXN5bmMgbG9hZEFuZFdhaXRGb3JSZXN1bHRzKFxuICAgIG9wdGlvbnM6IE5ld0luZ2VzdEpvYk9wdGlvbnMgJlxuICAgICAgUGFydGlhbDxCdWxrVjJQb2xsaW5nT3B0aW9ucz4gJiB7XG4gICAgICAgIGlucHV0OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nO1xuICAgICAgfSxcbiAgKTogUHJvbWlzZTxJbmdlc3RKb2JWMlJlc3VsdHM8Uz4+IHtcbiAgICBjb25zdCBqb2IgPSB0aGlzLmNyZWF0ZUpvYihvcHRpb25zKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgam9iLm9wZW4oKTtcbiAgICAgIGF3YWl0IGpvYi51cGxvYWREYXRhKG9wdGlvbnMuaW5wdXQpO1xuICAgICAgYXdhaXQgam9iLmNsb3NlKCk7XG4gICAgICBhd2FpdCBqb2IucG9sbChvcHRpb25zLnBvbGxJbnRlcnZhbCwgb3B0aW9ucy5wb2xsVGltZW91dCk7XG4gICAgICByZXR1cm4gYXdhaXQgam9iLmdldEFsbFJlc3VsdHMoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gJ0pvYlBvbGxpbmdUaW1lb3V0RXJyb3InKSB7XG4gICAgICAgIC8vIGZpcmVzIG9mZiBvbmUgbGFzdCBhdHRlbXB0IHRvIGNsZWFuIHVwIGFuZCBpZ25vcmVzIHRoZSByZXN1bHQgfCBlcnJvclxuICAgICAgICBqb2IuZGVsZXRlKCkuY2F0Y2goKGlnbm9yZWQpID0+IGlnbm9yZWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIGJ1bGsgcXVlcnkgYW5kIGdldCByZWNvcmQgc3RyZWFtXG4gICAqL1xuICBhc3luYyBxdWVyeShcbiAgICBzb3FsOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IFBhcnRpYWw8QnVsa1YyUG9sbGluZ09wdGlvbnM+LFxuICApOiBQcm9taXNlPFJlY29yZFtdPiB7XG4gICAgY29uc3QgcXVlcnlKb2IgPSBuZXcgUXVlcnlKb2JWMih7XG4gICAgICBjb25uZWN0aW9uOiB0aGlzLiNjb25uZWN0aW9uLFxuICAgICAgb3BlcmF0aW9uOiAncXVlcnknLFxuICAgICAgcXVlcnk6IHNvcWwsXG4gICAgICBwb2xsaW5nT3B0aW9uczogdGhpcyxcbiAgICB9KTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcXVlcnlKb2Iub3BlbigpO1xuICAgICAgYXdhaXQgcXVlcnlKb2IucG9sbChvcHRpb25zPy5wb2xsSW50ZXJ2YWwsIG9wdGlvbnM/LnBvbGxUaW1lb3V0KTtcbiAgICAgIHJldHVybiBhd2FpdCBxdWVyeUpvYi5nZXRSZXN1bHRzKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyLm5hbWUgIT09ICdKb2JQb2xsaW5nVGltZW91dEVycm9yJykge1xuICAgICAgICAvLyBmaXJlcyBvZmYgb25lIGxhc3QgYXR0ZW1wdCB0byBjbGVhbiB1cCBhbmQgaWdub3JlcyB0aGUgcmVzdWx0IHwgZXJyb3JcbiAgICAgICAgcXVlcnlKb2IuZGVsZXRlKCkuY2F0Y2goKGlnbm9yZWQpID0+IGlnbm9yZWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgUXVlcnlKb2JWMjxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHJlYWRvbmx5ICNjb25uZWN0aW9uOiBDb25uZWN0aW9uPFM+O1xuICByZWFkb25seSAjb3BlcmF0aW9uOiBRdWVyeU9wZXJhdGlvbjtcbiAgcmVhZG9ubHkgI3F1ZXJ5OiBzdHJpbmc7XG4gIHJlYWRvbmx5ICNwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG4gICNxdWVyeVJlc3VsdHM6IFJlY29yZFtdIHwgdW5kZWZpbmVkO1xuICAjZXJyb3I6IEVycm9yIHwgdW5kZWZpbmVkO1xuICBqb2JJbmZvOiBQYXJ0aWFsPEpvYkluZm9WMj4gfCB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3Iob3B0aW9uczogQ3JlYXRlUXVlcnlKb2JWMk9wdGlvbnM8Uz4pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuI2Nvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgdGhpcy4jb3BlcmF0aW9uID0gb3B0aW9ucy5vcGVyYXRpb247XG4gICAgdGhpcy4jcXVlcnkgPSBvcHRpb25zLnF1ZXJ5O1xuICAgIHRoaXMuI3BvbGxpbmdPcHRpb25zID0gb3B0aW9ucy5wb2xsaW5nT3B0aW9ucztcbiAgICAvLyBkZWZhdWx0IGVycm9yIGhhbmRsZXIgdG8ga2VlcCB0aGUgbGF0ZXN0IGVycm9yXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyb3IpID0+ICh0aGlzLiNlcnJvciA9IGVycm9yKSk7XG4gIH1cblxuICBhc3luYyBvcGVuKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZVF1ZXJ5UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIHBhdGg6ICcnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgb3BlcmF0aW9uOiB0aGlzLiNvcGVyYXRpb24sXG4gICAgICAgICAgcXVlcnk6IHRoaXMuI3F1ZXJ5LFxuICAgICAgICB9KSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoJ29wZW4nKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHN0YXR1cyB0byBhYm9ydFxuICAgKi9cbiAgYXN5bmMgYWJvcnQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXRlOiBKb2JTdGF0ZVYyID0gJ0Fib3J0ZWQnO1xuICAgICAgdGhpcy5qb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVRdWVyeVJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgcGF0aDogYC8ke3RoaXMuam9iSW5mbz8uaWR9YCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0ZSB9KSxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoJ2Fib3J0ZWQnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHBvbGwoXG4gICAgaW50ZXJ2YWw6IG51bWJlciA9IHRoaXMuI3BvbGxpbmdPcHRpb25zLnBvbGxJbnRlcnZhbCxcbiAgICB0aW1lb3V0OiBudW1iZXIgPSB0aGlzLiNwb2xsaW5nT3B0aW9ucy5wb2xsVGltZW91dCxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgam9iSWQgPSBnZXRKb2JJZE9yRXJyb3IodGhpcy5qb2JJbmZvKTtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuXG4gICAgd2hpbGUgKHN0YXJ0VGltZSArIHRpbWVvdXQgPiBEYXRlLm5vdygpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICAgIHN3aXRjaCAocmVzLnN0YXRlKSB7XG4gICAgICAgICAgY2FzZSAnT3Blbic6XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0pvYiBoYXMgbm90IGJlZW4gc3RhcnRlZCcpO1xuICAgICAgICAgIGNhc2UgJ0Fib3J0ZWQnOlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdKb2IgaGFzIGJlZW4gYWJvcnRlZCcpO1xuICAgICAgICAgIGNhc2UgJ1VwbG9hZENvbXBsZXRlJzpcbiAgICAgICAgICBjYXNlICdJblByb2dyZXNzJzpcbiAgICAgICAgICAgIGF3YWl0IGRlbGF5KGludGVydmFsKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ0ZhaWxlZCc6XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2ZhaWxlZCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIGNhc2UgJ0pvYkNvbXBsZXRlJzpcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnam9iY29tcGxldGUnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgdGltZW91dEVycm9yID0gbmV3IEpvYlBvbGxpbmdUaW1lb3V0RXJyb3IoXG4gICAgICBgUG9sbGluZyB0aW1lIG91dC4gSm9iIElkID0gJHtqb2JJZH1gLFxuICAgICAgam9iSWQsXG4gICAgKTtcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgdGltZW91dEVycm9yKTtcbiAgICB0aHJvdyB0aW1lb3V0RXJyb3I7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIGxhdGVzdCBiYXRjaCBzdGF0dXMgaW4gc2VydmVyXG4gICAqL1xuICBhc3luYyBjaGVjaygpOiBQcm9taXNlPEpvYkluZm9WMj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVRdWVyeVJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIHBhdGg6IGAvJHtnZXRKb2JJZE9yRXJyb3IodGhpcy5qb2JJbmZvKX1gLFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5qb2JJbmZvID0gam9iSW5mbztcbiAgICAgIHJldHVybiBqb2JJbmZvO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0UmVzdWx0cygpOiBQcm9taXNlPFJlY29yZFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICh0aGlzLiNxdWVyeVJlc3VsdHMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuI3F1ZXJ5UmVzdWx0cztcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IHRoaXMuY3JlYXRlUXVlcnlSZXF1ZXN0PFJlY29yZFtdIHwgdW5kZWZpbmVkPih7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIHBhdGg6IGAvJHtnZXRKb2JJZE9yRXJyb3IodGhpcy5qb2JJbmZvKX0vcmVzdWx0c2AsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLiNxdWVyeVJlc3VsdHMgPSByZXN1bHRzID8/IFtdO1xuXG4gICAgICByZXR1cm4gdGhpcy4jcXVlcnlSZXN1bHRzO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZGVsZXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLmNyZWF0ZVF1ZXJ5UmVxdWVzdDx2b2lkPih7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfWAsXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVF1ZXJ5UmVxdWVzdDxUPihyZXF1ZXN0OiBCdWxrUmVxdWVzdCkge1xuICAgIGNvbnN0IHsgcGF0aCwgcmVzcG9uc2VUeXBlIH0gPSByZXF1ZXN0O1xuICAgIGNvbnN0IGJhc2VVcmwgPSBbXG4gICAgICB0aGlzLiNjb25uZWN0aW9uLmluc3RhbmNlVXJsLFxuICAgICAgJ3NlcnZpY2VzL2RhdGEnLFxuICAgICAgYHYke3RoaXMuI2Nvbm5lY3Rpb24udmVyc2lvbn1gLFxuICAgICAgJ2pvYnMvcXVlcnknLFxuICAgIF0uam9pbignLycpO1xuXG4gICAgcmV0dXJuIG5ldyBCdWxrQXBpVjIodGhpcy4jY29ubmVjdGlvbiwgeyByZXNwb25zZVR5cGUgfSkucmVxdWVzdDxUPih7XG4gICAgICAuLi5yZXF1ZXN0LFxuICAgICAgdXJsOiBiYXNlVXJsICsgcGF0aCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIENsYXNzIGZvciBCdWxrIEFQSSBWMiBJbmdlc3QgSm9iXG4gKi9cbmV4cG9ydCBjbGFzcyBJbmdlc3RKb2JWMjxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgT3ByIGV4dGVuZHMgSW5nZXN0T3BlcmF0aW9uXG4+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgcmVhZG9ubHkgI2Nvbm5lY3Rpb246IENvbm5lY3Rpb248Uz47XG4gIHJlYWRvbmx5ICNwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG4gIHJlYWRvbmx5ICNqb2JEYXRhOiBKb2JEYXRhVjI8UywgT3ByPjtcbiAgI2J1bGtKb2JTdWNjZXNzZnVsUmVzdWx0czogSW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPiB8IHVuZGVmaW5lZDtcbiAgI2J1bGtKb2JGYWlsZWRSZXN1bHRzOiBJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8Uz4gfCB1bmRlZmluZWQ7XG4gICNidWxrSm9iVW5wcm9jZXNzZWRSZWNvcmRzOiBJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTPiB8IHVuZGVmaW5lZDtcbiAgI2Vycm9yOiBFcnJvciB8IHVuZGVmaW5lZDtcbiAgam9iSW5mbzogUGFydGlhbDxKb2JJbmZvVjI+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9uczogQ3JlYXRlSW5nZXN0Sm9iVjJPcHRpb25zPFM+KSB7XG4gICAgc3VwZXIoKTtcblxuICAgIHRoaXMuI2Nvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgdGhpcy4jcG9sbGluZ09wdGlvbnMgPSBvcHRpb25zLnBvbGxpbmdPcHRpb25zO1xuICAgIHRoaXMuam9iSW5mbyA9IG9wdGlvbnMuam9iSW5mbztcbiAgICB0aGlzLiNqb2JEYXRhID0gbmV3IEpvYkRhdGFWMjxTLCBPcHI+KHtcbiAgICAgIGNyZWF0ZVJlcXVlc3Q6IChyZXF1ZXN0KSA9PiB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3QocmVxdWVzdCksXG4gICAgICBqb2I6IHRoaXMsXG4gICAgfSk7XG4gICAgLy8gZGVmYXVsdCBlcnJvciBoYW5kbGVyIHRvIGtlZXAgdGhlIGxhdGVzdCBlcnJvclxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiAodGhpcy4jZXJyb3IgPSBlcnJvcikpO1xuICB9XG5cbiAgZ2V0IGlkKCkge1xuICAgIHJldHVybiB0aGlzLmpvYkluZm8uaWQ7XG4gIH1cblxuICBhc3luYyBvcGVuKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBwYXRoOiAnJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGFzc2lnbm1lbnRSdWxlSWQ6IHRoaXMuam9iSW5mbz8uYXNzaWdubWVudFJ1bGVJZCxcbiAgICAgICAgICBleHRlcm5hbElkRmllbGROYW1lOiB0aGlzLmpvYkluZm8/LmV4dGVybmFsSWRGaWVsZE5hbWUsXG4gICAgICAgICAgb2JqZWN0OiB0aGlzLmpvYkluZm8/Lm9iamVjdCxcbiAgICAgICAgICBvcGVyYXRpb246IHRoaXMuam9iSW5mbz8ub3BlcmF0aW9uLFxuICAgICAgICB9KSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoJ29wZW4nKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHVwbG9hZERhdGEoaW5wdXQ6IHN0cmluZyB8IFJlY29yZFtdIHwgUmVhZGFibGUpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLiNqb2JEYXRhLmV4ZWN1dGUoaW5wdXQpO1xuICB9XG5cbiAgYXN5bmMgZ2V0QWxsUmVzdWx0cygpOiBQcm9taXNlPEluZ2VzdEpvYlYyUmVzdWx0czxTPj4ge1xuICAgIGNvbnN0IFtcbiAgICAgIHN1Y2Nlc3NmdWxSZXN1bHRzLFxuICAgICAgZmFpbGVkUmVzdWx0cyxcbiAgICAgIHVucHJvY2Vzc2VkUmVjb3JkcyxcbiAgICBdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgdGhpcy5nZXRTdWNjZXNzZnVsUmVzdWx0cygpLFxuICAgICAgdGhpcy5nZXRGYWlsZWRSZXN1bHRzKCksXG4gICAgICB0aGlzLmdldFVucHJvY2Vzc2VkUmVjb3JkcygpLFxuICAgIF0pO1xuICAgIHJldHVybiB7IHN1Y2Nlc3NmdWxSZXN1bHRzLCBmYWlsZWRSZXN1bHRzLCB1bnByb2Nlc3NlZFJlY29yZHMgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZSBvcGVuZWQgam9iXG4gICAqL1xuICBhc3luYyBjbG9zZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RhdGU6IEpvYlN0YXRlVjIgPSAnVXBsb2FkQ29tcGxldGUnO1xuICAgICAgdGhpcy5qb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIHBhdGg6IGAvJHt0aGlzLmpvYkluZm8uaWR9YCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0ZSB9KSxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoJ3VwbG9hZGNvbXBsZXRlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2V0IHRoZSBzdGF0dXMgdG8gYWJvcnRcbiAgICovXG4gIGFzeW5jIGFib3J0KCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdGF0ZTogSm9iU3RhdGVWMiA9ICdBYm9ydGVkJztcbiAgICAgIHRoaXMuam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxuICAgICAgICBwYXRoOiBgLyR7dGhpcy5qb2JJbmZvLmlkfWAsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgc3RhdGUgfSksXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04JyB9LFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5lbWl0KCdhYm9ydGVkJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBhc3luYyBwb2xsKFxuICAgIGludGVydmFsOiBudW1iZXIgPSB0aGlzLiNwb2xsaW5nT3B0aW9ucy5wb2xsSW50ZXJ2YWwsXG4gICAgdGltZW91dDogbnVtYmVyID0gdGhpcy4jcG9sbGluZ09wdGlvbnMucG9sbFRpbWVvdXQsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGpvYklkID0gZ2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyk7XG4gICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcblxuICAgIHdoaWxlIChzdGFydFRpbWUgKyB0aW1lb3V0ID4gRGF0ZS5ub3coKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5jaGVjaygpO1xuICAgICAgICBzd2l0Y2ggKHJlcy5zdGF0ZSkge1xuICAgICAgICAgIGNhc2UgJ09wZW4nOlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdKb2IgaGFzIG5vdCBiZWVuIHN0YXJ0ZWQnKTtcbiAgICAgICAgICBjYXNlICdBYm9ydGVkJzpcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSm9iIGhhcyBiZWVuIGFib3J0ZWQnKTtcbiAgICAgICAgICBjYXNlICdVcGxvYWRDb21wbGV0ZSc6XG4gICAgICAgICAgY2FzZSAnSW5Qcm9ncmVzcyc6XG4gICAgICAgICAgICBhd2FpdCBkZWxheShpbnRlcnZhbCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlICdGYWlsZWQnOlxuICAgICAgICAgICAgdGhpcy5lbWl0KCdmYWlsZWQnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICBjYXNlICdKb2JDb21wbGV0ZSc6XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2pvYmNvbXBsZXRlJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHRpbWVvdXRFcnJvciA9IG5ldyBKb2JQb2xsaW5nVGltZW91dEVycm9yKFxuICAgICAgYFBvbGxpbmcgdGltZSBvdXQuIEpvYiBJZCA9ICR7am9iSWR9YCxcbiAgICAgIGpvYklkLFxuICAgICk7XG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIHRpbWVvdXRFcnJvcik7XG4gICAgdGhyb3cgdGltZW91dEVycm9yO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSBsYXRlc3QgYmF0Y2ggc3RhdHVzIGluIHNlcnZlclxuICAgKi9cbiAgYXN5bmMgY2hlY2soKTogUHJvbWlzZTxKb2JJbmZvVjI+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfWAsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmpvYkluZm8gPSBqb2JJbmZvO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRTdWNjZXNzZnVsUmVzdWx0cygpOiBQcm9taXNlPEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM8Uz4+IHtcbiAgICBpZiAodGhpcy4jYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzKSB7XG4gICAgICByZXR1cm4gdGhpcy4jYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMlN1Y2Nlc3NmdWxSZXN1bHRzPFM+IHwgdW5kZWZpbmVkXG4gICAgPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfS9zdWNjZXNzZnVsUmVzdWx0c2AsXG4gICAgICByZXNwb25zZVR5cGU6ICd0ZXh0L2NzdicsXG4gICAgfSk7XG5cbiAgICB0aGlzLiNidWxrSm9iU3VjY2Vzc2Z1bFJlc3VsdHMgPSByZXN1bHRzID8/IFtdO1xuXG4gICAgcmV0dXJuIHRoaXMuI2J1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cztcbiAgfVxuXG4gIGFzeW5jIGdldEZhaWxlZFJlc3VsdHMoKTogUHJvbWlzZTxJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8Uz4+IHtcbiAgICBpZiAodGhpcy4jYnVsa0pvYkZhaWxlZFJlc3VsdHMpIHtcbiAgICAgIHJldHVybiB0aGlzLiNidWxrSm9iRmFpbGVkUmVzdWx0cztcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PFxuICAgICAgSW5nZXN0Sm9iVjJGYWlsZWRSZXN1bHRzPFM+IHwgdW5kZWZpbmVkXG4gICAgPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfS9mYWlsZWRSZXN1bHRzYCxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICB9KTtcblxuICAgIHRoaXMuI2J1bGtKb2JGYWlsZWRSZXN1bHRzID0gcmVzdWx0cyA/PyBbXTtcblxuICAgIHJldHVybiB0aGlzLiNidWxrSm9iRmFpbGVkUmVzdWx0cztcbiAgfVxuXG4gIGFzeW5jIGdldFVucHJvY2Vzc2VkUmVjb3JkcygpOiBQcm9taXNlPEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+PiB7XG4gICAgaWYgKHRoaXMuI2J1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHMpIHtcbiAgICAgIHJldHVybiB0aGlzLiNidWxrSm9iVW5wcm9jZXNzZWRSZWNvcmRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTPiB8IHVuZGVmaW5lZFxuICAgID4oe1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6IGAvJHtnZXRKb2JJZE9yRXJyb3IodGhpcy5qb2JJbmZvKX0vdW5wcm9jZXNzZWRyZWNvcmRzYCxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICB9KTtcblxuICAgIHRoaXMuI2J1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHMgPSByZXN1bHRzID8/IFtdO1xuXG4gICAgcmV0dXJuIHRoaXMuI2J1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHM7XG4gIH1cblxuICBhc3luYyBkZWxldGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDx2b2lkPih7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfWAsXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZUluZ2VzdFJlcXVlc3Q8VD4ocmVxdWVzdDogQnVsa1JlcXVlc3QpIHtcbiAgICBjb25zdCB7IHBhdGgsIHJlc3BvbnNlVHlwZSB9ID0gcmVxdWVzdDtcbiAgICBjb25zdCBiYXNlVXJsID0gW1xuICAgICAgdGhpcy4jY29ubmVjdGlvbi5pbnN0YW5jZVVybCxcbiAgICAgICdzZXJ2aWNlcy9kYXRhJyxcbiAgICAgIGB2JHt0aGlzLiNjb25uZWN0aW9uLnZlcnNpb259YCxcbiAgICAgICdqb2JzL2luZ2VzdCcsXG4gICAgXS5qb2luKCcvJyk7XG5cbiAgICByZXR1cm4gbmV3IEJ1bGtBcGlWMih0aGlzLiNjb25uZWN0aW9uLCB7IHJlc3BvbnNlVHlwZSB9KS5yZXF1ZXN0PFQ+KHtcbiAgICAgIC4uLnJlcXVlc3QsXG4gICAgICB1cmw6IGJhc2VVcmwgKyBwYXRoLFxuICAgIH0pO1xuICB9XG59XG5cbmNsYXNzIEpvYkRhdGFWMjxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgT3ByIGV4dGVuZHMgSW5nZXN0T3BlcmF0aW9uXG4+IGV4dGVuZHMgV3JpdGFibGUge1xuICByZWFkb25seSAjam9iOiBJbmdlc3RKb2JWMjxTLCBPcHI+O1xuICByZWFkb25seSAjdXBsb2FkU3RyZWFtOiBTZXJpYWxpemFibGU7XG4gIHJlYWRvbmx5ICNkb3dubG9hZFN0cmVhbTogUGFyc2FibGU7XG4gIHJlYWRvbmx5ICNkYXRhU3RyZWFtOiBEdXBsZXg7XG4gICNyZXN1bHQ6IGFueTtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnM6IENyZWF0ZUpvYkRhdGFWMk9wdGlvbnM8UywgT3ByPikge1xuICAgIHN1cGVyKHsgb2JqZWN0TW9kZTogdHJ1ZSB9KTtcblxuICAgIGNvbnN0IGNyZWF0ZVJlcXVlc3QgPSBvcHRpb25zLmNyZWF0ZVJlcXVlc3Q7XG5cbiAgICB0aGlzLiNqb2IgPSBvcHRpb25zLmpvYjtcbiAgICB0aGlzLiN1cGxvYWRTdHJlYW0gPSBuZXcgU2VyaWFsaXphYmxlKCk7XG4gICAgdGhpcy4jZG93bmxvYWRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcblxuICAgIGNvbnN0IGNvbnZlcnRlck9wdGlvbnMgPSB7IG51bGxWYWx1ZTogJyNOL0EnIH07XG4gICAgY29uc3QgdXBsb2FkRGF0YVN0cmVhbSA9IHRoaXMuI3VwbG9hZFN0cmVhbS5zdHJlYW0oJ2NzdicsIGNvbnZlcnRlck9wdGlvbnMpO1xuICAgIGNvbnN0IGRvd25sb2FkRGF0YVN0cmVhbSA9IHRoaXMuI2Rvd25sb2FkU3RyZWFtLnN0cmVhbShcbiAgICAgICdjc3YnLFxuICAgICAgY29udmVydGVyT3B0aW9ucyxcbiAgICApO1xuXG4gICAgdGhpcy4jZGF0YVN0cmVhbSA9IGNvbmNhdFN0cmVhbXNBc0R1cGxleChcbiAgICAgIHVwbG9hZERhdGFTdHJlYW0sXG4gICAgICBkb3dubG9hZERhdGFTdHJlYW0sXG4gICAgKTtcblxuICAgIHRoaXMub24oJ2ZpbmlzaCcsICgpID0+IHRoaXMuI3VwbG9hZFN0cmVhbS5lbmQoKSk7XG5cbiAgICB1cGxvYWREYXRhU3RyZWFtLm9uY2UoJ3JlYWRhYmxlJywgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gcGlwZSB1cGxvYWQgZGF0YSB0byBiYXRjaCBBUEkgcmVxdWVzdCBzdHJlYW1cbiAgICAgICAgY29uc3QgcmVxID0gY3JlYXRlUmVxdWVzdCh7XG4gICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICBwYXRoOiBgLyR7dGhpcy4jam9iLmpvYkluZm8/LmlkfS9iYXRjaGVzYCxcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvY3N2JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcblxuICAgICAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCByZXE7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ3Jlc3BvbnNlJywgcmVzKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSkoKTtcblxuICAgICAgICB1cGxvYWREYXRhU3RyZWFtLnBpcGUocmVxLnN0cmVhbSgpKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIF93cml0ZShyZWNvcmRfOiBSZWNvcmQsIGVuYzogc3RyaW5nLCBjYjogKCkgPT4gdm9pZCkge1xuICAgIGNvbnN0IHsgSWQsIHR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJyZWMgfSA9IHJlY29yZF87XG4gICAgbGV0IHJlY29yZDtcbiAgICBzd2l0Y2ggKHRoaXMuI2pvYi5qb2JJbmZvLm9wZXJhdGlvbikge1xuICAgICAgY2FzZSAnaW5zZXJ0JzpcbiAgICAgICAgcmVjb3JkID0gcnJlYztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkZWxldGUnOlxuICAgICAgY2FzZSAnaGFyZERlbGV0ZSc6XG4gICAgICAgIHJlY29yZCA9IHsgSWQgfTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZWNvcmQgPSB7IElkLCAuLi5ycmVjIH07XG4gICAgfVxuICAgIHRoaXMuI3VwbG9hZFN0cmVhbS53cml0ZShyZWNvcmQsIGVuYywgY2IpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgZHVwbGV4IHN0cmVhbSB3aGljaCBhY2NlcHRzIENTViBkYXRhIGlucHV0IGFuZCBiYXRjaCByZXN1bHQgb3V0cHV0XG4gICAqL1xuICBzdHJlYW0oKSB7XG4gICAgcmV0dXJuIHRoaXMuI2RhdGFTdHJlYW07XG4gIH1cblxuICAvKipcbiAgICogRXhlY3V0ZSBiYXRjaCBvcGVyYXRpb25cbiAgICovXG4gIGV4ZWN1dGUoaW5wdXQ/OiBzdHJpbmcgfCBSZWNvcmRbXSB8IFJlYWRhYmxlKSB7XG4gICAgaWYgKHRoaXMuI3Jlc3VsdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdEYXRhIGNhbiBvbmx5IGJlIHVwbG9hZGVkIHRvIGEgam9iIG9uY2UuJyk7XG4gICAgfVxuXG4gICAgdGhpcy4jcmVzdWx0ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5vbmNlKCdyZXNwb25zZScsICgpID0+IHJlc29sdmUoKSk7XG4gICAgICB0aGlzLm9uY2UoJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcblxuICAgIGlmIChpc09iamVjdChpbnB1dCkgJiYgJ3BpcGUnIGluIGlucHV0ICYmIGlzRnVuY3Rpb24oaW5wdXQucGlwZSkpIHtcbiAgICAgIC8vIGlmIGlucHV0IGhhcyBzdHJlYW0uUmVhZGFibGUgaW50ZXJmYWNlXG4gICAgICBpbnB1dC5waXBlKHRoaXMuI2RhdGFTdHJlYW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkpIHtcbiAgICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgaW5wdXQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHJlY29yZFtrZXldID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgcmVjb3JkW2tleV0gPSBTdHJpbmcocmVjb3JkW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLndyaXRlKHJlY29yZCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5lbmQoKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICB0aGlzLiNkYXRhU3RyZWFtLndyaXRlKGlucHV0LCAndXRmOCcpO1xuICAgICAgICB0aGlzLiNkYXRhU3RyZWFtLmVuZCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFByb21pc2UvQSsgaW50ZXJmYWNlXG4gICAqIERlbGVnYXRlIHRvIHByb21pc2UsIHJldHVybiBwcm9taXNlIGluc3RhbmNlIGZvciBiYXRjaCByZXN1bHRcbiAgICovXG4gIHRoZW4ob25SZXNvbHZlZDogKCkgPT4gdm9pZCwgb25SZWplY3Q6IChlcnI6IGFueSkgPT4gdm9pZCkge1xuICAgIGlmICh0aGlzLiNyZXN1bHQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5leGVjdXRlKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLiNyZXN1bHQhLnRoZW4ob25SZXNvbHZlZCwgb25SZWplY3QpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGdldEpvYklkT3JFcnJvcihqb2JJbmZvOiBQYXJ0aWFsPEpvYkluZm9WMj4gfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICBjb25zdCBqb2JJZCA9IGpvYkluZm8/LmlkO1xuICBpZiAoam9iSWQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcignTm8gam9iIGlkLCBtYXliZSB5b3UgbmVlZCB0byBjYWxsIGBqb2Iub3BlbigpYCBmaXJzdC4nKTtcbiAgfVxuICByZXR1cm4gam9iSWQ7XG59XG5cbmZ1bmN0aW9uIGRlbGF5KG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIG1zKSk7XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdidWxrJywgKGNvbm4pID0+IG5ldyBCdWxrKGNvbm4pKTtcbnJlZ2lzdGVyTW9kdWxlKCdidWxrMicsIChjb25uKSA9PiBuZXcgQnVsa1YyKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgQnVsaztcbiJdfQ==