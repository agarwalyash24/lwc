import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Analytics API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import { ReportMetadata, ReportExecuteResult, ReportRetrieveResult, ReportDescribeResult, ReportInfo, ReportInstanceInfo, DashboardMetadata, DashboardResult, DashboardStatusResult, DashboardRefreshResult, DashboardInfo } from './analytics/types';

/*----------------------------------------------------------------------------------*/
export { ReportMetadata, ReportExecuteResult, ReportRetrieveResult, ReportDescribeResult, ReportInfo, ReportInstanceInfo, DashboardMetadata, DashboardResult, DashboardStatusResult, DashboardRefreshResult, DashboardInfo };

/*----------------------------------------------------------------------------------*/

/**
 * Report object class in Analytics API
 */
export class ReportInstance {
  /**
   *
   */
  constructor(report, id) {
    _defineProperty(this, "_report", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    this._report = report;
    this._conn = report._conn;
    this.id = id;
  }
  /**
   * Retrieve report result asynchronously executed
   */


  retrieve() {
    const url = [this._conn._baseUrl(), 'analytics', 'reports', this._report.id, 'instances', this.id].join('/');
    return this._conn.request(url);
  }

}
/*----------------------------------------------------------------------------------*/

/**
 * Report object class in Analytics API
 */

export class Report {
  /**
   *
   */
  constructor(conn, id) {
    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    _defineProperty(this, "run", this.execute);

    _defineProperty(this, "exec", this.execute);

    this._conn = conn;
    this.id = id;
  }
  /**
   * Describe report metadata
   */


  describe() {
    var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'describe'].join('/');
    return this._conn.request(url);
  }
  /**
   * Destroy a report
   */


  destroy() {
    const url = [this._conn._baseUrl(), 'analytics', 'reports', this.id].join('/');
    return this._conn.request({
      method: 'DELETE',
      url
    });
  }
  /**
   * Synonym of Analytics~Report#destroy()
   */


  /**
   * Clones a given report
   */
  clone(name) {
    const url = [this._conn._baseUrl(), 'analytics', 'reports'].join('/') + '?cloneId=' + this.id;
    const config = {
      reportMetadata: {
        name
      }
    };
    return this._conn.request({
      method: 'POST',
      url,
      headers: {
        'Content-Type': 'application/json'
      },
      body: _JSON$stringify(config)
    });
  }
  /**
   * Explain plan for executing report
   */


  explain() {
    const url = '/query/?explain=' + this.id;
    return this._conn.request(url);
  }
  /**
   * Run report synchronously
   */


  execute(options = {}) {
    const url = [this._conn._baseUrl(), 'analytics', 'reports', this.id].join('/') + '?includeDetails=' + (options.details ? 'true' : 'false');
    return this._conn.request(_objectSpread({
      url
    }, options.metadata ? {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: _JSON$stringify(options.metadata)
    } : {
      method: 'GET'
    }));
  }
  /**
   * Synonym of Analytics~Report#execute()
   */


  /**
   * Run report asynchronously
   */
  executeAsync(options = {}) {
    const url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'instances'].join('/') + (options.details ? '?includeDetails=true' : '');
    return this._conn.request(_objectSpread({
      method: 'POST',
      url
    }, options.metadata ? {
      headers: {
        'Content-Type': 'application/json'
      },
      body: _JSON$stringify(options.metadata)
    } : {
      body: ''
    }));
  }
  /**
   * Get report instance for specified instance ID
   */


  instance(id) {
    return new ReportInstance(this, id);
  }
  /**
   * List report instances which had been executed asynchronously
   */


  instances() {
    const url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'instances'].join('/');
    return this._conn.request(url);
  }

}
/*----------------------------------------------------------------------------------*/

/**
 * Dashboard object class in the Analytics API
 */

export class Dashboard {
  /**
   *
   */
  constructor(conn, id) {
    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    this._conn = conn;
    this.id = id;
  }
  /**
   * Describe dashboard metadata
   *
   * @method Analytics~Dashboard#describe
   * @param {Callback.<Analytics-DashboardMetadata>} [callback] - Callback function
   * @returns {Promise.<Analytics-DashboardMetadata>}
   */


  describe() {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id, 'describe'].join('/');
    return this._conn.request(url);
  }
  /**
   * Get details about dashboard components
   */


  components(componentIds) {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
    const config = {
      componentIds: _Array$isArray(componentIds) ? componentIds : typeof componentIds === 'string' ? [componentIds] : undefined
    };
    return this._conn.request({
      method: 'POST',
      url,
      headers: {
        'Content-Type': 'application/json'
      },
      body: _JSON$stringify(config)
    });
  }
  /**
   * Get dashboard status
   */


  status() {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id, 'status'].join('/');
    return this._conn.request(url);
  }
  /**
   * Refresh a dashboard
   */


  refresh() {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
    return this._conn.request({
      method: 'PUT',
      url,
      body: ''
    });
  }
  /**
   * Clone a dashboard
   */


  clone(config, folderId) {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards'].join('/') + '?cloneId=' + this.id;

    if (typeof config === 'string') {
      config = {
        name: config,
        folderId
      };
    }

    return this._conn.request({
      method: 'POST',
      url,
      headers: {
        'Content-Type': 'application/json'
      },
      body: _JSON$stringify(config)
    });
  }
  /**
   * Destroy a dashboard
   */


  destroy() {
    const url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
    return this._conn.request({
      method: 'DELETE',
      url
    });
  }
  /**
   * Synonym of Analytics~Dashboard#destroy()
   */


}
/*----------------------------------------------------------------------------------*/

/**
 * API class for Analytics API
 */

export class Analytics {
  /**
   *
   */
  constructor(conn) {
    _defineProperty(this, "_conn", void 0);

    this._conn = conn;
  }
  /**
   * Get report object of Analytics API
   */


  report(id) {
    return new Report(this._conn, id);
  }
  /**
   * Get recent report list
   */


  reports() {
    const url = [this._conn._baseUrl(), 'analytics', 'reports'].join('/');
    return this._conn.request(url);
  }
  /**
   * Get dashboard object of Analytics API
   */


  dashboard(id) {
    return new Dashboard(this._conn, id);
  }
  /**
   * Get recent dashboard list
   */


  dashboards() {
    var url = [this._conn._baseUrl(), 'analytics', 'dashboards'].join('/');
    return this._conn.request(url);
  }

}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('analytics', conn => new Analytics(conn));
export default Analytics;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYW5hbHl0aWNzLnRzIl0sIm5hbWVzIjpbInJlZ2lzdGVyTW9kdWxlIiwiUmVwb3J0TWV0YWRhdGEiLCJSZXBvcnRFeGVjdXRlUmVzdWx0IiwiUmVwb3J0UmV0cmlldmVSZXN1bHQiLCJSZXBvcnREZXNjcmliZVJlc3VsdCIsIlJlcG9ydEluZm8iLCJSZXBvcnRJbnN0YW5jZUluZm8iLCJEYXNoYm9hcmRNZXRhZGF0YSIsIkRhc2hib2FyZFJlc3VsdCIsIkRhc2hib2FyZFN0YXR1c1Jlc3VsdCIsIkRhc2hib2FyZFJlZnJlc2hSZXN1bHQiLCJEYXNoYm9hcmRJbmZvIiwiUmVwb3J0SW5zdGFuY2UiLCJjb25zdHJ1Y3RvciIsInJlcG9ydCIsImlkIiwiX3JlcG9ydCIsIl9jb25uIiwicmV0cmlldmUiLCJ1cmwiLCJfYmFzZVVybCIsImpvaW4iLCJyZXF1ZXN0IiwiUmVwb3J0IiwiY29ubiIsImRlc3Ryb3kiLCJleGVjdXRlIiwiZGVzY3JpYmUiLCJtZXRob2QiLCJjbG9uZSIsIm5hbWUiLCJjb25maWciLCJyZXBvcnRNZXRhZGF0YSIsImhlYWRlcnMiLCJib2R5IiwiZXhwbGFpbiIsIm9wdGlvbnMiLCJkZXRhaWxzIiwibWV0YWRhdGEiLCJleGVjdXRlQXN5bmMiLCJpbnN0YW5jZSIsImluc3RhbmNlcyIsIkRhc2hib2FyZCIsImNvbXBvbmVudHMiLCJjb21wb25lbnRJZHMiLCJ1bmRlZmluZWQiLCJzdGF0dXMiLCJyZWZyZXNoIiwiZm9sZGVySWQiLCJBbmFseXRpY3MiLCJyZXBvcnRzIiwiZGFzaGJvYXJkIiwiZGFzaGJvYXJkcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsY0FBVCxRQUErQixZQUEvQjtBQUdBLFNBQ0VDLGNBREYsRUFFRUMsbUJBRkYsRUFHRUMsb0JBSEYsRUFJRUMsb0JBSkYsRUFLRUMsVUFMRixFQU1FQyxrQkFORixFQU9FQyxpQkFQRixFQVFFQyxlQVJGLEVBU0VDLHFCQVRGLEVBVUVDLHNCQVZGLEVBV0VDLGFBWEYsUUFZTyxtQkFaUDs7QUFlQTtBQUNBLFNBQ0VWLGNBREYsRUFFRUMsbUJBRkYsRUFHRUMsb0JBSEYsRUFJRUMsb0JBSkYsRUFLRUMsVUFMRixFQU1FQyxrQkFORixFQU9FQyxpQkFQRixFQVFFQyxlQVJGLEVBU0VDLHFCQVRGLEVBVUVDLHNCQVZGLEVBV0VDLGFBWEY7O0FBcUJBOztBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sTUFBTUMsY0FBTixDQUF1QztBQUs1QztBQUNGO0FBQ0E7QUFDRUMsRUFBQUEsV0FBVyxDQUFDQyxNQUFELEVBQW9CQyxFQUFwQixFQUFnQztBQUFBOztBQUFBOztBQUFBOztBQUN6QyxTQUFLQyxPQUFMLEdBQWVGLE1BQWY7QUFDQSxTQUFLRyxLQUFMLEdBQWFILE1BQU0sQ0FBQ0csS0FBcEI7QUFDQSxTQUFLRixFQUFMLEdBQVVBLEVBQVY7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VHLEVBQUFBLFFBQVEsR0FBa0M7QUFDeEMsVUFBTUMsR0FBRyxHQUFHLENBQ1YsS0FBS0YsS0FBTCxDQUFXRyxRQUFYLEVBRFUsRUFFVixXQUZVLEVBR1YsU0FIVSxFQUlWLEtBQUtKLE9BQUwsQ0FBYUQsRUFKSCxFQUtWLFdBTFUsRUFNVixLQUFLQSxFQU5LLEVBT1ZNLElBUFUsQ0FPTCxHQVBLLENBQVo7QUFRQSxXQUFPLEtBQUtKLEtBQUwsQ0FBV0ssT0FBWCxDQUF5Q0gsR0FBekMsQ0FBUDtBQUNEOztBQTNCMkM7QUE4QjlDOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLE1BQU1JLE1BQU4sQ0FBK0I7QUFJcEM7QUFDRjtBQUNBO0FBQ0VWLEVBQUFBLFdBQVcsQ0FBQ1csSUFBRCxFQUFzQlQsRUFBdEIsRUFBa0M7QUFBQTs7QUFBQTs7QUFBQSxvQ0FnQ3BDLEtBQUtVLE9BaEMrQjs7QUFBQSxpQ0FxQ3ZDLEtBQUtBLE9BckNrQzs7QUFBQSxpQ0F1RnZDLEtBQUtDLE9BdkZrQzs7QUFBQSxrQ0E0RnRDLEtBQUtBLE9BNUZpQzs7QUFDM0MsU0FBS1QsS0FBTCxHQUFhTyxJQUFiO0FBQ0EsU0FBS1QsRUFBTCxHQUFVQSxFQUFWO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFWSxFQUFBQSxRQUFRLEdBQWtDO0FBQ3hDLFFBQUlSLEdBQUcsR0FBRyxDQUNSLEtBQUtGLEtBQUwsQ0FBV0csUUFBWCxFQURRLEVBRVIsV0FGUSxFQUdSLFNBSFEsRUFJUixLQUFLTCxFQUpHLEVBS1IsVUFMUSxFQU1STSxJQU5RLENBTUgsR0FORyxDQUFWO0FBT0EsV0FBTyxLQUFLSixLQUFMLENBQVdLLE9BQVgsQ0FBeUNILEdBQXpDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VNLEVBQUFBLE9BQU8sR0FBa0I7QUFDdkIsVUFBTU4sR0FBRyxHQUFHLENBQUMsS0FBS0YsS0FBTCxDQUFXRyxRQUFYLEVBQUQsRUFBd0IsV0FBeEIsRUFBcUMsU0FBckMsRUFBZ0QsS0FBS0wsRUFBckQsRUFBeURNLElBQXpELENBQ1YsR0FEVSxDQUFaO0FBR0EsV0FBTyxLQUFLSixLQUFMLENBQVdLLE9BQVgsQ0FBeUI7QUFBRU0sTUFBQUEsTUFBTSxFQUFFLFFBQVY7QUFBb0JULE1BQUFBO0FBQXBCLEtBQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBUUU7QUFDRjtBQUNBO0FBQ0VVLEVBQUFBLEtBQUssQ0FBQ0MsSUFBRCxFQUE4QztBQUNqRCxVQUFNWCxHQUFHLEdBQ1AsQ0FBQyxLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxTQUFyQyxFQUFnREMsSUFBaEQsQ0FBcUQsR0FBckQsSUFDQSxXQURBLEdBRUEsS0FBS04sRUFIUDtBQUlBLFVBQU1nQixNQUFNLEdBQUc7QUFBRUMsTUFBQUEsY0FBYyxFQUFFO0FBQUVGLFFBQUFBO0FBQUY7QUFBbEIsS0FBZjtBQUNBLFdBQU8sS0FBS2IsS0FBTCxDQUFXSyxPQUFYLENBQXlDO0FBQzlDTSxNQUFBQSxNQUFNLEVBQUUsTUFEc0M7QUFFOUNULE1BQUFBLEdBRjhDO0FBRzlDYyxNQUFBQSxPQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEIsT0FIcUM7QUFJOUNDLE1BQUFBLElBQUksRUFBRSxnQkFBZUgsTUFBZjtBQUp3QyxLQUF6QyxDQUFQO0FBTUQ7QUFFRDtBQUNGO0FBQ0E7OztBQUNFSSxFQUFBQSxPQUFPLEdBQWdDO0FBQ3JDLFVBQU1oQixHQUFHLEdBQUcscUJBQXFCLEtBQUtKLEVBQXRDO0FBQ0EsV0FBTyxLQUFLRSxLQUFMLENBQVdLLE9BQVgsQ0FBdUNILEdBQXZDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VPLEVBQUFBLE9BQU8sQ0FBQ1UsT0FBNkIsR0FBRyxFQUFqQyxFQUFtRTtBQUN4RSxVQUFNakIsR0FBRyxHQUNQLENBQUMsS0FBS0YsS0FBTCxDQUFXRyxRQUFYLEVBQUQsRUFBd0IsV0FBeEIsRUFBcUMsU0FBckMsRUFBZ0QsS0FBS0wsRUFBckQsRUFBeURNLElBQXpELENBQThELEdBQTlELElBQ0Esa0JBREEsSUFFQ2UsT0FBTyxDQUFDQyxPQUFSLEdBQWtCLE1BQWxCLEdBQTJCLE9BRjVCLENBREY7QUFJQSxXQUFPLEtBQUtwQixLQUFMLENBQVdLLE9BQVg7QUFDTEgsTUFBQUE7QUFESyxPQUVEaUIsT0FBTyxDQUFDRSxRQUFSLEdBQ0E7QUFDRVYsTUFBQUEsTUFBTSxFQUFFLE1BRFY7QUFFRUssTUFBQUEsT0FBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCLE9BRlg7QUFHRUMsTUFBQUEsSUFBSSxFQUFFLGdCQUFlRSxPQUFPLENBQUNFLFFBQXZCO0FBSFIsS0FEQSxHQU1BO0FBQUVWLE1BQUFBLE1BQU0sRUFBRTtBQUFWLEtBUkMsRUFBUDtBQVVEO0FBRUQ7QUFDRjtBQUNBOzs7QUFRRTtBQUNGO0FBQ0E7QUFDRVcsRUFBQUEsWUFBWSxDQUNWSCxPQUE2QixHQUFHLEVBRHRCLEVBRW1CO0FBQzdCLFVBQU1qQixHQUFHLEdBQ1AsQ0FDRSxLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFERixFQUVFLFdBRkYsRUFHRSxTQUhGLEVBSUUsS0FBS0wsRUFKUCxFQUtFLFdBTEYsRUFNRU0sSUFORixDQU1PLEdBTlAsS0FNZWUsT0FBTyxDQUFDQyxPQUFSLEdBQWtCLHNCQUFsQixHQUEyQyxFQU4xRCxDQURGO0FBUUEsV0FBTyxLQUFLcEIsS0FBTCxDQUFXSyxPQUFYO0FBQ0xNLE1BQUFBLE1BQU0sRUFBRSxNQURIO0FBRUxULE1BQUFBO0FBRkssT0FHRGlCLE9BQU8sQ0FBQ0UsUUFBUixHQUNBO0FBQ0VMLE1BQUFBLE9BQU8sRUFBRTtBQUFFLHdCQUFnQjtBQUFsQixPQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRSxnQkFBZUUsT0FBTyxDQUFDRSxRQUF2QjtBQUZSLEtBREEsR0FLQTtBQUFFSixNQUFBQSxJQUFJLEVBQUU7QUFBUixLQVJDLEVBQVA7QUFVRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VNLEVBQUFBLFFBQVEsQ0FBQ3pCLEVBQUQsRUFBYTtBQUNuQixXQUFPLElBQUlILGNBQUosQ0FBbUIsSUFBbkIsRUFBeUJHLEVBQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UwQixFQUFBQSxTQUFTLEdBQWtDO0FBQ3pDLFVBQU10QixHQUFHLEdBQUcsQ0FDVixLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixTQUhVLEVBSVYsS0FBS0wsRUFKSyxFQUtWLFdBTFUsRUFNVk0sSUFOVSxDQU1MLEdBTkssQ0FBWjtBQU9BLFdBQU8sS0FBS0osS0FBTCxDQUFXSyxPQUFYLENBQXlDSCxHQUF6QyxDQUFQO0FBQ0Q7O0FBbEptQztBQXFKdEM7O0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sTUFBTXVCLFNBQU4sQ0FBa0M7QUFJdkM7QUFDRjtBQUNBO0FBQ0U3QixFQUFBQSxXQUFXLENBQUNXLElBQUQsRUFBc0JULEVBQXRCLEVBQWtDO0FBQUE7O0FBQUE7O0FBQUEsb0NBcUhwQyxLQUFLVSxPQXJIK0I7O0FBQUEsaUNBMEh2QyxLQUFLQSxPQTFIa0M7O0FBQzNDLFNBQUtSLEtBQUwsR0FBYU8sSUFBYjtBQUNBLFNBQUtULEVBQUwsR0FBVUEsRUFBVjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFWSxFQUFBQSxRQUFRLEdBQStCO0FBQ3JDLFVBQU1SLEdBQUcsR0FBRyxDQUNWLEtBQUtGLEtBQUwsQ0FBV0csUUFBWCxFQURVLEVBRVYsV0FGVSxFQUdWLFlBSFUsRUFJVixLQUFLTCxFQUpLLEVBS1YsVUFMVSxFQU1WTSxJQU5VLENBTUwsR0FOSyxDQUFaO0FBT0EsV0FBTyxLQUFLSixLQUFMLENBQVdLLE9BQVgsQ0FBc0NILEdBQXRDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0V3QixFQUFBQSxVQUFVLENBQUNDLFlBQUQsRUFBNkQ7QUFDckUsVUFBTXpCLEdBQUcsR0FBRyxDQUNWLEtBQUtGLEtBQUwsQ0FBV0csUUFBWCxFQURVLEVBRVYsV0FGVSxFQUdWLFlBSFUsRUFJVixLQUFLTCxFQUpLLEVBS1ZNLElBTFUsQ0FLTCxHQUxLLENBQVo7QUFNQSxVQUFNVSxNQUFNLEdBQUc7QUFDYmEsTUFBQUEsWUFBWSxFQUFFLGVBQWNBLFlBQWQsSUFDVkEsWUFEVSxHQUVWLE9BQU9BLFlBQVAsS0FBd0IsUUFBeEIsR0FDQSxDQUFDQSxZQUFELENBREEsR0FFQUM7QUFMUyxLQUFmO0FBT0EsV0FBTyxLQUFLNUIsS0FBTCxDQUFXSyxPQUFYLENBQW9DO0FBQ3pDTSxNQUFBQSxNQUFNLEVBQUUsTUFEaUM7QUFFekNULE1BQUFBLEdBRnlDO0FBR3pDYyxNQUFBQSxPQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEIsT0FIZ0M7QUFJekNDLE1BQUFBLElBQUksRUFBRSxnQkFBZUgsTUFBZjtBQUptQyxLQUFwQyxDQUFQO0FBTUQ7QUFFRDtBQUNGO0FBQ0E7OztBQUNFZSxFQUFBQSxNQUFNLEdBQW1DO0FBQ3ZDLFVBQU0zQixHQUFHLEdBQUcsQ0FDVixLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixZQUhVLEVBSVYsS0FBS0wsRUFKSyxFQUtWLFFBTFUsRUFNVk0sSUFOVSxDQU1MLEdBTkssQ0FBWjtBQU9BLFdBQU8sS0FBS0osS0FBTCxDQUFXSyxPQUFYLENBQTBDSCxHQUExQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFNEIsRUFBQUEsT0FBTyxHQUFvQztBQUN6QyxVQUFNNUIsR0FBRyxHQUFHLENBQ1YsS0FBS0YsS0FBTCxDQUFXRyxRQUFYLEVBRFUsRUFFVixXQUZVLEVBR1YsWUFIVSxFQUlWLEtBQUtMLEVBSkssRUFLVk0sSUFMVSxDQUtMLEdBTEssQ0FBWjtBQU1BLFdBQU8sS0FBS0osS0FBTCxDQUFXSyxPQUFYLENBQTJDO0FBQ2hETSxNQUFBQSxNQUFNLEVBQUUsS0FEd0M7QUFFaERULE1BQUFBLEdBRmdEO0FBR2hEZSxNQUFBQSxJQUFJLEVBQUU7QUFIMEMsS0FBM0MsQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUwsRUFBQUEsS0FBSyxDQUNIRSxNQURHLEVBRUhpQixRQUZHLEVBR3lCO0FBQzVCLFVBQU03QixHQUFHLEdBQ1AsQ0FBQyxLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxZQUFyQyxFQUFtREMsSUFBbkQsQ0FBd0QsR0FBeEQsSUFDQSxXQURBLEdBRUEsS0FBS04sRUFIUDs7QUFJQSxRQUFJLE9BQU9nQixNQUFQLEtBQWtCLFFBQXRCLEVBQWdDO0FBQzlCQSxNQUFBQSxNQUFNLEdBQUc7QUFBRUQsUUFBQUEsSUFBSSxFQUFFQyxNQUFSO0FBQWdCaUIsUUFBQUE7QUFBaEIsT0FBVDtBQUNEOztBQUNELFdBQU8sS0FBSy9CLEtBQUwsQ0FBV0ssT0FBWCxDQUFzQztBQUMzQ00sTUFBQUEsTUFBTSxFQUFFLE1BRG1DO0FBRTNDVCxNQUFBQSxHQUYyQztBQUczQ2MsTUFBQUEsT0FBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCLE9BSGtDO0FBSTNDQyxNQUFBQSxJQUFJLEVBQUUsZ0JBQWVILE1BQWY7QUFKcUMsS0FBdEMsQ0FBUDtBQU1EO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRU4sRUFBQUEsT0FBTyxHQUFrQjtBQUN2QixVQUFNTixHQUFHLEdBQUcsQ0FDVixLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixZQUhVLEVBSVYsS0FBS0wsRUFKSyxFQUtWTSxJQUxVLENBS0wsR0FMSyxDQUFaO0FBTUEsV0FBTyxLQUFLSixLQUFMLENBQVdLLE9BQVgsQ0FBeUI7QUFBRU0sTUFBQUEsTUFBTSxFQUFFLFFBQVY7QUFBb0JULE1BQUFBO0FBQXBCLEtBQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBM0h5QztBQW9JekM7O0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sTUFBTThCLFNBQU4sQ0FBa0M7QUFHdkM7QUFDRjtBQUNBO0FBQ0VwQyxFQUFBQSxXQUFXLENBQUNXLElBQUQsRUFBc0I7QUFBQTs7QUFDL0IsU0FBS1AsS0FBTCxHQUFhTyxJQUFiO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFVixFQUFBQSxNQUFNLENBQUNDLEVBQUQsRUFBYTtBQUNqQixXQUFPLElBQUlRLE1BQUosQ0FBVyxLQUFLTixLQUFoQixFQUF1QkYsRUFBdkIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRW1DLEVBQUFBLE9BQU8sR0FBRztBQUNSLFVBQU0vQixHQUFHLEdBQUcsQ0FBQyxLQUFLRixLQUFMLENBQVdHLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxTQUFyQyxFQUFnREMsSUFBaEQsQ0FBcUQsR0FBckQsQ0FBWjtBQUNBLFdBQU8sS0FBS0osS0FBTCxDQUFXSyxPQUFYLENBQWlDSCxHQUFqQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFZ0MsRUFBQUEsU0FBUyxDQUFDcEMsRUFBRCxFQUFhO0FBQ3BCLFdBQU8sSUFBSTJCLFNBQUosQ0FBYyxLQUFLekIsS0FBbkIsRUFBMEJGLEVBQTFCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VxQyxFQUFBQSxVQUFVLEdBQUc7QUFDWCxRQUFJakMsR0FBRyxHQUFHLENBQUMsS0FBS0YsS0FBTCxDQUFXRyxRQUFYLEVBQUQsRUFBd0IsV0FBeEIsRUFBcUMsWUFBckMsRUFBbURDLElBQW5ELENBQXdELEdBQXhELENBQVY7QUFDQSxXQUFPLEtBQUtKLEtBQUwsQ0FBV0ssT0FBWCxDQUFvQ0gsR0FBcEMsQ0FBUDtBQUNEOztBQXRDc0M7QUF5Q3pDOztBQUNBO0FBQ0E7QUFDQTs7QUFDQW5CLGNBQWMsQ0FBQyxXQUFELEVBQWV3QixJQUFELElBQVUsSUFBSXlCLFNBQUosQ0FBY3pCLElBQWQsQ0FBeEIsQ0FBZDtBQUVBLGVBQWV5QixTQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgQW5hbHl0aWNzIEFQSVxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7XG4gIFJlcG9ydE1ldGFkYXRhLFxuICBSZXBvcnRFeGVjdXRlUmVzdWx0LFxuICBSZXBvcnRSZXRyaWV2ZVJlc3VsdCxcbiAgUmVwb3J0RGVzY3JpYmVSZXN1bHQsXG4gIFJlcG9ydEluZm8sXG4gIFJlcG9ydEluc3RhbmNlSW5mbyxcbiAgRGFzaGJvYXJkTWV0YWRhdGEsXG4gIERhc2hib2FyZFJlc3VsdCxcbiAgRGFzaGJvYXJkU3RhdHVzUmVzdWx0LFxuICBEYXNoYm9hcmRSZWZyZXNoUmVzdWx0LFxuICBEYXNoYm9hcmRJbmZvLFxufSBmcm9tICcuL2FuYWx5dGljcy90eXBlcyc7XG5pbXBvcnQgeyBRdWVyeUV4cGxhaW5SZXN1bHQgfSBmcm9tICcuLi9xdWVyeSc7XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5leHBvcnQge1xuICBSZXBvcnRNZXRhZGF0YSxcbiAgUmVwb3J0RXhlY3V0ZVJlc3VsdCxcbiAgUmVwb3J0UmV0cmlldmVSZXN1bHQsXG4gIFJlcG9ydERlc2NyaWJlUmVzdWx0LFxuICBSZXBvcnRJbmZvLFxuICBSZXBvcnRJbnN0YW5jZUluZm8sXG4gIERhc2hib2FyZE1ldGFkYXRhLFxuICBEYXNoYm9hcmRSZXN1bHQsXG4gIERhc2hib2FyZFN0YXR1c1Jlc3VsdCxcbiAgRGFzaGJvYXJkUmVmcmVzaFJlc3VsdCxcbiAgRGFzaGJvYXJkSW5mbyxcbn07XG5cbmV4cG9ydCB0eXBlIFJlcG9ydEV4ZWN1dGVPcHRpb25zID0ge1xuICBkZXRhaWxzPzogYm9vbGVhbjtcbiAgbWV0YWRhdGE/OiB7XG4gICAgcmVwb3J0TWV0YWRhdGE6IFBhcnRpYWw8UmVwb3J0TWV0YWRhdGE+O1xuICB9O1xufTtcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogUmVwb3J0IG9iamVjdCBjbGFzcyBpbiBBbmFseXRpY3MgQVBJXG4gKi9cbmV4cG9ydCBjbGFzcyBSZXBvcnRJbnN0YW5jZTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9yZXBvcnQ6IFJlcG9ydDxTPjtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIGlkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihyZXBvcnQ6IFJlcG9ydDxTPiwgaWQ6IHN0cmluZykge1xuICAgIHRoaXMuX3JlcG9ydCA9IHJlcG9ydDtcbiAgICB0aGlzLl9jb25uID0gcmVwb3J0Ll9jb25uO1xuICAgIHRoaXMuaWQgPSBpZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSByZXBvcnQgcmVzdWx0IGFzeW5jaHJvbm91c2x5IGV4ZWN1dGVkXG4gICAqL1xuICByZXRyaWV2ZSgpOiBQcm9taXNlPFJlcG9ydFJldHJpZXZlUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAncmVwb3J0cycsXG4gICAgICB0aGlzLl9yZXBvcnQuaWQsXG4gICAgICAnaW5zdGFuY2VzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSZXBvcnRSZXRyaWV2ZVJlc3VsdD4odXJsKTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBSZXBvcnQgb2JqZWN0IGNsYXNzIGluIEFuYWx5dGljcyBBUElcbiAqL1xuZXhwb3J0IGNsYXNzIFJlcG9ydDxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBpZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgaWQ6IHN0cmluZykge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuaWQgPSBpZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXNjcmliZSByZXBvcnQgbWV0YWRhdGFcbiAgICovXG4gIGRlc2NyaWJlKCk6IFByb21pc2U8UmVwb3J0RGVzY3JpYmVSZXN1bHQ+IHtcbiAgICB2YXIgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAncmVwb3J0cycsXG4gICAgICB0aGlzLmlkLFxuICAgICAgJ2Rlc2NyaWJlJyxcbiAgICBdLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydERlc2NyaWJlUmVzdWx0Pih1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3kgYSByZXBvcnRcbiAgICovXG4gIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJ2FuYWx5dGljcycsICdyZXBvcnRzJywgdGhpcy5pZF0uam9pbihcbiAgICAgICcvJyxcbiAgICApO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8dm9pZD4oeyBtZXRob2Q6ICdERUxFVEUnLCB1cmwgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBBbmFseXRpY3N+UmVwb3J0I2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsZXRlID0gdGhpcy5kZXN0cm95O1xuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFuYWx5dGljc35SZXBvcnQjZGVzdHJveSgpXG4gICAqL1xuICBkZWwgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIENsb25lcyBhIGdpdmVuIHJlcG9ydFxuICAgKi9cbiAgY2xvbmUobmFtZTogc3RyaW5nKTogUHJvbWlzZTxSZXBvcnREZXNjcmliZVJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9XG4gICAgICBbdGhpcy5fY29ubi5fYmFzZVVybCgpLCAnYW5hbHl0aWNzJywgJ3JlcG9ydHMnXS5qb2luKCcvJykgK1xuICAgICAgJz9jbG9uZUlkPScgK1xuICAgICAgdGhpcy5pZDtcbiAgICBjb25zdCBjb25maWcgPSB7IHJlcG9ydE1ldGFkYXRhOiB7IG5hbWUgfSB9O1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8UmVwb3J0RGVzY3JpYmVSZXN1bHQ+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShjb25maWcpLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4cGxhaW4gcGxhbiBmb3IgZXhlY3V0aW5nIHJlcG9ydFxuICAgKi9cbiAgZXhwbGFpbigpOiBQcm9taXNlPFF1ZXJ5RXhwbGFpblJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9ICcvcXVlcnkvP2V4cGxhaW49JyArIHRoaXMuaWQ7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxRdWVyeUV4cGxhaW5SZXN1bHQ+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogUnVuIHJlcG9ydCBzeW5jaHJvbm91c2x5XG4gICAqL1xuICBleGVjdXRlKG9wdGlvbnM6IFJlcG9ydEV4ZWN1dGVPcHRpb25zID0ge30pOiBQcm9taXNlPFJlcG9ydEV4ZWN1dGVSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPVxuICAgICAgW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJ2FuYWx5dGljcycsICdyZXBvcnRzJywgdGhpcy5pZF0uam9pbignLycpICtcbiAgICAgICc/aW5jbHVkZURldGFpbHM9JyArXG4gICAgICAob3B0aW9ucy5kZXRhaWxzID8gJ3RydWUnIDogJ2ZhbHNlJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSZXBvcnRFeGVjdXRlUmVzdWx0Pih7XG4gICAgICB1cmwsXG4gICAgICAuLi4ob3B0aW9ucy5tZXRhZGF0YVxuICAgICAgICA/IHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShvcHRpb25zLm1ldGFkYXRhKSxcbiAgICAgICAgICB9XG4gICAgICAgIDogeyBtZXRob2Q6ICdHRVQnIH0pLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQW5hbHl0aWNzflJlcG9ydCNleGVjdXRlKClcbiAgICovXG4gIHJ1biA9IHRoaXMuZXhlY3V0ZTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBBbmFseXRpY3N+UmVwb3J0I2V4ZWN1dGUoKVxuICAgKi9cbiAgZXhlYyA9IHRoaXMuZXhlY3V0ZTtcblxuICAvKipcbiAgICogUnVuIHJlcG9ydCBhc3luY2hyb25vdXNseVxuICAgKi9cbiAgZXhlY3V0ZUFzeW5jKFxuICAgIG9wdGlvbnM6IFJlcG9ydEV4ZWN1dGVPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8UmVwb3J0SW5zdGFuY2VJbmZvPiB7XG4gICAgY29uc3QgdXJsID1cbiAgICAgIFtcbiAgICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICAgJ3JlcG9ydHMnLFxuICAgICAgICB0aGlzLmlkLFxuICAgICAgICAnaW5zdGFuY2VzJyxcbiAgICAgIF0uam9pbignLycpICsgKG9wdGlvbnMuZGV0YWlscyA/ICc/aW5jbHVkZURldGFpbHM9dHJ1ZScgOiAnJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSZXBvcnRJbnN0YW5jZUluZm8+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgLi4uKG9wdGlvbnMubWV0YWRhdGFcbiAgICAgICAgPyB7XG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG9wdGlvbnMubWV0YWRhdGEpLFxuICAgICAgICAgIH1cbiAgICAgICAgOiB7IGJvZHk6ICcnIH0pLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZXBvcnQgaW5zdGFuY2UgZm9yIHNwZWNpZmllZCBpbnN0YW5jZSBJRFxuICAgKi9cbiAgaW5zdGFuY2UoaWQ6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgUmVwb3J0SW5zdGFuY2UodGhpcywgaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIExpc3QgcmVwb3J0IGluc3RhbmNlcyB3aGljaCBoYWQgYmVlbiBleGVjdXRlZCBhc3luY2hyb25vdXNseVxuICAgKi9cbiAgaW5zdGFuY2VzKCk6IFByb21pc2U8UmVwb3J0SW5zdGFuY2VJbmZvW10+IHtcbiAgICBjb25zdCB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdyZXBvcnRzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgICAnaW5zdGFuY2VzJyxcbiAgICBdLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydEluc3RhbmNlSW5mb1tdPih1cmwpO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIERhc2hib2FyZCBvYmplY3QgY2xhc3MgaW4gdGhlIEFuYWx5dGljcyBBUElcbiAqL1xuZXhwb3J0IGNsYXNzIERhc2hib2FyZDxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBpZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgaWQ6IHN0cmluZykge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuaWQgPSBpZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXNjcmliZSBkYXNoYm9hcmQgbWV0YWRhdGFcbiAgICpcbiAgICogQG1ldGhvZCBBbmFseXRpY3N+RGFzaGJvYXJkI2Rlc2NyaWJlXG4gICAqIEBwYXJhbSB7Q2FsbGJhY2suPEFuYWx5dGljcy1EYXNoYm9hcmRNZXRhZGF0YT59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7UHJvbWlzZS48QW5hbHl0aWNzLURhc2hib2FyZE1ldGFkYXRhPn1cbiAgICovXG4gIGRlc2NyaWJlKCk6IFByb21pc2U8RGFzaGJvYXJkTWV0YWRhdGE+IHtcbiAgICBjb25zdCB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdkYXNoYm9hcmRzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgICAnZGVzY3JpYmUnLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkTWV0YWRhdGE+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGRldGFpbHMgYWJvdXQgZGFzaGJvYXJkIGNvbXBvbmVudHNcbiAgICovXG4gIGNvbXBvbmVudHMoY29tcG9uZW50SWRzPzogc3RyaW5nIHwgc3RyaW5nW10pOiBQcm9taXNlPERhc2hib2FyZFJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICdhbmFseXRpY3MnLFxuICAgICAgJ2Rhc2hib2FyZHMnLFxuICAgICAgdGhpcy5pZCxcbiAgICBdLmpvaW4oJy8nKTtcbiAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICBjb21wb25lbnRJZHM6IEFycmF5LmlzQXJyYXkoY29tcG9uZW50SWRzKVxuICAgICAgICA/IGNvbXBvbmVudElkc1xuICAgICAgICA6IHR5cGVvZiBjb21wb25lbnRJZHMgPT09ICdzdHJpbmcnXG4gICAgICAgID8gW2NvbXBvbmVudElkc11cbiAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PERhc2hib2FyZFJlc3VsdD4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGNvbmZpZyksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGRhc2hib2FyZCBzdGF0dXNcbiAgICovXG4gIHN0YXR1cygpOiBQcm9taXNlPERhc2hib2FyZFN0YXR1c1Jlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICdhbmFseXRpY3MnLFxuICAgICAgJ2Rhc2hib2FyZHMnLFxuICAgICAgdGhpcy5pZCxcbiAgICAgICdzdGF0dXMnLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkU3RhdHVzUmVzdWx0Pih1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlZnJlc2ggYSBkYXNoYm9hcmRcbiAgICovXG4gIHJlZnJlc2goKTogUHJvbWlzZTxEYXNoYm9hcmRSZWZyZXNoUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAnZGFzaGJvYXJkcycsXG4gICAgICB0aGlzLmlkLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkUmVmcmVzaFJlc3VsdD4oe1xuICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6ICcnLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb25lIGEgZGFzaGJvYXJkXG4gICAqL1xuICBjbG9uZShcbiAgICBjb25maWc6IHsgbmFtZTogc3RyaW5nOyBmb2xkZXJJZD86IHN0cmluZyB9IHwgc3RyaW5nLFxuICAgIGZvbGRlcklkPzogc3RyaW5nLFxuICApOiBQcm9taXNlPERhc2hib2FyZE1ldGFkYXRhPiB7XG4gICAgY29uc3QgdXJsID1cbiAgICAgIFt0aGlzLl9jb25uLl9iYXNlVXJsKCksICdhbmFseXRpY3MnLCAnZGFzaGJvYXJkcyddLmpvaW4oJy8nKSArXG4gICAgICAnP2Nsb25lSWQ9JyArXG4gICAgICB0aGlzLmlkO1xuICAgIGlmICh0eXBlb2YgY29uZmlnID09PSAnc3RyaW5nJykge1xuICAgICAgY29uZmlnID0geyBuYW1lOiBjb25maWcsIGZvbGRlcklkIH07XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkTWV0YWRhdGE+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShjb25maWcpLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3kgYSBkYXNoYm9hcmRcbiAgICovXG4gIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAnZGFzaGJvYXJkcycsXG4gICAgICB0aGlzLmlkLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8dm9pZD4oeyBtZXRob2Q6ICdERUxFVEUnLCB1cmwgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBBbmFseXRpY3N+RGFzaGJvYXJkI2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsZXRlID0gdGhpcy5kZXN0cm95O1xuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFuYWx5dGljc35EYXNoYm9hcmQjZGVzdHJveSgpXG4gICAqL1xuICBkZWwgPSB0aGlzLmRlc3Ryb3k7XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIEFQSSBjbGFzcyBmb3IgQW5hbHl0aWNzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgQW5hbHl0aWNzPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlcG9ydCBvYmplY3Qgb2YgQW5hbHl0aWNzIEFQSVxuICAgKi9cbiAgcmVwb3J0KGlkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3IFJlcG9ydCh0aGlzLl9jb25uLCBpZCk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlY2VudCByZXBvcnQgbGlzdFxuICAgKi9cbiAgcmVwb3J0cygpIHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fY29ubi5fYmFzZVVybCgpLCAnYW5hbHl0aWNzJywgJ3JlcG9ydHMnXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSZXBvcnRJbmZvW10+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGRhc2hib2FyZCBvYmplY3Qgb2YgQW5hbHl0aWNzIEFQSVxuICAgKi9cbiAgZGFzaGJvYXJkKGlkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3IERhc2hib2FyZCh0aGlzLl9jb25uLCBpZCk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlY2VudCBkYXNoYm9hcmQgbGlzdFxuICAgKi9cbiAgZGFzaGJvYXJkcygpIHtcbiAgICB2YXIgdXJsID0gW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJ2FuYWx5dGljcycsICdkYXNoYm9hcmRzJ10uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkSW5mb1tdPih1cmwpO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdhbmFseXRpY3MnLCAoY29ubikgPT4gbmV3IEFuYWx5dGljcyhjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IEFuYWx5dGljcztcbiJdfQ==