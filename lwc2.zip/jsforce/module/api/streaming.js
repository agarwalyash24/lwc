import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 * @file Manages Streaming APIs
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Client, Subscription } from 'faye';
import { registerModule } from '../jsforce';
import * as StreamingExtension from './streaming/extension';
/**
 *
 */

export { Client, Subscription };
/*--------------------------------------------*/

/**
 * Streaming API topic class
 */

class Topic {
  constructor(streaming, name) {
    _defineProperty(this, "_streaming", void 0);

    _defineProperty(this, "name", void 0);

    this._streaming = streaming;
    this.name = name;
  }
  /**
   * Subscribe listener to topic
   */


  subscribe(listener) {
    return this._streaming.subscribe(this.name, listener);
  }
  /**
   * Unsubscribe listener from topic
   */


  unsubscribe(subscr) {
    this._streaming.unsubscribe(this.name, subscr);

    return this;
  }

}
/*--------------------------------------------*/

/**
 * Streaming API Generic Streaming Channel
 */


class Channel {
  constructor(streaming, name) {
    _defineProperty(this, "_streaming", void 0);

    _defineProperty(this, "_id", void 0);

    _defineProperty(this, "name", void 0);

    this._streaming = streaming;
    this.name = name;
  }
  /**
   * Subscribe to channel
   */


  subscribe(listener) {
    return this._streaming.subscribe(this.name, listener);
  }

  unsubscribe(subscr) {
    this._streaming.unsubscribe(this.name, subscr);

    return this;
  }

  async push(events) {
    const isArray = _Array$isArray(events);

    const pushEvents = _Array$isArray(events) ? events : [events];
    const conn = this._streaming._conn;

    if (!this._id) {
      this._id = conn.sobject('StreamingChannel').findOne({
        Name: this.name
      }, ['Id']).then(rec => rec === null || rec === void 0 ? void 0 : rec.Id);
    }

    const id = await this._id;

    if (!id) {
      throw new Error(`No streaming channel available for name: ${this.name}`);
    }

    const channelUrl = `/sobjects/StreamingChannel/${id}/push`;
    const rets = await conn.requestPost(channelUrl, {
      pushEvents
    });
    return isArray ? rets : rets[0];
  }

}
/*--------------------------------------------*/

/**
 * Streaming API class
 */


export class Streaming extends EventEmitter {
  /**
   *
   */
  constructor(conn) {
    super();

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_topics", {});

    _defineProperty(this, "_fayeClients", {});

    this._conn = conn;
  }
  /* @private */


  _createClient(forChannelName, extensions) {
    var _context;

    // forChannelName is advisory, for an API workaround. It does not restrict or select the channel.
    const needsReplayFix = typeof forChannelName === 'string' && _indexOfInstanceProperty(forChannelName).call(forChannelName, '/u/') === 0;
    const endpointUrl = [this._conn.instanceUrl, // special endpoint "/cometd/replay/xx.x" is only available in 36.0.
    // See https://releasenotes.docs.salesforce.com/en-us/summer16/release-notes/rn_api_streaming_classic_replay.htm
    'cometd' + (needsReplayFix === true && this._conn.version === '36.0' ? '/replay' : ''), this._conn.version].join('/');
    const fayeClient = new Client(endpointUrl, {});
    fayeClient.setHeader('Authorization', 'OAuth ' + this._conn.accessToken);

    if (_Array$isArray(extensions)) {
      for (const extension of extensions) {
        fayeClient.addExtension(extension);
      }
    } // prevent streaming API server error


    const dispatcher = fayeClient._dispatcher;

    if (_indexOfInstanceProperty(_context = dispatcher.getConnectionTypes()).call(_context, 'callback-polling') === -1) {
      dispatcher.selectTransport('long-polling');
      dispatcher._transport.batching = false;
    }

    return fayeClient;
  }
  /** @private **/


  _getFayeClient(channelName) {
    const isGeneric = _indexOfInstanceProperty(channelName).call(channelName, '/u/') === 0;
    const clientType = isGeneric ? 'generic' : 'pushTopic';

    if (!this._fayeClients[clientType]) {
      this._fayeClients[clientType] = this._createClient(channelName);
    }

    return this._fayeClients[clientType];
  }
  /**
   * Get named topic
   */


  topic(name) {
    this._topics = this._topics || {};
    const topic = this._topics[name] = this._topics[name] || new Topic(this, name);
    return topic;
  }
  /**
   * Get channel for channel name
   */


  channel(name) {
    return new Channel(this, name);
  }
  /**
   * Subscribe topic/channel
   */


  subscribe(name, listener) {
    const channelName = _indexOfInstanceProperty(name).call(name, '/') === 0 ? name : '/topic/' + name;

    const fayeClient = this._getFayeClient(channelName);

    return fayeClient.subscribe(channelName, listener);
  }
  /**
   * Unsubscribe topic
   */


  unsubscribe(name, subscription) {
    const channelName = _indexOfInstanceProperty(name).call(name, '/') === 0 ? name : '/topic/' + name;

    const fayeClient = this._getFayeClient(channelName);

    fayeClient.unsubscribe(channelName, subscription);
    return this;
  }
  /**
   * Create a Streaming client, optionally with extensions
   *
   * See Faye docs for implementation details: https://faye.jcoglan.com/browser/extensions.html
   *
   * Example usage:
   *
   * ```javascript
   * const jsforce = require('jsforce');
   *
   * // Establish a Salesforce connection. (Details elided)
   * const conn = new jsforce.Connection({ … });
   *
   * const fayeClient = conn.streaming.createClient();
   *
   * const subscription = fayeClient.subscribe(channel, data => {
   *   console.log('topic received data', data);
   * });
   *
   * subscription.cancel();
   * ```
   *
   * Example with extensions, using Replay & Auth Failure extensions in a server-side Node.js app:
   *
   * ```javascript
   * const jsforce = require('jsforce');
   * const { StreamingExtension } = require('jsforce/api/streaming');
   *
   * // Establish a Salesforce connection. (Details elided)
   * const conn = new jsforce.Connection({ … });
   *
   * const channel = "/event/My_Event__e";
   * const replayId = -2; // -2 is all retained events
   *
   * const exitCallback = () => process.exit(1);
   * const authFailureExt = new StreamingExtension.AuthFailure(exitCallback);
   *
   * const replayExt = new StreamingExtension.Replay(channel, replayId);
   *
   * const fayeClient = conn.streaming.createClient([
   *   authFailureExt,
   *   replayExt
   * ]);
   *
   * const subscription = fayeClient.subscribe(channel, data => {
   *   console.log('topic received data', data);
   * });
   *
   * subscription.cancel();
   * ```
   */


  createClient(extensions) {
    return this._createClient(null, extensions);
  }

}
export { StreamingExtension };
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('streaming', conn => new Streaming(conn));
export default Streaming;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvc3RyZWFtaW5nLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsIkNsaWVudCIsIlN1YnNjcmlwdGlvbiIsInJlZ2lzdGVyTW9kdWxlIiwiU3RyZWFtaW5nRXh0ZW5zaW9uIiwiVG9waWMiLCJjb25zdHJ1Y3RvciIsInN0cmVhbWluZyIsIm5hbWUiLCJfc3RyZWFtaW5nIiwic3Vic2NyaWJlIiwibGlzdGVuZXIiLCJ1bnN1YnNjcmliZSIsInN1YnNjciIsIkNoYW5uZWwiLCJwdXNoIiwiZXZlbnRzIiwiaXNBcnJheSIsInB1c2hFdmVudHMiLCJjb25uIiwiX2Nvbm4iLCJfaWQiLCJzb2JqZWN0IiwiZmluZE9uZSIsIk5hbWUiLCJ0aGVuIiwicmVjIiwiSWQiLCJpZCIsIkVycm9yIiwiY2hhbm5lbFVybCIsInJldHMiLCJyZXF1ZXN0UG9zdCIsIlN0cmVhbWluZyIsIl9jcmVhdGVDbGllbnQiLCJmb3JDaGFubmVsTmFtZSIsImV4dGVuc2lvbnMiLCJuZWVkc1JlcGxheUZpeCIsImVuZHBvaW50VXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwiam9pbiIsImZheWVDbGllbnQiLCJzZXRIZWFkZXIiLCJhY2Nlc3NUb2tlbiIsImV4dGVuc2lvbiIsImFkZEV4dGVuc2lvbiIsImRpc3BhdGNoZXIiLCJfZGlzcGF0Y2hlciIsImdldENvbm5lY3Rpb25UeXBlcyIsInNlbGVjdFRyYW5zcG9ydCIsIl90cmFuc3BvcnQiLCJiYXRjaGluZyIsIl9nZXRGYXllQ2xpZW50IiwiY2hhbm5lbE5hbWUiLCJpc0dlbmVyaWMiLCJjbGllbnRUeXBlIiwiX2ZheWVDbGllbnRzIiwidG9waWMiLCJfdG9waWNzIiwiY2hhbm5lbCIsInN1YnNjcmlwdGlvbiIsImNyZWF0ZUNsaWVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsU0FBU0MsTUFBVCxFQUFpQkMsWUFBakIsUUFBcUMsTUFBckM7QUFDQSxTQUFTQyxjQUFULFFBQStCLFlBQS9CO0FBR0EsT0FBTyxLQUFLQyxrQkFBWixNQUFvQyx1QkFBcEM7QUFFQTtBQUNBO0FBQ0E7O0FBOEJBLFNBQVNILE1BQVQsRUFBaUJDLFlBQWpCO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQU1HLEtBQU4sQ0FBZ0Q7QUFJOUNDLEVBQUFBLFdBQVcsQ0FBQ0MsU0FBRCxFQUEwQkMsSUFBMUIsRUFBd0M7QUFBQTs7QUFBQTs7QUFDakQsU0FBS0MsVUFBTCxHQUFrQkYsU0FBbEI7QUFDQSxTQUFLQyxJQUFMLEdBQVlBLElBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VFLEVBQUFBLFNBQVMsQ0FBQ0MsUUFBRCxFQUFpRTtBQUN4RSxXQUFPLEtBQUtGLFVBQUwsQ0FBZ0JDLFNBQWhCLENBQTBCLEtBQUtGLElBQS9CLEVBQXFDRyxRQUFyQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFQyxFQUFBQSxXQUFXLENBQUNDLE1BQUQsRUFBdUI7QUFDaEMsU0FBS0osVUFBTCxDQUFnQkcsV0FBaEIsQ0FBNEIsS0FBS0osSUFBakMsRUFBdUNLLE1BQXZDOztBQUNBLFdBQU8sSUFBUDtBQUNEOztBQXRCNkM7QUF5QmhEOztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUMsT0FBTixDQUFnQztBQUs5QlIsRUFBQUEsV0FBVyxDQUFDQyxTQUFELEVBQTBCQyxJQUExQixFQUF3QztBQUFBOztBQUFBOztBQUFBOztBQUNqRCxTQUFLQyxVQUFMLEdBQWtCRixTQUFsQjtBQUNBLFNBQUtDLElBQUwsR0FBWUEsSUFBWjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUUsRUFBQUEsU0FBUyxDQUFDQyxRQUFELEVBQW1DO0FBQzFDLFdBQU8sS0FBS0YsVUFBTCxDQUFnQkMsU0FBaEIsQ0FBMEIsS0FBS0YsSUFBL0IsRUFBcUNHLFFBQXJDLENBQVA7QUFDRDs7QUFFREMsRUFBQUEsV0FBVyxDQUFDQyxNQUFELEVBQXVCO0FBQ2hDLFNBQUtKLFVBQUwsQ0FBZ0JHLFdBQWhCLENBQTRCLEtBQUtKLElBQWpDLEVBQXVDSyxNQUF2Qzs7QUFDQSxXQUFPLElBQVA7QUFDRDs7QUFJRCxRQUFNRSxJQUFOLENBQVdDLE1BQVgsRUFBNEM7QUFDMUMsVUFBTUMsT0FBTyxHQUFHLGVBQWNELE1BQWQsQ0FBaEI7O0FBQ0EsVUFBTUUsVUFBVSxHQUFHLGVBQWNGLE1BQWQsSUFBd0JBLE1BQXhCLEdBQWlDLENBQUNBLE1BQUQsQ0FBcEQ7QUFDQSxVQUFNRyxJQUFnQixHQUFJLEtBQUtWLFVBQUwsQ0FBZ0JXLEtBQTFDOztBQUNBLFFBQUksQ0FBQyxLQUFLQyxHQUFWLEVBQWU7QUFDYixXQUFLQSxHQUFMLEdBQVdGLElBQUksQ0FDWkcsT0FEUSxDQUNBLGtCQURBLEVBRVJDLE9BRlEsQ0FFQTtBQUFFQyxRQUFBQSxJQUFJLEVBQUUsS0FBS2hCO0FBQWIsT0FGQSxFQUVxQixDQUFDLElBQUQsQ0FGckIsRUFHUmlCLElBSFEsQ0FHRkMsR0FBRCxJQUFTQSxHQUFULGFBQVNBLEdBQVQsdUJBQVNBLEdBQUcsQ0FBRUMsRUFIWCxDQUFYO0FBSUQ7O0FBQ0QsVUFBTUMsRUFBRSxHQUFHLE1BQU0sS0FBS1AsR0FBdEI7O0FBQ0EsUUFBSSxDQUFDTyxFQUFMLEVBQVM7QUFDUCxZQUFNLElBQUlDLEtBQUosQ0FBVyw0Q0FBMkMsS0FBS3JCLElBQUssRUFBaEUsQ0FBTjtBQUNEOztBQUNELFVBQU1zQixVQUFVLEdBQUksOEJBQTZCRixFQUFHLE9BQXBEO0FBQ0EsVUFBTUcsSUFBSSxHQUFHLE1BQU1aLElBQUksQ0FBQ2EsV0FBTCxDQUFvQ0YsVUFBcEMsRUFBZ0Q7QUFDakVaLE1BQUFBO0FBRGlFLEtBQWhELENBQW5CO0FBR0EsV0FBT0QsT0FBTyxHQUFHYyxJQUFILEdBQVVBLElBQUksQ0FBQyxDQUFELENBQTVCO0FBQ0Q7O0FBM0M2QjtBQThDaEM7O0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxPQUFPLE1BQU1FLFNBQU4sU0FBMENqQyxZQUExQyxDQUF1RDtBQUs1RDtBQUNGO0FBQ0E7QUFDRU0sRUFBQUEsV0FBVyxDQUFDYSxJQUFELEVBQXNCO0FBQy9COztBQUQrQjs7QUFBQSxxQ0FOZSxFQU1mOztBQUFBLDBDQUxnQixFQUtoQjs7QUFFL0IsU0FBS0MsS0FBTCxHQUFhRCxJQUFiO0FBQ0Q7QUFFRDs7O0FBQ0FlLEVBQUFBLGFBQWEsQ0FBQ0MsY0FBRCxFQUFpQ0MsVUFBakMsRUFBcUQ7QUFBQTs7QUFDaEU7QUFDQSxVQUFNQyxjQUFjLEdBQ2xCLE9BQU9GLGNBQVAsS0FBMEIsUUFBMUIsSUFBc0MseUJBQUFBLGNBQWMsTUFBZCxDQUFBQSxjQUFjLEVBQVMsS0FBVCxDQUFkLEtBQWtDLENBRDFFO0FBRUEsVUFBTUcsV0FBVyxHQUFHLENBQ2xCLEtBQUtsQixLQUFMLENBQVdtQixXQURPLEVBRWxCO0FBQ0E7QUFDQSxnQkFDR0YsY0FBYyxLQUFLLElBQW5CLElBQTJCLEtBQUtqQixLQUFMLENBQVdvQixPQUFYLEtBQXVCLE1BQWxELEdBQ0csU0FESCxHQUVHLEVBSE4sQ0FKa0IsRUFRbEIsS0FBS3BCLEtBQUwsQ0FBV29CLE9BUk8sRUFTbEJDLElBVGtCLENBU2IsR0FUYSxDQUFwQjtBQVVBLFVBQU1DLFVBQVUsR0FBRyxJQUFJekMsTUFBSixDQUFXcUMsV0FBWCxFQUF3QixFQUF4QixDQUFuQjtBQUNBSSxJQUFBQSxVQUFVLENBQUNDLFNBQVgsQ0FBcUIsZUFBckIsRUFBc0MsV0FBVyxLQUFLdkIsS0FBTCxDQUFXd0IsV0FBNUQ7O0FBQ0EsUUFBSSxlQUFjUixVQUFkLENBQUosRUFBK0I7QUFDN0IsV0FBSyxNQUFNUyxTQUFYLElBQXdCVCxVQUF4QixFQUFvQztBQUNsQ00sUUFBQUEsVUFBVSxDQUFDSSxZQUFYLENBQXdCRCxTQUF4QjtBQUNEO0FBQ0YsS0FwQitELENBcUJoRTs7O0FBQ0EsVUFBTUUsVUFBVSxHQUFJTCxVQUFELENBQW9CTSxXQUF2Qzs7QUFDQSxRQUFJLG9DQUFBRCxVQUFVLENBQUNFLGtCQUFYLG1CQUF3QyxrQkFBeEMsTUFBZ0UsQ0FBQyxDQUFyRSxFQUF3RTtBQUN0RUYsTUFBQUEsVUFBVSxDQUFDRyxlQUFYLENBQTJCLGNBQTNCO0FBQ0FILE1BQUFBLFVBQVUsQ0FBQ0ksVUFBWCxDQUFzQkMsUUFBdEIsR0FBaUMsS0FBakM7QUFDRDs7QUFDRCxXQUFPVixVQUFQO0FBQ0Q7QUFFRDs7O0FBQ0FXLEVBQUFBLGNBQWMsQ0FBQ0MsV0FBRCxFQUFzQjtBQUNsQyxVQUFNQyxTQUFTLEdBQUcseUJBQUFELFdBQVcsTUFBWCxDQUFBQSxXQUFXLEVBQVMsS0FBVCxDQUFYLEtBQStCLENBQWpEO0FBQ0EsVUFBTUUsVUFBVSxHQUFHRCxTQUFTLEdBQUcsU0FBSCxHQUFlLFdBQTNDOztBQUNBLFFBQUksQ0FBQyxLQUFLRSxZQUFMLENBQWtCRCxVQUFsQixDQUFMLEVBQW9DO0FBQ2xDLFdBQUtDLFlBQUwsQ0FBa0JELFVBQWxCLElBQWdDLEtBQUt0QixhQUFMLENBQW1Cb0IsV0FBbkIsQ0FBaEM7QUFDRDs7QUFDRCxXQUFPLEtBQUtHLFlBQUwsQ0FBa0JELFVBQWxCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VFLEVBQUFBLEtBQUssQ0FBNEJsRCxJQUE1QixFQUF1RDtBQUMxRCxTQUFLbUQsT0FBTCxHQUFlLEtBQUtBLE9BQUwsSUFBZ0IsRUFBL0I7QUFDQSxVQUFNRCxLQUFLLEdBQUksS0FBS0MsT0FBTCxDQUFhbkQsSUFBYixJQUNiLEtBQUttRCxPQUFMLENBQWFuRCxJQUFiLEtBQXNCLElBQUlILEtBQUosQ0FBZ0IsSUFBaEIsRUFBc0JHLElBQXRCLENBRHhCO0FBRUEsV0FBT2tELEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VFLEVBQUFBLE9BQU8sQ0FBQ3BELElBQUQsRUFBZTtBQUNwQixXQUFPLElBQUlNLE9BQUosQ0FBWSxJQUFaLEVBQWtCTixJQUFsQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFRSxFQUFBQSxTQUFTLENBQUNGLElBQUQsRUFBZUcsUUFBZixFQUFpRDtBQUN4RCxVQUFNMkMsV0FBVyxHQUFHLHlCQUFBOUMsSUFBSSxNQUFKLENBQUFBLElBQUksRUFBUyxHQUFULENBQUosS0FBc0IsQ0FBdEIsR0FBMEJBLElBQTFCLEdBQWlDLFlBQVlBLElBQWpFOztBQUNBLFVBQU1rQyxVQUFVLEdBQUcsS0FBS1csY0FBTCxDQUFvQkMsV0FBcEIsQ0FBbkI7O0FBQ0EsV0FBT1osVUFBVSxDQUFDaEMsU0FBWCxDQUFxQjRDLFdBQXJCLEVBQWtDM0MsUUFBbEMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsV0FBVyxDQUFDSixJQUFELEVBQWVxRCxZQUFmLEVBQTJDO0FBQ3BELFVBQU1QLFdBQVcsR0FBRyx5QkFBQTlDLElBQUksTUFBSixDQUFBQSxJQUFJLEVBQVMsR0FBVCxDQUFKLEtBQXNCLENBQXRCLEdBQTBCQSxJQUExQixHQUFpQyxZQUFZQSxJQUFqRTs7QUFDQSxVQUFNa0MsVUFBVSxHQUFHLEtBQUtXLGNBQUwsQ0FBb0JDLFdBQXBCLENBQW5COztBQUNBWixJQUFBQSxVQUFVLENBQUM5QixXQUFYLENBQXVCMEMsV0FBdkIsRUFBb0NPLFlBQXBDO0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxFQUFBQSxZQUFZLENBQUMxQixVQUFELEVBQW9CO0FBQzlCLFdBQU8sS0FBS0YsYUFBTCxDQUFtQixJQUFuQixFQUF5QkUsVUFBekIsQ0FBUDtBQUNEOztBQS9JMkQ7QUFrSjlELFNBQVNoQyxrQkFBVDtBQUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQUQsY0FBYyxDQUFDLFdBQUQsRUFBZWdCLElBQUQsSUFBVSxJQUFJYyxTQUFKLENBQWNkLElBQWQsQ0FBeEIsQ0FBZDtBQUVBLGVBQWVjLFNBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU3RyZWFtaW5nIEFQSXNcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgQ2xpZW50LCBTdWJzY3JpcHRpb24gfSBmcm9tICdmYXllJztcbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFJlY29yZCwgU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0ICogYXMgU3RyZWFtaW5nRXh0ZW5zaW9uIGZyb20gJy4vc3RyZWFtaW5nL2V4dGVuc2lvbic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU3RyZWFtaW5nTWVzc2FnZTxSIGV4dGVuZHMgUmVjb3JkPiA9IHtcbiAgZXZlbnQ6IHtcbiAgICB0eXBlOiBzdHJpbmc7XG4gICAgY3JlYXRlZERhdGU6IHN0cmluZztcbiAgICByZXBsYXlJZDogbnVtYmVyO1xuICB9O1xuICBzb2JqZWN0OiBSO1xufTtcblxuZXhwb3J0IHR5cGUgR2VuZXJpY1N0cmVhbWluZ01lc3NhZ2UgPSB7XG4gIGV2ZW50OiB7XG4gICAgY3JlYXRlZERhdGU6IHN0cmluZztcbiAgICByZXBsYXlJZDogbnVtYmVyO1xuICB9O1xuICBwYXlsb2FkOiBzdHJpbmc7XG59O1xuXG5leHBvcnQgdHlwZSBQdXNoRXZlbnQgPSB7XG4gIHBheWxvYWQ6IHN0cmluZztcbiAgdXNlcklkczogc3RyaW5nW107XG59O1xuXG5leHBvcnQgdHlwZSBQdXNoRXZlbnRSZXN1bHQgPSB7XG4gIGZhbm91dENvdW50OiBudW1iZXI7XG4gIHVzZXJPbmxpbmVTdGF0dXM6IHtcbiAgICBbdXNlcklkOiBzdHJpbmddOiBib29sZWFuO1xuICB9O1xufTtcblxuZXhwb3J0IHsgQ2xpZW50LCBTdWJzY3JpcHRpb24gfTtcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFN0cmVhbWluZyBBUEkgdG9waWMgY2xhc3NcbiAqL1xuY2xhc3MgVG9waWM8UyBleHRlbmRzIFNjaGVtYSwgUiBleHRlbmRzIFJlY29yZD4ge1xuICBfc3RyZWFtaW5nOiBTdHJlYW1pbmc8Uz47XG4gIG5hbWU6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihzdHJlYW1pbmc6IFN0cmVhbWluZzxTPiwgbmFtZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fc3RyZWFtaW5nID0gc3RyZWFtaW5nO1xuICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gIH1cblxuICAvKipcbiAgICogU3Vic2NyaWJlIGxpc3RlbmVyIHRvIHRvcGljXG4gICAqL1xuICBzdWJzY3JpYmUobGlzdGVuZXI6IChtZXNzYWdlOiBTdHJlYW1pbmdNZXNzYWdlPFI+KSA9PiB2b2lkKTogU3Vic2NyaXB0aW9uIHtcbiAgICByZXR1cm4gdGhpcy5fc3RyZWFtaW5nLnN1YnNjcmliZSh0aGlzLm5hbWUsIGxpc3RlbmVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZSBsaXN0ZW5lciBmcm9tIHRvcGljXG4gICAqL1xuICB1bnN1YnNjcmliZShzdWJzY3I6IFN1YnNjcmlwdGlvbikge1xuICAgIHRoaXMuX3N0cmVhbWluZy51bnN1YnNjcmliZSh0aGlzLm5hbWUsIHN1YnNjcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFN0cmVhbWluZyBBUEkgR2VuZXJpYyBTdHJlYW1pbmcgQ2hhbm5lbFxuICovXG5jbGFzcyBDaGFubmVsPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX3N0cmVhbWluZzogU3RyZWFtaW5nPFM+O1xuICBfaWQ6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB8IHVuZGVmaW5lZDtcbiAgbmFtZTogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHN0cmVhbWluZzogU3RyZWFtaW5nPFM+LCBuYW1lOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9zdHJlYW1pbmcgPSBzdHJlYW1pbmc7XG4gICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gY2hhbm5lbFxuICAgKi9cbiAgc3Vic2NyaWJlKGxpc3RlbmVyOiBGdW5jdGlvbik6IFN1YnNjcmlwdGlvbiB7XG4gICAgcmV0dXJuIHRoaXMuX3N0cmVhbWluZy5zdWJzY3JpYmUodGhpcy5uYW1lLCBsaXN0ZW5lcik7XG4gIH1cblxuICB1bnN1YnNjcmliZShzdWJzY3I6IFN1YnNjcmlwdGlvbikge1xuICAgIHRoaXMuX3N0cmVhbWluZy51bnN1YnNjcmliZSh0aGlzLm5hbWUsIHN1YnNjcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBwdXNoKGV2ZW50czogUHVzaEV2ZW50KTogUHJvbWlzZTxQdXNoRXZlbnRSZXN1bHQ+O1xuICBwdXNoKGV2ZW50czogUHVzaEV2ZW50KTogUHJvbWlzZTxQdXNoRXZlbnRSZXN1bHRbXT47XG4gIGFzeW5jIHB1c2goZXZlbnRzOiBQdXNoRXZlbnQgfCBQdXNoRXZlbnRbXSkge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KGV2ZW50cyk7XG4gICAgY29uc3QgcHVzaEV2ZW50cyA9IEFycmF5LmlzQXJyYXkoZXZlbnRzKSA/IGV2ZW50cyA6IFtldmVudHNdO1xuICAgIGNvbnN0IGNvbm46IENvbm5lY3Rpb24gPSAodGhpcy5fc3RyZWFtaW5nLl9jb25uIGFzIHVua25vd24pIGFzIENvbm5lY3Rpb247XG4gICAgaWYgKCF0aGlzLl9pZCkge1xuICAgICAgdGhpcy5faWQgPSBjb25uXG4gICAgICAgIC5zb2JqZWN0KCdTdHJlYW1pbmdDaGFubmVsJylcbiAgICAgICAgLmZpbmRPbmUoeyBOYW1lOiB0aGlzLm5hbWUgfSwgWydJZCddKVxuICAgICAgICAudGhlbigocmVjKSA9PiByZWM/LklkKTtcbiAgICB9XG4gICAgY29uc3QgaWQgPSBhd2FpdCB0aGlzLl9pZDtcbiAgICBpZiAoIWlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYE5vIHN0cmVhbWluZyBjaGFubmVsIGF2YWlsYWJsZSBmb3IgbmFtZTogJHt0aGlzLm5hbWV9YCk7XG4gICAgfVxuICAgIGNvbnN0IGNoYW5uZWxVcmwgPSBgL3NvYmplY3RzL1N0cmVhbWluZ0NoYW5uZWwvJHtpZH0vcHVzaGA7XG4gICAgY29uc3QgcmV0cyA9IGF3YWl0IGNvbm4ucmVxdWVzdFBvc3Q8UHVzaEV2ZW50UmVzdWx0W10+KGNoYW5uZWxVcmwsIHtcbiAgICAgIHB1c2hFdmVudHMsXG4gICAgfSk7XG4gICAgcmV0dXJuIGlzQXJyYXkgPyByZXRzIDogcmV0c1swXTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogU3RyZWFtaW5nIEFQSSBjbGFzc1xuICovXG5leHBvcnQgY2xhc3MgU3RyZWFtaW5nPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIF90b3BpY3M6IHsgW25hbWU6IHN0cmluZ106IFRvcGljPFMsIFJlY29yZD4gfSA9IHt9O1xuICBfZmF5ZUNsaWVudHM6IHsgW2NsaWVudFR5cGU6IHN0cmluZ106IENsaWVudCB9ID0ge307XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qIEBwcml2YXRlICovXG4gIF9jcmVhdGVDbGllbnQoZm9yQ2hhbm5lbE5hbWU/OiBzdHJpbmcgfCBudWxsLCBleHRlbnNpb25zPzogYW55W10pIHtcbiAgICAvLyBmb3JDaGFubmVsTmFtZSBpcyBhZHZpc29yeSwgZm9yIGFuIEFQSSB3b3JrYXJvdW5kLiBJdCBkb2VzIG5vdCByZXN0cmljdCBvciBzZWxlY3QgdGhlIGNoYW5uZWwuXG4gICAgY29uc3QgbmVlZHNSZXBsYXlGaXggPVxuICAgICAgdHlwZW9mIGZvckNoYW5uZWxOYW1lID09PSAnc3RyaW5nJyAmJiBmb3JDaGFubmVsTmFtZS5pbmRleE9mKCcvdS8nKSA9PT0gMDtcbiAgICBjb25zdCBlbmRwb2ludFVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uaW5zdGFuY2VVcmwsXG4gICAgICAvLyBzcGVjaWFsIGVuZHBvaW50IFwiL2NvbWV0ZC9yZXBsYXkveHgueFwiIGlzIG9ubHkgYXZhaWxhYmxlIGluIDM2LjAuXG4gICAgICAvLyBTZWUgaHR0cHM6Ly9yZWxlYXNlbm90ZXMuZG9jcy5zYWxlc2ZvcmNlLmNvbS9lbi11cy9zdW1tZXIxNi9yZWxlYXNlLW5vdGVzL3JuX2FwaV9zdHJlYW1pbmdfY2xhc3NpY19yZXBsYXkuaHRtXG4gICAgICAnY29tZXRkJyArXG4gICAgICAgIChuZWVkc1JlcGxheUZpeCA9PT0gdHJ1ZSAmJiB0aGlzLl9jb25uLnZlcnNpb24gPT09ICczNi4wJ1xuICAgICAgICAgID8gJy9yZXBsYXknXG4gICAgICAgICAgOiAnJyksXG4gICAgICB0aGlzLl9jb25uLnZlcnNpb24sXG4gICAgXS5qb2luKCcvJyk7XG4gICAgY29uc3QgZmF5ZUNsaWVudCA9IG5ldyBDbGllbnQoZW5kcG9pbnRVcmwsIHt9KTtcbiAgICBmYXllQ2xpZW50LnNldEhlYWRlcignQXV0aG9yaXphdGlvbicsICdPQXV0aCAnICsgdGhpcy5fY29ubi5hY2Nlc3NUb2tlbik7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoZXh0ZW5zaW9ucykpIHtcbiAgICAgIGZvciAoY29uc3QgZXh0ZW5zaW9uIG9mIGV4dGVuc2lvbnMpIHtcbiAgICAgICAgZmF5ZUNsaWVudC5hZGRFeHRlbnNpb24oZXh0ZW5zaW9uKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gcHJldmVudCBzdHJlYW1pbmcgQVBJIHNlcnZlciBlcnJvclxuICAgIGNvbnN0IGRpc3BhdGNoZXIgPSAoZmF5ZUNsaWVudCBhcyBhbnkpLl9kaXNwYXRjaGVyO1xuICAgIGlmIChkaXNwYXRjaGVyLmdldENvbm5lY3Rpb25UeXBlcygpLmluZGV4T2YoJ2NhbGxiYWNrLXBvbGxpbmcnKSA9PT0gLTEpIHtcbiAgICAgIGRpc3BhdGNoZXIuc2VsZWN0VHJhbnNwb3J0KCdsb25nLXBvbGxpbmcnKTtcbiAgICAgIGRpc3BhdGNoZXIuX3RyYW5zcG9ydC5iYXRjaGluZyA9IGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gZmF5ZUNsaWVudDtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqKi9cbiAgX2dldEZheWVDbGllbnQoY2hhbm5lbE5hbWU6IHN0cmluZykge1xuICAgIGNvbnN0IGlzR2VuZXJpYyA9IGNoYW5uZWxOYW1lLmluZGV4T2YoJy91LycpID09PSAwO1xuICAgIGNvbnN0IGNsaWVudFR5cGUgPSBpc0dlbmVyaWMgPyAnZ2VuZXJpYycgOiAncHVzaFRvcGljJztcbiAgICBpZiAoIXRoaXMuX2ZheWVDbGllbnRzW2NsaWVudFR5cGVdKSB7XG4gICAgICB0aGlzLl9mYXllQ2xpZW50c1tjbGllbnRUeXBlXSA9IHRoaXMuX2NyZWF0ZUNsaWVudChjaGFubmVsTmFtZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9mYXllQ2xpZW50c1tjbGllbnRUeXBlXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgbmFtZWQgdG9waWNcbiAgICovXG4gIHRvcGljPFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+KG5hbWU6IHN0cmluZyk6IFRvcGljPFMsIFI+IHtcbiAgICB0aGlzLl90b3BpY3MgPSB0aGlzLl90b3BpY3MgfHwge307XG4gICAgY29uc3QgdG9waWMgPSAodGhpcy5fdG9waWNzW25hbWVdID1cbiAgICAgIHRoaXMuX3RvcGljc1tuYW1lXSB8fCBuZXcgVG9waWM8UywgUj4odGhpcywgbmFtZSkpO1xuICAgIHJldHVybiB0b3BpYyBhcyBUb3BpYzxTLCBSPjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgY2hhbm5lbCBmb3IgY2hhbm5lbCBuYW1lXG4gICAqL1xuICBjaGFubmVsKG5hbWU6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgQ2hhbm5lbCh0aGlzLCBuYW1lKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG9waWMvY2hhbm5lbFxuICAgKi9cbiAgc3Vic2NyaWJlKG5hbWU6IHN0cmluZywgbGlzdGVuZXI6IEZ1bmN0aW9uKTogU3Vic2NyaXB0aW9uIHtcbiAgICBjb25zdCBjaGFubmVsTmFtZSA9IG5hbWUuaW5kZXhPZignLycpID09PSAwID8gbmFtZSA6ICcvdG9waWMvJyArIG5hbWU7XG4gICAgY29uc3QgZmF5ZUNsaWVudCA9IHRoaXMuX2dldEZheWVDbGllbnQoY2hhbm5lbE5hbWUpO1xuICAgIHJldHVybiBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsTmFtZSwgbGlzdGVuZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVuc3Vic2NyaWJlIHRvcGljXG4gICAqL1xuICB1bnN1YnNjcmliZShuYW1lOiBzdHJpbmcsIHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uKSB7XG4gICAgY29uc3QgY2hhbm5lbE5hbWUgPSBuYW1lLmluZGV4T2YoJy8nKSA9PT0gMCA/IG5hbWUgOiAnL3RvcGljLycgKyBuYW1lO1xuICAgIGNvbnN0IGZheWVDbGllbnQgPSB0aGlzLl9nZXRGYXllQ2xpZW50KGNoYW5uZWxOYW1lKTtcbiAgICBmYXllQ2xpZW50LnVuc3Vic2NyaWJlKGNoYW5uZWxOYW1lLCBzdWJzY3JpcHRpb24pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIFN0cmVhbWluZyBjbGllbnQsIG9wdGlvbmFsbHkgd2l0aCBleHRlbnNpb25zXG4gICAqXG4gICAqIFNlZSBGYXllIGRvY3MgZm9yIGltcGxlbWVudGF0aW9uIGRldGFpbHM6IGh0dHBzOi8vZmF5ZS5qY29nbGFuLmNvbS9icm93c2VyL2V4dGVuc2lvbnMuaHRtbFxuICAgKlxuICAgKiBFeGFtcGxlIHVzYWdlOlxuICAgKlxuICAgKiBgYGBqYXZhc2NyaXB0XG4gICAqIGNvbnN0IGpzZm9yY2UgPSByZXF1aXJlKCdqc2ZvcmNlJyk7XG4gICAqXG4gICAqIC8vIEVzdGFibGlzaCBhIFNhbGVzZm9yY2UgY29ubmVjdGlvbi4gKERldGFpbHMgZWxpZGVkKVxuICAgKiBjb25zdCBjb25uID0gbmV3IGpzZm9yY2UuQ29ubmVjdGlvbih7IOKApiB9KTtcbiAgICpcbiAgICogY29uc3QgZmF5ZUNsaWVudCA9IGNvbm4uc3RyZWFtaW5nLmNyZWF0ZUNsaWVudCgpO1xuICAgKlxuICAgKiBjb25zdCBzdWJzY3JpcHRpb24gPSBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsLCBkYXRhID0+IHtcbiAgICogICBjb25zb2xlLmxvZygndG9waWMgcmVjZWl2ZWQgZGF0YScsIGRhdGEpO1xuICAgKiB9KTtcbiAgICpcbiAgICogc3Vic2NyaXB0aW9uLmNhbmNlbCgpO1xuICAgKiBgYGBcbiAgICpcbiAgICogRXhhbXBsZSB3aXRoIGV4dGVuc2lvbnMsIHVzaW5nIFJlcGxheSAmIEF1dGggRmFpbHVyZSBleHRlbnNpb25zIGluIGEgc2VydmVyLXNpZGUgTm9kZS5qcyBhcHA6XG4gICAqXG4gICAqIGBgYGphdmFzY3JpcHRcbiAgICogY29uc3QganNmb3JjZSA9IHJlcXVpcmUoJ2pzZm9yY2UnKTtcbiAgICogY29uc3QgeyBTdHJlYW1pbmdFeHRlbnNpb24gfSA9IHJlcXVpcmUoJ2pzZm9yY2UvYXBpL3N0cmVhbWluZycpO1xuICAgKlxuICAgKiAvLyBFc3RhYmxpc2ggYSBTYWxlc2ZvcmNlIGNvbm5lY3Rpb24uIChEZXRhaWxzIGVsaWRlZClcbiAgICogY29uc3QgY29ubiA9IG5ldyBqc2ZvcmNlLkNvbm5lY3Rpb24oeyDigKYgfSk7XG4gICAqXG4gICAqIGNvbnN0IGNoYW5uZWwgPSBcIi9ldmVudC9NeV9FdmVudF9fZVwiO1xuICAgKiBjb25zdCByZXBsYXlJZCA9IC0yOyAvLyAtMiBpcyBhbGwgcmV0YWluZWQgZXZlbnRzXG4gICAqXG4gICAqIGNvbnN0IGV4aXRDYWxsYmFjayA9ICgpID0+IHByb2Nlc3MuZXhpdCgxKTtcbiAgICogY29uc3QgYXV0aEZhaWx1cmVFeHQgPSBuZXcgU3RyZWFtaW5nRXh0ZW5zaW9uLkF1dGhGYWlsdXJlKGV4aXRDYWxsYmFjayk7XG4gICAqXG4gICAqIGNvbnN0IHJlcGxheUV4dCA9IG5ldyBTdHJlYW1pbmdFeHRlbnNpb24uUmVwbGF5KGNoYW5uZWwsIHJlcGxheUlkKTtcbiAgICpcbiAgICogY29uc3QgZmF5ZUNsaWVudCA9IGNvbm4uc3RyZWFtaW5nLmNyZWF0ZUNsaWVudChbXG4gICAqICAgYXV0aEZhaWx1cmVFeHQsXG4gICAqICAgcmVwbGF5RXh0XG4gICAqIF0pO1xuICAgKlxuICAgKiBjb25zdCBzdWJzY3JpcHRpb24gPSBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsLCBkYXRhID0+IHtcbiAgICogICBjb25zb2xlLmxvZygndG9waWMgcmVjZWl2ZWQgZGF0YScsIGRhdGEpO1xuICAgKiB9KTtcbiAgICpcbiAgICogc3Vic2NyaXB0aW9uLmNhbmNlbCgpO1xuICAgKiBgYGBcbiAgICovXG4gIGNyZWF0ZUNsaWVudChleHRlbnNpb25zOiBhbnlbXSkge1xuICAgIHJldHVybiB0aGlzLl9jcmVhdGVDbGllbnQobnVsbCwgZXh0ZW5zaW9ucyk7XG4gIH1cbn1cblxuZXhwb3J0IHsgU3RyZWFtaW5nRXh0ZW5zaW9uIH07XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdzdHJlYW1pbmcnLCAoY29ubikgPT4gbmV3IFN0cmVhbWluZyhjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IFN0cmVhbWluZztcbiJdfQ==