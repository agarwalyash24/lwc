import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.promise";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Chatter REST API calls
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import { isObject } from '../util/function';
/**
 *
 */

/*--------------------------------------------*/

/**
 * A class representing chatter API request
 */
class Request {
  constructor(chatter, request) {
    _defineProperty(this, "_chatter", void 0);

    _defineProperty(this, "_request", void 0);

    _defineProperty(this, "_promise", void 0);

    this._chatter = chatter;
    this._request = request;
  }
  /**
   * Retrieve parameters in batch request form
   */


  batchParams() {
    const {
      method,
      url,
      body
    } = this._request;
    return _objectSpread({
      method,
      url: this._chatter._normalizeUrl(url)
    }, typeof body !== 'undefined' ? {
      richInput: body
    } : {});
  }
  /**
   * Retrieve parameters in batch request form
   *
   * @method Chatter~Request#promise
   * @returns {Promise.<Chatter~RequestResult>}
   */


  promise() {
    return this._promise || (this._promise = this._chatter._request(this._request));
  }
  /**
   * Returns Node.js Stream object for request
   *
   * @method Chatter~Request#stream
   * @returns {stream.Stream}
   */


  stream() {
    return this._chatter._request(this._request).stream();
  }
  /**
   * Promise/A+ interface
   * http://promises-aplus.github.io/promises-spec/
   *
   * Delegate to deferred promise, return promise instance for batch result
   */


  then(onResolve, onReject) {
    return this.promise().then(onResolve, onReject);
  }

}

function apppendQueryParamsToUrl(url, queryParams) {
  if (queryParams) {
    var _context;

    const qstring = _mapInstanceProperty(_context = _Object$keys(queryParams)).call(_context, name => {
      var _queryParams$name;

      return `${name}=${encodeURIComponent(String((_queryParams$name = queryParams[name]) !== null && _queryParams$name !== void 0 ? _queryParams$name : ''))}`;
    }).join('&');

    url += (_indexOfInstanceProperty(url).call(url, '?') > 0 ? '&' : '?') + qstring;
  }

  return url;
}
/*------------------------------*/


export class Resource extends Request {
  /**
   *
   */
  constructor(chatter, url, queryParams) {
    super(chatter, {
      method: 'GET',
      url: apppendQueryParamsToUrl(url, queryParams)
    });

    _defineProperty(this, "_url", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    this._url = this._request.url;
  }
  /**
   * Create a new resource
   */


  create(data) {
    return this._chatter.request({
      method: 'POST',
      url: this._url,
      body: data
    });
  }
  /**
   * Retrieve resource content
   */


  retrieve() {
    return this._chatter.request({
      method: 'GET',
      url: this._url
    });
  }
  /**
   * Update specified resource
   */


  update(data) {
    return this._chatter.request({
      method: 'POST',
      url: this._url,
      body: data
    });
  }
  /**
   * Delete specified resource
   */


  destroy() {
    return this._chatter.request({
      method: 'DELETE',
      url: this._url
    });
  }
  /**
   * Synonym of Resource#destroy()
   */


}
/*------------------------------*/

/**
 * API class for Chatter REST API call
 */

export class Chatter {
  /**
   *
   */
  constructor(conn) {
    _defineProperty(this, "_conn", void 0);

    this._conn = conn;
  }
  /**
   * Sending request to API endpoint
   * @private
   */


  _request(req_) {
    const {
      method,
      url: url_,
      headers: headers_,
      body: body_
    } = req_;
    let headers = headers_ !== null && headers_ !== void 0 ? headers_ : {};
    let body;

    if (/^(put|post|patch)$/i.test(method)) {
      if (isObject(body_)) {
        headers = _objectSpread(_objectSpread({}, headers_), {}, {
          'Content-Type': 'application/json'
        });
        body = _JSON$stringify(body_);
      } else {
        body = body_;
      }
    }

    const url = this._normalizeUrl(url_);

    return this._conn.request({
      method,
      url,
      headers,
      body
    });
  }
  /**
   * Convert path to site root relative url
   * @private
   */


  _normalizeUrl(url) {
    if (_indexOfInstanceProperty(url).call(url, '/chatter/') === 0 || _indexOfInstanceProperty(url).call(url, '/connect/') === 0) {
      return '/services/data/v' + this._conn.version + url;
    } else if (/^\/v[\d]+\.[\d]+\//.test(url)) {
      return '/services/data' + url;
    } else if (_indexOfInstanceProperty(url).call(url, '/services/') !== 0 && url[0] === '/') {
      return '/services/data/v' + this._conn.version + '/chatter' + url;
    } else {
      return url;
    }
  }
  /**
   * Make a request for chatter API resource
   */


  request(req) {
    return new Request(this, req);
  }
  /**
   * Make a resource request to chatter API
   */


  resource(url, queryParams) {
    return new Resource(this, url, queryParams);
  }
  /**
   * Make a batch request to chatter API
   */


  async batch(requests) {
    var _context2;

    const deferreds = _mapInstanceProperty(requests).call(requests, request => {
      const deferred = defer();
      request._promise = deferred.promise;
      return deferred;
    });

    const res = await this.request({
      method: 'POST',
      url: this._normalizeUrl('/connect/batch'),
      body: {
        batchRequests: _mapInstanceProperty(requests).call(requests, request => request.batchParams())
      }
    });

    _forEachInstanceProperty(_context2 = res.results).call(_context2, (result, i) => {
      const deferred = deferreds[i];

      if (result.statusCode >= 400) {
        deferred.reject(result.result);
      } else {
        deferred.resolve(result.result);
      }
    });

    return res;
  }

}

function defer() {
  let resolve_ = () => {};

  let reject_ = () => {};

  const promise = new _Promise((resolve, reject) => {
    resolve_ = resolve;
    reject_ = reject;
  });
  return {
    promise,
    resolve: resolve_,
    reject: reject_
  };
}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */


registerModule('chatter', conn => new Chatter(conn));
export default Chatter;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvY2hhdHRlci50cyJdLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsImlzT2JqZWN0IiwiUmVxdWVzdCIsImNvbnN0cnVjdG9yIiwiY2hhdHRlciIsInJlcXVlc3QiLCJfY2hhdHRlciIsIl9yZXF1ZXN0IiwiYmF0Y2hQYXJhbXMiLCJtZXRob2QiLCJ1cmwiLCJib2R5IiwiX25vcm1hbGl6ZVVybCIsInJpY2hJbnB1dCIsInByb21pc2UiLCJfcHJvbWlzZSIsInN0cmVhbSIsInRoZW4iLCJvblJlc29sdmUiLCJvblJlamVjdCIsImFwcHBlbmRRdWVyeVBhcmFtc1RvVXJsIiwicXVlcnlQYXJhbXMiLCJxc3RyaW5nIiwibmFtZSIsImVuY29kZVVSSUNvbXBvbmVudCIsIlN0cmluZyIsImpvaW4iLCJSZXNvdXJjZSIsImRlc3Ryb3kiLCJfdXJsIiwiY3JlYXRlIiwiZGF0YSIsInJldHJpZXZlIiwidXBkYXRlIiwiQ2hhdHRlciIsImNvbm4iLCJfY29ubiIsInJlcV8iLCJ1cmxfIiwiaGVhZGVycyIsImhlYWRlcnNfIiwiYm9keV8iLCJ0ZXN0IiwidmVyc2lvbiIsInJlcSIsInJlc291cmNlIiwiYmF0Y2giLCJyZXF1ZXN0cyIsImRlZmVycmVkcyIsImRlZmVycmVkIiwiZGVmZXIiLCJyZXMiLCJiYXRjaFJlcXVlc3RzIiwicmVzdWx0cyIsInJlc3VsdCIsImkiLCJzdGF0dXNDb2RlIiwicmVqZWN0IiwicmVzb2x2ZSIsInJlc29sdmVfIiwicmVqZWN0XyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsY0FBVCxRQUErQixZQUEvQjtBQUdBLFNBQVNDLFFBQVQsUUFBeUIsa0JBQXpCO0FBRUE7QUFDQTtBQUNBOztBQTJCQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxPQUFOLENBQW1DO0FBS2pDQyxFQUFBQSxXQUFXLENBQUNDLE9BQUQsRUFBc0JDLE9BQXRCLEVBQXFEO0FBQUE7O0FBQUE7O0FBQUE7O0FBQzlELFNBQUtDLFFBQUwsR0FBZ0JGLE9BQWhCO0FBQ0EsU0FBS0csUUFBTCxHQUFnQkYsT0FBaEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VHLEVBQUFBLFdBQVcsR0FBRztBQUNaLFVBQU07QUFBRUMsTUFBQUEsTUFBRjtBQUFVQyxNQUFBQSxHQUFWO0FBQWVDLE1BQUFBO0FBQWYsUUFBd0IsS0FBS0osUUFBbkM7QUFDQTtBQUNFRSxNQUFBQSxNQURGO0FBRUVDLE1BQUFBLEdBQUcsRUFBRSxLQUFLSixRQUFMLENBQWNNLGFBQWQsQ0FBNEJGLEdBQTVCO0FBRlAsT0FHTSxPQUFPQyxJQUFQLEtBQWdCLFdBQWhCLEdBQThCO0FBQUVFLE1BQUFBLFNBQVMsRUFBRUY7QUFBYixLQUE5QixHQUFvRCxFQUgxRDtBQUtEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUcsRUFBQUEsT0FBTyxHQUFHO0FBQ1IsV0FDRSxLQUFLQyxRQUFMLEtBQWtCLEtBQUtBLFFBQUwsR0FBZ0IsS0FBS1QsUUFBTCxDQUFjQyxRQUFkLENBQXVCLEtBQUtBLFFBQTVCLENBQWxDLENBREY7QUFHRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VTLEVBQUFBLE1BQU0sR0FBRztBQUNQLFdBQU8sS0FBS1YsUUFBTCxDQUFjQyxRQUFkLENBQTBCLEtBQUtBLFFBQS9CLEVBQXlDUyxNQUF6QyxFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxFQUFBQSxJQUFJLENBQ0ZDLFNBREUsRUFFRkMsUUFGRSxFQUdGO0FBQ0EsV0FBTyxLQUFLTCxPQUFMLEdBQWVHLElBQWYsQ0FBb0JDLFNBQXBCLEVBQStCQyxRQUEvQixDQUFQO0FBQ0Q7O0FBdkRnQzs7QUEwRG5DLFNBQVNDLHVCQUFULENBQ0VWLEdBREYsRUFFRVcsV0FGRixFQUdFO0FBQ0EsTUFBSUEsV0FBSixFQUFpQjtBQUFBOztBQUNmLFVBQU1DLE9BQU8sR0FBRyw2Q0FBWUQsV0FBWixrQkFFWEUsSUFBRDtBQUFBOztBQUFBLGFBQ0csR0FBRUEsSUFBSyxJQUFHQyxrQkFBa0IsQ0FBQ0MsTUFBTSxzQkFBQ0osV0FBVyxDQUFDRSxJQUFELENBQVosaUVBQXNCLEVBQXRCLENBQVAsQ0FBa0MsRUFEakU7QUFBQSxLQUZZLEVBS2JHLElBTGEsQ0FLUixHQUxRLENBQWhCOztBQU1BaEIsSUFBQUEsR0FBRyxJQUFJLENBQUMseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsR0FBVCxDQUFILEdBQW1CLENBQW5CLEdBQXVCLEdBQXZCLEdBQTZCLEdBQTlCLElBQXFDWSxPQUE1QztBQUNEOztBQUNELFNBQU9aLEdBQVA7QUFDRDtBQUVEOzs7QUFDQSxPQUFPLE1BQU1pQixRQUFOLFNBQTRDekIsT0FBNUMsQ0FBMEQ7QUFHL0Q7QUFDRjtBQUNBO0FBQ0VDLEVBQUFBLFdBQVcsQ0FDVEMsT0FEUyxFQUVUTSxHQUZTLEVBR1RXLFdBSFMsRUFJVDtBQUNBLFVBQU1qQixPQUFOLEVBQWU7QUFDYkssTUFBQUEsTUFBTSxFQUFFLEtBREs7QUFFYkMsTUFBQUEsR0FBRyxFQUFFVSx1QkFBdUIsQ0FBQ1YsR0FBRCxFQUFNVyxXQUFOO0FBRmYsS0FBZjs7QUFEQTs7QUFBQSxvQ0FxRE8sS0FBS08sT0FyRFo7O0FBQUEsaUNBMERJLEtBQUtBLE9BMURUOztBQUtBLFNBQUtDLElBQUwsR0FBWSxLQUFLdEIsUUFBTCxDQUFjRyxHQUExQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRW9CLEVBQUFBLE1BQU0sQ0FBV0MsSUFBWCxFQUF5QztBQUM3QyxXQUFPLEtBQUt6QixRQUFMLENBQWNELE9BQWQsQ0FBMEI7QUFDL0JJLE1BQUFBLE1BQU0sRUFBRSxNQUR1QjtBQUUvQkMsTUFBQUEsR0FBRyxFQUFFLEtBQUttQixJQUZxQjtBQUcvQmxCLE1BQUFBLElBQUksRUFBRW9CO0FBSHlCLEtBQTFCLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VDLEVBQUFBLFFBQVEsR0FBVztBQUNqQixXQUFPLEtBQUsxQixRQUFMLENBQWNELE9BQWQsQ0FBMEI7QUFDL0JJLE1BQUFBLE1BQU0sRUFBRSxLQUR1QjtBQUUvQkMsTUFBQUEsR0FBRyxFQUFFLEtBQUttQjtBQUZxQixLQUExQixDQUFQO0FBSUQ7QUFFRDtBQUNGO0FBQ0E7OztBQUNFSSxFQUFBQSxNQUFNLENBQVdGLElBQVgsRUFBeUI7QUFDN0IsV0FBTyxLQUFLekIsUUFBTCxDQUFjRCxPQUFkLENBQTBCO0FBQy9CSSxNQUFBQSxNQUFNLEVBQUUsTUFEdUI7QUFFL0JDLE1BQUFBLEdBQUcsRUFBRSxLQUFLbUIsSUFGcUI7QUFHL0JsQixNQUFBQSxJQUFJLEVBQUVvQjtBQUh5QixLQUExQixDQUFQO0FBS0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFSCxFQUFBQSxPQUFPLEdBQUc7QUFDUixXQUFPLEtBQUt0QixRQUFMLENBQWNELE9BQWQsQ0FBNEI7QUFDakNJLE1BQUFBLE1BQU0sRUFBRSxRQUR5QjtBQUVqQ0MsTUFBQUEsR0FBRyxFQUFFLEtBQUttQjtBQUZ1QixLQUE1QixDQUFQO0FBSUQ7QUFFRDtBQUNGO0FBQ0E7OztBQTlEaUU7QUF1RWpFOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLE1BQU1LLE9BQU4sQ0FBZ0M7QUFHckM7QUFDRjtBQUNBO0FBQ0UvQixFQUFBQSxXQUFXLENBQUNnQyxJQUFELEVBQXNCO0FBQUE7O0FBQy9CLFNBQUtDLEtBQUwsR0FBYUQsSUFBYjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFNUIsRUFBQUEsUUFBUSxDQUFJOEIsSUFBSixFQUFnQztBQUN0QyxVQUFNO0FBQUU1QixNQUFBQSxNQUFGO0FBQVVDLE1BQUFBLEdBQUcsRUFBRTRCLElBQWY7QUFBcUJDLE1BQUFBLE9BQU8sRUFBRUMsUUFBOUI7QUFBd0M3QixNQUFBQSxJQUFJLEVBQUU4QjtBQUE5QyxRQUF3REosSUFBOUQ7QUFDQSxRQUFJRSxPQUFPLEdBQUdDLFFBQUgsYUFBR0EsUUFBSCxjQUFHQSxRQUFILEdBQWUsRUFBMUI7QUFDQSxRQUFJN0IsSUFBSjs7QUFDQSxRQUFJLHNCQUFzQitCLElBQXRCLENBQTJCakMsTUFBM0IsQ0FBSixFQUF3QztBQUN0QyxVQUFJUixRQUFRLENBQUN3QyxLQUFELENBQVosRUFBcUI7QUFDbkJGLFFBQUFBLE9BQU8sbUNBQ0ZDLFFBREU7QUFFTCwwQkFBZ0I7QUFGWCxVQUFQO0FBSUE3QixRQUFBQSxJQUFJLEdBQUcsZ0JBQWU4QixLQUFmLENBQVA7QUFDRCxPQU5ELE1BTU87QUFDTDlCLFFBQUFBLElBQUksR0FBRzhCLEtBQVA7QUFDRDtBQUNGOztBQUNELFVBQU0vQixHQUFHLEdBQUcsS0FBS0UsYUFBTCxDQUFtQjBCLElBQW5CLENBQVo7O0FBQ0EsV0FBTyxLQUFLRixLQUFMLENBQVcvQixPQUFYLENBQXNCO0FBQzNCSSxNQUFBQSxNQUQyQjtBQUUzQkMsTUFBQUEsR0FGMkI7QUFHM0I2QixNQUFBQSxPQUgyQjtBQUkzQjVCLE1BQUFBO0FBSjJCLEtBQXRCLENBQVA7QUFNRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRUMsRUFBQUEsYUFBYSxDQUFDRixHQUFELEVBQWM7QUFDekIsUUFBSSx5QkFBQUEsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBUyxXQUFULENBQUgsS0FBNkIsQ0FBN0IsSUFBa0MseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsV0FBVCxDQUFILEtBQTZCLENBQW5FLEVBQXNFO0FBQ3BFLGFBQU8scUJBQXFCLEtBQUswQixLQUFMLENBQVdPLE9BQWhDLEdBQTBDakMsR0FBakQ7QUFDRCxLQUZELE1BRU8sSUFBSSxxQkFBcUJnQyxJQUFyQixDQUEwQmhDLEdBQTFCLENBQUosRUFBb0M7QUFDekMsYUFBTyxtQkFBbUJBLEdBQTFCO0FBQ0QsS0FGTSxNQUVBLElBQUkseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsWUFBVCxDQUFILEtBQThCLENBQTlCLElBQW1DQSxHQUFHLENBQUMsQ0FBRCxDQUFILEtBQVcsR0FBbEQsRUFBdUQ7QUFDNUQsYUFBTyxxQkFBcUIsS0FBSzBCLEtBQUwsQ0FBV08sT0FBaEMsR0FBMEMsVUFBMUMsR0FBdURqQyxHQUE5RDtBQUNELEtBRk0sTUFFQTtBQUNMLGFBQU9BLEdBQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUwsRUFBQUEsT0FBTyxDQUFjdUMsR0FBZCxFQUF5QztBQUM5QyxXQUFPLElBQUkxQyxPQUFKLENBQWtCLElBQWxCLEVBQXdCMEMsR0FBeEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsUUFBUSxDQUNObkMsR0FETSxFQUVOVyxXQUZNLEVBR047QUFDQSxXQUFPLElBQUlNLFFBQUosQ0FBbUIsSUFBbkIsRUFBeUJqQixHQUF6QixFQUE4QlcsV0FBOUIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNeUIsS0FBTixDQUNFQyxRQURGLEVBRThCO0FBQUE7O0FBQzVCLFVBQU1DLFNBQVMsR0FBRyxxQkFBQUQsUUFBUSxNQUFSLENBQUFBLFFBQVEsRUFBTTFDLE9BQUQsSUFBYTtBQUMxQyxZQUFNNEMsUUFBUSxHQUFHQyxLQUFLLEVBQXRCO0FBQ0E3QyxNQUFBQSxPQUFPLENBQUNVLFFBQVIsR0FBbUJrQyxRQUFRLENBQUNuQyxPQUE1QjtBQUNBLGFBQU9tQyxRQUFQO0FBQ0QsS0FKeUIsQ0FBMUI7O0FBS0EsVUFBTUUsR0FBRyxHQUFHLE1BQU0sS0FBSzlDLE9BQUwsQ0FBZ0M7QUFDaERJLE1BQUFBLE1BQU0sRUFBRSxNQUR3QztBQUVoREMsTUFBQUEsR0FBRyxFQUFFLEtBQUtFLGFBQUwsQ0FBbUIsZ0JBQW5CLENBRjJDO0FBR2hERCxNQUFBQSxJQUFJLEVBQUU7QUFDSnlDLFFBQUFBLGFBQWEsRUFBRSxxQkFBQUwsUUFBUSxNQUFSLENBQUFBLFFBQVEsRUFBTTFDLE9BQUQsSUFBYUEsT0FBTyxDQUFDRyxXQUFSLEVBQWxCO0FBRG5CO0FBSDBDLEtBQWhDLENBQWxCOztBQU9BLHlDQUFBMkMsR0FBRyxDQUFDRSxPQUFKLGtCQUFvQixDQUFDQyxNQUFELEVBQVNDLENBQVQsS0FBZTtBQUNqQyxZQUFNTixRQUFRLEdBQUdELFNBQVMsQ0FBQ08sQ0FBRCxDQUExQjs7QUFDQSxVQUFJRCxNQUFNLENBQUNFLFVBQVAsSUFBcUIsR0FBekIsRUFBOEI7QUFDNUJQLFFBQUFBLFFBQVEsQ0FBQ1EsTUFBVCxDQUFnQkgsTUFBTSxDQUFDQSxNQUF2QjtBQUNELE9BRkQsTUFFTztBQUNMTCxRQUFBQSxRQUFRLENBQUNTLE9BQVQsQ0FBaUJKLE1BQU0sQ0FBQ0EsTUFBeEI7QUFDRDtBQUNGLEtBUEQ7O0FBUUEsV0FBT0gsR0FBUDtBQUNEOztBQWxHb0M7O0FBcUd2QyxTQUFTRCxLQUFULEdBQW9CO0FBQ2xCLE1BQUlTLFFBQXlDLEdBQUcsTUFBTSxDQUFFLENBQXhEOztBQUNBLE1BQUlDLE9BQXlCLEdBQUcsTUFBTSxDQUFFLENBQXhDOztBQUNBLFFBQU05QyxPQUFPLEdBQUcsYUFBZSxDQUFDNEMsT0FBRCxFQUFVRCxNQUFWLEtBQXFCO0FBQ2xERSxJQUFBQSxRQUFRLEdBQUdELE9BQVg7QUFDQUUsSUFBQUEsT0FBTyxHQUFHSCxNQUFWO0FBQ0QsR0FIZSxDQUFoQjtBQUlBLFNBQU87QUFDTDNDLElBQUFBLE9BREs7QUFFTDRDLElBQUFBLE9BQU8sRUFBRUMsUUFGSjtBQUdMRixJQUFBQSxNQUFNLEVBQUVHO0FBSEgsR0FBUDtBQUtEO0FBRUQ7O0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTVELGNBQWMsQ0FBQyxTQUFELEVBQWFtQyxJQUFELElBQVUsSUFBSUQsT0FBSixDQUFZQyxJQUFaLENBQXRCLENBQWQ7QUFFQSxlQUFlRCxPQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgQ2hhdHRlciBSRVNUIEFQSSBjYWxsc1xuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBTY2hlbWEgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBpc09iamVjdCB9IGZyb20gJy4uL3V0aWwvZnVuY3Rpb24nO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIENoYXR0ZXJSZXF1ZXN0UGFyYW1zID0gT21pdDxIdHRwUmVxdWVzdCwgJ2JvZHknPiAmIHtcbiAgYm9keT86IHN0cmluZyB8IG9iamVjdCB8IG51bGw7XG59O1xuXG5leHBvcnQgdHlwZSBCYXRjaFJlcXVlc3RQYXJhbXMgPSB7XG4gIG1ldGhvZDogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgcmljaElucHV0PzogYW55O1xufTtcblxudHlwZSBCYXRjaFJlcXVlc3RUdXBwbGU8UyBleHRlbmRzIFNjaGVtYSwgUlQgZXh0ZW5kcyBhbnlbXT4gPSB7XG4gIFtLIGluIGtleW9mIFJUXTogUmVxdWVzdDxTLCBSVFtLXT47XG59O1xuXG50eXBlIEJhdGNoUmVzdWx0VHVwcGxlPFJUIGV4dGVuZHMgYW55W10+ID0ge1xuICBbSyBpbiBrZXlvZiBSVF06IHtcbiAgICBzdGF0dXNDb2RlOiBudW1iZXI7XG4gICAgcmVzdWx0OiBSVFtLXTtcbiAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIEJhdGNoUmVzcG9uc2U8UlQgZXh0ZW5kcyBhbnlbXT4gPSB7XG4gIGhhc0Vycm9yczogYm9vbGVhbjtcbiAgcmVzdWx0czogQmF0Y2hSZXN1bHRUdXBwbGU8UlQ+O1xufTtcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIEEgY2xhc3MgcmVwcmVzZW50aW5nIGNoYXR0ZXIgQVBJIHJlcXVlc3RcbiAqL1xuY2xhc3MgUmVxdWVzdDxTIGV4dGVuZHMgU2NoZW1hLCBSPiB7XG4gIF9jaGF0dGVyOiBDaGF0dGVyPFM+O1xuICBfcmVxdWVzdDogQ2hhdHRlclJlcXVlc3RQYXJhbXM7XG4gIF9wcm9taXNlOiBQcm9taXNlPFI+IHwgdW5kZWZpbmVkO1xuXG4gIGNvbnN0cnVjdG9yKGNoYXR0ZXI6IENoYXR0ZXI8Uz4sIHJlcXVlc3Q6IENoYXR0ZXJSZXF1ZXN0UGFyYW1zKSB7XG4gICAgdGhpcy5fY2hhdHRlciA9IGNoYXR0ZXI7XG4gICAgdGhpcy5fcmVxdWVzdCA9IHJlcXVlc3Q7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgcGFyYW1ldGVycyBpbiBiYXRjaCByZXF1ZXN0IGZvcm1cbiAgICovXG4gIGJhdGNoUGFyYW1zKCkge1xuICAgIGNvbnN0IHsgbWV0aG9kLCB1cmwsIGJvZHkgfSA9IHRoaXMuX3JlcXVlc3Q7XG4gICAgcmV0dXJuIHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIHVybDogdGhpcy5fY2hhdHRlci5fbm9ybWFsaXplVXJsKHVybCksXG4gICAgICAuLi4odHlwZW9mIGJvZHkgIT09ICd1bmRlZmluZWQnID8geyByaWNoSW5wdXQ6IGJvZHkgfSA6IHt9KSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHBhcmFtZXRlcnMgaW4gYmF0Y2ggcmVxdWVzdCBmb3JtXG4gICAqXG4gICAqIEBtZXRob2QgQ2hhdHRlcn5SZXF1ZXN0I3Byb21pc2VcbiAgICogQHJldHVybnMge1Byb21pc2UuPENoYXR0ZXJ+UmVxdWVzdFJlc3VsdD59XG4gICAqL1xuICBwcm9taXNlKCkge1xuICAgIHJldHVybiAoXG4gICAgICB0aGlzLl9wcm9taXNlIHx8ICh0aGlzLl9wcm9taXNlID0gdGhpcy5fY2hhdHRlci5fcmVxdWVzdCh0aGlzLl9yZXF1ZXN0KSlcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgTm9kZS5qcyBTdHJlYW0gb2JqZWN0IGZvciByZXF1ZXN0XG4gICAqXG4gICAqIEBtZXRob2QgQ2hhdHRlcn5SZXF1ZXN0I3N0cmVhbVxuICAgKiBAcmV0dXJucyB7c3RyZWFtLlN0cmVhbX1cbiAgICovXG4gIHN0cmVhbSgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2hhdHRlci5fcmVxdWVzdDxSPih0aGlzLl9yZXF1ZXN0KS5zdHJlYW0oKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9taXNlL0ErIGludGVyZmFjZVxuICAgKiBodHRwOi8vcHJvbWlzZXMtYXBsdXMuZ2l0aHViLmlvL3Byb21pc2VzLXNwZWMvXG4gICAqXG4gICAqIERlbGVnYXRlIHRvIGRlZmVycmVkIHByb21pc2UsIHJldHVybiBwcm9taXNlIGluc3RhbmNlIGZvciBiYXRjaCByZXN1bHRcbiAgICovXG4gIHRoZW48VT4oXG4gICAgb25SZXNvbHZlPzogKHZhbHVlOiBSKSA9PiBVIHwgUHJvbWlzZUxpa2U8VT4sXG4gICAgb25SZWplY3Q/OiAoZTogYW55KSA9PiBVIHwgUHJvbWlzZUxpa2U8VT4sXG4gICkge1xuICAgIHJldHVybiB0aGlzLnByb21pc2UoKS50aGVuKG9uUmVzb2x2ZSwgb25SZWplY3QpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFwcHBlbmRRdWVyeVBhcmFtc1RvVXJsKFxuICB1cmw6IHN0cmluZyxcbiAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbikge1xuICBpZiAocXVlcnlQYXJhbXMpIHtcbiAgICBjb25zdCBxc3RyaW5nID0gT2JqZWN0LmtleXMocXVlcnlQYXJhbXMpXG4gICAgICAubWFwKFxuICAgICAgICAobmFtZSkgPT5cbiAgICAgICAgICBgJHtuYW1lfT0ke2VuY29kZVVSSUNvbXBvbmVudChTdHJpbmcocXVlcnlQYXJhbXNbbmFtZV0gPz8gJycpKX1gLFxuICAgICAgKVxuICAgICAgLmpvaW4oJyYnKTtcbiAgICB1cmwgKz0gKHVybC5pbmRleE9mKCc/JykgPiAwID8gJyYnIDogJz8nKSArIHFzdHJpbmc7XG4gIH1cbiAgcmV0dXJuIHVybDtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuZXhwb3J0IGNsYXNzIFJlc291cmNlPFMgZXh0ZW5kcyBTY2hlbWEsIFI+IGV4dGVuZHMgUmVxdWVzdDxTLCBSPiB7XG4gIF91cmw6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIGNoYXR0ZXI6IENoYXR0ZXI8Uz4sXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbiAgKSB7XG4gICAgc3VwZXIoY2hhdHRlciwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHVybDogYXBwcGVuZFF1ZXJ5UGFyYW1zVG9VcmwodXJsLCBxdWVyeVBhcmFtcyksXG4gICAgfSk7XG4gICAgdGhpcy5fdXJsID0gdGhpcy5fcmVxdWVzdC51cmw7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IHJlc291cmNlXG4gICAqL1xuICBjcmVhdGU8UjEgPSBhbnk+KGRhdGE6IHN0cmluZyB8IG9iamVjdCB8IG51bGwpIHtcbiAgICByZXR1cm4gdGhpcy5fY2hhdHRlci5yZXF1ZXN0PFIxPih7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybDogdGhpcy5fdXJsLFxuICAgICAgYm9keTogZGF0YSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSByZXNvdXJjZSBjb250ZW50XG4gICAqL1xuICByZXRyaWV2ZTxSMSA9IFI+KCkge1xuICAgIHJldHVybiB0aGlzLl9jaGF0dGVyLnJlcXVlc3Q8UjE+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICB1cmw6IHRoaXMuX3VybCxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGUgc3BlY2lmaWVkIHJlc291cmNlXG4gICAqL1xuICB1cGRhdGU8UjEgPSBhbnk+KGRhdGE6IG9iamVjdCkge1xuICAgIHJldHVybiB0aGlzLl9jaGF0dGVyLnJlcXVlc3Q8UjE+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiB0aGlzLl91cmwsXG4gICAgICBib2R5OiBkYXRhLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSBzcGVjaWZpZWQgcmVzb3VyY2VcbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NoYXR0ZXIucmVxdWVzdDx2b2lkPih7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgdXJsOiB0aGlzLl91cmwsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBSZXNvdXJjZSNkZXN0cm95KClcbiAgICovXG4gIGRlbGV0ZSA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBSZXNvdXJjZSNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBBUEkgY2xhc3MgZm9yIENoYXR0ZXIgUkVTVCBBUEkgY2FsbFxuICovXG5leHBvcnQgY2xhc3MgQ2hhdHRlcjxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmRpbmcgcmVxdWVzdCB0byBBUEkgZW5kcG9pbnRcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZXF1ZXN0PFI+KHJlcV86IENoYXR0ZXJSZXF1ZXN0UGFyYW1zKSB7XG4gICAgY29uc3QgeyBtZXRob2QsIHVybDogdXJsXywgaGVhZGVyczogaGVhZGVyc18sIGJvZHk6IGJvZHlfIH0gPSByZXFfO1xuICAgIGxldCBoZWFkZXJzID0gaGVhZGVyc18gPz8ge307XG4gICAgbGV0IGJvZHk7XG4gICAgaWYgKC9eKHB1dHxwb3N0fHBhdGNoKSQvaS50ZXN0KG1ldGhvZCkpIHtcbiAgICAgIGlmIChpc09iamVjdChib2R5XykpIHtcbiAgICAgICAgaGVhZGVycyA9IHtcbiAgICAgICAgICAuLi5oZWFkZXJzXyxcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9O1xuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoYm9keV8pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYm9keSA9IGJvZHlfO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB1cmwgPSB0aGlzLl9ub3JtYWxpemVVcmwodXJsXyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPih7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzLFxuICAgICAgYm9keSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb252ZXJ0IHBhdGggdG8gc2l0ZSByb290IHJlbGF0aXZlIHVybFxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX25vcm1hbGl6ZVVybCh1cmw6IHN0cmluZykge1xuICAgIGlmICh1cmwuaW5kZXhPZignL2NoYXR0ZXIvJykgPT09IDAgfHwgdXJsLmluZGV4T2YoJy9jb25uZWN0LycpID09PSAwKSB7XG4gICAgICByZXR1cm4gJy9zZXJ2aWNlcy9kYXRhL3YnICsgdGhpcy5fY29ubi52ZXJzaW9uICsgdXJsO1xuICAgIH0gZWxzZSBpZiAoL15cXC92W1xcZF0rXFwuW1xcZF0rXFwvLy50ZXN0KHVybCkpIHtcbiAgICAgIHJldHVybiAnL3NlcnZpY2VzL2RhdGEnICsgdXJsO1xuICAgIH0gZWxzZSBpZiAodXJsLmluZGV4T2YoJy9zZXJ2aWNlcy8nKSAhPT0gMCAmJiB1cmxbMF0gPT09ICcvJykge1xuICAgICAgcmV0dXJuICcvc2VydmljZXMvZGF0YS92JyArIHRoaXMuX2Nvbm4udmVyc2lvbiArICcvY2hhdHRlcicgKyB1cmw7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB1cmw7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIE1ha2UgYSByZXF1ZXN0IGZvciBjaGF0dGVyIEFQSSByZXNvdXJjZVxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4ocmVxOiBDaGF0dGVyUmVxdWVzdFBhcmFtcykge1xuICAgIHJldHVybiBuZXcgUmVxdWVzdDxTLCBSPih0aGlzLCByZXEpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1ha2UgYSByZXNvdXJjZSByZXF1ZXN0IHRvIGNoYXR0ZXIgQVBJXG4gICAqL1xuICByZXNvdXJjZTxSID0gdW5rbm93bj4oXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbiAgKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNvdXJjZTxTLCBSPih0aGlzLCB1cmwsIHF1ZXJ5UGFyYW1zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNYWtlIGEgYmF0Y2ggcmVxdWVzdCB0byBjaGF0dGVyIEFQSVxuICAgKi9cbiAgYXN5bmMgYmF0Y2g8UlQgZXh0ZW5kcyBhbnlbXT4oXG4gICAgcmVxdWVzdHM6IEJhdGNoUmVxdWVzdFR1cHBsZTxTLCBSVD4sXG4gICk6IFByb21pc2U8QmF0Y2hSZXNwb25zZTxSVD4+IHtcbiAgICBjb25zdCBkZWZlcnJlZHMgPSByZXF1ZXN0cy5tYXAoKHJlcXVlc3QpID0+IHtcbiAgICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICAgIHJlcXVlc3QuX3Byb21pc2UgPSBkZWZlcnJlZC5wcm9taXNlO1xuICAgICAgcmV0dXJuIGRlZmVycmVkO1xuICAgIH0pO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdDxCYXRjaFJlc3BvbnNlPFJUPj4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHRoaXMuX25vcm1hbGl6ZVVybCgnL2Nvbm5lY3QvYmF0Y2gnKSxcbiAgICAgIGJvZHk6IHtcbiAgICAgICAgYmF0Y2hSZXF1ZXN0czogcmVxdWVzdHMubWFwKChyZXF1ZXN0KSA9PiByZXF1ZXN0LmJhdGNoUGFyYW1zKCkpLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXMucmVzdWx0cy5mb3JFYWNoKChyZXN1bHQsIGkpID0+IHtcbiAgICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXJyZWRzW2ldO1xuICAgICAgaWYgKHJlc3VsdC5zdGF0dXNDb2RlID49IDQwMCkge1xuICAgICAgICBkZWZlcnJlZC5yZWplY3QocmVzdWx0LnJlc3VsdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkZWZlcnJlZC5yZXNvbHZlKHJlc3VsdC5yZXN1bHQpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiByZXM7XG4gIH1cbn1cblxuZnVuY3Rpb24gZGVmZXI8VD4oKSB7XG4gIGxldCByZXNvbHZlXzogKHI6IFQgfCBQcm9taXNlTGlrZTxUPikgPT4gdm9pZCA9ICgpID0+IHt9O1xuICBsZXQgcmVqZWN0XzogKGU6IGFueSkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHJlc29sdmVfID0gcmVzb2x2ZTtcbiAgICByZWplY3RfID0gcmVqZWN0O1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBwcm9taXNlLFxuICAgIHJlc29sdmU6IHJlc29sdmVfLFxuICAgIHJlamVjdDogcmVqZWN0XyxcbiAgfTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKlxuICogUmVnaXN0ZXIgaG9vayBpbiBjb25uZWN0aW9uIGluc3RhbnRpYXRpb24gZm9yIGR5bmFtaWNhbGx5IGFkZGluZyB0aGlzIEFQSSBtb2R1bGUgZmVhdHVyZXNcbiAqL1xucmVnaXN0ZXJNb2R1bGUoJ2NoYXR0ZXInLCAoY29ubikgPT4gbmV3IENoYXR0ZXIoY29ubikpO1xuXG5leHBvcnQgZGVmYXVsdCBDaGF0dGVyO1xuIl19