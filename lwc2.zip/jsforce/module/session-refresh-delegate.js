import "core-js/modules/es.promise";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 *
 */
import { getLogger } from './util/logger';

/**
 *
 */
export class SessionRefreshDelegate {
  constructor(conn, refreshFn) {
    _defineProperty(this, "_refreshFn", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "_lastRefreshedAt", undefined);

    _defineProperty(this, "_refreshPromise", undefined);

    this._conn = conn;
    this._logger = conn._logLevel ? SessionRefreshDelegate._logger.createInstance(conn._logLevel) : SessionRefreshDelegate._logger;
    this._refreshFn = refreshFn;
  }
  /**
   * Refresh access token
   * @private
   */


  async refresh(since) {
    // Callback immediately When refreshed after designated time
    if (this._lastRefreshedAt && this._lastRefreshedAt > since) {
      return;
    }

    if (this._refreshPromise) {
      await this._refreshPromise;
      return;
    }

    try {
      this._logger.info('<refresh token>');

      this._refreshPromise = new _Promise((resolve, reject) => {
        this._refreshFn(this._conn, (err, accessToken, res) => {
          if (!err) {
            this._logger.debug('Connection refresh completed.');

            this._conn.accessToken = accessToken;

            this._conn.emit('refresh', accessToken, res);

            resolve();
          } else {
            reject(err);
          }
        });
      });
      await this._refreshPromise;

      this._logger.info('<refresh complete>');
    } finally {
      this._refreshPromise = undefined;
      this._lastRefreshedAt = _Date$now();
    }
  }

  isRefreshing() {
    return !!this._refreshPromise;
  }

  async waitRefresh() {
    return this._refreshPromise;
  }

}

_defineProperty(SessionRefreshDelegate, "_logger", getLogger('session-refresh-delegate'));

export default SessionRefreshDelegate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zZXNzaW9uLXJlZnJlc2gtZGVsZWdhdGUudHMiXSwibmFtZXMiOlsiZ2V0TG9nZ2VyIiwiU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSIsImNvbnN0cnVjdG9yIiwiY29ubiIsInJlZnJlc2hGbiIsInVuZGVmaW5lZCIsIl9jb25uIiwiX2xvZ2dlciIsIl9sb2dMZXZlbCIsImNyZWF0ZUluc3RhbmNlIiwiX3JlZnJlc2hGbiIsInJlZnJlc2giLCJzaW5jZSIsIl9sYXN0UmVmcmVzaGVkQXQiLCJfcmVmcmVzaFByb21pc2UiLCJpbmZvIiwicmVzb2x2ZSIsInJlamVjdCIsImVyciIsImFjY2Vzc1Rva2VuIiwicmVzIiwiZGVidWciLCJlbWl0IiwiaXNSZWZyZXNoaW5nIiwid2FpdFJlZnJlc2giXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsU0FBVCxRQUFrQyxlQUFsQzs7QUFhQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLHNCQUFOLENBQStDO0FBU3BEQyxFQUFBQSxXQUFXLENBQUNDLElBQUQsRUFBc0JDLFNBQXRCLEVBQXdEO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsOENBSHpCQyxTQUd5Qjs7QUFBQSw2Q0FGbkJBLFNBRW1COztBQUNqRSxTQUFLQyxLQUFMLEdBQWFILElBQWI7QUFDQSxTQUFLSSxPQUFMLEdBQWVKLElBQUksQ0FBQ0ssU0FBTCxHQUNYUCxzQkFBc0IsQ0FBQ00sT0FBdkIsQ0FBK0JFLGNBQS9CLENBQThDTixJQUFJLENBQUNLLFNBQW5ELENBRFcsR0FFWFAsc0JBQXNCLENBQUNNLE9BRjNCO0FBR0EsU0FBS0csVUFBTCxHQUFrQk4sU0FBbEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRSxRQUFNTyxPQUFOLENBQWNDLEtBQWQsRUFBNkI7QUFDM0I7QUFDQSxRQUFJLEtBQUtDLGdCQUFMLElBQXlCLEtBQUtBLGdCQUFMLEdBQXdCRCxLQUFyRCxFQUE0RDtBQUMxRDtBQUNEOztBQUNELFFBQUksS0FBS0UsZUFBVCxFQUEwQjtBQUN4QixZQUFNLEtBQUtBLGVBQVg7QUFDQTtBQUNEOztBQUNELFFBQUk7QUFDRixXQUFLUCxPQUFMLENBQWFRLElBQWIsQ0FBa0IsaUJBQWxCOztBQUNBLFdBQUtELGVBQUwsR0FBdUIsYUFBWSxDQUFDRSxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDdEQsYUFBS1AsVUFBTCxDQUFnQixLQUFLSixLQUFyQixFQUE0QixDQUFDWSxHQUFELEVBQU1DLFdBQU4sRUFBbUJDLEdBQW5CLEtBQTJCO0FBQ3JELGNBQUksQ0FBQ0YsR0FBTCxFQUFVO0FBQ1IsaUJBQUtYLE9BQUwsQ0FBYWMsS0FBYixDQUFtQiwrQkFBbkI7O0FBQ0EsaUJBQUtmLEtBQUwsQ0FBV2EsV0FBWCxHQUF5QkEsV0FBekI7O0FBQ0EsaUJBQUtiLEtBQUwsQ0FBV2dCLElBQVgsQ0FBZ0IsU0FBaEIsRUFBMkJILFdBQTNCLEVBQXdDQyxHQUF4Qzs7QUFDQUosWUFBQUEsT0FBTztBQUNSLFdBTEQsTUFLTztBQUNMQyxZQUFBQSxNQUFNLENBQUNDLEdBQUQsQ0FBTjtBQUNEO0FBQ0YsU0FURDtBQVVELE9BWHNCLENBQXZCO0FBWUEsWUFBTSxLQUFLSixlQUFYOztBQUNBLFdBQUtQLE9BQUwsQ0FBYVEsSUFBYixDQUFrQixvQkFBbEI7QUFDRCxLQWhCRCxTQWdCVTtBQUNSLFdBQUtELGVBQUwsR0FBdUJULFNBQXZCO0FBQ0EsV0FBS1EsZ0JBQUwsR0FBd0IsV0FBeEI7QUFDRDtBQUNGOztBQUVEVSxFQUFBQSxZQUFZLEdBQVk7QUFDdEIsV0FBTyxDQUFDLENBQUMsS0FBS1QsZUFBZDtBQUNEOztBQUVELFFBQU1VLFdBQU4sR0FBb0I7QUFDbEIsV0FBTyxLQUFLVixlQUFaO0FBQ0Q7O0FBMURtRDs7Z0JBQXpDYixzQixhQUNjRCxTQUFTLENBQUMsMEJBQUQsQzs7QUE0RHBDLGVBQWVDLHNCQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBnZXRMb2dnZXIsIExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgQ2FsbGJhY2ssIFNjaGVtYSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFRva2VuUmVzcG9uc2UgfSBmcm9tICcuL29hdXRoMic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU2Vzc2lvblJlZnJlc2hGdW5jPFMgZXh0ZW5kcyBTY2hlbWE+ID0gKFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikgPT4gdm9pZDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIHN0YXRpYyBfbG9nZ2VyOiBMb2dnZXIgPSBnZXRMb2dnZXIoJ3Nlc3Npb24tcmVmcmVzaC1kZWxlZ2F0ZScpO1xuXG4gIHByaXZhdGUgX3JlZnJlc2hGbjogU2Vzc2lvblJlZnJlc2hGdW5jPFM+O1xuICBwcml2YXRlIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBwcml2YXRlIF9sb2dnZXI6IExvZ2dlcjtcbiAgcHJpdmF0ZSBfbGFzdFJlZnJlc2hlZEF0OiBudW1iZXIgfCB2b2lkID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF9yZWZyZXNoUHJvbWlzZTogUHJvbWlzZTx2b2lkPiB8IHZvaWQgPSB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgcmVmcmVzaEZuOiBTZXNzaW9uUmVmcmVzaEZ1bmM8Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgICB0aGlzLl9sb2dnZXIgPSBjb25uLl9sb2dMZXZlbFxuICAgICAgPyBTZXNzaW9uUmVmcmVzaERlbGVnYXRlLl9sb2dnZXIuY3JlYXRlSW5zdGFuY2UoY29ubi5fbG9nTGV2ZWwpXG4gICAgICA6IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUuX2xvZ2dlcjtcbiAgICB0aGlzLl9yZWZyZXNoRm4gPSByZWZyZXNoRm47XG4gIH1cblxuICAvKipcbiAgICogUmVmcmVzaCBhY2Nlc3MgdG9rZW5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIHJlZnJlc2goc2luY2U6IG51bWJlcikge1xuICAgIC8vIENhbGxiYWNrIGltbWVkaWF0ZWx5IFdoZW4gcmVmcmVzaGVkIGFmdGVyIGRlc2lnbmF0ZWQgdGltZVxuICAgIGlmICh0aGlzLl9sYXN0UmVmcmVzaGVkQXQgJiYgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID4gc2luY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3JlZnJlc2hQcm9taXNlKSB7XG4gICAgICBhd2FpdCB0aGlzLl9yZWZyZXNoUHJvbWlzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuX2xvZ2dlci5pbmZvKCc8cmVmcmVzaCB0b2tlbj4nKTtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICB0aGlzLl9yZWZyZXNoRm4odGhpcy5fY29ubiwgKGVyciwgYWNjZXNzVG9rZW4sIHJlcykgPT4ge1xuICAgICAgICAgIGlmICghZXJyKSB7XG4gICAgICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ0Nvbm5lY3Rpb24gcmVmcmVzaCBjb21wbGV0ZWQuJyk7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmFjY2Vzc1Rva2VuID0gYWNjZXNzVG9rZW47XG4gICAgICAgICAgICB0aGlzLl9jb25uLmVtaXQoJ3JlZnJlc2gnLCBhY2Nlc3NUb2tlbiwgcmVzKTtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gICAgICB0aGlzLl9sb2dnZXIuaW5mbygnPHJlZnJlc2ggY29tcGxldGU+Jyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID0gRGF0ZS5ub3coKTtcbiAgICB9XG4gIH1cblxuICBpc1JlZnJlc2hpbmcoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cblxuICBhc3luYyB3YWl0UmVmcmVzaCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTtcbiJdfQ==