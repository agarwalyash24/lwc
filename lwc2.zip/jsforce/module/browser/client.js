import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.iterator";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _reverseInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reverse";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _setInterval from "@babel/runtime-corejs3/core-js-stable/set-interval";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source), true)).call(_context2, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source))).call(_context3, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Browser client connection management class
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import qs from 'querystring';
import Connection from '../connection';
import OAuth2 from '../oauth2';
/**
 * @private
 */

function popupWin(url, w, h) {
  const left = screen.width / 2 - w / 2;
  const top = screen.height / 2 - h / 2;
  return window.open(url, undefined, `location=yes,toolbar=no,status=no,menubar=no,width=${w},height=${h},top=${top},left=${left}`);
}
/**
 * @private
 */


function handleCallbackResponse() {
  const res = checkCallbackResponse();
  const state = localStorage.getItem('jsforce_state');

  if (res && state && res.body.state === state) {
    localStorage.removeItem('jsforce_state');
    const [prefix, promptType] = state.split('.');
    const cli = new BrowserClient(prefix);

    if (res.success) {
      cli._storeTokens(res.body);

      location.hash = '';
    } else {
      cli._storeError(res.body);
    }

    if (promptType === 'popup') {
      window.close();
    }

    return true;
  }
}
/**
 * @private
 */


function checkCallbackResponse() {
  let params;

  if (window.location.hash) {
    params = qs.parse(window.location.hash.substring(1));

    if (params.access_token) {
      return {
        success: true,
        body: params
      };
    }
  } else if (window.location.search) {
    params = qs.parse(window.location.search.substring(1));

    if (params.error) {
      return {
        success: false,
        body: params
      };
    }
  }
}
/**
 *
 */


/**
 *
 */
const DEFAULT_POPUP_WIN_WIDTH = 912;
const DEFAULT_POPUP_WIN_HEIGHT = 513;
/** @private **/

let clientIdx = 0;
/**
 *
 */

export class BrowserClient extends EventEmitter {
  /**
   *
   */
  constructor(prefix) {
    super();

    _defineProperty(this, "_prefix", void 0);

    _defineProperty(this, "_config", void 0);

    _defineProperty(this, "_connection", void 0);

    this._prefix = prefix || 'jsforce' + clientIdx++;
  }

  get connection() {
    if (!this._connection) {
      this._connection = new Connection(this._config);
    }

    return this._connection;
  }
  /**
   *
   */


  init(config) {
    if (handleCallbackResponse()) {
      return;
    }

    this._config = config;

    const tokens = this._getTokens();

    if (tokens) {
      this.connection._establish(tokens);

      _setTimeout(() => {
        this.emit('connect', this.connection);
      }, 10);
    }
  }
  /**
   *
   */


  login(options = {}) {
    var _this$_config, _size$width, _size$height;

    const {
      scope,
      size
    } = options;
    const oauth2 = new OAuth2((_this$_config = this._config) !== null && _this$_config !== void 0 ? _this$_config : {});
    const rand = Math.random().toString(36).substring(2);
    const state = [this._prefix, 'popup', rand].join('.');
    localStorage.setItem('jsforce_state', state);
    const authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
      response_type: 'token',
      state
    }, scope ? {
      scope
    } : {}));
    const pw = popupWin(authzUrl, (_size$width = size === null || size === void 0 ? void 0 : size.width) !== null && _size$width !== void 0 ? _size$width : DEFAULT_POPUP_WIN_WIDTH, (_size$height = size === null || size === void 0 ? void 0 : size.height) !== null && _size$height !== void 0 ? _size$height : DEFAULT_POPUP_WIN_HEIGHT);
    return new _Promise((resolve, reject) => {
      if (!pw) {
        const state = [this._prefix, 'redirect', rand].join('.');
        localStorage.setItem('jsforce_state', state);
        const authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
          response_type: 'token',
          state
        }, scope ? {
          scope
        } : {}));
        location.href = authzUrl;
        return;
      }

      this._removeTokens();

      const pid = _setInterval(() => {
        try {
          if (!pw || pw.closed) {
            clearInterval(pid);

            const tokens = this._getTokens();

            if (tokens) {
              this.connection._establish(tokens);

              this.emit('connect', this.connection);
              resolve({
                status: 'connect'
              });
            } else {
              const err = this._getError();

              if (err) {
                reject(new Error(err.error + ': ' + err.error_description));
              } else {
                resolve({
                  status: 'cancel'
                });
              }
            }
          }
        } catch (e) {//
        }
      }, 1000);
    });
  }
  /**
   *
   */


  isLoggedIn() {
    return !!this.connection.accessToken;
  }
  /**
   *
   */


  logout() {
    this.connection.logout();

    this._removeTokens();

    this.emit('disconnect');
  }
  /**
   * @private
   */


  _getTokens() {
    const regexp = new RegExp('(^|;\\s*)' + this._prefix + '_loggedin=true(;|$)');

    if (document.cookie.match(regexp)) {
      const issuedAt = Number(localStorage.getItem(this._prefix + '_issued_at')); // 2 hours

      if (_Date$now() < issuedAt + 2 * 60 * 60 * 1000) {
        let userInfo;
        const idUrl = localStorage.getItem(this._prefix + '_id');

        if (idUrl) {
          var _context;

          const [id, organizationId] = _reverseInstanceProperty(_context = idUrl.split('/')).call(_context);

          userInfo = {
            id,
            organizationId,
            url: idUrl
          };
        }

        return {
          accessToken: localStorage.getItem(this._prefix + '_access_token'),
          instanceUrl: localStorage.getItem(this._prefix + '_instance_url'),
          userInfo
        };
      }
    }

    return null;
  }
  /**
   * @private
   */


  _storeTokens(params) {
    localStorage.setItem(this._prefix + '_access_token', params.access_token);
    localStorage.setItem(this._prefix + '_instance_url', params.instance_url);
    localStorage.setItem(this._prefix + '_issued_at', params.issued_at);
    localStorage.setItem(this._prefix + '_id', params.id);
    document.cookie = this._prefix + '_loggedin=true;';
  }
  /**
   * @private
   */


  _removeTokens() {
    localStorage.removeItem(this._prefix + '_access_token');
    localStorage.removeItem(this._prefix + '_instance_url');
    localStorage.removeItem(this._prefix + '_issued_at');
    localStorage.removeItem(this._prefix + '_id');
    document.cookie = this._prefix + '_loggedin=';
  }
  /**
   * @private
   */


  _getError() {
    try {
      var _localStorage$getItem;

      const err = JSON.parse((_localStorage$getItem = localStorage.getItem(this._prefix + '_error')) !== null && _localStorage$getItem !== void 0 ? _localStorage$getItem : '');
      localStorage.removeItem(this._prefix + '_error');
      return err;
    } catch (e) {//
    }
  }
  /**
   * @private
   */


  _storeError(err) {
    localStorage.setItem(this._prefix + '_error', _JSON$stringify(err));
  }

}
/**
 *
 */

const client = new BrowserClient();
export default client;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9icm93c2VyL2NsaWVudC50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJxcyIsIkNvbm5lY3Rpb24iLCJPQXV0aDIiLCJwb3B1cFdpbiIsInVybCIsInciLCJoIiwibGVmdCIsInNjcmVlbiIsIndpZHRoIiwidG9wIiwiaGVpZ2h0Iiwid2luZG93Iiwib3BlbiIsInVuZGVmaW5lZCIsImhhbmRsZUNhbGxiYWNrUmVzcG9uc2UiLCJyZXMiLCJjaGVja0NhbGxiYWNrUmVzcG9uc2UiLCJzdGF0ZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJib2R5IiwicmVtb3ZlSXRlbSIsInByZWZpeCIsInByb21wdFR5cGUiLCJzcGxpdCIsImNsaSIsIkJyb3dzZXJDbGllbnQiLCJzdWNjZXNzIiwiX3N0b3JlVG9rZW5zIiwibG9jYXRpb24iLCJoYXNoIiwiX3N0b3JlRXJyb3IiLCJjbG9zZSIsInBhcmFtcyIsInBhcnNlIiwic3Vic3RyaW5nIiwiYWNjZXNzX3Rva2VuIiwic2VhcmNoIiwiZXJyb3IiLCJERUZBVUxUX1BPUFVQX1dJTl9XSURUSCIsIkRFRkFVTFRfUE9QVVBfV0lOX0hFSUdIVCIsImNsaWVudElkeCIsImNvbnN0cnVjdG9yIiwiX3ByZWZpeCIsImNvbm5lY3Rpb24iLCJfY29ubmVjdGlvbiIsIl9jb25maWciLCJpbml0IiwiY29uZmlnIiwidG9rZW5zIiwiX2dldFRva2VucyIsIl9lc3RhYmxpc2giLCJlbWl0IiwibG9naW4iLCJvcHRpb25zIiwic2NvcGUiLCJzaXplIiwib2F1dGgyIiwicmFuZCIsIk1hdGgiLCJyYW5kb20iLCJ0b1N0cmluZyIsImpvaW4iLCJzZXRJdGVtIiwiYXV0aHpVcmwiLCJnZXRBdXRob3JpemF0aW9uVXJsIiwicmVzcG9uc2VfdHlwZSIsInB3IiwicmVzb2x2ZSIsInJlamVjdCIsImhyZWYiLCJfcmVtb3ZlVG9rZW5zIiwicGlkIiwiY2xvc2VkIiwiY2xlYXJJbnRlcnZhbCIsInN0YXR1cyIsImVyciIsIl9nZXRFcnJvciIsIkVycm9yIiwiZXJyb3JfZGVzY3JpcHRpb24iLCJlIiwiaXNMb2dnZWRJbiIsImFjY2Vzc1Rva2VuIiwibG9nb3V0IiwicmVnZXhwIiwiUmVnRXhwIiwiZG9jdW1lbnQiLCJjb29raWUiLCJtYXRjaCIsImlzc3VlZEF0IiwiTnVtYmVyIiwidXNlckluZm8iLCJpZFVybCIsImlkIiwib3JnYW5pemF0aW9uSWQiLCJpbnN0YW5jZVVybCIsImluc3RhbmNlX3VybCIsImlzc3VlZF9hdCIsIkpTT04iLCJjbGllbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBVCxRQUE2QixRQUE3QjtBQUNBLE9BQU9DLEVBQVAsTUFBZSxhQUFmO0FBQ0EsT0FBT0MsVUFBUCxNQUE2QyxlQUE3QztBQUNBLE9BQU9DLE1BQVAsTUFBc0MsV0FBdEM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0MsUUFBVCxDQUFrQkMsR0FBbEIsRUFBK0JDLENBQS9CLEVBQTBDQyxDQUExQyxFQUFxRDtBQUNuRCxRQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQ0MsS0FBUCxHQUFlLENBQWYsR0FBbUJKLENBQUMsR0FBRyxDQUFwQztBQUNBLFFBQU1LLEdBQUcsR0FBR0YsTUFBTSxDQUFDRyxNQUFQLEdBQWdCLENBQWhCLEdBQW9CTCxDQUFDLEdBQUcsQ0FBcEM7QUFDQSxTQUFPTSxNQUFNLENBQUNDLElBQVAsQ0FDTFQsR0FESyxFQUVMVSxTQUZLLEVBR0osc0RBQXFEVCxDQUFFLFdBQVVDLENBQUUsUUFBT0ksR0FBSSxTQUFRSCxJQUFLLEVBSHZGLENBQVA7QUFLRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1Esc0JBQVQsR0FBa0M7QUFDaEMsUUFBTUMsR0FBRyxHQUFHQyxxQkFBcUIsRUFBakM7QUFDQSxRQUFNQyxLQUFLLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixlQUFyQixDQUFkOztBQUNBLE1BQUlKLEdBQUcsSUFBSUUsS0FBUCxJQUFnQkYsR0FBRyxDQUFDSyxJQUFKLENBQVNILEtBQVQsS0FBbUJBLEtBQXZDLEVBQThDO0FBQzVDQyxJQUFBQSxZQUFZLENBQUNHLFVBQWIsQ0FBd0IsZUFBeEI7QUFDQSxVQUFNLENBQUNDLE1BQUQsRUFBU0MsVUFBVCxJQUF1Qk4sS0FBSyxDQUFDTyxLQUFOLENBQVksR0FBWixDQUE3QjtBQUNBLFVBQU1DLEdBQUcsR0FBRyxJQUFJQyxhQUFKLENBQWtCSixNQUFsQixDQUFaOztBQUNBLFFBQUlQLEdBQUcsQ0FBQ1ksT0FBUixFQUFpQjtBQUNmRixNQUFBQSxHQUFHLENBQUNHLFlBQUosQ0FBaUJiLEdBQUcsQ0FBQ0ssSUFBckI7O0FBQ0FTLE1BQUFBLFFBQVEsQ0FBQ0MsSUFBVCxHQUFnQixFQUFoQjtBQUNELEtBSEQsTUFHTztBQUNMTCxNQUFBQSxHQUFHLENBQUNNLFdBQUosQ0FBZ0JoQixHQUFHLENBQUNLLElBQXBCO0FBQ0Q7O0FBQ0QsUUFBSUcsVUFBVSxLQUFLLE9BQW5CLEVBQTRCO0FBQzFCWixNQUFBQSxNQUFNLENBQUNxQixLQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxJQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU2hCLHFCQUFULEdBQWlDO0FBQy9CLE1BQUlpQixNQUFKOztBQUNBLE1BQUl0QixNQUFNLENBQUNrQixRQUFQLENBQWdCQyxJQUFwQixFQUEwQjtBQUN4QkcsSUFBQUEsTUFBTSxHQUFHbEMsRUFBRSxDQUFDbUMsS0FBSCxDQUFTdkIsTUFBTSxDQUFDa0IsUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUJLLFNBQXJCLENBQStCLENBQS9CLENBQVQsQ0FBVDs7QUFDQSxRQUFJRixNQUFNLENBQUNHLFlBQVgsRUFBeUI7QUFDdkIsYUFBTztBQUFFVCxRQUFBQSxPQUFPLEVBQUUsSUFBWDtBQUFpQlAsUUFBQUEsSUFBSSxFQUFFYTtBQUF2QixPQUFQO0FBQ0Q7QUFDRixHQUxELE1BS08sSUFBSXRCLE1BQU0sQ0FBQ2tCLFFBQVAsQ0FBZ0JRLE1BQXBCLEVBQTRCO0FBQ2pDSixJQUFBQSxNQUFNLEdBQUdsQyxFQUFFLENBQUNtQyxLQUFILENBQVN2QixNQUFNLENBQUNrQixRQUFQLENBQWdCUSxNQUFoQixDQUF1QkYsU0FBdkIsQ0FBaUMsQ0FBakMsQ0FBVCxDQUFUOztBQUNBLFFBQUlGLE1BQU0sQ0FBQ0ssS0FBWCxFQUFrQjtBQUNoQixhQUFPO0FBQUVYLFFBQUFBLE9BQU8sRUFBRSxLQUFYO0FBQWtCUCxRQUFBQSxJQUFJLEVBQUVhO0FBQXhCLE9BQVA7QUFDRDtBQUNGO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7OztBQU1BO0FBQ0E7QUFDQTtBQUNBLE1BQU1NLHVCQUF1QixHQUFHLEdBQWhDO0FBQ0EsTUFBTUMsd0JBQXdCLEdBQUcsR0FBakM7QUFFQTs7QUFDQSxJQUFJQyxTQUFTLEdBQUcsQ0FBaEI7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNZixhQUFOLFNBQTRCNUIsWUFBNUIsQ0FBeUM7QUFLOUM7QUFDRjtBQUNBO0FBQ0U0QyxFQUFBQSxXQUFXLENBQUNwQixNQUFELEVBQWtCO0FBQzNCOztBQUQyQjs7QUFBQTs7QUFBQTs7QUFFM0IsU0FBS3FCLE9BQUwsR0FBZXJCLE1BQU0sSUFBSSxZQUFZbUIsU0FBUyxFQUE5QztBQUNEOztBQUVELE1BQUlHLFVBQUosR0FBNkI7QUFDM0IsUUFBSSxDQUFDLEtBQUtDLFdBQVYsRUFBdUI7QUFDckIsV0FBS0EsV0FBTCxHQUFtQixJQUFJN0MsVUFBSixDQUFlLEtBQUs4QyxPQUFwQixDQUFuQjtBQUNEOztBQUNELFdBQU8sS0FBS0QsV0FBWjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUUsRUFBQUEsSUFBSSxDQUFDQyxNQUFELEVBQTJCO0FBQzdCLFFBQUlsQyxzQkFBc0IsRUFBMUIsRUFBOEI7QUFDNUI7QUFDRDs7QUFDRCxTQUFLZ0MsT0FBTCxHQUFlRSxNQUFmOztBQUNBLFVBQU1DLE1BQU0sR0FBRyxLQUFLQyxVQUFMLEVBQWY7O0FBQ0EsUUFBSUQsTUFBSixFQUFZO0FBQ1YsV0FBS0wsVUFBTCxDQUFnQk8sVUFBaEIsQ0FBMkJGLE1BQTNCOztBQUNBLGtCQUFXLE1BQU07QUFDZixhQUFLRyxJQUFMLENBQVUsU0FBVixFQUFxQixLQUFLUixVQUExQjtBQUNELE9BRkQsRUFFRyxFQUZIO0FBR0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VTLEVBQUFBLEtBQUssQ0FBQ0MsT0FBcUIsR0FBRyxFQUF6QixFQUE2QjtBQUFBOztBQUNoQyxVQUFNO0FBQUVDLE1BQUFBLEtBQUY7QUFBU0MsTUFBQUE7QUFBVCxRQUFrQkYsT0FBeEI7QUFDQSxVQUFNRyxNQUFNLEdBQUcsSUFBSXhELE1BQUosa0JBQVcsS0FBSzZDLE9BQWhCLHlEQUEyQixFQUEzQixDQUFmO0FBQ0EsVUFBTVksSUFBSSxHQUFHQyxJQUFJLENBQUNDLE1BQUwsR0FBY0MsUUFBZCxDQUF1QixFQUF2QixFQUEyQjFCLFNBQTNCLENBQXFDLENBQXJDLENBQWI7QUFDQSxVQUFNbEIsS0FBSyxHQUFHLENBQUMsS0FBSzBCLE9BQU4sRUFBZSxPQUFmLEVBQXdCZSxJQUF4QixFQUE4QkksSUFBOUIsQ0FBbUMsR0FBbkMsQ0FBZDtBQUNBNUMsSUFBQUEsWUFBWSxDQUFDNkMsT0FBYixDQUFxQixlQUFyQixFQUFzQzlDLEtBQXRDO0FBQ0EsVUFBTStDLFFBQVEsR0FBR1AsTUFBTSxDQUFDUSxtQkFBUDtBQUNmQyxNQUFBQSxhQUFhLEVBQUUsT0FEQTtBQUVmakQsTUFBQUE7QUFGZSxPQUdYc0MsS0FBSyxHQUFHO0FBQUVBLE1BQUFBO0FBQUYsS0FBSCxHQUFlLEVBSFQsRUFBakI7QUFLQSxVQUFNWSxFQUFFLEdBQUdqRSxRQUFRLENBQ2pCOEQsUUFEaUIsaUJBRWpCUixJQUZpQixhQUVqQkEsSUFGaUIsdUJBRWpCQSxJQUFJLENBQUVoRCxLQUZXLHFEQUVGK0IsdUJBRkUsa0JBR2pCaUIsSUFIaUIsYUFHakJBLElBSGlCLHVCQUdqQkEsSUFBSSxDQUFFOUMsTUFIVyx1REFHRDhCLHdCQUhDLENBQW5CO0FBS0EsV0FBTyxhQUFnQyxDQUFDNEIsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQzFELFVBQUksQ0FBQ0YsRUFBTCxFQUFTO0FBQ1AsY0FBTWxELEtBQUssR0FBRyxDQUFDLEtBQUswQixPQUFOLEVBQWUsVUFBZixFQUEyQmUsSUFBM0IsRUFBaUNJLElBQWpDLENBQXNDLEdBQXRDLENBQWQ7QUFDQTVDLFFBQUFBLFlBQVksQ0FBQzZDLE9BQWIsQ0FBcUIsZUFBckIsRUFBc0M5QyxLQUF0QztBQUNBLGNBQU0rQyxRQUFRLEdBQUdQLE1BQU0sQ0FBQ1EsbUJBQVA7QUFDZkMsVUFBQUEsYUFBYSxFQUFFLE9BREE7QUFFZmpELFVBQUFBO0FBRmUsV0FHWHNDLEtBQUssR0FBRztBQUFFQSxVQUFBQTtBQUFGLFNBQUgsR0FBZSxFQUhULEVBQWpCO0FBS0ExQixRQUFBQSxRQUFRLENBQUN5QyxJQUFULEdBQWdCTixRQUFoQjtBQUNBO0FBQ0Q7O0FBQ0QsV0FBS08sYUFBTDs7QUFDQSxZQUFNQyxHQUFHLEdBQUcsYUFBWSxNQUFNO0FBQzVCLFlBQUk7QUFDRixjQUFJLENBQUNMLEVBQUQsSUFBT0EsRUFBRSxDQUFDTSxNQUFkLEVBQXNCO0FBQ3BCQyxZQUFBQSxhQUFhLENBQUNGLEdBQUQsQ0FBYjs7QUFDQSxrQkFBTXZCLE1BQU0sR0FBRyxLQUFLQyxVQUFMLEVBQWY7O0FBQ0EsZ0JBQUlELE1BQUosRUFBWTtBQUNWLG1CQUFLTCxVQUFMLENBQWdCTyxVQUFoQixDQUEyQkYsTUFBM0I7O0FBQ0EsbUJBQUtHLElBQUwsQ0FBVSxTQUFWLEVBQXFCLEtBQUtSLFVBQTFCO0FBQ0F3QixjQUFBQSxPQUFPLENBQUM7QUFBRU8sZ0JBQUFBLE1BQU0sRUFBRTtBQUFWLGVBQUQsQ0FBUDtBQUNELGFBSkQsTUFJTztBQUNMLG9CQUFNQyxHQUFHLEdBQUcsS0FBS0MsU0FBTCxFQUFaOztBQUNBLGtCQUFJRCxHQUFKLEVBQVM7QUFDUFAsZ0JBQUFBLE1BQU0sQ0FBQyxJQUFJUyxLQUFKLENBQVVGLEdBQUcsQ0FBQ3RDLEtBQUosR0FBWSxJQUFaLEdBQW1Cc0MsR0FBRyxDQUFDRyxpQkFBakMsQ0FBRCxDQUFOO0FBQ0QsZUFGRCxNQUVPO0FBQ0xYLGdCQUFBQSxPQUFPLENBQUM7QUFBRU8sa0JBQUFBLE1BQU0sRUFBRTtBQUFWLGlCQUFELENBQVA7QUFDRDtBQUNGO0FBQ0Y7QUFDRixTQWpCRCxDQWlCRSxPQUFPSyxDQUFQLEVBQVUsQ0FDVjtBQUNEO0FBQ0YsT0FyQlcsRUFxQlQsSUFyQlMsQ0FBWjtBQXNCRCxLQW5DTSxDQUFQO0FBb0NEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsVUFBVSxHQUFHO0FBQ1gsV0FBTyxDQUFDLENBQUMsS0FBS3JDLFVBQUwsQ0FBZ0JzQyxXQUF6QjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsTUFBTSxHQUFHO0FBQ1AsU0FBS3ZDLFVBQUwsQ0FBZ0J1QyxNQUFoQjs7QUFDQSxTQUFLWixhQUFMOztBQUNBLFNBQUtuQixJQUFMLENBQVUsWUFBVjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUYsRUFBQUEsVUFBVSxHQUFHO0FBQ1gsVUFBTWtDLE1BQU0sR0FBRyxJQUFJQyxNQUFKLENBQ2IsY0FBYyxLQUFLMUMsT0FBbkIsR0FBNkIscUJBRGhCLENBQWY7O0FBR0EsUUFBSTJDLFFBQVEsQ0FBQ0MsTUFBVCxDQUFnQkMsS0FBaEIsQ0FBc0JKLE1BQXRCLENBQUosRUFBbUM7QUFDakMsWUFBTUssUUFBUSxHQUFHQyxNQUFNLENBQ3JCeEUsWUFBWSxDQUFDQyxPQUFiLENBQXFCLEtBQUt3QixPQUFMLEdBQWUsWUFBcEMsQ0FEcUIsQ0FBdkIsQ0FEaUMsQ0FJakM7O0FBQ0EsVUFBSSxjQUFhOEMsUUFBUSxHQUFHLElBQUksRUFBSixHQUFTLEVBQVQsR0FBYyxJQUExQyxFQUFnRDtBQUM5QyxZQUFJRSxRQUFKO0FBQ0EsY0FBTUMsS0FBSyxHQUFHMUUsWUFBWSxDQUFDQyxPQUFiLENBQXFCLEtBQUt3QixPQUFMLEdBQWUsS0FBcEMsQ0FBZDs7QUFDQSxZQUFJaUQsS0FBSixFQUFXO0FBQUE7O0FBQ1QsZ0JBQU0sQ0FBQ0MsRUFBRCxFQUFLQyxjQUFMLElBQXVCLG9DQUFBRixLQUFLLENBQUNwRSxLQUFOLENBQVksR0FBWixpQkFBN0I7O0FBQ0FtRSxVQUFBQSxRQUFRLEdBQUc7QUFBRUUsWUFBQUEsRUFBRjtBQUFNQyxZQUFBQSxjQUFOO0FBQXNCM0YsWUFBQUEsR0FBRyxFQUFFeUY7QUFBM0IsV0FBWDtBQUNEOztBQUNELGVBQU87QUFDTFYsVUFBQUEsV0FBVyxFQUFFaEUsWUFBWSxDQUFDQyxPQUFiLENBQXFCLEtBQUt3QixPQUFMLEdBQWUsZUFBcEMsQ0FEUjtBQUVMb0QsVUFBQUEsV0FBVyxFQUFFN0UsWUFBWSxDQUFDQyxPQUFiLENBQXFCLEtBQUt3QixPQUFMLEdBQWUsZUFBcEMsQ0FGUjtBQUdMZ0QsVUFBQUE7QUFISyxTQUFQO0FBS0Q7QUFDRjs7QUFDRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UvRCxFQUFBQSxZQUFZLENBQUNLLE1BQUQsRUFBd0I7QUFDbENmLElBQUFBLFlBQVksQ0FBQzZDLE9BQWIsQ0FBcUIsS0FBS3BCLE9BQUwsR0FBZSxlQUFwQyxFQUFxRFYsTUFBTSxDQUFDRyxZQUE1RDtBQUNBbEIsSUFBQUEsWUFBWSxDQUFDNkMsT0FBYixDQUFxQixLQUFLcEIsT0FBTCxHQUFlLGVBQXBDLEVBQXFEVixNQUFNLENBQUMrRCxZQUE1RDtBQUNBOUUsSUFBQUEsWUFBWSxDQUFDNkMsT0FBYixDQUFxQixLQUFLcEIsT0FBTCxHQUFlLFlBQXBDLEVBQWtEVixNQUFNLENBQUNnRSxTQUF6RDtBQUNBL0UsSUFBQUEsWUFBWSxDQUFDNkMsT0FBYixDQUFxQixLQUFLcEIsT0FBTCxHQUFlLEtBQXBDLEVBQTJDVixNQUFNLENBQUM0RCxFQUFsRDtBQUNBUCxJQUFBQSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsS0FBSzVDLE9BQUwsR0FBZSxpQkFBakM7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0U0QixFQUFBQSxhQUFhLEdBQUc7QUFDZHJELElBQUFBLFlBQVksQ0FBQ0csVUFBYixDQUF3QixLQUFLc0IsT0FBTCxHQUFlLGVBQXZDO0FBQ0F6QixJQUFBQSxZQUFZLENBQUNHLFVBQWIsQ0FBd0IsS0FBS3NCLE9BQUwsR0FBZSxlQUF2QztBQUNBekIsSUFBQUEsWUFBWSxDQUFDRyxVQUFiLENBQXdCLEtBQUtzQixPQUFMLEdBQWUsWUFBdkM7QUFDQXpCLElBQUFBLFlBQVksQ0FBQ0csVUFBYixDQUF3QixLQUFLc0IsT0FBTCxHQUFlLEtBQXZDO0FBQ0EyQyxJQUFBQSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsS0FBSzVDLE9BQUwsR0FBZSxZQUFqQztBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRWtDLEVBQUFBLFNBQVMsR0FBRztBQUNWLFFBQUk7QUFBQTs7QUFDRixZQUFNRCxHQUFHLEdBQUdzQixJQUFJLENBQUNoRSxLQUFMLDBCQUNWaEIsWUFBWSxDQUFDQyxPQUFiLENBQXFCLEtBQUt3QixPQUFMLEdBQWUsUUFBcEMsQ0FEVSx5RUFDdUMsRUFEdkMsQ0FBWjtBQUdBekIsTUFBQUEsWUFBWSxDQUFDRyxVQUFiLENBQXdCLEtBQUtzQixPQUFMLEdBQWUsUUFBdkM7QUFDQSxhQUFPaUMsR0FBUDtBQUNELEtBTkQsQ0FNRSxPQUFPSSxDQUFQLEVBQVUsQ0FDVjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7OztBQUNFakQsRUFBQUEsV0FBVyxDQUFDNkMsR0FBRCxFQUFXO0FBQ3BCMUQsSUFBQUEsWUFBWSxDQUFDNkMsT0FBYixDQUFxQixLQUFLcEIsT0FBTCxHQUFlLFFBQXBDLEVBQThDLGdCQUFlaUMsR0FBZixDQUE5QztBQUNEOztBQXJMNkM7QUF3TGhEO0FBQ0E7QUFDQTs7QUFDQSxNQUFNdUIsTUFBTSxHQUFHLElBQUl6RSxhQUFKLEVBQWY7QUFFQSxlQUFleUUsTUFBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQnJvd3NlciBjbGllbnQgY29ubmVjdGlvbiBtYW5hZ2VtZW50IGNsYXNzXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCBxcyBmcm9tICdxdWVyeXN0cmluZyc7XG5pbXBvcnQgQ29ubmVjdGlvbiwgeyBDb25uZWN0aW9uQ29uZmlnIH0gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgT0F1dGgyLCB7IFRva2VuUmVzcG9uc2UgfSBmcm9tICcuLi9vYXV0aDInO1xuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIHBvcHVwV2luKHVybDogc3RyaW5nLCB3OiBudW1iZXIsIGg6IG51bWJlcikge1xuICBjb25zdCBsZWZ0ID0gc2NyZWVuLndpZHRoIC8gMiAtIHcgLyAyO1xuICBjb25zdCB0b3AgPSBzY3JlZW4uaGVpZ2h0IC8gMiAtIGggLyAyO1xuICByZXR1cm4gd2luZG93Lm9wZW4oXG4gICAgdXJsLFxuICAgIHVuZGVmaW5lZCxcbiAgICBgbG9jYXRpb249eWVzLHRvb2xiYXI9bm8sc3RhdHVzPW5vLG1lbnViYXI9bm8sd2lkdGg9JHt3fSxoZWlnaHQ9JHtofSx0b3A9JHt0b3B9LGxlZnQ9JHtsZWZ0fWAsXG4gICk7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gaGFuZGxlQ2FsbGJhY2tSZXNwb25zZSgpIHtcbiAgY29uc3QgcmVzID0gY2hlY2tDYWxsYmFja1Jlc3BvbnNlKCk7XG4gIGNvbnN0IHN0YXRlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2pzZm9yY2Vfc3RhdGUnKTtcbiAgaWYgKHJlcyAmJiBzdGF0ZSAmJiByZXMuYm9keS5zdGF0ZSA9PT0gc3RhdGUpIHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnanNmb3JjZV9zdGF0ZScpO1xuICAgIGNvbnN0IFtwcmVmaXgsIHByb21wdFR5cGVdID0gc3RhdGUuc3BsaXQoJy4nKTtcbiAgICBjb25zdCBjbGkgPSBuZXcgQnJvd3NlckNsaWVudChwcmVmaXgpO1xuICAgIGlmIChyZXMuc3VjY2Vzcykge1xuICAgICAgY2xpLl9zdG9yZVRva2VucyhyZXMuYm9keSBhcyBUb2tlblJlc3BvbnNlKTtcbiAgICAgIGxvY2F0aW9uLmhhc2ggPSAnJztcbiAgICB9IGVsc2Uge1xuICAgICAgY2xpLl9zdG9yZUVycm9yKHJlcy5ib2R5KTtcbiAgICB9XG4gICAgaWYgKHByb21wdFR5cGUgPT09ICdwb3B1cCcpIHtcbiAgICAgIHdpbmRvdy5jbG9zZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIGNoZWNrQ2FsbGJhY2tSZXNwb25zZSgpIHtcbiAgbGV0IHBhcmFtcztcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5oYXNoKSB7XG4gICAgcGFyYW1zID0gcXMucGFyc2Uod2luZG93LmxvY2F0aW9uLmhhc2guc3Vic3RyaW5nKDEpKTtcbiAgICBpZiAocGFyYW1zLmFjY2Vzc190b2tlbikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgYm9keTogcGFyYW1zIH07XG4gICAgfVxuICB9IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpIHtcbiAgICBwYXJhbXMgPSBxcy5wYXJzZSh3aW5kb3cubG9jYXRpb24uc2VhcmNoLnN1YnN0cmluZygxKSk7XG4gICAgaWYgKHBhcmFtcy5lcnJvcikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGJvZHk6IHBhcmFtcyB9O1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIExvZ2luT3B0aW9ucyA9IHtcbiAgc2NvcGU/OiBzdHJpbmc7XG4gIHNpemU/OiB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH07XG59O1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IERFRkFVTFRfUE9QVVBfV0lOX1dJRFRIID0gOTEyO1xuY29uc3QgREVGQVVMVF9QT1BVUF9XSU5fSEVJR0hUID0gNTEzO1xuXG4vKiogQHByaXZhdGUgKiovXG5sZXQgY2xpZW50SWR4ID0gMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQnJvd3NlckNsaWVudCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIF9wcmVmaXg6IHN0cmluZztcbiAgX2NvbmZpZzogQ29ubmVjdGlvbkNvbmZpZyB8IHVuZGVmaW5lZDtcbiAgX2Nvbm5lY3Rpb246IENvbm5lY3Rpb24gfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihwcmVmaXg/OiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX3ByZWZpeCA9IHByZWZpeCB8fCAnanNmb3JjZScgKyBjbGllbnRJZHgrKztcbiAgfVxuXG4gIGdldCBjb25uZWN0aW9uKCk6IENvbm5lY3Rpb24ge1xuICAgIGlmICghdGhpcy5fY29ubmVjdGlvbikge1xuICAgICAgdGhpcy5fY29ubmVjdGlvbiA9IG5ldyBDb25uZWN0aW9uKHRoaXMuX2NvbmZpZyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9jb25uZWN0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBpbml0KGNvbmZpZzogQ29ubmVjdGlvbkNvbmZpZykge1xuICAgIGlmIChoYW5kbGVDYWxsYmFja1Jlc3BvbnNlKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fY29uZmlnID0gY29uZmlnO1xuICAgIGNvbnN0IHRva2VucyA9IHRoaXMuX2dldFRva2VucygpO1xuICAgIGlmICh0b2tlbnMpIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5fZXN0YWJsaXNoKHRva2Vucyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JywgdGhpcy5jb25uZWN0aW9uKTtcbiAgICAgIH0sIDEwKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGxvZ2luKG9wdGlvbnM6IExvZ2luT3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgeyBzY29wZSwgc2l6ZSB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBvYXV0aDIgPSBuZXcgT0F1dGgyKHRoaXMuX2NvbmZpZyA/PyB7fSk7XG4gICAgY29uc3QgcmFuZCA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyKTtcbiAgICBjb25zdCBzdGF0ZSA9IFt0aGlzLl9wcmVmaXgsICdwb3B1cCcsIHJhbmRdLmpvaW4oJy4nKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnanNmb3JjZV9zdGF0ZScsIHN0YXRlKTtcbiAgICBjb25zdCBhdXRoelVybCA9IG9hdXRoMi5nZXRBdXRob3JpemF0aW9uVXJsKHtcbiAgICAgIHJlc3BvbnNlX3R5cGU6ICd0b2tlbicsXG4gICAgICBzdGF0ZSxcbiAgICAgIC4uLihzY29wZSA/IHsgc2NvcGUgfSA6IHt9KSxcbiAgICB9KTtcbiAgICBjb25zdCBwdyA9IHBvcHVwV2luKFxuICAgICAgYXV0aHpVcmwsXG4gICAgICBzaXplPy53aWR0aCA/PyBERUZBVUxUX1BPUFVQX1dJTl9XSURUSCxcbiAgICAgIHNpemU/LmhlaWdodCA/PyBERUZBVUxUX1BPUFVQX1dJTl9IRUlHSFQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8eyBzdGF0dXM6IHN0cmluZyB9PigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBpZiAoIXB3KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gW3RoaXMuX3ByZWZpeCwgJ3JlZGlyZWN0JywgcmFuZF0uam9pbignLicpO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnanNmb3JjZV9zdGF0ZScsIHN0YXRlKTtcbiAgICAgICAgY29uc3QgYXV0aHpVcmwgPSBvYXV0aDIuZ2V0QXV0aG9yaXphdGlvblVybCh7XG4gICAgICAgICAgcmVzcG9uc2VfdHlwZTogJ3Rva2VuJyxcbiAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICAuLi4oc2NvcGUgPyB7IHNjb3BlIH0gOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBsb2NhdGlvbi5ocmVmID0gYXV0aHpVcmw7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3JlbW92ZVRva2VucygpO1xuICAgICAgY29uc3QgcGlkID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGlmICghcHcgfHwgcHcuY2xvc2VkKSB7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKHBpZCk7XG4gICAgICAgICAgICBjb25zdCB0b2tlbnMgPSB0aGlzLl9nZXRUb2tlbnMoKTtcbiAgICAgICAgICAgIGlmICh0b2tlbnMpIHtcbiAgICAgICAgICAgICAgdGhpcy5jb25uZWN0aW9uLl9lc3RhYmxpc2godG9rZW5zKTtcbiAgICAgICAgICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JywgdGhpcy5jb25uZWN0aW9uKTtcbiAgICAgICAgICAgICAgcmVzb2x2ZSh7IHN0YXR1czogJ2Nvbm5lY3QnIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc3QgZXJyID0gdGhpcy5fZ2V0RXJyb3IoKTtcbiAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXJyLmVycm9yICsgJzogJyArIGVyci5lcnJvcl9kZXNjcmlwdGlvbikpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmUoeyBzdGF0dXM6ICdjYW5jZWwnIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy9cbiAgICAgICAgfVxuICAgICAgfSwgMTAwMCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGlzTG9nZ2VkSW4oKSB7XG4gICAgcmV0dXJuICEhdGhpcy5jb25uZWN0aW9uLmFjY2Vzc1Rva2VuO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBsb2dvdXQoKSB7XG4gICAgdGhpcy5jb25uZWN0aW9uLmxvZ291dCgpO1xuICAgIHRoaXMuX3JlbW92ZVRva2VucygpO1xuICAgIHRoaXMuZW1pdCgnZGlzY29ubmVjdCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZ2V0VG9rZW5zKCkge1xuICAgIGNvbnN0IHJlZ2V4cCA9IG5ldyBSZWdFeHAoXG4gICAgICAnKF58O1xcXFxzKiknICsgdGhpcy5fcHJlZml4ICsgJ19sb2dnZWRpbj10cnVlKDt8JCknLFxuICAgICk7XG4gICAgaWYgKGRvY3VtZW50LmNvb2tpZS5tYXRjaChyZWdleHApKSB7XG4gICAgICBjb25zdCBpc3N1ZWRBdCA9IE51bWJlcihcbiAgICAgICAgbG9jYWxTdG9yYWdlLmdldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pc3N1ZWRfYXQnKSxcbiAgICAgICk7XG4gICAgICAvLyAyIGhvdXJzXG4gICAgICBpZiAoRGF0ZS5ub3coKSA8IGlzc3VlZEF0ICsgMiAqIDYwICogNjAgKiAxMDAwKSB7XG4gICAgICAgIGxldCB1c2VySW5mbztcbiAgICAgICAgY29uc3QgaWRVcmwgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2lkJyk7XG4gICAgICAgIGlmIChpZFVybCkge1xuICAgICAgICAgIGNvbnN0IFtpZCwgb3JnYW5pemF0aW9uSWRdID0gaWRVcmwuc3BsaXQoJy8nKS5yZXZlcnNlKCk7XG4gICAgICAgICAgdXNlckluZm8gPSB7IGlkLCBvcmdhbml6YXRpb25JZCwgdXJsOiBpZFVybCB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgYWNjZXNzVG9rZW46IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfYWNjZXNzX3Rva2VuJyksXG4gICAgICAgICAgaW5zdGFuY2VVcmw6IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaW5zdGFuY2VfdXJsJyksXG4gICAgICAgICAgdXNlckluZm8sXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfc3RvcmVUb2tlbnMocGFyYW1zOiBUb2tlblJlc3BvbnNlKSB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nLCBwYXJhbXMuYWNjZXNzX3Rva2VuKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2luc3RhbmNlX3VybCcsIHBhcmFtcy5pbnN0YW5jZV91cmwpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaXNzdWVkX2F0JywgcGFyYW1zLmlzc3VlZF9hdCk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pZCcsIHBhcmFtcy5pZCk7XG4gICAgZG9jdW1lbnQuY29va2llID0gdGhpcy5fcHJlZml4ICsgJ19sb2dnZWRpbj10cnVlOyc7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZW1vdmVUb2tlbnMoKSB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSh0aGlzLl9wcmVmaXggKyAnX2luc3RhbmNlX3VybCcpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKHRoaXMuX3ByZWZpeCArICdfaXNzdWVkX2F0Jyk7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19pZCcpO1xuICAgIGRvY3VtZW50LmNvb2tpZSA9IHRoaXMuX3ByZWZpeCArICdfbG9nZ2VkaW49JztcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2dldEVycm9yKCkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlcnIgPSBKU09OLnBhcnNlKFxuICAgICAgICBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJykgPz8gJycsXG4gICAgICApO1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19lcnJvcicpO1xuICAgICAgcmV0dXJuIGVycjtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvL1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N0b3JlRXJyb3IoZXJyOiBhbnkpIHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJywgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5jb25zdCBjbGllbnQgPSBuZXcgQnJvd3NlckNsaWVudCgpO1xuXG5leHBvcnQgZGVmYXVsdCBjbGllbnQ7XG4iXX0=