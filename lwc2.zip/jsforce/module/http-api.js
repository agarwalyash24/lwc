import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 *
 */
import { EventEmitter } from 'events';
import xml2js from 'xml2js';
import { getLogger } from './util/logger';
import { StreamPromise } from './util/promise';
import { parseCSV } from './csv';
import { createLazyStream } from './util/stream';
/** @private */

function parseJSON(str) {
  return JSON.parse(str);
}
/** @private */


async function parseXML(str) {
  return xml2js.parseStringPromise(str, {
    explicitArray: false
  });
}
/** @private */


function parseText(str) {
  return str;
}
/**
 * HTTP based API class with authorization hook
 */


export class HttpApi extends EventEmitter {
  constructor(conn, options) {
    super();

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "_transport", void 0);

    _defineProperty(this, "_responseType", void 0);

    _defineProperty(this, "_noContentResponse", void 0);

    this._conn = conn;
    this._logger = conn._logLevel ? HttpApi._logger.createInstance(conn._logLevel) : HttpApi._logger;
    this._responseType = options.responseType;
    this._transport = options.transport || conn._transport;
    this._noContentResponse = options.noContentResponse;
  }
  /**
   * Callout to API endpoint using http
   */


  request(request) {
    return StreamPromise.create(() => {
      const {
        stream,
        setStream
      } = createLazyStream();

      const promise = (async () => {
        const refreshDelegate = this.getRefreshDelegate();
        /* TODO decide remove or not this section */

        /*
        // remember previous instance url in case it changes after a refresh
        const lastInstanceUrl = conn.instanceUrl;
         // check to see if the token refresh has changed the instance url
        if(lastInstanceUrl !== conn.instanceUrl){
          // if the instance url has changed
          // then replace the current request urls instance url fragment
          // with the updated instance url
          request.url = request.url.replace(lastInstanceUrl,conn.instanceUrl);
        }
        */

        if (refreshDelegate && refreshDelegate.isRefreshing()) {
          await refreshDelegate.waitRefresh();
          const bodyPromise = this.request(request);
          setStream(bodyPromise.stream());
          const body = await bodyPromise;
          return body;
        } // hook before sending


        this.beforeSend(request);
        this.emit('request', request);

        this._logger.debug(`<request> method=${request.method}, url=${request.url}`);

        const requestTime = _Date$now();

        const requestPromise = this._transport.httpRequest(request);

        setStream(requestPromise.stream());
        let response;

        try {
          response = await requestPromise;
        } catch (err) {
          this._logger.error(err);

          throw err;
        } finally {
          const responseTime = _Date$now();

          this._logger.debug(`elapsed time: ${responseTime - requestTime} msec`);
        }

        if (!response) {
          return;
        }

        this._logger.debug(`<response> status=${String(response.statusCode)}, url=${request.url}`);

        this.emit('response', response); // Refresh token if session has been expired and requires authentication
        // when session refresh delegate is available

        if (this.isSessionExpired(response) && refreshDelegate) {
          await refreshDelegate.refresh(requestTime);
          return this.request(request);
        }

        if (this.isErrorResponse(response)) {
          const err = await this.getError(response);
          throw err;
        }

        const body = await this.getResponseBody(response);
        return body;
      })();

      return {
        stream,
        promise
      };
    });
  }
  /**
   * @protected
   */


  getRefreshDelegate() {
    return this._conn._refreshDelegate;
  }
  /**
   * @protected
   */


  beforeSend(request) {
    /* eslint-disable no-param-reassign */
    const headers = request.headers || {};

    if (this._conn.accessToken) {
      headers.Authorization = `Bearer ${this._conn.accessToken}`;
    }

    if (this._conn._callOptions) {
      const callOptions = [];

      for (const name of _Object$keys(this._conn._callOptions)) {
        callOptions.push(`${name}=${this._conn._callOptions[name]}`);
      }

      headers['Sforce-Call-Options'] = callOptions.join(', ');
    }

    request.headers = headers;
  }
  /**
   * Detect response content mime-type
   * @protected
   */


  getResponseContentType(response) {
    return this._responseType || response.headers && response.headers['content-type'];
  }
  /**
   * @private
   */


  async parseResponseBody(response) {
    const contentType = this.getResponseContentType(response) || '';
    const parseBody = /^(text|application)\/xml(;|$)/.test(contentType) ? parseXML : /^application\/json(;|$)/.test(contentType) ? parseJSON : /^text\/csv(;|$)/.test(contentType) ? parseCSV : parseText;

    try {
      return parseBody(response.body);
    } catch (e) {
      return response.body;
    }
  }
  /**
   * Get response body
   * @protected
   */


  async getResponseBody(response) {
    if (response.statusCode === 204) {
      // No Content
      return this._noContentResponse;
    }

    const body = await this.parseResponseBody(response);
    let err;

    if (this.hasErrorInResponseBody(body)) {
      err = await this.getError(response, body);
      throw err;
    }

    if (response.statusCode === 300) {
      // Multiple Choices
      throw new HttpApiError('Multiple records found', 'MULTIPLE_CHOICES', body);
    }

    return body;
  }
  /**
   * Detect session expiry
   * @protected
   */


  isSessionExpired(response) {
    return response.statusCode === 401;
  }
  /**
   * Detect error response
   * @protected
   */


  isErrorResponse(response) {
    return response.statusCode >= 400;
  }
  /**
   * Detect error in response body
   * @protected
   */


  hasErrorInResponseBody(_body) {
    return false;
  }
  /**
   * Parsing error message in response
   * @protected
   */


  parseError(body) {
    const errors = body;
    return _Array$isArray(errors) ? errors[0] : errors;
  }
  /**
   * Get error message in response
   * @protected
   */


  async getError(response, body) {
    let error;

    try {
      error = this.parseError(body || (await this.parseResponseBody(response)));
    } catch (e) {// eslint-disable no-empty
    }

    error = typeof error === 'object' && error !== null && typeof error.message === 'string' ? error : {
      errorCode: `ERROR_HTTP_${response.statusCode}`,
      message: response.body
    };
    return new HttpApiError(error.message, error.errorCode);
  }

}
/**
 *
 */

_defineProperty(HttpApi, "_logger", getLogger('http-api'));

class HttpApiError extends Error {
  constructor(message, errorCode, content) {
    super(message);

    _defineProperty(this, "errorCode", void 0);

    _defineProperty(this, "content", void 0);

    this.name = errorCode || this.name;
    this.errorCode = this.name;
    this.content = content;
  }

}

export default HttpApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9odHRwLWFwaS50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJ4bWwyanMiLCJnZXRMb2dnZXIiLCJTdHJlYW1Qcm9taXNlIiwicGFyc2VDU1YiLCJjcmVhdGVMYXp5U3RyZWFtIiwicGFyc2VKU09OIiwic3RyIiwiSlNPTiIsInBhcnNlIiwicGFyc2VYTUwiLCJwYXJzZVN0cmluZ1Byb21pc2UiLCJleHBsaWNpdEFycmF5IiwicGFyc2VUZXh0IiwiSHR0cEFwaSIsImNvbnN0cnVjdG9yIiwiY29ubiIsIm9wdGlvbnMiLCJfY29ubiIsIl9sb2dnZXIiLCJfbG9nTGV2ZWwiLCJjcmVhdGVJbnN0YW5jZSIsIl9yZXNwb25zZVR5cGUiLCJyZXNwb25zZVR5cGUiLCJfdHJhbnNwb3J0IiwidHJhbnNwb3J0IiwiX25vQ29udGVudFJlc3BvbnNlIiwibm9Db250ZW50UmVzcG9uc2UiLCJyZXF1ZXN0IiwiY3JlYXRlIiwic3RyZWFtIiwic2V0U3RyZWFtIiwicHJvbWlzZSIsInJlZnJlc2hEZWxlZ2F0ZSIsImdldFJlZnJlc2hEZWxlZ2F0ZSIsImlzUmVmcmVzaGluZyIsIndhaXRSZWZyZXNoIiwiYm9keVByb21pc2UiLCJib2R5IiwiYmVmb3JlU2VuZCIsImVtaXQiLCJkZWJ1ZyIsIm1ldGhvZCIsInVybCIsInJlcXVlc3RUaW1lIiwicmVxdWVzdFByb21pc2UiLCJodHRwUmVxdWVzdCIsInJlc3BvbnNlIiwiZXJyIiwiZXJyb3IiLCJyZXNwb25zZVRpbWUiLCJTdHJpbmciLCJzdGF0dXNDb2RlIiwiaXNTZXNzaW9uRXhwaXJlZCIsInJlZnJlc2giLCJpc0Vycm9yUmVzcG9uc2UiLCJnZXRFcnJvciIsImdldFJlc3BvbnNlQm9keSIsIl9yZWZyZXNoRGVsZWdhdGUiLCJoZWFkZXJzIiwiYWNjZXNzVG9rZW4iLCJBdXRob3JpemF0aW9uIiwiX2NhbGxPcHRpb25zIiwiY2FsbE9wdGlvbnMiLCJuYW1lIiwicHVzaCIsImpvaW4iLCJnZXRSZXNwb25zZUNvbnRlbnRUeXBlIiwicGFyc2VSZXNwb25zZUJvZHkiLCJjb250ZW50VHlwZSIsInBhcnNlQm9keSIsInRlc3QiLCJlIiwiaGFzRXJyb3JJblJlc3BvbnNlQm9keSIsIkh0dHBBcGlFcnJvciIsIl9ib2R5IiwicGFyc2VFcnJvciIsImVycm9ycyIsIm1lc3NhZ2UiLCJlcnJvckNvZGUiLCJFcnJvciIsImNvbnRlbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixRQUFuQjtBQUNBLFNBQWlCQyxTQUFqQixRQUFrQyxlQUFsQztBQUNBLFNBQVNDLGFBQVQsUUFBOEIsZ0JBQTlCO0FBR0EsU0FBU0MsUUFBVCxRQUF5QixPQUF6QjtBQUVBLFNBQVNDLGdCQUFULFFBQWlDLGVBQWpDO0FBRUE7O0FBQ0EsU0FBU0MsU0FBVCxDQUFtQkMsR0FBbkIsRUFBZ0M7QUFDOUIsU0FBT0MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLEdBQVgsQ0FBUDtBQUNEO0FBRUQ7OztBQUNBLGVBQWVHLFFBQWYsQ0FBd0JILEdBQXhCLEVBQXFDO0FBQ25DLFNBQU9OLE1BQU0sQ0FBQ1Usa0JBQVAsQ0FBMEJKLEdBQTFCLEVBQStCO0FBQUVLLElBQUFBLGFBQWEsRUFBRTtBQUFqQixHQUEvQixDQUFQO0FBQ0Q7QUFFRDs7O0FBQ0EsU0FBU0MsU0FBVCxDQUFtQk4sR0FBbkIsRUFBZ0M7QUFDOUIsU0FBT0EsR0FBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxPQUFPLE1BQU1PLE9BQU4sU0FBd0NkLFlBQXhDLENBQXFEO0FBUzFEZSxFQUFBQSxXQUFXLENBQUNDLElBQUQsRUFBc0JDLE9BQXRCLEVBQW9DO0FBQzdDOztBQUQ2Qzs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFFN0MsU0FBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0EsU0FBS0csT0FBTCxHQUFlSCxJQUFJLENBQUNJLFNBQUwsR0FDWE4sT0FBTyxDQUFDSyxPQUFSLENBQWdCRSxjQUFoQixDQUErQkwsSUFBSSxDQUFDSSxTQUFwQyxDQURXLEdBRVhOLE9BQU8sQ0FBQ0ssT0FGWjtBQUdBLFNBQUtHLGFBQUwsR0FBcUJMLE9BQU8sQ0FBQ00sWUFBN0I7QUFDQSxTQUFLQyxVQUFMLEdBQWtCUCxPQUFPLENBQUNRLFNBQVIsSUFBcUJULElBQUksQ0FBQ1EsVUFBNUM7QUFDQSxTQUFLRSxrQkFBTCxHQUEwQlQsT0FBTyxDQUFDVSxpQkFBbEM7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VDLEVBQUFBLE9BQU8sQ0FBY0EsT0FBZCxFQUFzRDtBQUMzRCxXQUFPekIsYUFBYSxDQUFDMEIsTUFBZCxDQUF3QixNQUFNO0FBQ25DLFlBQU07QUFBRUMsUUFBQUEsTUFBRjtBQUFVQyxRQUFBQTtBQUFWLFVBQXdCMUIsZ0JBQWdCLEVBQTlDOztBQUNBLFlBQU0yQixPQUFPLEdBQUcsQ0FBQyxZQUFZO0FBQzNCLGNBQU1DLGVBQWUsR0FBRyxLQUFLQyxrQkFBTCxFQUF4QjtBQUNBOztBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRVEsWUFBSUQsZUFBZSxJQUFJQSxlQUFlLENBQUNFLFlBQWhCLEVBQXZCLEVBQXVEO0FBQ3JELGdCQUFNRixlQUFlLENBQUNHLFdBQWhCLEVBQU47QUFDQSxnQkFBTUMsV0FBVyxHQUFHLEtBQUtULE9BQUwsQ0FBYUEsT0FBYixDQUFwQjtBQUNBRyxVQUFBQSxTQUFTLENBQUNNLFdBQVcsQ0FBQ1AsTUFBWixFQUFELENBQVQ7QUFDQSxnQkFBTVEsSUFBSSxHQUFHLE1BQU1ELFdBQW5CO0FBQ0EsaUJBQU9DLElBQVA7QUFDRCxTQXJCMEIsQ0F1QjNCOzs7QUFDQSxhQUFLQyxVQUFMLENBQWdCWCxPQUFoQjtBQUVBLGFBQUtZLElBQUwsQ0FBVSxTQUFWLEVBQXFCWixPQUFyQjs7QUFDQSxhQUFLVCxPQUFMLENBQWFzQixLQUFiLENBQ0csb0JBQW1CYixPQUFPLENBQUNjLE1BQU8sU0FBUWQsT0FBTyxDQUFDZSxHQUFJLEVBRHpEOztBQUdBLGNBQU1DLFdBQVcsR0FBRyxXQUFwQjs7QUFDQSxjQUFNQyxjQUFjLEdBQUcsS0FBS3JCLFVBQUwsQ0FBZ0JzQixXQUFoQixDQUE0QmxCLE9BQTVCLENBQXZCOztBQUVBRyxRQUFBQSxTQUFTLENBQUNjLGNBQWMsQ0FBQ2YsTUFBZixFQUFELENBQVQ7QUFFQSxZQUFJaUIsUUFBSjs7QUFDQSxZQUFJO0FBQ0ZBLFVBQUFBLFFBQVEsR0FBRyxNQUFNRixjQUFqQjtBQUNELFNBRkQsQ0FFRSxPQUFPRyxHQUFQLEVBQVk7QUFDWixlQUFLN0IsT0FBTCxDQUFhOEIsS0FBYixDQUFtQkQsR0FBbkI7O0FBQ0EsZ0JBQU1BLEdBQU47QUFDRCxTQUxELFNBS1U7QUFDUixnQkFBTUUsWUFBWSxHQUFHLFdBQXJCOztBQUNBLGVBQUsvQixPQUFMLENBQWFzQixLQUFiLENBQ0csaUJBQWdCUyxZQUFZLEdBQUdOLFdBQVksT0FEOUM7QUFHRDs7QUFDRCxZQUFJLENBQUNHLFFBQUwsRUFBZTtBQUNiO0FBQ0Q7O0FBQ0QsYUFBSzVCLE9BQUwsQ0FBYXNCLEtBQWIsQ0FDRyxxQkFBb0JVLE1BQU0sQ0FBQ0osUUFBUSxDQUFDSyxVQUFWLENBQXNCLFNBQy9DeEIsT0FBTyxDQUFDZSxHQUNULEVBSEg7O0FBS0EsYUFBS0gsSUFBTCxDQUFVLFVBQVYsRUFBc0JPLFFBQXRCLEVBdkQyQixDQXdEM0I7QUFDQTs7QUFDQSxZQUFJLEtBQUtNLGdCQUFMLENBQXNCTixRQUF0QixLQUFtQ2QsZUFBdkMsRUFBd0Q7QUFDdEQsZ0JBQU1BLGVBQWUsQ0FBQ3FCLE9BQWhCLENBQXdCVixXQUF4QixDQUFOO0FBQ0EsaUJBQU8sS0FBS2hCLE9BQUwsQ0FBYUEsT0FBYixDQUFQO0FBQ0Q7O0FBQ0QsWUFBSSxLQUFLMkIsZUFBTCxDQUFxQlIsUUFBckIsQ0FBSixFQUFvQztBQUNsQyxnQkFBTUMsR0FBRyxHQUFHLE1BQU0sS0FBS1EsUUFBTCxDQUFjVCxRQUFkLENBQWxCO0FBQ0EsZ0JBQU1DLEdBQU47QUFDRDs7QUFDRCxjQUFNVixJQUFJLEdBQUcsTUFBTSxLQUFLbUIsZUFBTCxDQUFxQlYsUUFBckIsQ0FBbkI7QUFDQSxlQUFPVCxJQUFQO0FBQ0QsT0FwRWUsR0FBaEI7O0FBcUVBLGFBQU87QUFBRVIsUUFBQUEsTUFBRjtBQUFVRSxRQUFBQTtBQUFWLE9BQVA7QUFDRCxLQXhFTSxDQUFQO0FBeUVEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUUsRUFBQUEsa0JBQWtCLEdBQUc7QUFDbkIsV0FBTyxLQUFLaEIsS0FBTCxDQUFXd0MsZ0JBQWxCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFbkIsRUFBQUEsVUFBVSxDQUFDWCxPQUFELEVBQXVCO0FBQy9CO0FBQ0EsVUFBTStCLE9BQU8sR0FBRy9CLE9BQU8sQ0FBQytCLE9BQVIsSUFBbUIsRUFBbkM7O0FBQ0EsUUFBSSxLQUFLekMsS0FBTCxDQUFXMEMsV0FBZixFQUE0QjtBQUMxQkQsTUFBQUEsT0FBTyxDQUFDRSxhQUFSLEdBQXlCLFVBQVMsS0FBSzNDLEtBQUwsQ0FBVzBDLFdBQVksRUFBekQ7QUFDRDs7QUFDRCxRQUFJLEtBQUsxQyxLQUFMLENBQVc0QyxZQUFmLEVBQTZCO0FBQzNCLFlBQU1DLFdBQVcsR0FBRyxFQUFwQjs7QUFDQSxXQUFLLE1BQU1DLElBQVgsSUFBbUIsYUFBWSxLQUFLOUMsS0FBTCxDQUFXNEMsWUFBdkIsQ0FBbkIsRUFBeUQ7QUFDdkRDLFFBQUFBLFdBQVcsQ0FBQ0UsSUFBWixDQUFrQixHQUFFRCxJQUFLLElBQUcsS0FBSzlDLEtBQUwsQ0FBVzRDLFlBQVgsQ0FBd0JFLElBQXhCLENBQThCLEVBQTFEO0FBQ0Q7O0FBQ0RMLE1BQUFBLE9BQU8sQ0FBQyxxQkFBRCxDQUFQLEdBQWlDSSxXQUFXLENBQUNHLElBQVosQ0FBaUIsSUFBakIsQ0FBakM7QUFDRDs7QUFDRHRDLElBQUFBLE9BQU8sQ0FBQytCLE9BQVIsR0FBa0JBLE9BQWxCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VRLEVBQUFBLHNCQUFzQixDQUFDcEIsUUFBRCxFQUEyQztBQUMvRCxXQUNFLEtBQUt6QixhQUFMLElBQ0N5QixRQUFRLENBQUNZLE9BQVQsSUFBb0JaLFFBQVEsQ0FBQ1ksT0FBVCxDQUFpQixjQUFqQixDQUZ2QjtBQUlEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNUyxpQkFBTixDQUF3QnJCLFFBQXhCLEVBQWdEO0FBQzlDLFVBQU1zQixXQUFXLEdBQUcsS0FBS0Ysc0JBQUwsQ0FBNEJwQixRQUE1QixLQUF5QyxFQUE3RDtBQUNBLFVBQU11QixTQUFTLEdBQUcsZ0NBQWdDQyxJQUFoQyxDQUFxQ0YsV0FBckMsSUFDZDNELFFBRGMsR0FFZCwwQkFBMEI2RCxJQUExQixDQUErQkYsV0FBL0IsSUFDQS9ELFNBREEsR0FFQSxrQkFBa0JpRSxJQUFsQixDQUF1QkYsV0FBdkIsSUFDQWpFLFFBREEsR0FFQVMsU0FOSjs7QUFPQSxRQUFJO0FBQ0YsYUFBT3lELFNBQVMsQ0FBQ3ZCLFFBQVEsQ0FBQ1QsSUFBVixDQUFoQjtBQUNELEtBRkQsQ0FFRSxPQUFPa0MsQ0FBUCxFQUFVO0FBQ1YsYUFBT3pCLFFBQVEsQ0FBQ1QsSUFBaEI7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFLFFBQU1tQixlQUFOLENBQXNCVixRQUF0QixFQUE4QztBQUM1QyxRQUFJQSxRQUFRLENBQUNLLFVBQVQsS0FBd0IsR0FBNUIsRUFBaUM7QUFDL0I7QUFDQSxhQUFPLEtBQUsxQixrQkFBWjtBQUNEOztBQUNELFVBQU1ZLElBQUksR0FBRyxNQUFNLEtBQUs4QixpQkFBTCxDQUF1QnJCLFFBQXZCLENBQW5CO0FBQ0EsUUFBSUMsR0FBSjs7QUFDQSxRQUFJLEtBQUt5QixzQkFBTCxDQUE0Qm5DLElBQTVCLENBQUosRUFBdUM7QUFDckNVLE1BQUFBLEdBQUcsR0FBRyxNQUFNLEtBQUtRLFFBQUwsQ0FBY1QsUUFBZCxFQUF3QlQsSUFBeEIsQ0FBWjtBQUNBLFlBQU1VLEdBQU47QUFDRDs7QUFDRCxRQUFJRCxRQUFRLENBQUNLLFVBQVQsS0FBd0IsR0FBNUIsRUFBaUM7QUFDL0I7QUFDQSxZQUFNLElBQUlzQixZQUFKLENBQ0osd0JBREksRUFFSixrQkFGSSxFQUdKcEMsSUFISSxDQUFOO0FBS0Q7O0FBQ0QsV0FBT0EsSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFZSxFQUFBQSxnQkFBZ0IsQ0FBQ04sUUFBRCxFQUF5QjtBQUN2QyxXQUFPQSxRQUFRLENBQUNLLFVBQVQsS0FBd0IsR0FBL0I7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRUcsRUFBQUEsZUFBZSxDQUFDUixRQUFELEVBQXlCO0FBQ3RDLFdBQU9BLFFBQVEsQ0FBQ0ssVUFBVCxJQUF1QixHQUE5QjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFcUIsRUFBQUEsc0JBQXNCLENBQUNFLEtBQUQsRUFBMEI7QUFDOUMsV0FBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VDLEVBQUFBLFVBQVUsQ0FBQ3RDLElBQUQsRUFBWTtBQUNwQixVQUFNdUMsTUFBTSxHQUFHdkMsSUFBZjtBQUNBLFdBQU8sZUFBY3VDLE1BQWQsSUFBd0JBLE1BQU0sQ0FBQyxDQUFELENBQTlCLEdBQW9DQSxNQUEzQztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFLFFBQU1yQixRQUFOLENBQWVULFFBQWYsRUFBdUNULElBQXZDLEVBQW1FO0FBQ2pFLFFBQUlXLEtBQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxLQUFLLEdBQUcsS0FBSzJCLFVBQUwsQ0FBZ0J0QyxJQUFJLEtBQUssTUFBTSxLQUFLOEIsaUJBQUwsQ0FBdUJyQixRQUF2QixDQUFYLENBQXBCLENBQVI7QUFDRCxLQUZELENBRUUsT0FBT3lCLENBQVAsRUFBVSxDQUNWO0FBQ0Q7O0FBQ0R2QixJQUFBQSxLQUFLLEdBQ0gsT0FBT0EsS0FBUCxLQUFpQixRQUFqQixJQUNBQSxLQUFLLEtBQUssSUFEVixJQUVBLE9BQU9BLEtBQUssQ0FBQzZCLE9BQWIsS0FBeUIsUUFGekIsR0FHSTdCLEtBSEosR0FJSTtBQUNFOEIsTUFBQUEsU0FBUyxFQUFHLGNBQWFoQyxRQUFRLENBQUNLLFVBQVcsRUFEL0M7QUFFRTBCLE1BQUFBLE9BQU8sRUFBRS9CLFFBQVEsQ0FBQ1Q7QUFGcEIsS0FMTjtBQVNBLFdBQU8sSUFBSW9DLFlBQUosQ0FBaUJ6QixLQUFLLENBQUM2QixPQUF2QixFQUFnQzdCLEtBQUssQ0FBQzhCLFNBQXRDLENBQVA7QUFDRDs7QUEzT3lEO0FBOE81RDtBQUNBO0FBQ0E7O2dCQWhQYWpFLE8sYUFDTVosU0FBUyxDQUFDLFVBQUQsQzs7QUFnUDVCLE1BQU13RSxZQUFOLFNBQTJCTSxLQUEzQixDQUFpQztBQUcvQmpFLEVBQUFBLFdBQVcsQ0FBQytELE9BQUQsRUFBa0JDLFNBQWxCLEVBQWtERSxPQUFsRCxFQUFpRTtBQUMxRSxVQUFNSCxPQUFOOztBQUQwRTs7QUFBQTs7QUFFMUUsU0FBS2QsSUFBTCxHQUFZZSxTQUFTLElBQUksS0FBS2YsSUFBOUI7QUFDQSxTQUFLZSxTQUFMLEdBQWlCLEtBQUtmLElBQXRCO0FBQ0EsU0FBS2lCLE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQVI4Qjs7QUFXakMsZUFBZW5FLE9BQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgeG1sMmpzIGZyb20gJ3htbDJqcyc7XG5pbXBvcnQgeyBMb2dnZXIsIGdldExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgU3RyZWFtUHJvbWlzZSB9IGZyb20gJy4vdXRpbC9wcm9taXNlJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4vY29ubmVjdGlvbic7XG5pbXBvcnQgVHJhbnNwb3J0IGZyb20gJy4vdHJhbnNwb3J0JztcbmltcG9ydCB7IHBhcnNlQ1NWIH0gZnJvbSAnLi9jc3YnO1xuaW1wb3J0IHsgSHR0cFJlcXVlc3QsIEh0dHBSZXNwb25zZSwgT3B0aW9uYWwsIFNjaGVtYSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgY3JlYXRlTGF6eVN0cmVhbSB9IGZyb20gJy4vdXRpbC9zdHJlYW0nO1xuXG4vKiogQHByaXZhdGUgKi9cbmZ1bmN0aW9uIHBhcnNlSlNPTihzdHI6IHN0cmluZykge1xuICByZXR1cm4gSlNPTi5wYXJzZShzdHIpO1xufVxuXG4vKiogQHByaXZhdGUgKi9cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlWE1MKHN0cjogc3RyaW5nKSB7XG4gIHJldHVybiB4bWwyanMucGFyc2VTdHJpbmdQcm9taXNlKHN0ciwgeyBleHBsaWNpdEFycmF5OiBmYWxzZSB9KTtcbn1cblxuLyoqIEBwcml2YXRlICovXG5mdW5jdGlvbiBwYXJzZVRleHQoc3RyOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHN0cjtcbn1cblxuLyoqXG4gKiBIVFRQIGJhc2VkIEFQSSBjbGFzcyB3aXRoIGF1dGhvcml6YXRpb24gaG9va1xuICovXG5leHBvcnQgY2xhc3MgSHR0cEFwaTxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHN0YXRpYyBfbG9nZ2VyID0gZ2V0TG9nZ2VyKCdodHRwLWFwaScpO1xuXG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBfbG9nZ2VyOiBMb2dnZXI7XG4gIF90cmFuc3BvcnQ6IFRyYW5zcG9ydDtcbiAgX3Jlc3BvbnNlVHlwZTogc3RyaW5nIHwgdm9pZDtcbiAgX25vQ29udGVudFJlc3BvbnNlOiBzdHJpbmcgfCB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb248Uz4sIG9wdGlvbnM6IGFueSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5fbG9nZ2VyID0gY29ubi5fbG9nTGV2ZWxcbiAgICAgID8gSHR0cEFwaS5fbG9nZ2VyLmNyZWF0ZUluc3RhbmNlKGNvbm4uX2xvZ0xldmVsKVxuICAgICAgOiBIdHRwQXBpLl9sb2dnZXI7XG4gICAgdGhpcy5fcmVzcG9uc2VUeXBlID0gb3B0aW9ucy5yZXNwb25zZVR5cGU7XG4gICAgdGhpcy5fdHJhbnNwb3J0ID0gb3B0aW9ucy50cmFuc3BvcnQgfHwgY29ubi5fdHJhbnNwb3J0O1xuICAgIHRoaXMuX25vQ29udGVudFJlc3BvbnNlID0gb3B0aW9ucy5ub0NvbnRlbnRSZXNwb25zZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsb3V0IHRvIEFQSSBlbmRwb2ludCB1c2luZyBodHRwXG4gICAqL1xuICByZXF1ZXN0PFIgPSB1bmtub3duPihyZXF1ZXN0OiBIdHRwUmVxdWVzdCk6IFN0cmVhbVByb21pc2U8Uj4ge1xuICAgIHJldHVybiBTdHJlYW1Qcm9taXNlLmNyZWF0ZTxSPigoKSA9PiB7XG4gICAgICBjb25zdCB7IHN0cmVhbSwgc2V0U3RyZWFtIH0gPSBjcmVhdGVMYXp5U3RyZWFtKCk7XG4gICAgICBjb25zdCBwcm9taXNlID0gKGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVmcmVzaERlbGVnYXRlID0gdGhpcy5nZXRSZWZyZXNoRGVsZWdhdGUoKTtcbiAgICAgICAgLyogVE9ETyBkZWNpZGUgcmVtb3ZlIG9yIG5vdCB0aGlzIHNlY3Rpb24gKi9cbiAgICAgICAgLypcbiAgICAgICAgLy8gcmVtZW1iZXIgcHJldmlvdXMgaW5zdGFuY2UgdXJsIGluIGNhc2UgaXQgY2hhbmdlcyBhZnRlciBhIHJlZnJlc2hcbiAgICAgICAgY29uc3QgbGFzdEluc3RhbmNlVXJsID0gY29ubi5pbnN0YW5jZVVybDtcblxuICAgICAgICAvLyBjaGVjayB0byBzZWUgaWYgdGhlIHRva2VuIHJlZnJlc2ggaGFzIGNoYW5nZWQgdGhlIGluc3RhbmNlIHVybFxuICAgICAgICBpZihsYXN0SW5zdGFuY2VVcmwgIT09IGNvbm4uaW5zdGFuY2VVcmwpe1xuICAgICAgICAgIC8vIGlmIHRoZSBpbnN0YW5jZSB1cmwgaGFzIGNoYW5nZWRcbiAgICAgICAgICAvLyB0aGVuIHJlcGxhY2UgdGhlIGN1cnJlbnQgcmVxdWVzdCB1cmxzIGluc3RhbmNlIHVybCBmcmFnbWVudFxuICAgICAgICAgIC8vIHdpdGggdGhlIHVwZGF0ZWQgaW5zdGFuY2UgdXJsXG4gICAgICAgICAgcmVxdWVzdC51cmwgPSByZXF1ZXN0LnVybC5yZXBsYWNlKGxhc3RJbnN0YW5jZVVybCxjb25uLmluc3RhbmNlVXJsKTtcbiAgICAgICAgfVxuICAgICAgICAqL1xuICAgICAgICBpZiAocmVmcmVzaERlbGVnYXRlICYmIHJlZnJlc2hEZWxlZ2F0ZS5pc1JlZnJlc2hpbmcoKSkge1xuICAgICAgICAgIGF3YWl0IHJlZnJlc2hEZWxlZ2F0ZS53YWl0UmVmcmVzaCgpO1xuICAgICAgICAgIGNvbnN0IGJvZHlQcm9taXNlID0gdGhpcy5yZXF1ZXN0KHJlcXVlc3QpO1xuICAgICAgICAgIHNldFN0cmVhbShib2R5UHJvbWlzZS5zdHJlYW0oKSk7XG4gICAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IGJvZHlQcm9taXNlO1xuICAgICAgICAgIHJldHVybiBib2R5O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gaG9vayBiZWZvcmUgc2VuZGluZ1xuICAgICAgICB0aGlzLmJlZm9yZVNlbmQocmVxdWVzdCk7XG5cbiAgICAgICAgdGhpcy5lbWl0KCdyZXF1ZXN0JywgcmVxdWVzdCk7XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgICBgPHJlcXVlc3Q+IG1ldGhvZD0ke3JlcXVlc3QubWV0aG9kfSwgdXJsPSR7cmVxdWVzdC51cmx9YCxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCByZXF1ZXN0UHJvbWlzZSA9IHRoaXMuX3RyYW5zcG9ydC5odHRwUmVxdWVzdChyZXF1ZXN0KTtcblxuICAgICAgICBzZXRTdHJlYW0ocmVxdWVzdFByb21pc2Uuc3RyZWFtKCkpO1xuXG4gICAgICAgIGxldCByZXNwb25zZTogSHR0cFJlc3BvbnNlIHwgdm9pZDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IHJlcXVlc3RQcm9taXNlO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICB0aGlzLl9sb2dnZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgY29uc3QgcmVzcG9uc2VUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoXG4gICAgICAgICAgICBgZWxhcHNlZCB0aW1lOiAke3Jlc3BvbnNlVGltZSAtIHJlcXVlc3RUaW1lfSBtc2VjYCxcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmICghcmVzcG9uc2UpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgICAgIGA8cmVzcG9uc2U+IHN0YXR1cz0ke1N0cmluZyhyZXNwb25zZS5zdGF0dXNDb2RlKX0sIHVybD0ke1xuICAgICAgICAgICAgcmVxdWVzdC51cmxcbiAgICAgICAgICB9YCxcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgICAgICAgLy8gUmVmcmVzaCB0b2tlbiBpZiBzZXNzaW9uIGhhcyBiZWVuIGV4cGlyZWQgYW5kIHJlcXVpcmVzIGF1dGhlbnRpY2F0aW9uXG4gICAgICAgIC8vIHdoZW4gc2Vzc2lvbiByZWZyZXNoIGRlbGVnYXRlIGlzIGF2YWlsYWJsZVxuICAgICAgICBpZiAodGhpcy5pc1Nlc3Npb25FeHBpcmVkKHJlc3BvbnNlKSAmJiByZWZyZXNoRGVsZWdhdGUpIHtcbiAgICAgICAgICBhd2FpdCByZWZyZXNoRGVsZWdhdGUucmVmcmVzaChyZXF1ZXN0VGltZSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChyZXF1ZXN0KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5pc0Vycm9yUmVzcG9uc2UocmVzcG9uc2UpKSB7XG4gICAgICAgICAgY29uc3QgZXJyID0gYXdhaXQgdGhpcy5nZXRFcnJvcihyZXNwb25zZSk7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLmdldFJlc3BvbnNlQm9keShyZXNwb25zZSk7XG4gICAgICAgIHJldHVybiBib2R5O1xuICAgICAgfSkoKTtcbiAgICAgIHJldHVybiB7IHN0cmVhbSwgcHJvbWlzZSB9O1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGdldFJlZnJlc2hEZWxlZ2F0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5fcmVmcmVzaERlbGVnYXRlO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGJlZm9yZVNlbmQocmVxdWVzdDogSHR0cFJlcXVlc3QpIHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1wYXJhbS1yZWFzc2lnbiAqL1xuICAgIGNvbnN0IGhlYWRlcnMgPSByZXF1ZXN0LmhlYWRlcnMgfHwge307XG4gICAgaWYgKHRoaXMuX2Nvbm4uYWNjZXNzVG9rZW4pIHtcbiAgICAgIGhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCZWFyZXIgJHt0aGlzLl9jb25uLmFjY2Vzc1Rva2VufWA7XG4gICAgfVxuICAgIGlmICh0aGlzLl9jb25uLl9jYWxsT3B0aW9ucykge1xuICAgICAgY29uc3QgY2FsbE9wdGlvbnMgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyh0aGlzLl9jb25uLl9jYWxsT3B0aW9ucykpIHtcbiAgICAgICAgY2FsbE9wdGlvbnMucHVzaChgJHtuYW1lfT0ke3RoaXMuX2Nvbm4uX2NhbGxPcHRpb25zW25hbWVdfWApO1xuICAgICAgfVxuICAgICAgaGVhZGVyc1snU2ZvcmNlLUNhbGwtT3B0aW9ucyddID0gY2FsbE9wdGlvbnMuam9pbignLCAnKTtcbiAgICB9XG4gICAgcmVxdWVzdC5oZWFkZXJzID0gaGVhZGVycztcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3QgcmVzcG9uc2UgY29udGVudCBtaW1lLXR5cGVcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgZ2V0UmVzcG9uc2VDb250ZW50VHlwZShyZXNwb25zZTogSHR0cFJlc3BvbnNlKTogT3B0aW9uYWw8c3RyaW5nPiB7XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuX3Jlc3BvbnNlVHlwZSB8fFxuICAgICAgKHJlc3BvbnNlLmhlYWRlcnMgJiYgcmVzcG9uc2UuaGVhZGVyc1snY29udGVudC10eXBlJ10pXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgcGFyc2VSZXNwb25zZUJvZHkocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gdGhpcy5nZXRSZXNwb25zZUNvbnRlbnRUeXBlKHJlc3BvbnNlKSB8fCAnJztcbiAgICBjb25zdCBwYXJzZUJvZHkgPSAvXih0ZXh0fGFwcGxpY2F0aW9uKVxcL3htbCg7fCQpLy50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgPyBwYXJzZVhNTFxuICAgICAgOiAvXmFwcGxpY2F0aW9uXFwvanNvbig7fCQpLy50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgPyBwYXJzZUpTT05cbiAgICAgIDogL150ZXh0XFwvY3N2KDt8JCkvLnRlc3QoY29udGVudFR5cGUpXG4gICAgICA/IHBhcnNlQ1NWXG4gICAgICA6IHBhcnNlVGV4dDtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHBhcnNlQm9keShyZXNwb25zZS5ib2R5KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuYm9keTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlc3BvbnNlIGJvZHlcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgYXN5bmMgZ2V0UmVzcG9uc2VCb2R5KHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gMjA0KSB7XG4gICAgICAvLyBObyBDb250ZW50XG4gICAgICByZXR1cm4gdGhpcy5fbm9Db250ZW50UmVzcG9uc2U7XG4gICAgfVxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnBhcnNlUmVzcG9uc2VCb2R5KHJlc3BvbnNlKTtcbiAgICBsZXQgZXJyO1xuICAgIGlmICh0aGlzLmhhc0Vycm9ySW5SZXNwb25zZUJvZHkoYm9keSkpIHtcbiAgICAgIGVyciA9IGF3YWl0IHRoaXMuZ2V0RXJyb3IocmVzcG9uc2UsIGJvZHkpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gMzAwKSB7XG4gICAgICAvLyBNdWx0aXBsZSBDaG9pY2VzXG4gICAgICB0aHJvdyBuZXcgSHR0cEFwaUVycm9yKFxuICAgICAgICAnTXVsdGlwbGUgcmVjb3JkcyBmb3VuZCcsXG4gICAgICAgICdNVUxUSVBMRV9DSE9JQ0VTJyxcbiAgICAgICAgYm9keSxcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBib2R5O1xuICB9XG5cbiAgLyoqXG4gICAqIERldGVjdCBzZXNzaW9uIGV4cGlyeVxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBpc1Nlc3Npb25FeHBpcmVkKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICByZXR1cm4gcmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gNDAxO1xuICB9XG5cbiAgLyoqXG4gICAqIERldGVjdCBlcnJvciByZXNwb25zZVxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBpc0Vycm9yUmVzcG9uc2UocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIHJldHVybiByZXNwb25zZS5zdGF0dXNDb2RlID49IDQwMDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3QgZXJyb3IgaW4gcmVzcG9uc2UgYm9keVxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBoYXNFcnJvckluUmVzcG9uc2VCb2R5KF9ib2R5OiBPcHRpb25hbDxzdHJpbmc+KSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFBhcnNpbmcgZXJyb3IgbWVzc2FnZSBpbiByZXNwb25zZVxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBwYXJzZUVycm9yKGJvZHk6IGFueSkge1xuICAgIGNvbnN0IGVycm9ycyA9IGJvZHk7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoZXJyb3JzKSA/IGVycm9yc1swXSA6IGVycm9ycztcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZXJyb3IgbWVzc2FnZSBpbiByZXNwb25zZVxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBhc3luYyBnZXRFcnJvcihyZXNwb25zZTogSHR0cFJlc3BvbnNlLCBib2R5PzogYW55KTogUHJvbWlzZTxFcnJvcj4ge1xuICAgIGxldCBlcnJvcjtcbiAgICB0cnkge1xuICAgICAgZXJyb3IgPSB0aGlzLnBhcnNlRXJyb3IoYm9keSB8fCAoYXdhaXQgdGhpcy5wYXJzZVJlc3BvbnNlQm9keShyZXNwb25zZSkpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZSBuby1lbXB0eVxuICAgIH1cbiAgICBlcnJvciA9XG4gICAgICB0eXBlb2YgZXJyb3IgPT09ICdvYmplY3QnICYmXG4gICAgICBlcnJvciAhPT0gbnVsbCAmJlxuICAgICAgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09ICdzdHJpbmcnXG4gICAgICAgID8gZXJyb3JcbiAgICAgICAgOiB7XG4gICAgICAgICAgICBlcnJvckNvZGU6IGBFUlJPUl9IVFRQXyR7cmVzcG9uc2Uuc3RhdHVzQ29kZX1gLFxuICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2UuYm9keSxcbiAgICAgICAgICB9O1xuICAgIHJldHVybiBuZXcgSHR0cEFwaUVycm9yKGVycm9yLm1lc3NhZ2UsIGVycm9yLmVycm9yQ29kZSk7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5jbGFzcyBIdHRwQXBpRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGVycm9yQ29kZTogc3RyaW5nO1xuICBjb250ZW50OiBhbnk7XG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgZXJyb3JDb2RlPzogc3RyaW5nIHwgdW5kZWZpbmVkLCBjb250ZW50PzogYW55KSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gZXJyb3JDb2RlIHx8IHRoaXMubmFtZTtcbiAgICB0aGlzLmVycm9yQ29kZSA9IHRoaXMubmFtZTtcbiAgICB0aGlzLmNvbnRlbnQgPSBjb250ZW50O1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEh0dHBBcGk7XG4iXX0=