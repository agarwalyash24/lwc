import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";

var _ref, _process$env$HTTPS_PR;

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */
import request, { setDefaults } from './request';
import { StreamPromise } from './util/promise';
import jsonp from './browser/jsonp';
import canvas from './browser/canvas';
/**
 * Normarize Salesforce API host name
 * @private
 */

function normalizeApiHost(apiHost) {
  const m = /(\w+)\.(visual\.force|salesforce)\.com$/.exec(apiHost);

  if (m) {
    return `${m[1]}.salesforce.com`;
  }

  return apiHost;
}

setDefaults({
  httpProxy: (_ref = (_process$env$HTTPS_PR = process.env.HTTPS_PROXY) !== null && _process$env$HTTPS_PR !== void 0 ? _process$env$HTTPS_PR : process.env.HTTP_PROXY) !== null && _ref !== void 0 ? _ref : undefined,
  timeout: process.env.HTTP_TIMEOUT ? _parseInt(process.env.HTTP_TIMEOUT, 10) : undefined,
  followRedirect: true
});
const baseUrl = typeof window !== 'undefined' && window.location && window.location.host ? `https://${normalizeApiHost(window.location.host)}` : process.env.LOCATION_BASE_URL || '';
/**
 * Class for HTTP request transport
 *
 * @class
 * @protected
 */

export class Transport {
  /**
   */
  httpRequest(req, options = {}) {
    return StreamPromise.create(() => {
      const createStream = this.getRequestStreamCreator();
      const stream = createStream(req, options);
      const promise = new _Promise((resolve, reject) => {
        stream.on('complete', res => resolve(res)).on('error', reject);
      });
      return {
        stream,
        promise
      };
    });
  }
  /**
   * @protected
   */


  getRequestStreamCreator() {
    return request;
  }

}
/**
 * Class for JSONP request transport
 */

export class JsonpTransport extends Transport {
  constructor(jsonpParam) {
    super();

    _defineProperty(this, "_jsonpParam", void 0);

    this._jsonpParam = jsonpParam;
  }

  getRequestStreamCreator() {
    const jsonpRequest = jsonp.createRequest(this._jsonpParam);
    return params => jsonpRequest(params);
  }

}
/**
 * Class for Sfdc Canvas request transport
 */

_defineProperty(JsonpTransport, "supprted", jsonp.supported);

export class CanvasTransport extends Transport {
  constructor(signedRequest) {
    super();

    _defineProperty(this, "_signedRequest", void 0);

    this._signedRequest = signedRequest;
  }

  getRequestStreamCreator() {
    const canvasRequest = canvas.createRequest(this._signedRequest);
    return params => canvasRequest(params);
  }

}
/* @private */

_defineProperty(CanvasTransport, "supported", canvas.supported);

function createXdProxyRequest(req, proxyUrl) {
  const headers = {
    'salesforceproxy-endpoint': req.url
  };

  if (req.headers) {
    for (const name of _Object$keys(req.headers)) {
      headers[name] = req.headers[name];
    }
  }

  const nocache = `${_Date$now()}.${String(Math.random()).substring(2)}`;
  return _objectSpread({
    method: req.method,
    url: `${proxyUrl}?${nocache}`,
    headers
  }, req.body != null ? {
    body: req.body
  } : {});
}
/**
 * Class for HTTP request transport using cross-domain AJAX proxy service
 */


export class XdProxyTransport extends Transport {
  constructor(xdProxyUrl) {
    super();

    _defineProperty(this, "_xdProxyUrl", void 0);

    this._xdProxyUrl = xdProxyUrl;
  }
  /**
   * Make HTTP request via AJAX proxy
   */


  httpRequest(req, _options = {}) {
    const xdProxyUrl = this._xdProxyUrl;

    const {
      url,
      body
    } = req,
          rreq = _objectWithoutProperties(req, ["url", "body"]);

    const canonicalUrl = _indexOfInstanceProperty(url).call(url, '/') === 0 ? baseUrl + url : url;
    const xdProxyReq = createXdProxyRequest(_objectSpread(_objectSpread({}, rreq), {}, {
      url: canonicalUrl,
      body
    }), xdProxyUrl);
    return super.httpRequest(xdProxyReq, {
      followRedirect: redirectUrl => createXdProxyRequest(_objectSpread(_objectSpread({}, rreq), {}, {
        method: 'GET',
        url: redirectUrl
      }), xdProxyUrl)
    });
  }

}
/**
 * Class for HTTP request transport using a proxy server
 */

export class HttpProxyTransport extends Transport {
  constructor(httpProxy) {
    super();

    _defineProperty(this, "_httpProxy", void 0);

    this._httpProxy = httpProxy;
  }
  /**
   * Make HTTP request via proxy server
   */


  httpRequest(req, options_ = {}) {
    const options = _objectSpread(_objectSpread({}, options_), {}, {
      httpProxy: this._httpProxy
    });

    return super.httpRequest(req, options);
  }

}
export default Transport;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy90cmFuc3BvcnQudHMiXSwibmFtZXMiOlsicmVxdWVzdCIsInNldERlZmF1bHRzIiwiU3RyZWFtUHJvbWlzZSIsImpzb25wIiwiY2FudmFzIiwibm9ybWFsaXplQXBpSG9zdCIsImFwaUhvc3QiLCJtIiwiZXhlYyIsImh0dHBQcm94eSIsInByb2Nlc3MiLCJlbnYiLCJIVFRQU19QUk9YWSIsIkhUVFBfUFJPWFkiLCJ1bmRlZmluZWQiLCJ0aW1lb3V0IiwiSFRUUF9USU1FT1VUIiwiZm9sbG93UmVkaXJlY3QiLCJiYXNlVXJsIiwid2luZG93IiwibG9jYXRpb24iLCJob3N0IiwiTE9DQVRJT05fQkFTRV9VUkwiLCJUcmFuc3BvcnQiLCJodHRwUmVxdWVzdCIsInJlcSIsIm9wdGlvbnMiLCJjcmVhdGUiLCJjcmVhdGVTdHJlYW0iLCJnZXRSZXF1ZXN0U3RyZWFtQ3JlYXRvciIsInN0cmVhbSIsInByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0Iiwib24iLCJyZXMiLCJKc29ucFRyYW5zcG9ydCIsImNvbnN0cnVjdG9yIiwianNvbnBQYXJhbSIsIl9qc29ucFBhcmFtIiwianNvbnBSZXF1ZXN0IiwiY3JlYXRlUmVxdWVzdCIsInBhcmFtcyIsInN1cHBvcnRlZCIsIkNhbnZhc1RyYW5zcG9ydCIsInNpZ25lZFJlcXVlc3QiLCJfc2lnbmVkUmVxdWVzdCIsImNhbnZhc1JlcXVlc3QiLCJjcmVhdGVYZFByb3h5UmVxdWVzdCIsInByb3h5VXJsIiwiaGVhZGVycyIsInVybCIsIm5hbWUiLCJub2NhY2hlIiwiU3RyaW5nIiwiTWF0aCIsInJhbmRvbSIsInN1YnN0cmluZyIsIm1ldGhvZCIsImJvZHkiLCJYZFByb3h5VHJhbnNwb3J0IiwieGRQcm94eVVybCIsIl94ZFByb3h5VXJsIiwiX29wdGlvbnMiLCJycmVxIiwiY2Fub25pY2FsVXJsIiwieGRQcm94eVJlcSIsInJlZGlyZWN0VXJsIiwiSHR0cFByb3h5VHJhbnNwb3J0IiwiX2h0dHBQcm94eSIsIm9wdGlvbnNfIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBRUEsT0FBT0EsT0FBUCxJQUFrQkMsV0FBbEIsUUFBcUMsV0FBckM7QUFFQSxTQUFTQyxhQUFULFFBQThCLGdCQUE5QjtBQUNBLE9BQU9DLEtBQVAsTUFBa0IsaUJBQWxCO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixrQkFBbkI7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTQyxnQkFBVCxDQUEwQkMsT0FBMUIsRUFBMkM7QUFDekMsUUFBTUMsQ0FBQyxHQUFHLDBDQUEwQ0MsSUFBMUMsQ0FBK0NGLE9BQS9DLENBQVY7O0FBQ0EsTUFBSUMsQ0FBSixFQUFPO0FBQ0wsV0FBUSxHQUFFQSxDQUFDLENBQUMsQ0FBRCxDQUFJLGlCQUFmO0FBQ0Q7O0FBQ0QsU0FBT0QsT0FBUDtBQUNEOztBQUVETCxXQUFXLENBQUM7QUFDVlEsRUFBQUEsU0FBUyxtQ0FBRUMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFdBQWQseUVBQTZCRixPQUFPLENBQUNDLEdBQVIsQ0FBWUUsVUFBekMsdUNBQXVEQyxTQUR0RDtBQUVWQyxFQUFBQSxPQUFPLEVBQUVMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxZQUFaLEdBQ0wsVUFBU04sT0FBTyxDQUFDQyxHQUFSLENBQVlLLFlBQXJCLEVBQW1DLEVBQW5DLENBREssR0FFTEYsU0FKTTtBQUtWRyxFQUFBQSxjQUFjLEVBQUU7QUFMTixDQUFELENBQVg7QUFRQSxNQUFNQyxPQUFPLEdBQ1gsT0FBT0MsTUFBUCxLQUFrQixXQUFsQixJQUFpQ0EsTUFBTSxDQUFDQyxRQUF4QyxJQUFvREQsTUFBTSxDQUFDQyxRQUFQLENBQWdCQyxJQUFwRSxHQUNLLFdBQVVoQixnQkFBZ0IsQ0FBQ2MsTUFBTSxDQUFDQyxRQUFQLENBQWdCQyxJQUFqQixDQUF1QixFQUR0RCxHQUVJWCxPQUFPLENBQUNDLEdBQVIsQ0FBWVcsaUJBQVosSUFBaUMsRUFIdkM7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNQyxTQUFOLENBQWdCO0FBQ3JCO0FBQ0Y7QUFDRUMsRUFBQUEsV0FBVyxDQUNUQyxHQURTLEVBRVRDLE9BQTJCLEdBQUcsRUFGckIsRUFHb0I7QUFDN0IsV0FBT3hCLGFBQWEsQ0FBQ3lCLE1BQWQsQ0FBcUIsTUFBTTtBQUNoQyxZQUFNQyxZQUFZLEdBQUcsS0FBS0MsdUJBQUwsRUFBckI7QUFDQSxZQUFNQyxNQUFNLEdBQUdGLFlBQVksQ0FBQ0gsR0FBRCxFQUFNQyxPQUFOLENBQTNCO0FBQ0EsWUFBTUssT0FBTyxHQUFHLGFBQTBCLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUM3REgsUUFBQUEsTUFBTSxDQUNISSxFQURILENBQ00sVUFETixFQUNtQkMsR0FBRCxJQUF1QkgsT0FBTyxDQUFDRyxHQUFELENBRGhELEVBRUdELEVBRkgsQ0FFTSxPQUZOLEVBRWVELE1BRmY7QUFHRCxPQUplLENBQWhCO0FBS0EsYUFBTztBQUFFSCxRQUFBQSxNQUFGO0FBQVVDLFFBQUFBO0FBQVYsT0FBUDtBQUNELEtBVE0sQ0FBUDtBQVVEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUYsRUFBQUEsdUJBQXVCLEdBR1g7QUFDVixXQUFPN0IsT0FBUDtBQUNEOztBQTNCb0I7QUE4QnZCO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLE1BQU1vQyxjQUFOLFNBQTZCYixTQUE3QixDQUF1QztBQUk1Q2MsRUFBQUEsV0FBVyxDQUFDQyxVQUFELEVBQXFCO0FBQzlCOztBQUQ4Qjs7QUFFOUIsU0FBS0MsV0FBTCxHQUFtQkQsVUFBbkI7QUFDRDs7QUFFRFQsRUFBQUEsdUJBQXVCLEdBR1g7QUFDVixVQUFNVyxZQUFZLEdBQUdyQyxLQUFLLENBQUNzQyxhQUFOLENBQW9CLEtBQUtGLFdBQXpCLENBQXJCO0FBQ0EsV0FBUUcsTUFBRCxJQUFZRixZQUFZLENBQUNFLE1BQUQsQ0FBL0I7QUFDRDs7QUFmMkM7QUFrQjlDO0FBQ0E7QUFDQTs7Z0JBcEJhTixjLGNBQ2dCakMsS0FBSyxDQUFDd0MsUzs7QUFvQm5DLE9BQU8sTUFBTUMsZUFBTixTQUE4QnJCLFNBQTlCLENBQXdDO0FBSTdDYyxFQUFBQSxXQUFXLENBQUNRLGFBQUQsRUFBcUI7QUFDOUI7O0FBRDhCOztBQUU5QixTQUFLQyxjQUFMLEdBQXNCRCxhQUF0QjtBQUNEOztBQUVEaEIsRUFBQUEsdUJBQXVCLEdBR1g7QUFDVixVQUFNa0IsYUFBYSxHQUFHM0MsTUFBTSxDQUFDcUMsYUFBUCxDQUFxQixLQUFLSyxjQUExQixDQUF0QjtBQUNBLFdBQVFKLE1BQUQsSUFBWUssYUFBYSxDQUFDTCxNQUFELENBQWhDO0FBQ0Q7O0FBZjRDO0FBa0IvQzs7Z0JBbEJhRSxlLGVBQ2lCeEMsTUFBTSxDQUFDdUMsUzs7QUFrQnJDLFNBQVNLLG9CQUFULENBQThCdkIsR0FBOUIsRUFBZ0R3QixRQUFoRCxFQUErRTtBQUM3RSxRQUFNQyxPQUFtQyxHQUFHO0FBQzFDLGdDQUE0QnpCLEdBQUcsQ0FBQzBCO0FBRFUsR0FBNUM7O0FBR0EsTUFBSTFCLEdBQUcsQ0FBQ3lCLE9BQVIsRUFBaUI7QUFDZixTQUFLLE1BQU1FLElBQVgsSUFBbUIsYUFBWTNCLEdBQUcsQ0FBQ3lCLE9BQWhCLENBQW5CLEVBQTZDO0FBQzNDQSxNQUFBQSxPQUFPLENBQUNFLElBQUQsQ0FBUCxHQUFnQjNCLEdBQUcsQ0FBQ3lCLE9BQUosQ0FBWUUsSUFBWixDQUFoQjtBQUNEO0FBQ0Y7O0FBQ0QsUUFBTUMsT0FBTyxHQUFJLEdBQUUsV0FBVyxJQUFHQyxNQUFNLENBQUNDLElBQUksQ0FBQ0MsTUFBTCxFQUFELENBQU4sQ0FBc0JDLFNBQXRCLENBQWdDLENBQWhDLENBQW1DLEVBQXBFO0FBQ0E7QUFDRUMsSUFBQUEsTUFBTSxFQUFFakMsR0FBRyxDQUFDaUMsTUFEZDtBQUVFUCxJQUFBQSxHQUFHLEVBQUcsR0FBRUYsUUFBUyxJQUFHSSxPQUFRLEVBRjlCO0FBR0VILElBQUFBO0FBSEYsS0FJTXpCLEdBQUcsQ0FBQ2tDLElBQUosSUFBWSxJQUFaLEdBQW1CO0FBQUVBLElBQUFBLElBQUksRUFBRWxDLEdBQUcsQ0FBQ2tDO0FBQVosR0FBbkIsR0FBd0MsRUFKOUM7QUFNRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsT0FBTyxNQUFNQyxnQkFBTixTQUErQnJDLFNBQS9CLENBQXlDO0FBRzlDYyxFQUFBQSxXQUFXLENBQUN3QixVQUFELEVBQXFCO0FBQzlCOztBQUQ4Qjs7QUFFOUIsU0FBS0MsV0FBTCxHQUFtQkQsVUFBbkI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VyQyxFQUFBQSxXQUFXLENBQUNDLEdBQUQsRUFBbUJzQyxRQUE0QixHQUFHLEVBQWxELEVBQXNEO0FBQy9ELFVBQU1GLFVBQVUsR0FBRyxLQUFLQyxXQUF4Qjs7QUFDQSxVQUFNO0FBQUVYLE1BQUFBLEdBQUY7QUFBT1EsTUFBQUE7QUFBUCxRQUF5QmxDLEdBQS9CO0FBQUEsVUFBc0J1QyxJQUF0Qiw0QkFBK0J2QyxHQUEvQjs7QUFDQSxVQUFNd0MsWUFBWSxHQUFHLHlCQUFBZCxHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFTLEdBQVQsQ0FBSCxLQUFxQixDQUFyQixHQUF5QmpDLE9BQU8sR0FBR2lDLEdBQW5DLEdBQXlDQSxHQUE5RDtBQUNBLFVBQU1lLFVBQVUsR0FBR2xCLG9CQUFvQixpQ0FDaENnQixJQURnQztBQUMxQmIsTUFBQUEsR0FBRyxFQUFFYyxZQURxQjtBQUNQTixNQUFBQTtBQURPLFFBRXJDRSxVQUZxQyxDQUF2QztBQUlBLFdBQU8sTUFBTXJDLFdBQU4sQ0FBa0IwQyxVQUFsQixFQUE4QjtBQUNuQ2pELE1BQUFBLGNBQWMsRUFBR2tELFdBQUQsSUFDZG5CLG9CQUFvQixpQ0FDYmdCLElBRGE7QUFDUE4sUUFBQUEsTUFBTSxFQUFFLEtBREQ7QUFDUVAsUUFBQUEsR0FBRyxFQUFFZ0I7QUFEYixVQUVsQk4sVUFGa0I7QUFGYSxLQUE5QixDQUFQO0FBT0Q7O0FBMUI2QztBQTZCaEQ7QUFDQTtBQUNBOztBQUNBLE9BQU8sTUFBTU8sa0JBQU4sU0FBaUM3QyxTQUFqQyxDQUEyQztBQUdoRGMsRUFBQUEsV0FBVyxDQUFDNUIsU0FBRCxFQUFvQjtBQUM3Qjs7QUFENkI7O0FBRTdCLFNBQUs0RCxVQUFMLEdBQWtCNUQsU0FBbEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VlLEVBQUFBLFdBQVcsQ0FBQ0MsR0FBRCxFQUFtQjZDLFFBQTRCLEdBQUcsRUFBbEQsRUFBc0Q7QUFDL0QsVUFBTTVDLE9BQU8sbUNBQVE0QyxRQUFSO0FBQWtCN0QsTUFBQUEsU0FBUyxFQUFFLEtBQUs0RDtBQUFsQyxNQUFiOztBQUNBLFdBQU8sTUFBTTdDLFdBQU4sQ0FBa0JDLEdBQWxCLEVBQXVCQyxPQUF2QixDQUFQO0FBQ0Q7O0FBZCtDO0FBaUJsRCxlQUFlSCxTQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBEdXBsZXggfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHJlcXVlc3QsIHsgc2V0RGVmYXVsdHMgfSBmcm9tICcuL3JlcXVlc3QnO1xuaW1wb3J0IHsgSHR0cFJlcXVlc3QsIEh0dHBSZXF1ZXN0T3B0aW9ucywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBTdHJlYW1Qcm9taXNlIH0gZnJvbSAnLi91dGlsL3Byb21pc2UnO1xuaW1wb3J0IGpzb25wIGZyb20gJy4vYnJvd3Nlci9qc29ucCc7XG5pbXBvcnQgY2FudmFzIGZyb20gJy4vYnJvd3Nlci9jYW52YXMnO1xuXG4vKipcbiAqIE5vcm1hcml6ZSBTYWxlc2ZvcmNlIEFQSSBob3N0IG5hbWVcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZUFwaUhvc3QoYXBpSG9zdDogc3RyaW5nKSB7XG4gIGNvbnN0IG0gPSAvKFxcdyspXFwuKHZpc3VhbFxcLmZvcmNlfHNhbGVzZm9yY2UpXFwuY29tJC8uZXhlYyhhcGlIb3N0KTtcbiAgaWYgKG0pIHtcbiAgICByZXR1cm4gYCR7bVsxXX0uc2FsZXNmb3JjZS5jb21gO1xuICB9XG4gIHJldHVybiBhcGlIb3N0O1xufVxuXG5zZXREZWZhdWx0cyh7XG4gIGh0dHBQcm94eTogcHJvY2Vzcy5lbnYuSFRUUFNfUFJPWFkgPz8gcHJvY2Vzcy5lbnYuSFRUUF9QUk9YWSA/PyB1bmRlZmluZWQsXG4gIHRpbWVvdXQ6IHByb2Nlc3MuZW52LkhUVFBfVElNRU9VVFxuICAgID8gcGFyc2VJbnQocHJvY2Vzcy5lbnYuSFRUUF9USU1FT1VULCAxMClcbiAgICA6IHVuZGVmaW5lZCxcbiAgZm9sbG93UmVkaXJlY3Q6IHRydWUsXG59KTtcblxuY29uc3QgYmFzZVVybCA9XG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5sb2NhdGlvbiAmJiB3aW5kb3cubG9jYXRpb24uaG9zdFxuICAgID8gYGh0dHBzOi8vJHtub3JtYWxpemVBcGlIb3N0KHdpbmRvdy5sb2NhdGlvbi5ob3N0KX1gXG4gICAgOiBwcm9jZXNzLmVudi5MT0NBVElPTl9CQVNFX1VSTCB8fCAnJztcblxuLyoqXG4gKiBDbGFzcyBmb3IgSFRUUCByZXF1ZXN0IHRyYW5zcG9ydFxuICpcbiAqIEBjbGFzc1xuICogQHByb3RlY3RlZFxuICovXG5leHBvcnQgY2xhc3MgVHJhbnNwb3J0IHtcbiAgLyoqXG4gICAqL1xuICBodHRwUmVxdWVzdChcbiAgICByZXE6IEh0dHBSZXF1ZXN0LFxuICAgIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyA9IHt9LFxuICApOiBTdHJlYW1Qcm9taXNlPEh0dHBSZXNwb25zZT4ge1xuICAgIHJldHVybiBTdHJlYW1Qcm9taXNlLmNyZWF0ZSgoKSA9PiB7XG4gICAgICBjb25zdCBjcmVhdGVTdHJlYW0gPSB0aGlzLmdldFJlcXVlc3RTdHJlYW1DcmVhdG9yKCk7XG4gICAgICBjb25zdCBzdHJlYW0gPSBjcmVhdGVTdHJlYW0ocmVxLCBvcHRpb25zKTtcbiAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZTxIdHRwUmVzcG9uc2U+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgc3RyZWFtXG4gICAgICAgICAgLm9uKCdjb21wbGV0ZScsIChyZXM6IEh0dHBSZXNwb25zZSkgPT4gcmVzb2x2ZShyZXMpKVxuICAgICAgICAgIC5vbignZXJyb3InLCByZWplY3QpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4geyBzdHJlYW0sIHByb21pc2UgfTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBnZXRSZXF1ZXN0U3RyZWFtQ3JlYXRvcigpOiAoXG4gICAgcmVxOiBIdHRwUmVxdWVzdCxcbiAgICBvcHRpb25zOiBIdHRwUmVxdWVzdE9wdGlvbnMsXG4gICkgPT4gRHVwbGV4IHtcbiAgICByZXR1cm4gcmVxdWVzdDtcbiAgfVxufVxuXG4vKipcbiAqIENsYXNzIGZvciBKU09OUCByZXF1ZXN0IHRyYW5zcG9ydFxuICovXG5leHBvcnQgY2xhc3MgSnNvbnBUcmFuc3BvcnQgZXh0ZW5kcyBUcmFuc3BvcnQge1xuICBzdGF0aWMgc3VwcHJ0ZWQ6IGJvb2xlYW4gPSBqc29ucC5zdXBwb3J0ZWQ7XG4gIF9qc29ucFBhcmFtOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoanNvbnBQYXJhbTogc3RyaW5nKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9qc29ucFBhcmFtID0ganNvbnBQYXJhbTtcbiAgfVxuXG4gIGdldFJlcXVlc3RTdHJlYW1DcmVhdG9yKCk6IChcbiAgICByZXE6IEh0dHBSZXF1ZXN0LFxuICAgIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgKSA9PiBEdXBsZXgge1xuICAgIGNvbnN0IGpzb25wUmVxdWVzdCA9IGpzb25wLmNyZWF0ZVJlcXVlc3QodGhpcy5fanNvbnBQYXJhbSk7XG4gICAgcmV0dXJuIChwYXJhbXMpID0+IGpzb25wUmVxdWVzdChwYXJhbXMpO1xuICB9XG59XG5cbi8qKlxuICogQ2xhc3MgZm9yIFNmZGMgQ2FudmFzIHJlcXVlc3QgdHJhbnNwb3J0XG4gKi9cbmV4cG9ydCBjbGFzcyBDYW52YXNUcmFuc3BvcnQgZXh0ZW5kcyBUcmFuc3BvcnQge1xuICBzdGF0aWMgc3VwcG9ydGVkOiBib29sZWFuID0gY2FudmFzLnN1cHBvcnRlZDtcbiAgX3NpZ25lZFJlcXVlc3Q6IGFueTtcblxuICBjb25zdHJ1Y3RvcihzaWduZWRSZXF1ZXN0OiBhbnkpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX3NpZ25lZFJlcXVlc3QgPSBzaWduZWRSZXF1ZXN0O1xuICB9XG5cbiAgZ2V0UmVxdWVzdFN0cmVhbUNyZWF0b3IoKTogKFxuICAgIHJlcTogSHR0cFJlcXVlc3QsXG4gICAgb3B0aW9uczogSHR0cFJlcXVlc3RPcHRpb25zLFxuICApID0+IER1cGxleCB7XG4gICAgY29uc3QgY2FudmFzUmVxdWVzdCA9IGNhbnZhcy5jcmVhdGVSZXF1ZXN0KHRoaXMuX3NpZ25lZFJlcXVlc3QpO1xuICAgIHJldHVybiAocGFyYW1zKSA9PiBjYW52YXNSZXF1ZXN0KHBhcmFtcyk7XG4gIH1cbn1cblxuLyogQHByaXZhdGUgKi9cbmZ1bmN0aW9uIGNyZWF0ZVhkUHJveHlSZXF1ZXN0KHJlcTogSHR0cFJlcXVlc3QsIHByb3h5VXJsOiBzdHJpbmcpOiBIdHRwUmVxdWVzdCB7XG4gIGNvbnN0IGhlYWRlcnM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9ID0ge1xuICAgICdzYWxlc2ZvcmNlcHJveHktZW5kcG9pbnQnOiByZXEudXJsLFxuICB9O1xuICBpZiAocmVxLmhlYWRlcnMpIHtcbiAgICBmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMocmVxLmhlYWRlcnMpKSB7XG4gICAgICBoZWFkZXJzW25hbWVdID0gcmVxLmhlYWRlcnNbbmFtZV07XG4gICAgfVxuICB9XG4gIGNvbnN0IG5vY2FjaGUgPSBgJHtEYXRlLm5vdygpfS4ke1N0cmluZyhNYXRoLnJhbmRvbSgpKS5zdWJzdHJpbmcoMil9YDtcbiAgcmV0dXJuIHtcbiAgICBtZXRob2Q6IHJlcS5tZXRob2QsXG4gICAgdXJsOiBgJHtwcm94eVVybH0/JHtub2NhY2hlfWAsXG4gICAgaGVhZGVycyxcbiAgICAuLi4ocmVxLmJvZHkgIT0gbnVsbCA/IHsgYm9keTogcmVxLmJvZHkgfSA6IHt9KSxcbiAgfTtcbn1cblxuLyoqXG4gKiBDbGFzcyBmb3IgSFRUUCByZXF1ZXN0IHRyYW5zcG9ydCB1c2luZyBjcm9zcy1kb21haW4gQUpBWCBwcm94eSBzZXJ2aWNlXG4gKi9cbmV4cG9ydCBjbGFzcyBYZFByb3h5VHJhbnNwb3J0IGV4dGVuZHMgVHJhbnNwb3J0IHtcbiAgX3hkUHJveHlVcmw6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcih4ZFByb3h5VXJsOiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX3hkUHJveHlVcmwgPSB4ZFByb3h5VXJsO1xuICB9XG5cbiAgLyoqXG4gICAqIE1ha2UgSFRUUCByZXF1ZXN0IHZpYSBBSkFYIHByb3h5XG4gICAqL1xuICBodHRwUmVxdWVzdChyZXE6IEh0dHBSZXF1ZXN0LCBfb3B0aW9uczogSHR0cFJlcXVlc3RPcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB4ZFByb3h5VXJsID0gdGhpcy5feGRQcm94eVVybDtcbiAgICBjb25zdCB7IHVybCwgYm9keSwgLi4ucnJlcSB9ID0gcmVxO1xuICAgIGNvbnN0IGNhbm9uaWNhbFVybCA9IHVybC5pbmRleE9mKCcvJykgPT09IDAgPyBiYXNlVXJsICsgdXJsIDogdXJsO1xuICAgIGNvbnN0IHhkUHJveHlSZXEgPSBjcmVhdGVYZFByb3h5UmVxdWVzdChcbiAgICAgIHsgLi4ucnJlcSwgdXJsOiBjYW5vbmljYWxVcmwsIGJvZHkgfSxcbiAgICAgIHhkUHJveHlVcmwsXG4gICAgKTtcbiAgICByZXR1cm4gc3VwZXIuaHR0cFJlcXVlc3QoeGRQcm94eVJlcSwge1xuICAgICAgZm9sbG93UmVkaXJlY3Q6IChyZWRpcmVjdFVybCkgPT5cbiAgICAgICAgY3JlYXRlWGRQcm94eVJlcXVlc3QoXG4gICAgICAgICAgeyAuLi5ycmVxLCBtZXRob2Q6ICdHRVQnLCB1cmw6IHJlZGlyZWN0VXJsIH0sXG4gICAgICAgICAgeGRQcm94eVVybCxcbiAgICAgICAgKSxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIENsYXNzIGZvciBIVFRQIHJlcXVlc3QgdHJhbnNwb3J0IHVzaW5nIGEgcHJveHkgc2VydmVyXG4gKi9cbmV4cG9ydCBjbGFzcyBIdHRwUHJveHlUcmFuc3BvcnQgZXh0ZW5kcyBUcmFuc3BvcnQge1xuICBfaHR0cFByb3h5OiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoaHR0cFByb3h5OiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2h0dHBQcm94eSA9IGh0dHBQcm94eTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNYWtlIEhUVFAgcmVxdWVzdCB2aWEgcHJveHkgc2VydmVyXG4gICAqL1xuICBodHRwUmVxdWVzdChyZXE6IEh0dHBSZXF1ZXN0LCBvcHRpb25zXzogSHR0cFJlcXVlc3RPcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBvcHRpb25zID0geyAuLi5vcHRpb25zXywgaHR0cFByb3h5OiB0aGlzLl9odHRwUHJveHkgfTtcbiAgICByZXR1cm4gc3VwZXIuaHR0cFJlcXVlc3QocmVxLCBvcHRpb25zKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBUcmFuc3BvcnQ7XG4iXX0=