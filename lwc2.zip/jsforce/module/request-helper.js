import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.promise";
import _Set from "@babel/runtime-corejs3/core-js-stable/set";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import { PassThrough } from 'stream';
import { concatStreamsAsDuplex, readAll } from './util/stream';

/**
 *
 */
export function createHttpRequestHandlerStreams(req) {
  const {
    body: reqBody
  } = req;
  const input = new PassThrough();
  const output = new PassThrough();
  const duplex = concatStreamsAsDuplex(input, output);

  if (typeof reqBody !== 'undefined') {
    _setTimeout(() => {
      duplex.end(reqBody, 'utf8');
    }, 0);
  }

  duplex.on('response', async res => {
    if (duplex.listenerCount('complete') > 0) {
      const resBody = await readAll(duplex);
      duplex.emit('complete', _objectSpread(_objectSpread({}, res), {}, {
        body: resBody
      }));
    }
  });
  return {
    input,
    output,
    stream: duplex
  };
}
const redirectStatuses = new _Set([301, 302, 303, 307, 308]);
/**
 *
 */

export function isRedirect(status) {
  return redirectStatuses.has(status);
}
/**
 *
 */

const MAX_REDIRECT_COUNT = 10;
/**
 *
 */

export function performRedirectRequest(req, res, followRedirect, counter, redirectCallback) {
  if (counter >= MAX_REDIRECT_COUNT) {
    throw new Error('Reached to maximum redirect count');
  }

  const redirectUrl = res.headers['location'];

  if (!redirectUrl) {
    throw new Error('No redirect URI found');
  }

  const getRedirectRequest = typeof followRedirect === 'function' ? followRedirect : () => ({
    method: 'GET',
    url: redirectUrl,
    headers: req.headers
  });
  const nextReqParams = getRedirectRequest(redirectUrl);

  if (!nextReqParams) {
    throw new Error('Cannot handle redirect for ' + redirectUrl);
  }

  redirectCallback(nextReqParams);
}
/**
 *
 */

export async function executeWithTimeout(execFn, msec, cancelCallback) {
  let timeout = false;
  let pid = msec != null ? _setTimeout(() => {
    timeout = true;
    cancelCallback === null || cancelCallback === void 0 ? void 0 : cancelCallback();
  }, msec) : undefined;
  let res;

  try {
    res = await execFn();
  } finally {
    if (pid) {
      clearTimeout(pid);
    }
  }

  if (timeout) {
    throw new Error('Request Timeout');
  }

  return res;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZXF1ZXN0LWhlbHBlci50cyJdLCJuYW1lcyI6WyJQYXNzVGhyb3VnaCIsImNvbmNhdFN0cmVhbXNBc0R1cGxleCIsInJlYWRBbGwiLCJjcmVhdGVIdHRwUmVxdWVzdEhhbmRsZXJTdHJlYW1zIiwicmVxIiwiYm9keSIsInJlcUJvZHkiLCJpbnB1dCIsIm91dHB1dCIsImR1cGxleCIsImVuZCIsIm9uIiwicmVzIiwibGlzdGVuZXJDb3VudCIsInJlc0JvZHkiLCJlbWl0Iiwic3RyZWFtIiwicmVkaXJlY3RTdGF0dXNlcyIsImlzUmVkaXJlY3QiLCJzdGF0dXMiLCJoYXMiLCJNQVhfUkVESVJFQ1RfQ09VTlQiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZm9sbG93UmVkaXJlY3QiLCJjb3VudGVyIiwicmVkaXJlY3RDYWxsYmFjayIsIkVycm9yIiwicmVkaXJlY3RVcmwiLCJoZWFkZXJzIiwiZ2V0UmVkaXJlY3RSZXF1ZXN0IiwibWV0aG9kIiwidXJsIiwibmV4dFJlcVBhcmFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImV4ZWNGbiIsIm1zZWMiLCJjYW5jZWxDYWxsYmFjayIsInRpbWVvdXQiLCJwaWQiLCJ1bmRlZmluZWQiLCJjbGVhclRpbWVvdXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBU0EsV0FBVCxRQUE0QixRQUE1QjtBQUNBLFNBQVNDLHFCQUFULEVBQWdDQyxPQUFoQyxRQUErQyxlQUEvQzs7QUFHQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNDLCtCQUFULENBQXlDQyxHQUF6QyxFQUEyRDtBQUNoRSxRQUFNO0FBQUVDLElBQUFBLElBQUksRUFBRUM7QUFBUixNQUFvQkYsR0FBMUI7QUFDQSxRQUFNRyxLQUFLLEdBQUcsSUFBSVAsV0FBSixFQUFkO0FBQ0EsUUFBTVEsTUFBTSxHQUFHLElBQUlSLFdBQUosRUFBZjtBQUNBLFFBQU1TLE1BQU0sR0FBR1IscUJBQXFCLENBQUNNLEtBQUQsRUFBUUMsTUFBUixDQUFwQzs7QUFDQSxNQUFJLE9BQU9GLE9BQVAsS0FBbUIsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQVcsTUFBTTtBQUNmRyxNQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FBV0osT0FBWCxFQUFvQixNQUFwQjtBQUNELEtBRkQsRUFFRyxDQUZIO0FBR0Q7O0FBQ0RHLEVBQUFBLE1BQU0sQ0FBQ0UsRUFBUCxDQUFVLFVBQVYsRUFBc0IsTUFBT0MsR0FBUCxJQUFlO0FBQ25DLFFBQUlILE1BQU0sQ0FBQ0ksYUFBUCxDQUFxQixVQUFyQixJQUFtQyxDQUF2QyxFQUEwQztBQUN4QyxZQUFNQyxPQUFPLEdBQUcsTUFBTVosT0FBTyxDQUFDTyxNQUFELENBQTdCO0FBQ0FBLE1BQUFBLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLFVBQVosa0NBQ0tILEdBREw7QUFFRVAsUUFBQUEsSUFBSSxFQUFFUztBQUZSO0FBSUQ7QUFDRixHQVJEO0FBU0EsU0FBTztBQUFFUCxJQUFBQSxLQUFGO0FBQVNDLElBQUFBLE1BQVQ7QUFBaUJRLElBQUFBLE1BQU0sRUFBRVA7QUFBekIsR0FBUDtBQUNEO0FBRUQsTUFBTVEsZ0JBQWdCLEdBQUcsU0FBUSxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxFQUFnQixHQUFoQixFQUFxQixHQUFyQixDQUFSLENBQXpCO0FBRUE7QUFDQTtBQUNBOztBQUNBLE9BQU8sU0FBU0MsVUFBVCxDQUFvQkMsTUFBcEIsRUFBb0M7QUFDekMsU0FBT0YsZ0JBQWdCLENBQUNHLEdBQWpCLENBQXFCRCxNQUFyQixDQUFQO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsTUFBTUUsa0JBQWtCLEdBQUcsRUFBM0I7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTQyxzQkFBVCxDQUNMbEIsR0FESyxFQUVMUSxHQUZLLEVBR0xXLGNBSEssRUFJTEMsT0FKSyxFQUtMQyxnQkFMSyxFQU1MO0FBQ0EsTUFBSUQsT0FBTyxJQUFJSCxrQkFBZixFQUFtQztBQUNqQyxVQUFNLElBQUlLLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFBTUMsV0FBVyxHQUFHZixHQUFHLENBQUNnQixPQUFKLENBQVksVUFBWixDQUFwQjs7QUFDQSxNQUFJLENBQUNELFdBQUwsRUFBa0I7QUFDaEIsVUFBTSxJQUFJRCxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQUNEOztBQUNELFFBQU1HLGtCQUFrQixHQUN0QixPQUFPTixjQUFQLEtBQTBCLFVBQTFCLEdBQ0lBLGNBREosR0FFSSxPQUFPO0FBQ0xPLElBQUFBLE1BQU0sRUFBRSxLQURIO0FBRUxDLElBQUFBLEdBQUcsRUFBRUosV0FGQTtBQUdMQyxJQUFBQSxPQUFPLEVBQUV4QixHQUFHLENBQUN3QjtBQUhSLEdBQVAsQ0FITjtBQVFBLFFBQU1JLGFBQWEsR0FBR0gsa0JBQWtCLENBQUNGLFdBQUQsQ0FBeEM7O0FBQ0EsTUFBSSxDQUFDSyxhQUFMLEVBQW9CO0FBQ2xCLFVBQU0sSUFBSU4sS0FBSixDQUFVLGdDQUFnQ0MsV0FBMUMsQ0FBTjtBQUNEOztBQUNERixFQUFBQSxnQkFBZ0IsQ0FBQ08sYUFBRCxDQUFoQjtBQUNEO0FBRUQ7QUFDQTtBQUNBOztBQUNBLE9BQU8sZUFBZUMsa0JBQWYsQ0FDTEMsTUFESyxFQUVMQyxJQUZLLEVBR0xDLGNBSEssRUFJTztBQUNaLE1BQUlDLE9BQU8sR0FBRyxLQUFkO0FBQ0EsTUFBSUMsR0FBRyxHQUNMSCxJQUFJLElBQUksSUFBUixHQUNJLFlBQVcsTUFBTTtBQUNmRSxJQUFBQSxPQUFPLEdBQUcsSUFBVjtBQUNBRCxJQUFBQSxjQUFjLFNBQWQsSUFBQUEsY0FBYyxXQUFkLFlBQUFBLGNBQWM7QUFDZixHQUhELEVBR0dELElBSEgsQ0FESixHQUtJSSxTQU5OO0FBT0EsTUFBSTNCLEdBQUo7O0FBQ0EsTUFBSTtBQUNGQSxJQUFBQSxHQUFHLEdBQUcsTUFBTXNCLE1BQU0sRUFBbEI7QUFDRCxHQUZELFNBRVU7QUFDUixRQUFJSSxHQUFKLEVBQVM7QUFDUEUsTUFBQUEsWUFBWSxDQUFDRixHQUFELENBQVo7QUFDRDtBQUNGOztBQUNELE1BQUlELE9BQUosRUFBYTtBQUNYLFVBQU0sSUFBSVgsS0FBSixDQUFVLGlCQUFWLENBQU47QUFDRDs7QUFDRCxTQUFPZCxHQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYXNzVGhyb3VnaCB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgeyBjb25jYXRTdHJlYW1zQXNEdXBsZXgsIHJlYWRBbGwgfSBmcm9tICcuL3V0aWwvc3RyZWFtJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBIdHRwUmVxdWVzdE9wdGlvbnMsIEh0dHBSZXNwb25zZSB9IGZyb20gJy4vdHlwZXMnO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVIdHRwUmVxdWVzdEhhbmRsZXJTdHJlYW1zKHJlcTogSHR0cFJlcXVlc3QpIHtcbiAgY29uc3QgeyBib2R5OiByZXFCb2R5IH0gPSByZXE7XG4gIGNvbnN0IGlucHV0ID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gIGNvbnN0IG91dHB1dCA9IG5ldyBQYXNzVGhyb3VnaCgpO1xuICBjb25zdCBkdXBsZXggPSBjb25jYXRTdHJlYW1zQXNEdXBsZXgoaW5wdXQsIG91dHB1dCk7XG4gIGlmICh0eXBlb2YgcmVxQm9keSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGR1cGxleC5lbmQocmVxQm9keSwgJ3V0ZjgnKTtcbiAgICB9LCAwKTtcbiAgfVxuICBkdXBsZXgub24oJ3Jlc3BvbnNlJywgYXN5bmMgKHJlcykgPT4ge1xuICAgIGlmIChkdXBsZXgubGlzdGVuZXJDb3VudCgnY29tcGxldGUnKSA+IDApIHtcbiAgICAgIGNvbnN0IHJlc0JvZHkgPSBhd2FpdCByZWFkQWxsKGR1cGxleCk7XG4gICAgICBkdXBsZXguZW1pdCgnY29tcGxldGUnLCB7XG4gICAgICAgIC4uLnJlcyxcbiAgICAgICAgYm9keTogcmVzQm9keSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiB7IGlucHV0LCBvdXRwdXQsIHN0cmVhbTogZHVwbGV4IH07XG59XG5cbmNvbnN0IHJlZGlyZWN0U3RhdHVzZXMgPSBuZXcgU2V0KFszMDEsIDMwMiwgMzAzLCAzMDcsIDMwOF0pO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc1JlZGlyZWN0KHN0YXR1czogbnVtYmVyKSB7XG4gIHJldHVybiByZWRpcmVjdFN0YXR1c2VzLmhhcyhzdGF0dXMpO1xufVxuXG4vKipcbiAqXG4gKi9cbmNvbnN0IE1BWF9SRURJUkVDVF9DT1VOVCA9IDEwO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0KFxuICByZXE6IEh0dHBSZXF1ZXN0LFxuICByZXM6IE9taXQ8SHR0cFJlc3BvbnNlLCAnYm9keSc+LFxuICBmb2xsb3dSZWRpcmVjdDogTm9uTnVsbGFibGU8SHR0cFJlcXVlc3RPcHRpb25zWydmb2xsb3dSZWRpcmVjdCddPixcbiAgY291bnRlcjogbnVtYmVyLFxuICByZWRpcmVjdENhbGxiYWNrOiAocmVxOiBIdHRwUmVxdWVzdCkgPT4gdm9pZCxcbikge1xuICBpZiAoY291bnRlciA+PSBNQVhfUkVESVJFQ1RfQ09VTlQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlYWNoZWQgdG8gbWF4aW11bSByZWRpcmVjdCBjb3VudCcpO1xuICB9XG4gIGNvbnN0IHJlZGlyZWN0VXJsID0gcmVzLmhlYWRlcnNbJ2xvY2F0aW9uJ107XG4gIGlmICghcmVkaXJlY3RVcmwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHJlZGlyZWN0IFVSSSBmb3VuZCcpO1xuICB9XG4gIGNvbnN0IGdldFJlZGlyZWN0UmVxdWVzdCA9XG4gICAgdHlwZW9mIGZvbGxvd1JlZGlyZWN0ID09PSAnZnVuY3Rpb24nXG4gICAgICA/IGZvbGxvd1JlZGlyZWN0XG4gICAgICA6ICgpID0+ICh7XG4gICAgICAgICAgbWV0aG9kOiAnR0VUJyBhcyBjb25zdCxcbiAgICAgICAgICB1cmw6IHJlZGlyZWN0VXJsLFxuICAgICAgICAgIGhlYWRlcnM6IHJlcS5oZWFkZXJzLFxuICAgICAgICB9KTtcbiAgY29uc3QgbmV4dFJlcVBhcmFtcyA9IGdldFJlZGlyZWN0UmVxdWVzdChyZWRpcmVjdFVybCk7XG4gIGlmICghbmV4dFJlcVBhcmFtcykge1xuICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGhhbmRsZSByZWRpcmVjdCBmb3IgJyArIHJlZGlyZWN0VXJsKTtcbiAgfVxuICByZWRpcmVjdENhbGxiYWNrKG5leHRSZXFQYXJhbXMpO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleGVjdXRlV2l0aFRpbWVvdXQ8VD4oXG4gIGV4ZWNGbjogKCkgPT4gUHJvbWlzZTxUPixcbiAgbXNlYzogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICBjYW5jZWxDYWxsYmFjaz86ICgpID0+IHZvaWQsXG4pOiBQcm9taXNlPFQ+IHtcbiAgbGV0IHRpbWVvdXQgPSBmYWxzZTtcbiAgbGV0IHBpZCA9XG4gICAgbXNlYyAhPSBudWxsXG4gICAgICA/IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRpbWVvdXQgPSB0cnVlO1xuICAgICAgICAgIGNhbmNlbENhbGxiYWNrPy4oKTtcbiAgICAgICAgfSwgbXNlYylcbiAgICAgIDogdW5kZWZpbmVkO1xuICBsZXQgcmVzO1xuICB0cnkge1xuICAgIHJlcyA9IGF3YWl0IGV4ZWNGbigpO1xuICB9IGZpbmFsbHkge1xuICAgIGlmIChwaWQpIHtcbiAgICAgIGNsZWFyVGltZW91dChwaWQpO1xuICAgIH1cbiAgfVxuICBpZiAodGltZW91dCkge1xuICAgIHRocm93IG5ldyBFcnJvcignUmVxdWVzdCBUaW1lb3V0Jyk7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbiJdfQ==