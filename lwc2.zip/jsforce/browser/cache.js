import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.join";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * @file Manages asynchronous method response cache
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
/**
 * type def
 */

/**
 * Class for managing cache entry
 *
 * @private
 * @class
 * @constructor
 * @template T
 */
var CacheEntry = /*#__PURE__*/function (_EventEmitter) {
  _inherits(CacheEntry, _EventEmitter);

  var _super = _createSuper(CacheEntry);

  function CacheEntry() {
    var _context;

    var _this;

    _classCallCheck(this, CacheEntry);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, _concatInstanceProperty(_context = [this]).call(_context, args));

    _defineProperty(_assertThisInitialized(_this), "_fetching", false);

    _defineProperty(_assertThisInitialized(_this), "_value", undefined);

    return _this;
  }

  _createClass(CacheEntry, [{
    key: "get",

    /**
     * Get value in the cache entry
     *
     * @param {() => Promise<T>} [callback] - Callback function callbacked the cache entry updated
     * @returns {T|undefined}
     */
    value: function get(callback) {
      if (callback) {
        var cb = callback;
        this.once('value', function (v) {
          return cb(v);
        });

        if (typeof this._value !== 'undefined') {
          this.emit('value', this._value);
        }
      }

      return this._value;
    }
    /**
     * Set value in the cache entry
     */

  }, {
    key: "set",
    value: function set(value) {
      this._value = value;
      this.emit('value', this._value);
    }
    /**
     * Clear cached value
     */

  }, {
    key: "clear",
    value: function clear() {
      this._fetching = false;
      this._value = undefined;
    }
  }]);

  return CacheEntry;
}(EventEmitter);
/**
 * create and return cache key from namespace and serialized arguments.
 * @private
 */


function createCacheKey(namespace, args) {
  var _context2, _context3;

  return _concatInstanceProperty(_context2 = "".concat(namespace || '', "(")).call(_context2, _mapInstanceProperty(_context3 = _toConsumableArray(args)).call(_context3, function (a) {
    return _JSON$stringify(a);
  }).join(','), ")");
}

function generateKeyString(options, scope, args) {
  return typeof options.key === 'string' ? options.key : typeof options.key === 'function' ? options.key.apply(scope, args) : createCacheKey(options.namespace, args);
}
/**
 * Caching manager for async methods
 *
 * @class
 * @constructor
 */


export var Cache = /*#__PURE__*/function () {
  function Cache() {
    _classCallCheck(this, Cache);

    _defineProperty(this, "_entries", {});
  }

  _createClass(Cache, [{
    key: "get",

    /**
     * retrive cache entry, or create if not exists.
     *
     * @param {String} [key] - Key of cache entry
     * @returns {CacheEntry}
     */
    value: function get(key) {
      if (this._entries[key]) {
        return this._entries[key];
      }

      var entry = new CacheEntry();
      this._entries[key] = entry;
      return entry;
    }
    /**
     * clear cache entries prefix matching given key
     */

  }, {
    key: "clear",
    value: function clear(key) {
      for (var _i = 0, _Object$keys = _Object$keys2(this._entries); _i < _Object$keys.length; _i++) {
        var k = _Object$keys[_i];

        if (!key || _indexOfInstanceProperty(k).call(k, key) === 0) {
          this._entries[k].clear();
        }
      }
    }
    /**
     * Enable caching for async call fn to lookup the response cache first,
     * then invoke original if no cached value.
     */

  }, {
    key: "createCachedFunction",
    value: function createCachedFunction(fn, scope) {
      var _this2 = this;

      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
        strategy: 'NOCACHE'
      };
      var strategy = options.strategy;

      var $fn = function $fn() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }

        var key = generateKeyString(options, scope, args);

        var entry = _this2.get(key);

        var executeFetch = /*#__PURE__*/function () {
          var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
            var result;
            return _regeneratorRuntime.wrap(function _callee$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    entry._fetching = true;
                    _context4.prev = 1;
                    _context4.next = 4;
                    return fn.apply(scope || _this2, args);

                  case 4:
                    result = _context4.sent;
                    entry.set({
                      error: undefined,
                      result: result
                    });
                    return _context4.abrupt("return", result);

                  case 9:
                    _context4.prev = 9;
                    _context4.t0 = _context4["catch"](1);
                    entry.set({
                      error: _context4.t0,
                      result: undefined
                    });
                    throw _context4.t0;

                  case 13:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee, null, [[1, 9]]);
          }));

          return function executeFetch() {
            return _ref.apply(this, arguments);
          };
        }();

        var value;

        switch (strategy) {
          case 'IMMEDIATE':
            value = entry.get();

            if (!value) {
              throw new Error('Function call result is not cached yet.');
            }

            if (value.error) {
              throw value.error;
            }

            return value.result;

          case 'HIT':
            return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
              return _regeneratorRuntime.wrap(function _callee2$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      if (entry._fetching) {
                        _context5.next = 3;
                        break;
                      }

                      _context5.next = 3;
                      return executeFetch();

                    case 3:
                      return _context5.abrupt("return", new _Promise(function (resolve, reject) {
                        entry.get(function (_ref3) {
                          var error = _ref3.error,
                              result = _ref3.result;
                          if (error) reject(error);else resolve(result);
                        });
                      }));

                    case 4:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee2);
            }))();

          case 'NOCACHE':
          default:
            return executeFetch();
        }
      };

      $fn.clear = function () {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }

        var key = generateKeyString(options, scope, args);

        _this2.clear(key);
      };

      return $fn;
    }
  }]);

  return Cache;
}();
export default Cache;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9jYWNoZS50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJDYWNoZUVudHJ5IiwidW5kZWZpbmVkIiwiY2FsbGJhY2siLCJjYiIsIm9uY2UiLCJ2IiwiX3ZhbHVlIiwiZW1pdCIsInZhbHVlIiwiX2ZldGNoaW5nIiwiY3JlYXRlQ2FjaGVLZXkiLCJuYW1lc3BhY2UiLCJhcmdzIiwiYSIsImpvaW4iLCJnZW5lcmF0ZUtleVN0cmluZyIsIm9wdGlvbnMiLCJzY29wZSIsImtleSIsImFwcGx5IiwiQ2FjaGUiLCJfZW50cmllcyIsImVudHJ5IiwiayIsImNsZWFyIiwiZm4iLCJzdHJhdGVneSIsIiRmbiIsImdldCIsImV4ZWN1dGVGZXRjaCIsInJlc3VsdCIsInNldCIsImVycm9yIiwiRXJyb3IiLCJyZXNvbHZlIiwicmVqZWN0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFFQTtBQUNBO0FBQ0E7O0FBY0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNNQyxVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0VBQ2lCLEs7OzZEQUNVQyxTOzs7Ozs7OztBQUUvQjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7d0JBQ01DLFEsRUFBZ0Q7QUFDbEQsVUFBSUEsUUFBSixFQUFjO0FBQ1osWUFBTUMsRUFBRSxHQUFHRCxRQUFYO0FBQ0EsYUFBS0UsSUFBTCxDQUFVLE9BQVYsRUFBbUIsVUFBQ0MsQ0FBRDtBQUFBLGlCQUFVRixFQUFFLENBQUNFLENBQUQsQ0FBWjtBQUFBLFNBQW5COztBQUNBLFlBQUksT0FBTyxLQUFLQyxNQUFaLEtBQXVCLFdBQTNCLEVBQXdDO0FBQ3RDLGVBQUtDLElBQUwsQ0FBVSxPQUFWLEVBQW1CLEtBQUtELE1BQXhCO0FBQ0Q7QUFDRjs7QUFDRCxhQUFPLEtBQUtBLE1BQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7Ozt3QkFDTUUsSyxFQUFzQjtBQUN4QixXQUFLRixNQUFMLEdBQWNFLEtBQWQ7QUFDQSxXQUFLRCxJQUFMLENBQVUsT0FBVixFQUFtQixLQUFLRCxNQUF4QjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7OzRCQUNVO0FBQ04sV0FBS0csU0FBTCxHQUFpQixLQUFqQjtBQUNBLFdBQUtILE1BQUwsR0FBY0wsU0FBZDtBQUNEOzs7O0VBbkN5QkYsWTtBQXNDNUI7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFNBQVNXLGNBQVQsQ0FBd0JDLFNBQXhCLEVBQWtEQyxJQUFsRCxFQUF1RTtBQUFBOztBQUNyRSx1REFBVUQsU0FBUyxJQUFJLEVBQXZCLHdCQUE2QixvREFBSUMsSUFBSixtQkFDdEIsVUFBQ0MsQ0FBRDtBQUFBLFdBQU8sZ0JBQWVBLENBQWYsQ0FBUDtBQUFBLEdBRHNCLEVBRTFCQyxJQUYwQixDQUVyQixHQUZxQixDQUE3QjtBQUdEOztBQUVELFNBQVNDLGlCQUFULENBQ0VDLE9BREYsRUFFRUMsS0FGRixFQUdFTCxJQUhGLEVBSVU7QUFDUixTQUFPLE9BQU9JLE9BQU8sQ0FBQ0UsR0FBZixLQUF1QixRQUF2QixHQUNIRixPQUFPLENBQUNFLEdBREwsR0FFSCxPQUFPRixPQUFPLENBQUNFLEdBQWYsS0FBdUIsVUFBdkIsR0FDQUYsT0FBTyxDQUFDRSxHQUFSLENBQVlDLEtBQVosQ0FBa0JGLEtBQWxCLEVBQXlCTCxJQUF6QixDQURBLEdBRUFGLGNBQWMsQ0FBQ00sT0FBTyxDQUFDTCxTQUFULEVBQW9CQyxJQUFwQixDQUpsQjtBQUtEO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFhUSxLQUFiO0FBQUE7QUFBQTs7QUFBQSxzQ0FDeUQsRUFEekQ7QUFBQTs7QUFBQTtBQUFBOztBQUdFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVJBLHdCQVNNRixHQVROLEVBU21CO0FBQ2YsVUFBSSxLQUFLRyxRQUFMLENBQWNILEdBQWQsQ0FBSixFQUF3QjtBQUN0QixlQUFPLEtBQUtHLFFBQUwsQ0FBY0gsR0FBZCxDQUFQO0FBQ0Q7O0FBQ0QsVUFBTUksS0FBSyxHQUFHLElBQUl0QixVQUFKLEVBQWQ7QUFDQSxXQUFLcUIsUUFBTCxDQUFjSCxHQUFkLElBQXFCSSxLQUFyQjtBQUNBLGFBQU9BLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFwQkE7QUFBQTtBQUFBLDBCQXFCUUosR0FyQlIsRUFxQnNCO0FBQ2xCLHNDQUFnQixjQUFZLEtBQUtHLFFBQWpCLENBQWhCLGtDQUE0QztBQUF2QyxZQUFNRSxDQUFDLG1CQUFQOztBQUNILFlBQUksQ0FBQ0wsR0FBRCxJQUFRLHlCQUFBSyxDQUFDLE1BQUQsQ0FBQUEsQ0FBQyxFQUFTTCxHQUFULENBQUQsS0FBbUIsQ0FBL0IsRUFBa0M7QUFDaEMsZUFBS0csUUFBTCxDQUFjRSxDQUFkLEVBQWlCQyxLQUFqQjtBQUNEO0FBQ0Y7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBOztBQWhDQTtBQUFBO0FBQUEseUNBa0NJQyxFQWxDSixFQW1DSVIsS0FuQ0osRUFxQ3dCO0FBQUE7O0FBQUEsVUFEcEJELE9BQ29CLHVFQURNO0FBQUVVLFFBQUFBLFFBQVEsRUFBRTtBQUFaLE9BQ047QUFDcEIsVUFBTUEsUUFBUSxHQUFHVixPQUFPLENBQUNVLFFBQXpCOztBQUNBLFVBQU1DLEdBQVEsR0FBRyxTQUFYQSxHQUFXLEdBQW9CO0FBQUEsMkNBQWhCZixJQUFnQjtBQUFoQkEsVUFBQUEsSUFBZ0I7QUFBQTs7QUFDbkMsWUFBTU0sR0FBRyxHQUFHSCxpQkFBaUIsQ0FBQ0MsT0FBRCxFQUFVQyxLQUFWLEVBQWlCTCxJQUFqQixDQUE3Qjs7QUFDQSxZQUFNVSxLQUFLLEdBQUcsTUFBSSxDQUFDTSxHQUFMLENBQVNWLEdBQVQsQ0FBZDs7QUFDQSxZQUFNVyxZQUFZO0FBQUEsOEVBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ25CUCxvQkFBQUEsS0FBSyxDQUFDYixTQUFOLEdBQWtCLElBQWxCO0FBRG1CO0FBQUE7QUFBQSwyQkFHSWdCLEVBQUUsQ0FBQ04sS0FBSCxDQUFTRixLQUFLLElBQUksTUFBbEIsRUFBd0JMLElBQXhCLENBSEo7O0FBQUE7QUFHWGtCLG9CQUFBQSxNQUhXO0FBSWpCUixvQkFBQUEsS0FBSyxDQUFDUyxHQUFOLENBQVU7QUFBRUMsc0JBQUFBLEtBQUssRUFBRS9CLFNBQVQ7QUFBb0I2QixzQkFBQUEsTUFBTSxFQUFOQTtBQUFwQixxQkFBVjtBQUppQixzREFLVkEsTUFMVTs7QUFBQTtBQUFBO0FBQUE7QUFPakJSLG9CQUFBQSxLQUFLLENBQUNTLEdBQU4sQ0FBVTtBQUFFQyxzQkFBQUEsS0FBSyxjQUFQO0FBQXlCRixzQkFBQUEsTUFBTSxFQUFFN0I7QUFBakMscUJBQVY7QUFQaUI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSDs7QUFBQSwwQkFBWjRCLFlBQVk7QUFBQTtBQUFBO0FBQUEsV0FBbEI7O0FBV0EsWUFBSXJCLEtBQUo7O0FBQ0EsZ0JBQVFrQixRQUFSO0FBQ0UsZUFBSyxXQUFMO0FBQ0VsQixZQUFBQSxLQUFLLEdBQUdjLEtBQUssQ0FBQ00sR0FBTixFQUFSOztBQUNBLGdCQUFJLENBQUNwQixLQUFMLEVBQVk7QUFDVixvQkFBTSxJQUFJeUIsS0FBSixDQUFVLHlDQUFWLENBQU47QUFDRDs7QUFDRCxnQkFBSXpCLEtBQUssQ0FBQ3dCLEtBQVYsRUFBaUI7QUFDZixvQkFBTXhCLEtBQUssQ0FBQ3dCLEtBQVo7QUFDRDs7QUFDRCxtQkFBT3hCLEtBQUssQ0FBQ3NCLE1BQWI7O0FBQ0YsZUFBSyxLQUFMO0FBQ0UsbUJBQU8seURBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUNEUixLQUFLLENBQUNiLFNBREw7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSw2QkFHRW9CLFlBQVksRUFIZDs7QUFBQTtBQUFBLHdEQUtDLGFBQVksVUFBQ0ssT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3RDYix3QkFBQUEsS0FBSyxDQUFDTSxHQUFOLENBQVUsaUJBQXVCO0FBQUEsOEJBQXBCSSxLQUFvQixTQUFwQkEsS0FBb0I7QUFBQSw4QkFBYkYsTUFBYSxTQUFiQSxNQUFhO0FBQy9CLDhCQUFJRSxLQUFKLEVBQVdHLE1BQU0sQ0FBQ0gsS0FBRCxDQUFOLENBQVgsS0FDS0UsT0FBTyxDQUFDSixNQUFELENBQVA7QUFDTix5QkFIRDtBQUlELHVCQUxNLENBTEQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRCxJQUFQOztBQVlGLGVBQUssU0FBTDtBQUNBO0FBQ0UsbUJBQU9ELFlBQVksRUFBbkI7QUF6Qko7QUEyQkQsT0ExQ0Q7O0FBMkNBRixNQUFBQSxHQUFHLENBQUNILEtBQUosR0FBWSxZQUFvQjtBQUFBLDJDQUFoQlosSUFBZ0I7QUFBaEJBLFVBQUFBLElBQWdCO0FBQUE7O0FBQzlCLFlBQU1NLEdBQUcsR0FBR0gsaUJBQWlCLENBQUNDLE9BQUQsRUFBVUMsS0FBVixFQUFpQkwsSUFBakIsQ0FBN0I7O0FBQ0EsUUFBQSxNQUFJLENBQUNZLEtBQUwsQ0FBV04sR0FBWDtBQUNELE9BSEQ7O0FBSUEsYUFBT1MsR0FBUDtBQUNEO0FBdkZIOztBQUFBO0FBQUE7QUEwRkEsZUFBZVAsS0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBhc3luY2hyb25vdXMgbWV0aG9kIHJlc3BvbnNlIGNhY2hlXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcblxuLyoqXG4gKiB0eXBlIGRlZlxuICovXG5leHBvcnQgdHlwZSBDYWNoaW5nT3B0aW9ucyA9IHtcbiAga2V5Pzogc3RyaW5nIHwgKCguLi5hcmdzOiBhbnlbXSkgPT4gc3RyaW5nKTtcbiAgbmFtZXNwYWNlPzogc3RyaW5nO1xuICBzdHJhdGVneTogJ05PQ0FDSEUnIHwgJ0hJVCcgfCAnSU1NRURJQVRFJztcbn07XG5cbnR5cGUgQ2FjaGVWYWx1ZTxUPiA9IHtcbiAgZXJyb3I/OiBFcnJvcjtcbiAgcmVzdWx0OiBUO1xufTtcblxuZXhwb3J0IHR5cGUgQ2FjaGVkRnVuY3Rpb248Rm4+ID0gRm4gJiB7IGNsZWFyOiAoLi4uYXJnczogYW55W10pID0+IHZvaWQgfTtcblxuLyoqXG4gKiBDbGFzcyBmb3IgbWFuYWdpbmcgY2FjaGUgZW50cnlcbiAqXG4gKiBAcHJpdmF0ZVxuICogQGNsYXNzXG4gKiBAY29uc3RydWN0b3JcbiAqIEB0ZW1wbGF0ZSBUXG4gKi9cbmNsYXNzIENhY2hlRW50cnk8VD4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBfZmV0Y2hpbmc6IGJvb2xlYW4gPSBmYWxzZTtcbiAgX3ZhbHVlOiBDYWNoZVZhbHVlPFQ+IHwgdm9pZCA9IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICogR2V0IHZhbHVlIGluIHRoZSBjYWNoZSBlbnRyeVxuICAgKlxuICAgKiBAcGFyYW0geygpID0+IFByb21pc2U8VD59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvbiBjYWxsYmFja2VkIHRoZSBjYWNoZSBlbnRyeSB1cGRhdGVkXG4gICAqIEByZXR1cm5zIHtUfHVuZGVmaW5lZH1cbiAgICovXG4gIGdldChjYWxsYmFjaz86ICh2OiBUKSA9PiBhbnkpOiBDYWNoZVZhbHVlPFQ+IHwgdm9pZCB7XG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICBjb25zdCBjYiA9IGNhbGxiYWNrO1xuICAgICAgdGhpcy5vbmNlKCd2YWx1ZScsICh2OiBUKSA9PiBjYih2KSk7XG4gICAgICBpZiAodHlwZW9mIHRoaXMuX3ZhbHVlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICB0aGlzLmVtaXQoJ3ZhbHVlJywgdGhpcy5fdmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cblxuICAvKipcbiAgICogU2V0IHZhbHVlIGluIHRoZSBjYWNoZSBlbnRyeVxuICAgKi9cbiAgc2V0KHZhbHVlOiBDYWNoZVZhbHVlPFQ+KSB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB0aGlzLmVtaXQoJ3ZhbHVlJywgdGhpcy5fdmFsdWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIENsZWFyIGNhY2hlZCB2YWx1ZVxuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5fZmV0Y2hpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl92YWx1ZSA9IHVuZGVmaW5lZDtcbiAgfVxufVxuXG4vKipcbiAqIGNyZWF0ZSBhbmQgcmV0dXJuIGNhY2hlIGtleSBmcm9tIG5hbWVzcGFjZSBhbmQgc2VyaWFsaXplZCBhcmd1bWVudHMuXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjcmVhdGVDYWNoZUtleShuYW1lc3BhY2U6IHN0cmluZyB8IHZvaWQsIGFyZ3M6IGFueVtdKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke25hbWVzcGFjZSB8fCAnJ30oJHtbLi4uYXJnc11cbiAgICAubWFwKChhKSA9PiBKU09OLnN0cmluZ2lmeShhKSlcbiAgICAuam9pbignLCcpfSlgO1xufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZUtleVN0cmluZyhcbiAgb3B0aW9uczogQ2FjaGluZ09wdGlvbnMsXG4gIHNjb3BlOiBhbnksXG4gIGFyZ3M6IGFueVtdLFxuKTogc3RyaW5nIHtcbiAgcmV0dXJuIHR5cGVvZiBvcHRpb25zLmtleSA9PT0gJ3N0cmluZydcbiAgICA/IG9wdGlvbnMua2V5XG4gICAgOiB0eXBlb2Ygb3B0aW9ucy5rZXkgPT09ICdmdW5jdGlvbidcbiAgICA/IG9wdGlvbnMua2V5LmFwcGx5KHNjb3BlLCBhcmdzKVxuICAgIDogY3JlYXRlQ2FjaGVLZXkob3B0aW9ucy5uYW1lc3BhY2UsIGFyZ3MpO1xufVxuXG4vKipcbiAqIENhY2hpbmcgbWFuYWdlciBmb3IgYXN5bmMgbWV0aG9kc1xuICpcbiAqIEBjbGFzc1xuICogQGNvbnN0cnVjdG9yXG4gKi9cbmV4cG9ydCBjbGFzcyBDYWNoZSB7XG4gIHByaXZhdGUgX2VudHJpZXM6IHsgW2tleTogc3RyaW5nXTogQ2FjaGVFbnRyeTxhbnk+IH0gPSB7fTtcblxuICAvKipcbiAgICogcmV0cml2ZSBjYWNoZSBlbnRyeSwgb3IgY3JlYXRlIGlmIG5vdCBleGlzdHMuXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBba2V5XSAtIEtleSBvZiBjYWNoZSBlbnRyeVxuICAgKiBAcmV0dXJucyB7Q2FjaGVFbnRyeX1cbiAgICovXG4gIGdldChrZXk6IHN0cmluZykge1xuICAgIGlmICh0aGlzLl9lbnRyaWVzW2tleV0pIHtcbiAgICAgIHJldHVybiB0aGlzLl9lbnRyaWVzW2tleV07XG4gICAgfVxuICAgIGNvbnN0IGVudHJ5ID0gbmV3IENhY2hlRW50cnkoKTtcbiAgICB0aGlzLl9lbnRyaWVzW2tleV0gPSBlbnRyeTtcbiAgICByZXR1cm4gZW50cnk7XG4gIH1cblxuICAvKipcbiAgICogY2xlYXIgY2FjaGUgZW50cmllcyBwcmVmaXggbWF0Y2hpbmcgZ2l2ZW4ga2V5XG4gICAqL1xuICBjbGVhcihrZXk/OiBzdHJpbmcpIHtcbiAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXModGhpcy5fZW50cmllcykpIHtcbiAgICAgIGlmICgha2V5IHx8IGsuaW5kZXhPZihrZXkpID09PSAwKSB7XG4gICAgICAgIHRoaXMuX2VudHJpZXNba10uY2xlYXIoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRW5hYmxlIGNhY2hpbmcgZm9yIGFzeW5jIGNhbGwgZm4gdG8gbG9va3VwIHRoZSByZXNwb25zZSBjYWNoZSBmaXJzdCxcbiAgICogdGhlbiBpbnZva2Ugb3JpZ2luYWwgaWYgbm8gY2FjaGVkIHZhbHVlLlxuICAgKi9cbiAgY3JlYXRlQ2FjaGVkRnVuY3Rpb248Rm4gZXh0ZW5kcyBGdW5jdGlvbj4oXG4gICAgZm46IEZuLFxuICAgIHNjb3BlOiBhbnksXG4gICAgb3B0aW9uczogQ2FjaGluZ09wdGlvbnMgPSB7IHN0cmF0ZWd5OiAnTk9DQUNIRScgfSxcbiAgKTogQ2FjaGVkRnVuY3Rpb248Rm4+IHtcbiAgICBjb25zdCBzdHJhdGVneSA9IG9wdGlvbnMuc3RyYXRlZ3k7XG4gICAgY29uc3QgJGZuOiBhbnkgPSAoLi4uYXJnczogYW55W10pID0+IHtcbiAgICAgIGNvbnN0IGtleSA9IGdlbmVyYXRlS2V5U3RyaW5nKG9wdGlvbnMsIHNjb3BlLCBhcmdzKTtcbiAgICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5nZXQoa2V5KTtcbiAgICAgIGNvbnN0IGV4ZWN1dGVGZXRjaCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgZW50cnkuX2ZldGNoaW5nID0gdHJ1ZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbi5hcHBseShzY29wZSB8fCB0aGlzLCBhcmdzKTtcbiAgICAgICAgICBlbnRyeS5zZXQoeyBlcnJvcjogdW5kZWZpbmVkLCByZXN1bHQgfSk7XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBlbnRyeS5zZXQoeyBlcnJvcjogZXJyb3IgYXMgRXJyb3IsIHJlc3VsdDogdW5kZWZpbmVkIH0pO1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgbGV0IHZhbHVlO1xuICAgICAgc3dpdGNoIChzdHJhdGVneSkge1xuICAgICAgICBjYXNlICdJTU1FRElBVEUnOlxuICAgICAgICAgIHZhbHVlID0gZW50cnkuZ2V0KCk7XG4gICAgICAgICAgaWYgKCF2YWx1ZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGdW5jdGlvbiBjYWxsIHJlc3VsdCBpcyBub3QgY2FjaGVkIHlldC4nKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbHVlLmVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyB2YWx1ZS5lcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHZhbHVlLnJlc3VsdDtcbiAgICAgICAgY2FzZSAnSElUJzpcbiAgICAgICAgICByZXR1cm4gKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGlmICghZW50cnkuX2ZldGNoaW5nKSB7XG4gICAgICAgICAgICAgIC8vIG9ubHkgd2hlbiBubyBvdGhlciBjbGllbnQgaXMgY2FsbGluZyBmdW5jdGlvblxuICAgICAgICAgICAgICBhd2FpdCBleGVjdXRlRmV0Y2goKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIGVudHJ5LmdldCgoeyBlcnJvciwgcmVzdWx0IH0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgZWxzZSByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSkoKTtcbiAgICAgICAgY2FzZSAnTk9DQUNIRSc6XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuIGV4ZWN1dGVGZXRjaCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgJGZuLmNsZWFyID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSBnZW5lcmF0ZUtleVN0cmluZyhvcHRpb25zLCBzY29wZSwgYXJncyk7XG4gICAgICB0aGlzLmNsZWFyKGtleSk7XG4gICAgfTtcbiAgICByZXR1cm4gJGZuIGFzIENhY2hlZEZ1bmN0aW9uPEZuPjtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDYWNoZTtcbiJdfQ==