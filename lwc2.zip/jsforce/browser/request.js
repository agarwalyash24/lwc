import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _keysInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/keys";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import "regenerator-runtime/runtime";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context5; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context5 = Object.prototype.toString.call(o)).call(_context5, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import fetch from 'node-fetch';
import AbortController from 'abort-controller';
import createHttpsProxyAgent from 'https-proxy-agent';
import { createHttpRequestHandlerStreams, executeWithTimeout, isRedirect, performRedirectRequest } from './request-helper';

/**
 *
 */
var defaults = {};
/**
 *
 */

export function setDefaults(defaults_) {
  defaults = defaults_;
}
/**
 *
 */

function startFetchRequest(_x, _x2, _x3, _x4, _x5) {
  return _startFetchRequest.apply(this, arguments);
}
/**
 *
 */


function _startFetchRequest() {
  _startFetchRequest = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(request, options, input, output, emitter) {
    var _context;

    var counter,
        httpProxy,
        followRedirect,
        agent,
        url,
        body,
        rrequest,
        controller,
        res,
        headers,
        _iterator,
        _step,
        headerName,
        response,
        _args = arguments;

    return _regeneratorRuntime.wrap(function _callee$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            counter = _args.length > 5 && _args[5] !== undefined ? _args[5] : 0;
            httpProxy = options.httpProxy, followRedirect = options.followRedirect;
            agent = httpProxy ? createHttpsProxyAgent(httpProxy) : undefined;
            url = request.url, body = request.body, rrequest = _objectWithoutProperties(request, ["url", "body"]);
            controller = new AbortController();
            _context2.prev = 5;
            _context2.next = 8;
            return executeWithTimeout(function () {
              return fetch(url, _objectSpread(_objectSpread(_objectSpread({}, rrequest), input && /^(post|put|patch)$/i.test(request.method) ? {
                body: input
              } : {}), {}, {
                redirect: 'manual',
                signal: controller.signal,
                agent: agent
              }));
            }, options.timeout, function () {
              return controller.abort();
            });

          case 8:
            res = _context2.sent;
            _context2.next = 15;
            break;

          case 11:
            _context2.prev = 11;
            _context2.t0 = _context2["catch"](5);
            emitter.emit('error', _context2.t0);
            return _context2.abrupt("return");

          case 15:
            headers = {};
            _iterator = _createForOfIteratorHelper(_keysInstanceProperty(_context = res.headers).call(_context));

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                headerName = _step.value;
                headers[headerName.toLowerCase()] = res.headers.get(headerName);
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            response = {
              statusCode: res.status,
              headers: headers
            };

            if (!(followRedirect && isRedirect(response.statusCode))) {
              _context2.next = 22;
              break;
            }

            try {
              performRedirectRequest(request, response, followRedirect, counter, function (req) {
                return startFetchRequest(req, options, undefined, output, emitter, counter + 1);
              });
            } catch (err) {
              emitter.emit('error', err);
            }

            return _context2.abrupt("return");

          case 22:
            emitter.emit('response', response);
            res.body.pipe(output);

          case 24:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee, null, [[5, 11]]);
  }));
  return _startFetchRequest.apply(this, arguments);
}

export default function request(req) {
  var options_ = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = _objectSpread(_objectSpread({}, defaults), options_);

  var _createHttpRequestHan = createHttpRequestHandlerStreams(req),
      input = _createHttpRequestHan.input,
      output = _createHttpRequestHan.output,
      stream = _createHttpRequestHan.stream;

  startFetchRequest(req, options, input, output, stream);
  return stream;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZXF1ZXN0LnRzIl0sIm5hbWVzIjpbImZldGNoIiwiQWJvcnRDb250cm9sbGVyIiwiY3JlYXRlSHR0cHNQcm94eUFnZW50IiwiY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImlzUmVkaXJlY3QiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZGVmYXVsdHMiLCJzZXREZWZhdWx0cyIsImRlZmF1bHRzXyIsInN0YXJ0RmV0Y2hSZXF1ZXN0IiwicmVxdWVzdCIsIm9wdGlvbnMiLCJpbnB1dCIsIm91dHB1dCIsImVtaXR0ZXIiLCJjb3VudGVyIiwiaHR0cFByb3h5IiwiZm9sbG93UmVkaXJlY3QiLCJhZ2VudCIsInVuZGVmaW5lZCIsInVybCIsImJvZHkiLCJycmVxdWVzdCIsImNvbnRyb2xsZXIiLCJ0ZXN0IiwibWV0aG9kIiwicmVkaXJlY3QiLCJzaWduYWwiLCJ0aW1lb3V0IiwiYWJvcnQiLCJyZXMiLCJlbWl0IiwiaGVhZGVycyIsImhlYWRlck5hbWUiLCJ0b0xvd2VyQ2FzZSIsImdldCIsInJlc3BvbnNlIiwic3RhdHVzQ29kZSIsInN0YXR1cyIsInJlcSIsImVyciIsInBpcGUiLCJvcHRpb25zXyIsInN0cmVhbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLE9BQU9BLEtBQVAsTUFBa0IsWUFBbEI7QUFDQSxPQUFPQyxlQUFQLE1BQTRCLGtCQUE1QjtBQUNBLE9BQU9DLHFCQUFQLE1BQWtDLG1CQUFsQztBQUNBLFNBQ0VDLCtCQURGLEVBRUVDLGtCQUZGLEVBR0VDLFVBSEYsRUFJRUMsc0JBSkYsUUFLTyxrQkFMUDs7QUFRQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQyxRQUE0QixHQUFHLEVBQW5DO0FBRUE7QUFDQTtBQUNBOztBQUNBLE9BQU8sU0FBU0MsV0FBVCxDQUFxQkMsU0FBckIsRUFBb0Q7QUFDekRGLEVBQUFBLFFBQVEsR0FBR0UsU0FBWDtBQUNEO0FBRUQ7QUFDQTtBQUNBOztTQUNlQyxpQjs7O0FBa0VmO0FBQ0E7QUFDQTs7OztnRkFwRUEsaUJBQ0VDLE9BREYsRUFFRUMsT0FGRixFQUdFQyxLQUhGLEVBSUVDLE1BSkYsRUFLRUMsT0FMRjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1FQyxZQUFBQSxPQU5GLDJEQU1vQixDQU5wQjtBQVFVQyxZQUFBQSxTQVJWLEdBUXdDTCxPQVJ4QyxDQVFVSyxTQVJWLEVBUXFCQyxjQVJyQixHQVF3Q04sT0FSeEMsQ0FRcUJNLGNBUnJCO0FBU1FDLFlBQUFBLEtBVFIsR0FTZ0JGLFNBQVMsR0FBR2YscUJBQXFCLENBQUNlLFNBQUQsQ0FBeEIsR0FBc0NHLFNBVC9EO0FBVVVDLFlBQUFBLEdBVlYsR0FVcUNWLE9BVnJDLENBVVVVLEdBVlYsRUFVZUMsSUFWZixHQVVxQ1gsT0FWckMsQ0FVZVcsSUFWZixFQVV3QkMsUUFWeEIsNEJBVXFDWixPQVZyQztBQVdRYSxZQUFBQSxVQVhSLEdBV3FCLElBQUl2QixlQUFKLEVBWHJCO0FBQUE7QUFBQTtBQUFBLG1CQWNnQkcsa0JBQWtCLENBQzVCO0FBQUEscUJBQ0VKLEtBQUssQ0FBQ3FCLEdBQUQsZ0RBQ0FFLFFBREEsR0FFQ1YsS0FBSyxJQUFJLHNCQUFzQlksSUFBdEIsQ0FBMkJkLE9BQU8sQ0FBQ2UsTUFBbkMsQ0FBVCxHQUNBO0FBQUVKLGdCQUFBQSxJQUFJLEVBQUVUO0FBQVIsZUFEQSxHQUVBLEVBSkQ7QUFLSGMsZ0JBQUFBLFFBQVEsRUFBRSxRQUxQO0FBTUhDLGdCQUFBQSxNQUFNLEVBQUVKLFVBQVUsQ0FBQ0ksTUFOaEI7QUFPSFQsZ0JBQUFBLEtBQUssRUFBTEE7QUFQRyxpQkFEUDtBQUFBLGFBRDRCLEVBVzVCUCxPQUFPLENBQUNpQixPQVhvQixFQVk1QjtBQUFBLHFCQUFNTCxVQUFVLENBQUNNLEtBQVgsRUFBTjtBQUFBLGFBWjRCLENBZGxDOztBQUFBO0FBY0lDLFlBQUFBLEdBZEo7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQTZCSWhCLFlBQUFBLE9BQU8sQ0FBQ2lCLElBQVIsQ0FBYSxPQUFiO0FBN0JKOztBQUFBO0FBZ0NRQyxZQUFBQSxPQWhDUixHQWdDMEMsRUFoQzFDO0FBQUEsbURBaUMyQixpQ0FBQUYsR0FBRyxDQUFDRSxPQUFKLGdCQWpDM0I7O0FBQUE7QUFpQ0Usa0VBQTZDO0FBQWxDQyxnQkFBQUEsVUFBa0M7QUFDM0NELGdCQUFBQSxPQUFPLENBQUNDLFVBQVUsQ0FBQ0MsV0FBWCxFQUFELENBQVAsR0FBb0NKLEdBQUcsQ0FBQ0UsT0FBSixDQUFZRyxHQUFaLENBQWdCRixVQUFoQixDQUFwQztBQUNEO0FBbkNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBb0NRRyxZQUFBQSxRQXBDUixHQW9DbUI7QUFDZkMsY0FBQUEsVUFBVSxFQUFFUCxHQUFHLENBQUNRLE1BREQ7QUFFZk4sY0FBQUEsT0FBTyxFQUFQQTtBQUZlLGFBcENuQjs7QUFBQSxrQkF3Q01mLGNBQWMsSUFBSWIsVUFBVSxDQUFDZ0MsUUFBUSxDQUFDQyxVQUFWLENBeENsQztBQUFBO0FBQUE7QUFBQTs7QUF5Q0ksZ0JBQUk7QUFDRmhDLGNBQUFBLHNCQUFzQixDQUNwQkssT0FEb0IsRUFFcEIwQixRQUZvQixFQUdwQm5CLGNBSG9CLEVBSXBCRixPQUpvQixFQUtwQixVQUFDd0IsR0FBRDtBQUFBLHVCQUNFOUIsaUJBQWlCLENBQ2Y4QixHQURlLEVBRWY1QixPQUZlLEVBR2ZRLFNBSGUsRUFJZk4sTUFKZSxFQUtmQyxPQUxlLEVBTWZDLE9BQU8sR0FBRyxDQU5LLENBRG5CO0FBQUEsZUFMb0IsQ0FBdEI7QUFlRCxhQWhCRCxDQWdCRSxPQUFPeUIsR0FBUCxFQUFZO0FBQ1oxQixjQUFBQSxPQUFPLENBQUNpQixJQUFSLENBQWEsT0FBYixFQUFzQlMsR0FBdEI7QUFDRDs7QUEzREw7O0FBQUE7QUE4REUxQixZQUFBQSxPQUFPLENBQUNpQixJQUFSLENBQWEsVUFBYixFQUF5QkssUUFBekI7QUFDQU4sWUFBQUEsR0FBRyxDQUFDVCxJQUFKLENBQVNvQixJQUFULENBQWM1QixNQUFkOztBQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBcUVBLGVBQWUsU0FBU0gsT0FBVCxDQUNiNkIsR0FEYSxFQUdMO0FBQUEsTUFEUkcsUUFDUSx1RUFEdUIsRUFDdkI7O0FBQ1IsTUFBTS9CLE9BQU8sbUNBQVFMLFFBQVIsR0FBcUJvQyxRQUFyQixDQUFiOztBQURRLDhCQUUwQnhDLCtCQUErQixDQUFDcUMsR0FBRCxDQUZ6RDtBQUFBLE1BRUEzQixLQUZBLHlCQUVBQSxLQUZBO0FBQUEsTUFFT0MsTUFGUCx5QkFFT0EsTUFGUDtBQUFBLE1BRWU4QixNQUZmLHlCQUVlQSxNQUZmOztBQUdSbEMsRUFBQUEsaUJBQWlCLENBQUM4QixHQUFELEVBQU01QixPQUFOLEVBQWVDLEtBQWYsRUFBc0JDLE1BQXRCLEVBQThCOEIsTUFBOUIsQ0FBakI7QUFDQSxTQUFPQSxNQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgRHVwbGV4LCBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IGZldGNoIGZyb20gJ25vZGUtZmV0Y2gnO1xuaW1wb3J0IEFib3J0Q29udHJvbGxlciBmcm9tICdhYm9ydC1jb250cm9sbGVyJztcbmltcG9ydCBjcmVhdGVIdHRwc1Byb3h5QWdlbnQgZnJvbSAnaHR0cHMtcHJveHktYWdlbnQnO1xuaW1wb3J0IHtcbiAgY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyxcbiAgZXhlY3V0ZVdpdGhUaW1lb3V0LFxuICBpc1JlZGlyZWN0LFxuICBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0LFxufSBmcm9tICcuL3JlcXVlc3QtaGVscGVyJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBIdHRwUmVxdWVzdE9wdGlvbnMgfSBmcm9tICcuL3R5cGVzJztcblxuLyoqXG4gKlxuICovXG5sZXQgZGVmYXVsdHM6IEh0dHBSZXF1ZXN0T3B0aW9ucyA9IHt9O1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXREZWZhdWx0cyhkZWZhdWx0c186IEh0dHBSZXF1ZXN0T3B0aW9ucykge1xuICBkZWZhdWx0cyA9IGRlZmF1bHRzXztcbn1cblxuLyoqXG4gKlxuICovXG5hc3luYyBmdW5jdGlvbiBzdGFydEZldGNoUmVxdWVzdChcbiAgcmVxdWVzdDogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgaW5wdXQ6IFJlYWRhYmxlIHwgdW5kZWZpbmVkLFxuICBvdXRwdXQ6IFdyaXRhYmxlLFxuICBlbWl0dGVyOiBFdmVudEVtaXR0ZXIsXG4gIGNvdW50ZXI6IG51bWJlciA9IDAsXG4pIHtcbiAgY29uc3QgeyBodHRwUHJveHksIGZvbGxvd1JlZGlyZWN0IH0gPSBvcHRpb25zO1xuICBjb25zdCBhZ2VudCA9IGh0dHBQcm94eSA/IGNyZWF0ZUh0dHBzUHJveHlBZ2VudChodHRwUHJveHkpIDogdW5kZWZpbmVkO1xuICBjb25zdCB7IHVybCwgYm9keSwgLi4ucnJlcXVlc3QgfSA9IHJlcXVlc3Q7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gIGxldCByZXM7XG4gIHRyeSB7XG4gICAgcmVzID0gYXdhaXQgZXhlY3V0ZVdpdGhUaW1lb3V0KFxuICAgICAgKCkgPT5cbiAgICAgICAgZmV0Y2godXJsLCB7XG4gICAgICAgICAgLi4ucnJlcXVlc3QsXG4gICAgICAgICAgLi4uKGlucHV0ICYmIC9eKHBvc3R8cHV0fHBhdGNoKSQvaS50ZXN0KHJlcXVlc3QubWV0aG9kKVxuICAgICAgICAgICAgPyB7IGJvZHk6IGlucHV0IH1cbiAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgIHJlZGlyZWN0OiAnbWFudWFsJyxcbiAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgIGFnZW50LFxuICAgICAgICB9KSxcbiAgICAgIG9wdGlvbnMudGltZW91dCxcbiAgICAgICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSxcbiAgICApO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBlbWl0dGVyLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9O1xuICBmb3IgKGNvbnN0IGhlYWRlck5hbWUgb2YgcmVzLmhlYWRlcnMua2V5cygpKSB7XG4gICAgaGVhZGVyc1toZWFkZXJOYW1lLnRvTG93ZXJDYXNlKCldID0gcmVzLmhlYWRlcnMuZ2V0KGhlYWRlck5hbWUpO1xuICB9XG4gIGNvbnN0IHJlc3BvbnNlID0ge1xuICAgIHN0YXR1c0NvZGU6IHJlcy5zdGF0dXMsXG4gICAgaGVhZGVycyxcbiAgfTtcbiAgaWYgKGZvbGxvd1JlZGlyZWN0ICYmIGlzUmVkaXJlY3QocmVzcG9uc2Uuc3RhdHVzQ29kZSkpIHtcbiAgICB0cnkge1xuICAgICAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGZvbGxvd1JlZGlyZWN0LFxuICAgICAgICBjb3VudGVyLFxuICAgICAgICAocmVxKSA9PlxuICAgICAgICAgIHN0YXJ0RmV0Y2hSZXF1ZXN0KFxuICAgICAgICAgICAgcmVxLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGVtaXR0ZXIsXG4gICAgICAgICAgICBjb3VudGVyICsgMSxcbiAgICAgICAgICApLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdHRlci5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgcmVzLmJvZHkucGlwZShvdXRwdXQpO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlcXVlc3QoXG4gIHJlcTogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnNfOiBIdHRwUmVxdWVzdE9wdGlvbnMgPSB7fSxcbik6IER1cGxleCB7XG4gIGNvbnN0IG9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzLCAuLi5vcHRpb25zXyB9O1xuICBjb25zdCB7IGlucHV0LCBvdXRwdXQsIHN0cmVhbSB9ID0gY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyhyZXEpO1xuICBzdGFydEZldGNoUmVxdWVzdChyZXEsIG9wdGlvbnMsIGlucHV0LCBvdXRwdXQsIHN0cmVhbSk7XG4gIHJldHVybiBzdHJlYW07XG59XG4iXX0=