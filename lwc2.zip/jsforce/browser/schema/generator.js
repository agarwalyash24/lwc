import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context16; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context16 = Object.prototype.toString.call(o)).call(_context16, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

import os from 'os';
import fs from 'fs-extra';
import path from 'path';
import { Cli } from '../cli/cli';
import { VERSION } from '..';
import { Command } from 'commander';

function getCacheFileDir() {
  return path.join(os.tmpdir(), 'jsforce-gen-schema-cache');
}

function getCacheFilePath(orgId) {
  return path.join(getCacheFileDir(), orgId, 'describe.json');
}

function readDescribedCache(_x) {
  return _readDescribedCache.apply(this, arguments);
}

function _readDescribedCache() {
  _readDescribedCache = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(orgId) {
    var cacheFile, data;
    return _regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            cacheFile = getCacheFilePath(orgId);
            _context.next = 4;
            return fs.readFile(cacheFile, 'utf8');

          case 4:
            data = _context.sent;
            return _context.abrupt("return", JSON.parse(data));

          case 8:
            _context.prev = 8;
            _context.t0 = _context["catch"](0);
            return _context.abrupt("return", null);

          case 11:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 8]]);
  }));
  return _readDescribedCache.apply(this, arguments);
}

function loadDescribeResult(_x2, _x3, _x4) {
  return _loadDescribeResult.apply(this, arguments);
}

function _loadDescribeResult() {
  _loadDescribeResult = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(conn, orgId, cache) {
    var _yield$conn$describeG, sos, sobjects, _iterator2, _step2, name, so, cacheFile;

    return _regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            console.info('describing global');
            _context2.next = 3;
            return conn.describeGlobal();

          case 3:
            _yield$conn$describeG = _context2.sent;
            sos = _yield$conn$describeG.sobjects;
            sobjects = [];
            _iterator2 = _createForOfIteratorHelper(sos);
            _context2.prev = 7;

            _iterator2.s();

          case 9:
            if ((_step2 = _iterator2.n()).done) {
              _context2.next = 18;
              break;
            }

            name = _step2.value.name;
            console.info('describing ' + name);
            _context2.next = 14;
            return conn.describe(name);

          case 14:
            so = _context2.sent;
            sobjects.push(so);

          case 16:
            _context2.next = 9;
            break;

          case 18:
            _context2.next = 23;
            break;

          case 20:
            _context2.prev = 20;
            _context2.t0 = _context2["catch"](7);

            _iterator2.e(_context2.t0);

          case 23:
            _context2.prev = 23;

            _iterator2.f();

            return _context2.finish(23);

          case 26:
            if (!cache) {
              _context2.next = 30;
              break;
            }

            cacheFile = getCacheFilePath(orgId);
            _context2.next = 30;
            return fs.outputFile(cacheFile, _JSON$stringify(sobjects, null, 2), 'utf8');

          case 30:
            return _context2.abrupt("return", sobjects);

          case 31:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[7, 20, 23, 26]]);
  }));
  return _loadDescribeResult.apply(this, arguments);
}

function getParentReferences(sobject) {
  var parentReferences = [];

  var _iterator = _createForOfIteratorHelper(sobject.fields),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var _step$value = _step.value,
          type = _step$value.type,
          nillable = _step$value.nillable,
          relationshipName = _step$value.relationshipName,
          referenceTo = _step$value.referenceTo;

      if (type === 'reference' && relationshipName && referenceTo && referenceTo.length > 0) {
        var parentSObject = referenceTo.length > 1 ? 'Name' : referenceTo[0];
        parentReferences.push({
          nillable: nillable,
          parentSObject: parentSObject,
          relationshipName: relationshipName
        });
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return parentReferences;
}

function getTSTypeString(type) {
  return type === 'double' || type === 'int' || type === 'currency' || type === 'percent' ? 'number' : type === 'boolean' ? 'boolean' : type === 'date' || type === 'datetime' || type === 'time' ? 'DateString' : type === 'base64' ? 'BlobString' : type === 'address' ? 'Address' : type === 'complexvalue' ? 'any' : 'string';
}

function dumpSchema(_x5, _x6, _x7, _x8, _x9) {
  return _dumpSchema.apply(this, arguments);
}

function _dumpSchema() {
  _dumpSchema = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(conn, orgId, outputFile, schemaName, cache) {
    var sobjects, out;
    return _regeneratorRuntime.wrap(function _callee3$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            if (!cache) {
              _context14.next = 6;
              break;
            }

            _context14.next = 3;
            return readDescribedCache(orgId);

          case 3:
            _context14.t1 = _context14.sent;
            _context14.next = 7;
            break;

          case 6:
            _context14.t1 = null;

          case 7:
            _context14.t0 = _context14.t1;

            if (_context14.t0) {
              _context14.next = 12;
              break;
            }

            _context14.next = 11;
            return loadDescribeResult(conn, orgId, cache);

          case 11:
            _context14.t0 = _context14.sent;

          case 12:
            sobjects = _context14.t0;
            _context14.next = 15;
            return fs.ensureFile(outputFile);

          case 15:
            out = fs.createWriteStream(outputFile, 'utf8');
            return _context14.abrupt("return", new _Promise(function (resolve, reject) {
              out.on('error', function (err) {
                return reject(err);
              });
              out.on('finish', resolve);

              var writeLine = function writeLine(message) {
                return out.write(message + '\n');
              };

              writeLine("import { Schema, SObjectDefinition, DateString, BlobString, Address } from 'jsforce';");
              writeLine('');

              var _iterator3 = _createForOfIteratorHelper(sobjects),
                  _step3;

              try {
                for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                  var _context3, _context4, _context5, _context6, _context7;

                  var sobject = _step3.value;
                  var name = sobject.name,
                      fields = sobject.fields,
                      childRelationships = sobject.childRelationships;
                  writeLine("type Fields$".concat(name, " = {"));
                  writeLine('  //');

                  var _iterator5 = _createForOfIteratorHelper(fields),
                      _step5;

                  try {
                    for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                      var _context8, _context9;

                      var _step5$value = _step5.value,
                          _name = _step5$value.name,
                          type = _step5$value.type,
                          nillable = _step5$value.nillable;
                      var tsType = getTSTypeString(type);
                      var orNull = nillable ? ' | null' : '';
                      writeLine(_concatInstanceProperty(_context8 = _concatInstanceProperty(_context9 = "  ".concat(_name, ": ")).call(_context9, tsType)).call(_context8, orNull, ";"));
                    }
                  } catch (err) {
                    _iterator5.e(err);
                  } finally {
                    _iterator5.f();
                  }

                  writeLine('};');
                  writeLine('');
                  writeLine("type ParentReferences$".concat(name, " = {"));
                  writeLine('  //');
                  var parentReferences = getParentReferences(sobject);

                  var _iterator6 = _createForOfIteratorHelper(parentReferences),
                      _step6;

                  try {
                    for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                      var _context10, _context11;

                      var _step6$value = _step6.value,
                          _nillable = _step6$value.nillable,
                          parentSObject = _step6$value.parentSObject,
                          relationshipName = _step6$value.relationshipName;

                      var _orNull = _nillable ? ' | null' : '';

                      writeLine(_concatInstanceProperty(_context10 = _concatInstanceProperty(_context11 = "  ".concat(relationshipName, ": SObjectDefinition$")).call(_context11, parentSObject)).call(_context10, _orNull, ";"));
                    }
                  } catch (err) {
                    _iterator6.e(err);
                  } finally {
                    _iterator6.f();
                  }

                  writeLine('};');
                  writeLine('');
                  writeLine("type ChildRelationships$".concat(name, " = {"));
                  writeLine('  //');

                  var _iterator7 = _createForOfIteratorHelper(childRelationships),
                      _step7;

                  try {
                    for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                      var _step7$value = _step7.value,
                          field = _step7$value.field,
                          childSObject = _step7$value.childSObject,
                          _relationshipName = _step7$value.relationshipName;

                      if (field && childSObject && _relationshipName && !/__c$/.test(field)) {
                        var _context12;

                        writeLine(_concatInstanceProperty(_context12 = "  ".concat(_relationshipName, ": SObjectDefinition$")).call(_context12, childSObject, ";"));
                      }
                    }
                  } catch (err) {
                    _iterator7.e(err);
                  } finally {
                    _iterator7.f();
                  }

                  writeLine('};');
                  writeLine('');
                  writeLine(_concatInstanceProperty(_context3 = _concatInstanceProperty(_context4 = _concatInstanceProperty(_context5 = _concatInstanceProperty(_context6 = _concatInstanceProperty(_context7 = "interface SObjectDefinition$".concat(name, " extends SObjectDefinition<'")).call(_context7, name, "'> {\n    Name: '")).call(_context6, name, "';\n    Fields: Fields$")).call(_context5, name, ";\n    ParentReferences: ParentReferences$")).call(_context4, name, ";\n    ChildRelationships: ChildRelationships$")).call(_context3, name, ";\n  }"));
                  writeLine('');
                }
              } catch (err) {
                _iterator3.e(err);
              } finally {
                _iterator3.f();
              }

              writeLine('');
              writeLine("export interface ".concat(schemaName, " extends Schema {"));
              writeLine('  SObjects: {');

              var _iterator4 = _createForOfIteratorHelper(sobjects),
                  _step4;

              try {
                for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                  var _context13;

                  var _name2 = _step4.value.name;
                  writeLine(_concatInstanceProperty(_context13 = "    ".concat(_name2, ": SObjectDefinition$")).call(_context13, _name2, ";"));
                }
              } catch (err) {
                _iterator4.e(err);
              } finally {
                _iterator4.f();
              }

              writeLine('  };');
              writeLine('}');
              out.end();
            }));

          case 17:
          case "end":
            return _context14.stop();
        }
      }
    }, _callee3);
  }));
  return _dumpSchema.apply(this, arguments);
}

/**
 *
 */
function readCommand() {
  return new Command().option('-u, --username [username]', 'Salesforce username').option('-p, --password [password]', 'Salesforce password (and security token, if available)').option('-c, --connection [connection]', 'Connection name stored in connection registry').option('-l, --loginUrl [loginUrl]', 'Salesforce login url').option('-n, --schemaName [schemaName]', 'Name of schema type', 'MySchema').requiredOption('-o, --outputFile <outputFile>', 'Generated schema file path', './schema.d.ts').option('--sandbox', 'Login to Salesforce sandbox').option('--no-cache', 'Do not generate cache file for described result in tmp directory').option('--clearCache', 'Clear all existing described cache files').version(VERSION).parse(process.argv);
}
/**
 *
 */


export default function main() {
  return _main.apply(this, arguments);
}

function _main() {
  _main = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
    var program, cli, conn;
    return _regeneratorRuntime.wrap(function _callee4$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            program = readCommand();
            cli = new Cli();
            _context15.next = 4;
            return cli.connect(program);

          case 4:
            conn = cli.getCurrentConnection();

            if (conn.userInfo) {
              _context15.next = 8;
              break;
            }

            console.error('Cannot connect to Salesforce');
            return _context15.abrupt("return");

          case 8:
            _context15.next = 10;
            return dumpSchema(conn, conn.userInfo.organizationId, program.outputFile, program.schemaName, program.cache);

          case 10:
            if (!program.clearCache) {
              _context15.next = 14;
              break;
            }

            console.log('removing cache files');
            _context15.next = 14;
            return fs.remove(getCacheFileDir());

          case 14:
            console.log("Dumped to: ".concat(program.outputFile));

          case 15:
          case "end":
            return _context15.stop();
        }
      }
    }, _callee4);
  }));
  return _main.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zY2hlbWEvZ2VuZXJhdG9yLnRzIl0sIm5hbWVzIjpbIm9zIiwiZnMiLCJwYXRoIiwiQ2xpIiwiVkVSU0lPTiIsIkNvbW1hbmQiLCJnZXRDYWNoZUZpbGVEaXIiLCJqb2luIiwidG1wZGlyIiwiZ2V0Q2FjaGVGaWxlUGF0aCIsIm9yZ0lkIiwicmVhZERlc2NyaWJlZENhY2hlIiwiY2FjaGVGaWxlIiwicmVhZEZpbGUiLCJkYXRhIiwiSlNPTiIsInBhcnNlIiwibG9hZERlc2NyaWJlUmVzdWx0IiwiY29ubiIsImNhY2hlIiwiY29uc29sZSIsImluZm8iLCJkZXNjcmliZUdsb2JhbCIsInNvcyIsInNvYmplY3RzIiwibmFtZSIsImRlc2NyaWJlIiwic28iLCJwdXNoIiwib3V0cHV0RmlsZSIsImdldFBhcmVudFJlZmVyZW5jZXMiLCJzb2JqZWN0IiwicGFyZW50UmVmZXJlbmNlcyIsImZpZWxkcyIsInR5cGUiLCJuaWxsYWJsZSIsInJlbGF0aW9uc2hpcE5hbWUiLCJyZWZlcmVuY2VUbyIsImxlbmd0aCIsInBhcmVudFNPYmplY3QiLCJnZXRUU1R5cGVTdHJpbmciLCJkdW1wU2NoZW1hIiwic2NoZW1hTmFtZSIsImVuc3VyZUZpbGUiLCJvdXQiLCJjcmVhdGVXcml0ZVN0cmVhbSIsInJlc29sdmUiLCJyZWplY3QiLCJvbiIsImVyciIsIndyaXRlTGluZSIsIm1lc3NhZ2UiLCJ3cml0ZSIsImNoaWxkUmVsYXRpb25zaGlwcyIsInRzVHlwZSIsIm9yTnVsbCIsImZpZWxkIiwiY2hpbGRTT2JqZWN0IiwidGVzdCIsImVuZCIsInJlYWRDb21tYW5kIiwib3B0aW9uIiwicmVxdWlyZWRPcHRpb24iLCJ2ZXJzaW9uIiwicHJvY2VzcyIsImFyZ3YiLCJtYWluIiwicHJvZ3JhbSIsImNsaSIsImNvbm5lY3QiLCJnZXRDdXJyZW50Q29ubmVjdGlvbiIsInVzZXJJbmZvIiwiZXJyb3IiLCJvcmdhbml6YXRpb25JZCIsImNsZWFyQ2FjaGUiLCJsb2ciLCJyZW1vdmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLEVBQVAsTUFBZSxJQUFmO0FBQ0EsT0FBT0MsRUFBUCxNQUFlLFVBQWY7QUFDQSxPQUFPQyxJQUFQLE1BQWlCLE1BQWpCO0FBRUEsU0FBU0MsR0FBVCxRQUFvQixZQUFwQjtBQUNBLFNBQXFCQyxPQUFyQixRQUFvQyxJQUFwQztBQUNBLFNBQVNDLE9BQVQsUUFBd0IsV0FBeEI7O0FBSUEsU0FBU0MsZUFBVCxHQUEyQjtBQUN6QixTQUFPSixJQUFJLENBQUNLLElBQUwsQ0FBVVAsRUFBRSxDQUFDUSxNQUFILEVBQVYsRUFBdUIsMEJBQXZCLENBQVA7QUFDRDs7QUFFRCxTQUFTQyxnQkFBVCxDQUEwQkMsS0FBMUIsRUFBeUM7QUFDdkMsU0FBT1IsSUFBSSxDQUFDSyxJQUFMLENBQVVELGVBQWUsRUFBekIsRUFBNkJJLEtBQTdCLEVBQW9DLGVBQXBDLENBQVA7QUFDRDs7U0FFY0Msa0I7Ozs7O2lGQUFmLGlCQUNFRCxLQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSVVFLFlBQUFBLFNBSlYsR0FJc0JILGdCQUFnQixDQUFDQyxLQUFELENBSnRDO0FBQUE7QUFBQSxtQkFLdUJULEVBQUUsQ0FBQ1ksUUFBSCxDQUFZRCxTQUFaLEVBQXVCLE1BQXZCLENBTHZCOztBQUFBO0FBS1VFLFlBQUFBLElBTFY7QUFBQSw2Q0FNV0MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLElBQVgsQ0FOWDs7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FRVyxJQVJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7U0FZZUcsa0I7Ozs7O2lGQUFmLGtCQUNFQyxJQURGLEVBRUVSLEtBRkYsRUFHRVMsS0FIRjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0VDLFlBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLG1CQUFiO0FBTEY7QUFBQSxtQkFNa0NILElBQUksQ0FBQ0ksY0FBTCxFQU5sQzs7QUFBQTtBQUFBO0FBTW9CQyxZQUFBQSxHQU5wQix5QkFNVUMsUUFOVjtBQU9RQSxZQUFBQSxRQVBSLEdBT21CLEVBUG5CO0FBQUEsb0RBUXlCRCxHQVJ6QjtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBUWVFLFlBQUFBLElBUmYsZ0JBUWVBLElBUmY7QUFTSUwsWUFBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWEsZ0JBQWdCSSxJQUE3QjtBQVRKO0FBQUEsbUJBVXFCUCxJQUFJLENBQUNRLFFBQUwsQ0FBY0QsSUFBZCxDQVZyQjs7QUFBQTtBQVVVRSxZQUFBQSxFQVZWO0FBV0lILFlBQUFBLFFBQVEsQ0FBQ0ksSUFBVCxDQUFjRCxFQUFkOztBQVhKO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7QUFBQSxpQkFhTVIsS0FiTjtBQUFBO0FBQUE7QUFBQTs7QUFjVVAsWUFBQUEsU0FkVixHQWNzQkgsZ0JBQWdCLENBQUNDLEtBQUQsQ0FkdEM7QUFBQTtBQUFBLG1CQWVVVCxFQUFFLENBQUM0QixVQUFILENBQWNqQixTQUFkLEVBQXlCLGdCQUFlWSxRQUFmLEVBQXlCLElBQXpCLEVBQStCLENBQS9CLENBQXpCLEVBQTRELE1BQTVELENBZlY7O0FBQUE7QUFBQSw4Q0FpQlNBLFFBakJUOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7QUFvQkEsU0FBU00sbUJBQVQsQ0FBNkJDLE9BQTdCLEVBQTZEO0FBQzNELE1BQU1DLGdCQUFnQixHQUFHLEVBQXpCOztBQUQyRCw2Q0FPdERELE9BQU8sQ0FBQ0UsTUFQOEM7QUFBQTs7QUFBQTtBQUUzRCx3REFLcUI7QUFBQTtBQUFBLFVBSm5CQyxJQUltQixlQUpuQkEsSUFJbUI7QUFBQSxVQUhuQkMsUUFHbUIsZUFIbkJBLFFBR21CO0FBQUEsVUFGbkJDLGdCQUVtQixlQUZuQkEsZ0JBRW1CO0FBQUEsVUFEbkJDLFdBQ21CLGVBRG5CQSxXQUNtQjs7QUFDbkIsVUFDRUgsSUFBSSxLQUFLLFdBQVQsSUFDQUUsZ0JBREEsSUFFQUMsV0FGQSxJQUdBQSxXQUFXLENBQUNDLE1BQVosR0FBcUIsQ0FKdkIsRUFLRTtBQUNBLFlBQU1DLGFBQWEsR0FBR0YsV0FBVyxDQUFDQyxNQUFaLEdBQXFCLENBQXJCLEdBQXlCLE1BQXpCLEdBQWtDRCxXQUFXLENBQUMsQ0FBRCxDQUFuRTtBQUNBTCxRQUFBQSxnQkFBZ0IsQ0FBQ0osSUFBakIsQ0FBc0I7QUFBRU8sVUFBQUEsUUFBUSxFQUFSQSxRQUFGO0FBQVlJLFVBQUFBLGFBQWEsRUFBYkEsYUFBWjtBQUEyQkgsVUFBQUEsZ0JBQWdCLEVBQWhCQTtBQUEzQixTQUF0QjtBQUNEO0FBQ0Y7QUFqQjBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBa0IzRCxTQUFPSixnQkFBUDtBQUNEOztBQUVELFNBQVNRLGVBQVQsQ0FBeUJOLElBQXpCLEVBQStDO0FBQzdDLFNBQU9BLElBQUksS0FBSyxRQUFULElBQ0xBLElBQUksS0FBSyxLQURKLElBRUxBLElBQUksS0FBSyxVQUZKLElBR0xBLElBQUksS0FBSyxTQUhKLEdBSUgsUUFKRyxHQUtIQSxJQUFJLEtBQUssU0FBVCxHQUNBLFNBREEsR0FFQUEsSUFBSSxLQUFLLE1BQVQsSUFBbUJBLElBQUksS0FBSyxVQUE1QixJQUEwQ0EsSUFBSSxLQUFLLE1BQW5ELEdBQ0EsWUFEQSxHQUVBQSxJQUFJLEtBQUssUUFBVCxHQUNBLFlBREEsR0FFQUEsSUFBSSxLQUFLLFNBQVQsR0FDQSxTQURBLEdBRUFBLElBQUksS0FBSyxjQUFULEdBQ0EsS0FEQSxHQUVBLFFBZko7QUFnQkQ7O1NBRWNPLFU7Ozs7O3lFQUFmLGtCQUNFdkIsSUFERixFQUVFUixLQUZGLEVBR0VtQixVQUhGLEVBSUVhLFVBSkYsRUFLRXZCLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUtBLEtBUkw7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxtQkFRbUJSLGtCQUFrQixDQUFDRCxLQUFELENBUnJDOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsNEJBUStDLElBUi9DOztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxtQkFTV08sa0JBQWtCLENBQUNDLElBQUQsRUFBT1IsS0FBUCxFQUFjUyxLQUFkLENBVDdCOztBQUFBO0FBQUE7O0FBQUE7QUFPUUssWUFBQUEsUUFQUjtBQUFBO0FBQUEsbUJBVVF2QixFQUFFLENBQUMwQyxVQUFILENBQWNkLFVBQWQsQ0FWUjs7QUFBQTtBQVdRZSxZQUFBQSxHQVhSLEdBV2MzQyxFQUFFLENBQUM0QyxpQkFBSCxDQUFxQmhCLFVBQXJCLEVBQWlDLE1BQWpDLENBWGQ7QUFBQSwrQ0FZUyxhQUFZLFVBQUNpQixPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDdENILGNBQUFBLEdBQUcsQ0FBQ0ksRUFBSixDQUFPLE9BQVAsRUFBZ0IsVUFBQ0MsR0FBRDtBQUFBLHVCQUFTRixNQUFNLENBQUNFLEdBQUQsQ0FBZjtBQUFBLGVBQWhCO0FBQ0FMLGNBQUFBLEdBQUcsQ0FBQ0ksRUFBSixDQUFPLFFBQVAsRUFBaUJGLE9BQWpCOztBQUNBLGtCQUFNSSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxPQUFEO0FBQUEsdUJBQXFCUCxHQUFHLENBQUNRLEtBQUosQ0FBVUQsT0FBTyxHQUFHLElBQXBCLENBQXJCO0FBQUEsZUFBbEI7O0FBQ0FELGNBQUFBLFNBQVMsQ0FDUCx1RkFETyxDQUFUO0FBR0FBLGNBQUFBLFNBQVMsQ0FBQyxFQUFELENBQVQ7O0FBUHNDLDBEQVFoQjFCLFFBUmdCO0FBQUE7O0FBQUE7QUFRdEMsdUVBQWdDO0FBQUE7O0FBQUEsc0JBQXJCTyxPQUFxQjtBQUFBLHNCQUN0Qk4sSUFEc0IsR0FDZU0sT0FEZixDQUN0Qk4sSUFEc0I7QUFBQSxzQkFDaEJRLE1BRGdCLEdBQ2VGLE9BRGYsQ0FDaEJFLE1BRGdCO0FBQUEsc0JBQ1JvQixrQkFEUSxHQUNldEIsT0FEZixDQUNSc0Isa0JBRFE7QUFFOUJILGtCQUFBQSxTQUFTLHVCQUFnQnpCLElBQWhCLFVBQVQ7QUFDQXlCLGtCQUFBQSxTQUFTLENBQUMsTUFBRCxDQUFUOztBQUg4Qiw4REFJU2pCLE1BSlQ7QUFBQTs7QUFBQTtBQUk5QiwyRUFBK0M7QUFBQTs7QUFBQTtBQUFBLDBCQUFsQ1IsS0FBa0MsZ0JBQWxDQSxJQUFrQztBQUFBLDBCQUE1QlMsSUFBNEIsZ0JBQTVCQSxJQUE0QjtBQUFBLDBCQUF0QkMsUUFBc0IsZ0JBQXRCQSxRQUFzQjtBQUM3QywwQkFBTW1CLE1BQU0sR0FBR2QsZUFBZSxDQUFDTixJQUFELENBQTlCO0FBQ0EsMEJBQU1xQixNQUFNLEdBQUdwQixRQUFRLEdBQUcsU0FBSCxHQUFlLEVBQXRDO0FBQ0FlLHNCQUFBQSxTQUFTLHFGQUFNekIsS0FBTix5QkFBZTZCLE1BQWYsbUJBQXdCQyxNQUF4QixPQUFUO0FBQ0Q7QUFSNkI7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFTOUJMLGtCQUFBQSxTQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0FBLGtCQUFBQSxTQUFTLENBQUMsRUFBRCxDQUFUO0FBQ0FBLGtCQUFBQSxTQUFTLGlDQUEwQnpCLElBQTFCLFVBQVQ7QUFDQXlCLGtCQUFBQSxTQUFTLENBQUMsTUFBRCxDQUFUO0FBQ0Esc0JBQU1sQixnQkFBZ0IsR0FBR0YsbUJBQW1CLENBQUNDLE9BQUQsQ0FBNUM7O0FBYjhCLDhEQWtCekJDLGdCQWxCeUI7QUFBQTs7QUFBQTtBQWM5QiwyRUFJdUI7QUFBQTs7QUFBQTtBQUFBLDBCQUhyQkcsU0FHcUIsZ0JBSHJCQSxRQUdxQjtBQUFBLDBCQUZyQkksYUFFcUIsZ0JBRnJCQSxhQUVxQjtBQUFBLDBCQURyQkgsZ0JBQ3FCLGdCQURyQkEsZ0JBQ3FCOztBQUNyQiwwQkFBTW1CLE9BQU0sR0FBR3BCLFNBQVEsR0FBRyxTQUFILEdBQWUsRUFBdEM7O0FBQ0FlLHNCQUFBQSxTQUFTLHVGQUNGZCxnQkFERSw0Q0FDcUNHLGFBRHJDLG9CQUNxRGdCLE9BRHJELE9BQVQ7QUFHRDtBQXZCNkI7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUF3QjlCTCxrQkFBQUEsU0FBUyxDQUFDLElBQUQsQ0FBVDtBQUNBQSxrQkFBQUEsU0FBUyxDQUFDLEVBQUQsQ0FBVDtBQUNBQSxrQkFBQUEsU0FBUyxtQ0FBNEJ6QixJQUE1QixVQUFUO0FBQ0F5QixrQkFBQUEsU0FBUyxDQUFDLE1BQUQsQ0FBVDs7QUEzQjhCLDhEQWdDekJHLGtCQWhDeUI7QUFBQTs7QUFBQTtBQTRCOUIsMkVBSXlCO0FBQUE7QUFBQSwwQkFIdkJHLEtBR3VCLGdCQUh2QkEsS0FHdUI7QUFBQSwwQkFGdkJDLFlBRXVCLGdCQUZ2QkEsWUFFdUI7QUFBQSwwQkFEdkJyQixpQkFDdUIsZ0JBRHZCQSxnQkFDdUI7O0FBQ3ZCLDBCQUFJb0IsS0FBSyxJQUFJQyxZQUFULElBQXlCckIsaUJBQXpCLElBQTZDLENBQUMsT0FBT3NCLElBQVAsQ0FBWUYsS0FBWixDQUFsRCxFQUFzRTtBQUFBOztBQUNwRU4sd0JBQUFBLFNBQVMsa0RBQ0ZkLGlCQURFLDRDQUNxQ3FCLFlBRHJDLE9BQVQ7QUFHRDtBQUNGO0FBdEM2QjtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQXVDOUJQLGtCQUFBQSxTQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0FBLGtCQUFBQSxTQUFTLENBQUMsRUFBRCxDQUFUO0FBQ0FBLGtCQUFBQSxTQUFTLDJOQUN3QnpCLElBRHhCLG1EQUMyREEsSUFEM0Qsd0NBRUZBLElBRkUsOENBR01BLElBSE4saUVBSTBCQSxJQUoxQixxRUFLOEJBLElBTDlCLFlBQVQ7QUFRQXlCLGtCQUFBQSxTQUFTLENBQUMsRUFBRCxDQUFUO0FBQ0Q7QUExRHFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBMkR0Q0EsY0FBQUEsU0FBUyxDQUFDLEVBQUQsQ0FBVDtBQUNBQSxjQUFBQSxTQUFTLDRCQUFxQlIsVUFBckIsdUJBQVQ7QUFDQVEsY0FBQUEsU0FBUyxDQUFDLGVBQUQsQ0FBVDs7QUE3RHNDLDBEQThEZjFCLFFBOURlO0FBQUE7O0FBQUE7QUE4RHRDLHVFQUFpQztBQUFBOztBQUFBLHNCQUFwQkMsTUFBb0IsZ0JBQXBCQSxJQUFvQjtBQUMvQnlCLGtCQUFBQSxTQUFTLG9EQUFRekIsTUFBUiw0Q0FBbUNBLE1BQW5DLE9BQVQ7QUFDRDtBQWhFcUM7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFpRXRDeUIsY0FBQUEsU0FBUyxDQUFDLE1BQUQsQ0FBVDtBQUNBQSxjQUFBQSxTQUFTLENBQUMsR0FBRCxDQUFUO0FBQ0FOLGNBQUFBLEdBQUcsQ0FBQ2UsR0FBSjtBQUNELGFBcEVNLENBWlQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRzs7OztBQThGQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxXQUFULEdBQXlDO0FBQ3ZDLFNBQU8sSUFBSXZELE9BQUosR0FDSndELE1BREksQ0FDRywyQkFESCxFQUNnQyxxQkFEaEMsRUFFSkEsTUFGSSxDQUdILDJCQUhHLEVBSUgsd0RBSkcsRUFNSkEsTUFOSSxDQU9ILCtCQVBHLEVBUUgsK0NBUkcsRUFVSkEsTUFWSSxDQVVHLDJCQVZILEVBVWdDLHNCQVZoQyxFQVdKQSxNQVhJLENBV0csK0JBWEgsRUFXb0MscUJBWHBDLEVBVzJELFVBWDNELEVBWUpDLGNBWkksQ0FhSCwrQkFiRyxFQWNILDRCQWRHLEVBZUgsZUFmRyxFQWlCSkQsTUFqQkksQ0FpQkcsV0FqQkgsRUFpQmdCLDZCQWpCaEIsRUFrQkpBLE1BbEJJLENBbUJILFlBbkJHLEVBb0JILGtFQXBCRyxFQXNCSkEsTUF0QkksQ0FzQkcsY0F0QkgsRUFzQm1CLDBDQXRCbkIsRUF1QkpFLE9BdkJJLENBdUJJM0QsT0F2QkosRUF3QkpZLEtBeEJJLENBd0JFZ0QsT0FBTyxDQUFDQyxJQXhCVixDQUFQO0FBeUJEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSx3QkFBOEJDLElBQTlCO0FBQUE7QUFBQTs7O21FQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNQQyxZQUFBQSxPQURPLEdBQ0dQLFdBQVcsRUFEZDtBQUVQUSxZQUFBQSxHQUZPLEdBRUQsSUFBSWpFLEdBQUosRUFGQztBQUFBO0FBQUEsbUJBR1BpRSxHQUFHLENBQUNDLE9BQUosQ0FBWUYsT0FBWixDQUhPOztBQUFBO0FBSVBqRCxZQUFBQSxJQUpPLEdBSUFrRCxHQUFHLENBQUNFLG9CQUFKLEVBSkE7O0FBQUEsZ0JBS1JwRCxJQUFJLENBQUNxRCxRQUxHO0FBQUE7QUFBQTtBQUFBOztBQU1YbkQsWUFBQUEsT0FBTyxDQUFDb0QsS0FBUixDQUFjLDhCQUFkO0FBTlc7O0FBQUE7QUFBQTtBQUFBLG1CQVNQL0IsVUFBVSxDQUNkdkIsSUFEYyxFQUVkQSxJQUFJLENBQUNxRCxRQUFMLENBQWNFLGNBRkEsRUFHZE4sT0FBTyxDQUFDdEMsVUFITSxFQUlkc0MsT0FBTyxDQUFDekIsVUFKTSxFQUtkeUIsT0FBTyxDQUFDaEQsS0FMTSxDQVRIOztBQUFBO0FBQUEsaUJBZ0JUZ0QsT0FBTyxDQUFDTyxVQWhCQztBQUFBO0FBQUE7QUFBQTs7QUFpQlh0RCxZQUFBQSxPQUFPLENBQUN1RCxHQUFSLENBQVksc0JBQVo7QUFqQlc7QUFBQSxtQkFrQkwxRSxFQUFFLENBQUMyRSxNQUFILENBQVV0RSxlQUFlLEVBQXpCLENBbEJLOztBQUFBO0FBb0JiYyxZQUFBQSxPQUFPLENBQUN1RCxHQUFSLHNCQUEwQlIsT0FBTyxDQUFDdEMsVUFBbEM7O0FBcEJhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgb3MgZnJvbSAnb3MnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgRGVzY3JpYmVTT2JqZWN0UmVzdWx0IH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgQ2xpIH0gZnJvbSAnLi4vY2xpL2NsaSc7XG5pbXBvcnQgeyBDb25uZWN0aW9uLCBWRVJTSU9OIH0gZnJvbSAnLi4nO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2NvbW1hbmRlcic7XG5cbnR5cGUgVW53cmFwUHJvbWlzZTxUPiA9IFQgZXh0ZW5kcyBQcm9taXNlPGluZmVyIFU+ID8gVSA6IG5ldmVyO1xuXG5mdW5jdGlvbiBnZXRDYWNoZUZpbGVEaXIoKSB7XG4gIHJldHVybiBwYXRoLmpvaW4ob3MudG1wZGlyKCksICdqc2ZvcmNlLWdlbi1zY2hlbWEtY2FjaGUnKTtcbn1cblxuZnVuY3Rpb24gZ2V0Q2FjaGVGaWxlUGF0aChvcmdJZDogc3RyaW5nKSB7XG4gIHJldHVybiBwYXRoLmpvaW4oZ2V0Q2FjaGVGaWxlRGlyKCksIG9yZ0lkLCAnZGVzY3JpYmUuanNvbicpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWFkRGVzY3JpYmVkQ2FjaGUoXG4gIG9yZ0lkOiBzdHJpbmcsXG4pOiBQcm9taXNlPFVud3JhcFByb21pc2U8UmV0dXJuVHlwZTx0eXBlb2YgbG9hZERlc2NyaWJlUmVzdWx0Pj4gfCBudWxsPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgY2FjaGVGaWxlID0gZ2V0Q2FjaGVGaWxlUGF0aChvcmdJZCk7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGZzLnJlYWRGaWxlKGNhY2hlRmlsZSwgJ3V0ZjgnKTtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWREZXNjcmliZVJlc3VsdChcbiAgY29ubjogQ29ubmVjdGlvbixcbiAgb3JnSWQ6IHN0cmluZyxcbiAgY2FjaGU/OiBib29sZWFuLFxuKSB7XG4gIGNvbnNvbGUuaW5mbygnZGVzY3JpYmluZyBnbG9iYWwnKTtcbiAgY29uc3QgeyBzb2JqZWN0czogc29zIH0gPSBhd2FpdCBjb25uLmRlc2NyaWJlR2xvYmFsKCk7XG4gIGNvbnN0IHNvYmplY3RzID0gW107XG4gIGZvciAoY29uc3QgeyBuYW1lIH0gb2Ygc29zKSB7XG4gICAgY29uc29sZS5pbmZvKCdkZXNjcmliaW5nICcgKyBuYW1lKTtcbiAgICBjb25zdCBzbyA9IGF3YWl0IGNvbm4uZGVzY3JpYmUobmFtZSk7XG4gICAgc29iamVjdHMucHVzaChzbyk7XG4gIH1cbiAgaWYgKGNhY2hlKSB7XG4gICAgY29uc3QgY2FjaGVGaWxlID0gZ2V0Q2FjaGVGaWxlUGF0aChvcmdJZCk7XG4gICAgYXdhaXQgZnMub3V0cHV0RmlsZShjYWNoZUZpbGUsIEpTT04uc3RyaW5naWZ5KHNvYmplY3RzLCBudWxsLCAyKSwgJ3V0ZjgnKTtcbiAgfVxuICByZXR1cm4gc29iamVjdHM7XG59XG5cbmZ1bmN0aW9uIGdldFBhcmVudFJlZmVyZW5jZXMoc29iamVjdDogRGVzY3JpYmVTT2JqZWN0UmVzdWx0KSB7XG4gIGNvbnN0IHBhcmVudFJlZmVyZW5jZXMgPSBbXTtcbiAgZm9yIChjb25zdCB7XG4gICAgdHlwZSxcbiAgICBuaWxsYWJsZSxcbiAgICByZWxhdGlvbnNoaXBOYW1lLFxuICAgIHJlZmVyZW5jZVRvLFxuICB9IG9mIHNvYmplY3QuZmllbGRzKSB7XG4gICAgaWYgKFxuICAgICAgdHlwZSA9PT0gJ3JlZmVyZW5jZScgJiZcbiAgICAgIHJlbGF0aW9uc2hpcE5hbWUgJiZcbiAgICAgIHJlZmVyZW5jZVRvICYmXG4gICAgICByZWZlcmVuY2VUby5sZW5ndGggPiAwXG4gICAgKSB7XG4gICAgICBjb25zdCBwYXJlbnRTT2JqZWN0ID0gcmVmZXJlbmNlVG8ubGVuZ3RoID4gMSA/ICdOYW1lJyA6IHJlZmVyZW5jZVRvWzBdO1xuICAgICAgcGFyZW50UmVmZXJlbmNlcy5wdXNoKHsgbmlsbGFibGUsIHBhcmVudFNPYmplY3QsIHJlbGF0aW9uc2hpcE5hbWUgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwYXJlbnRSZWZlcmVuY2VzO1xufVxuXG5mdW5jdGlvbiBnZXRUU1R5cGVTdHJpbmcodHlwZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHR5cGUgPT09ICdkb3VibGUnIHx8XG4gICAgdHlwZSA9PT0gJ2ludCcgfHxcbiAgICB0eXBlID09PSAnY3VycmVuY3knIHx8XG4gICAgdHlwZSA9PT0gJ3BlcmNlbnQnXG4gICAgPyAnbnVtYmVyJ1xuICAgIDogdHlwZSA9PT0gJ2Jvb2xlYW4nXG4gICAgPyAnYm9vbGVhbidcbiAgICA6IHR5cGUgPT09ICdkYXRlJyB8fCB0eXBlID09PSAnZGF0ZXRpbWUnIHx8IHR5cGUgPT09ICd0aW1lJ1xuICAgID8gJ0RhdGVTdHJpbmcnXG4gICAgOiB0eXBlID09PSAnYmFzZTY0J1xuICAgID8gJ0Jsb2JTdHJpbmcnXG4gICAgOiB0eXBlID09PSAnYWRkcmVzcydcbiAgICA/ICdBZGRyZXNzJ1xuICAgIDogdHlwZSA9PT0gJ2NvbXBsZXh2YWx1ZSdcbiAgICA/ICdhbnknXG4gICAgOiAnc3RyaW5nJztcbn1cblxuYXN5bmMgZnVuY3Rpb24gZHVtcFNjaGVtYShcbiAgY29ubjogQ29ubmVjdGlvbixcbiAgb3JnSWQ6IHN0cmluZyxcbiAgb3V0cHV0RmlsZTogc3RyaW5nLFxuICBzY2hlbWFOYW1lOiBzdHJpbmcsXG4gIGNhY2hlPzogYm9vbGVhbixcbikge1xuICBjb25zdCBzb2JqZWN0cyA9XG4gICAgKGNhY2hlID8gYXdhaXQgcmVhZERlc2NyaWJlZENhY2hlKG9yZ0lkKSA6IG51bGwpIHx8XG4gICAgKGF3YWl0IGxvYWREZXNjcmliZVJlc3VsdChjb25uLCBvcmdJZCwgY2FjaGUpKTtcbiAgYXdhaXQgZnMuZW5zdXJlRmlsZShvdXRwdXRGaWxlKTtcbiAgY29uc3Qgb3V0ID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0ob3V0cHV0RmlsZSwgJ3V0ZjgnKTtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBvdXQub24oJ2Vycm9yJywgKGVycikgPT4gcmVqZWN0KGVycikpO1xuICAgIG91dC5vbignZmluaXNoJywgcmVzb2x2ZSk7XG4gICAgY29uc3Qgd3JpdGVMaW5lID0gKG1lc3NhZ2U6IHN0cmluZykgPT4gb3V0LndyaXRlKG1lc3NhZ2UgKyAnXFxuJyk7XG4gICAgd3JpdGVMaW5lKFxuICAgICAgXCJpbXBvcnQgeyBTY2hlbWEsIFNPYmplY3REZWZpbml0aW9uLCBEYXRlU3RyaW5nLCBCbG9iU3RyaW5nLCBBZGRyZXNzIH0gZnJvbSAnanNmb3JjZSc7XCIsXG4gICAgKTtcbiAgICB3cml0ZUxpbmUoJycpO1xuICAgIGZvciAoY29uc3Qgc29iamVjdCBvZiBzb2JqZWN0cykge1xuICAgICAgY29uc3QgeyBuYW1lLCBmaWVsZHMsIGNoaWxkUmVsYXRpb25zaGlwcyB9ID0gc29iamVjdDtcbiAgICAgIHdyaXRlTGluZShgdHlwZSBGaWVsZHMkJHtuYW1lfSA9IHtgKTtcbiAgICAgIHdyaXRlTGluZSgnICAvLycpO1xuICAgICAgZm9yIChjb25zdCB7IG5hbWUsIHR5cGUsIG5pbGxhYmxlIH0gb2YgZmllbGRzKSB7XG4gICAgICAgIGNvbnN0IHRzVHlwZSA9IGdldFRTVHlwZVN0cmluZyh0eXBlKTtcbiAgICAgICAgY29uc3Qgb3JOdWxsID0gbmlsbGFibGUgPyAnIHwgbnVsbCcgOiAnJztcbiAgICAgICAgd3JpdGVMaW5lKGAgICR7bmFtZX06ICR7dHNUeXBlfSR7b3JOdWxsfTtgKTtcbiAgICAgIH1cbiAgICAgIHdyaXRlTGluZSgnfTsnKTtcbiAgICAgIHdyaXRlTGluZSgnJyk7XG4gICAgICB3cml0ZUxpbmUoYHR5cGUgUGFyZW50UmVmZXJlbmNlcyQke25hbWV9ID0ge2ApO1xuICAgICAgd3JpdGVMaW5lKCcgIC8vJyk7XG4gICAgICBjb25zdCBwYXJlbnRSZWZlcmVuY2VzID0gZ2V0UGFyZW50UmVmZXJlbmNlcyhzb2JqZWN0KTtcbiAgICAgIGZvciAoY29uc3Qge1xuICAgICAgICBuaWxsYWJsZSxcbiAgICAgICAgcGFyZW50U09iamVjdCxcbiAgICAgICAgcmVsYXRpb25zaGlwTmFtZSxcbiAgICAgIH0gb2YgcGFyZW50UmVmZXJlbmNlcykge1xuICAgICAgICBjb25zdCBvck51bGwgPSBuaWxsYWJsZSA/ICcgfCBudWxsJyA6ICcnO1xuICAgICAgICB3cml0ZUxpbmUoXG4gICAgICAgICAgYCAgJHtyZWxhdGlvbnNoaXBOYW1lfTogU09iamVjdERlZmluaXRpb24kJHtwYXJlbnRTT2JqZWN0fSR7b3JOdWxsfTtgLFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgd3JpdGVMaW5lKCd9OycpO1xuICAgICAgd3JpdGVMaW5lKCcnKTtcbiAgICAgIHdyaXRlTGluZShgdHlwZSBDaGlsZFJlbGF0aW9uc2hpcHMkJHtuYW1lfSA9IHtgKTtcbiAgICAgIHdyaXRlTGluZSgnICAvLycpO1xuICAgICAgZm9yIChjb25zdCB7XG4gICAgICAgIGZpZWxkLFxuICAgICAgICBjaGlsZFNPYmplY3QsXG4gICAgICAgIHJlbGF0aW9uc2hpcE5hbWUsXG4gICAgICB9IG9mIGNoaWxkUmVsYXRpb25zaGlwcykge1xuICAgICAgICBpZiAoZmllbGQgJiYgY2hpbGRTT2JqZWN0ICYmIHJlbGF0aW9uc2hpcE5hbWUgJiYgIS9fX2MkLy50ZXN0KGZpZWxkKSkge1xuICAgICAgICAgIHdyaXRlTGluZShcbiAgICAgICAgICAgIGAgICR7cmVsYXRpb25zaGlwTmFtZX06IFNPYmplY3REZWZpbml0aW9uJCR7Y2hpbGRTT2JqZWN0fTtgLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHdyaXRlTGluZSgnfTsnKTtcbiAgICAgIHdyaXRlTGluZSgnJyk7XG4gICAgICB3cml0ZUxpbmUoXG4gICAgICAgIGBpbnRlcmZhY2UgU09iamVjdERlZmluaXRpb24kJHtuYW1lfSBleHRlbmRzIFNPYmplY3REZWZpbml0aW9uPCcke25hbWV9Jz4ge1xuICAgIE5hbWU6ICcke25hbWV9JztcbiAgICBGaWVsZHM6IEZpZWxkcyQke25hbWV9O1xuICAgIFBhcmVudFJlZmVyZW5jZXM6IFBhcmVudFJlZmVyZW5jZXMkJHtuYW1lfTtcbiAgICBDaGlsZFJlbGF0aW9uc2hpcHM6IENoaWxkUmVsYXRpb25zaGlwcyQke25hbWV9O1xuICB9YCxcbiAgICAgICk7XG4gICAgICB3cml0ZUxpbmUoJycpO1xuICAgIH1cbiAgICB3cml0ZUxpbmUoJycpO1xuICAgIHdyaXRlTGluZShgZXhwb3J0IGludGVyZmFjZSAke3NjaGVtYU5hbWV9IGV4dGVuZHMgU2NoZW1hIHtgKTtcbiAgICB3cml0ZUxpbmUoJyAgU09iamVjdHM6IHsnKTtcbiAgICBmb3IgKGNvbnN0IHsgbmFtZSB9IG9mIHNvYmplY3RzKSB7XG4gICAgICB3cml0ZUxpbmUoYCAgICAke25hbWV9OiBTT2JqZWN0RGVmaW5pdGlvbiQke25hbWV9O2ApO1xuICAgIH1cbiAgICB3cml0ZUxpbmUoJyAgfTsnKTtcbiAgICB3cml0ZUxpbmUoJ30nKTtcbiAgICBvdXQuZW5kKCk7XG4gIH0pO1xufVxuXG5pbnRlcmZhY2UgR2VuZXJhdG9yQ29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICBjb25uZWN0aW9uPzogc3RyaW5nO1xuICB1c2VybmFtZT86IHN0cmluZztcbiAgcGFzc3dvcmQ/OiBzdHJpbmc7XG4gIGxvZ2luVXJsPzogc3RyaW5nO1xuICBzYW5kYm94PzogYm9vbGVhbjtcbiAgb3V0cHV0RmlsZTogc3RyaW5nO1xuICBjYWNoZT86IGJvb2xlYW47XG4gIGNsZWFyQ2FjaGU/OiBib29sZWFuO1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHJlYWRDb21tYW5kKCk6IEdlbmVyYXRvckNvbW1hbmQge1xuICByZXR1cm4gbmV3IENvbW1hbmQoKVxuICAgIC5vcHRpb24oJy11LCAtLXVzZXJuYW1lIFt1c2VybmFtZV0nLCAnU2FsZXNmb3JjZSB1c2VybmFtZScpXG4gICAgLm9wdGlvbihcbiAgICAgICctcCwgLS1wYXNzd29yZCBbcGFzc3dvcmRdJyxcbiAgICAgICdTYWxlc2ZvcmNlIHBhc3N3b3JkIChhbmQgc2VjdXJpdHkgdG9rZW4sIGlmIGF2YWlsYWJsZSknLFxuICAgIClcbiAgICAub3B0aW9uKFxuICAgICAgJy1jLCAtLWNvbm5lY3Rpb24gW2Nvbm5lY3Rpb25dJyxcbiAgICAgICdDb25uZWN0aW9uIG5hbWUgc3RvcmVkIGluIGNvbm5lY3Rpb24gcmVnaXN0cnknLFxuICAgIClcbiAgICAub3B0aW9uKCctbCwgLS1sb2dpblVybCBbbG9naW5VcmxdJywgJ1NhbGVzZm9yY2UgbG9naW4gdXJsJylcbiAgICAub3B0aW9uKCctbiwgLS1zY2hlbWFOYW1lIFtzY2hlbWFOYW1lXScsICdOYW1lIG9mIHNjaGVtYSB0eXBlJywgJ015U2NoZW1hJylcbiAgICAucmVxdWlyZWRPcHRpb24oXG4gICAgICAnLW8sIC0tb3V0cHV0RmlsZSA8b3V0cHV0RmlsZT4nLFxuICAgICAgJ0dlbmVyYXRlZCBzY2hlbWEgZmlsZSBwYXRoJyxcbiAgICAgICcuL3NjaGVtYS5kLnRzJyxcbiAgICApXG4gICAgLm9wdGlvbignLS1zYW5kYm94JywgJ0xvZ2luIHRvIFNhbGVzZm9yY2Ugc2FuZGJveCcpXG4gICAgLm9wdGlvbihcbiAgICAgICctLW5vLWNhY2hlJyxcbiAgICAgICdEbyBub3QgZ2VuZXJhdGUgY2FjaGUgZmlsZSBmb3IgZGVzY3JpYmVkIHJlc3VsdCBpbiB0bXAgZGlyZWN0b3J5JyxcbiAgICApXG4gICAgLm9wdGlvbignLS1jbGVhckNhY2hlJywgJ0NsZWFyIGFsbCBleGlzdGluZyBkZXNjcmliZWQgY2FjaGUgZmlsZXMnKVxuICAgIC52ZXJzaW9uKFZFUlNJT04pXG4gICAgLnBhcnNlKHByb2Nlc3MuYXJndikgYXMgR2VuZXJhdG9yQ29tbWFuZDtcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICBjb25zdCBwcm9ncmFtID0gcmVhZENvbW1hbmQoKTtcbiAgY29uc3QgY2xpID0gbmV3IENsaSgpO1xuICBhd2FpdCBjbGkuY29ubmVjdChwcm9ncmFtKTtcbiAgY29uc3QgY29ubiA9IGNsaS5nZXRDdXJyZW50Q29ubmVjdGlvbigpO1xuICBpZiAoIWNvbm4udXNlckluZm8pIHtcbiAgICBjb25zb2xlLmVycm9yKCdDYW5ub3QgY29ubmVjdCB0byBTYWxlc2ZvcmNlJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGF3YWl0IGR1bXBTY2hlbWEoXG4gICAgY29ubixcbiAgICBjb25uLnVzZXJJbmZvLm9yZ2FuaXphdGlvbklkLFxuICAgIHByb2dyYW0ub3V0cHV0RmlsZSxcbiAgICBwcm9ncmFtLnNjaGVtYU5hbWUsXG4gICAgcHJvZ3JhbS5jYWNoZSxcbiAgKTtcbiAgaWYgKHByb2dyYW0uY2xlYXJDYWNoZSkge1xuICAgIGNvbnNvbGUubG9nKCdyZW1vdmluZyBjYWNoZSBmaWxlcycpO1xuICAgIGF3YWl0IGZzLnJlbW92ZShnZXRDYWNoZUZpbGVEaXIoKSk7XG4gIH1cbiAgY29uc29sZS5sb2coYER1bXBlZCB0bzogJHtwcm9ncmFtLm91dHB1dEZpbGV9YCk7XG59XG4iXX0=