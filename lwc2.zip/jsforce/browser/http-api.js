import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import "regenerator-runtime/runtime";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 *
 */
import { EventEmitter } from 'events';
import xml2js from 'xml2js';
import { getLogger } from './util/logger';
import { StreamPromise } from './util/promise';
import { parseCSV } from './csv';
import { createLazyStream } from './util/stream';
/** @private */

function parseJSON(str) {
  return JSON.parse(str);
}
/** @private */


function parseXML(_x) {
  return _parseXML.apply(this, arguments);
}
/** @private */


function _parseXML() {
  _parseXML = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(str) {
    return _regeneratorRuntime.wrap(function _callee5$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            return _context8.abrupt("return", xml2js.parseStringPromise(str, {
              explicitArray: false
            }));

          case 1:
          case "end":
            return _context8.stop();
        }
      }
    }, _callee5);
  }));
  return _parseXML.apply(this, arguments);
}

function parseText(str) {
  return str;
}
/**
 * HTTP based API class with authorization hook
 */


export var HttpApi = /*#__PURE__*/function (_EventEmitter) {
  _inherits(HttpApi, _EventEmitter);

  var _super = _createSuper(HttpApi);

  function HttpApi(conn, options) {
    var _this;

    _classCallCheck(this, HttpApi);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_conn", void 0);

    _defineProperty(_assertThisInitialized(_this), "_logger", void 0);

    _defineProperty(_assertThisInitialized(_this), "_transport", void 0);

    _defineProperty(_assertThisInitialized(_this), "_responseType", void 0);

    _defineProperty(_assertThisInitialized(_this), "_noContentResponse", void 0);

    _this._conn = conn;
    _this._logger = conn._logLevel ? HttpApi._logger.createInstance(conn._logLevel) : HttpApi._logger;
    _this._responseType = options.responseType;
    _this._transport = options.transport || conn._transport;
    _this._noContentResponse = options.noContentResponse;
    return _this;
  }
  /**
   * Callout to API endpoint using http
   */


  _createClass(HttpApi, [{
    key: "request",
    value: function request(_request) {
      var _this2 = this;

      return StreamPromise.create(function () {
        var _createLazyStream = createLazyStream(),
            stream = _createLazyStream.stream,
            setStream = _createLazyStream.setStream;

        var promise = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var _context, _context2;

          var refreshDelegate, bodyPromise, _body2, requestTime, requestPromise, response, responseTime, err, body;

          return _regeneratorRuntime.wrap(function _callee$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  refreshDelegate = _this2.getRefreshDelegate();
                  /* TODO decide remove or not this section */

                  /*
                  // remember previous instance url in case it changes after a refresh
                  const lastInstanceUrl = conn.instanceUrl;
                   // check to see if the token refresh has changed the instance url
                  if(lastInstanceUrl !== conn.instanceUrl){
                    // if the instance url has changed
                    // then replace the current request urls instance url fragment
                    // with the updated instance url
                    request.url = request.url.replace(lastInstanceUrl,conn.instanceUrl);
                  }
                  */

                  if (!(refreshDelegate && refreshDelegate.isRefreshing())) {
                    _context3.next = 10;
                    break;
                  }

                  _context3.next = 4;
                  return refreshDelegate.waitRefresh();

                case 4:
                  bodyPromise = _this2.request(_request);
                  setStream(bodyPromise.stream());
                  _context3.next = 8;
                  return bodyPromise;

                case 8:
                  _body2 = _context3.sent;
                  return _context3.abrupt("return", _body2);

                case 10:
                  // hook before sending
                  _this2.beforeSend(_request);

                  _this2.emit('request', _request);

                  _this2._logger.debug(_concatInstanceProperty(_context = "<request> method=".concat(_request.method, ", url=")).call(_context, _request.url));

                  requestTime = _Date$now();
                  requestPromise = _this2._transport.httpRequest(_request);
                  setStream(requestPromise.stream());
                  _context3.prev = 16;
                  _context3.next = 19;
                  return requestPromise;

                case 19:
                  response = _context3.sent;
                  _context3.next = 26;
                  break;

                case 22:
                  _context3.prev = 22;
                  _context3.t0 = _context3["catch"](16);

                  _this2._logger.error(_context3.t0);

                  throw _context3.t0;

                case 26:
                  _context3.prev = 26;
                  responseTime = _Date$now();

                  _this2._logger.debug("elapsed time: ".concat(responseTime - requestTime, " msec"));

                  return _context3.finish(26);

                case 30:
                  if (response) {
                    _context3.next = 32;
                    break;
                  }

                  return _context3.abrupt("return");

                case 32:
                  _this2._logger.debug(_concatInstanceProperty(_context2 = "<response> status=".concat(String(response.statusCode), ", url=")).call(_context2, _request.url));

                  _this2.emit('response', response); // Refresh token if session has been expired and requires authentication
                  // when session refresh delegate is available


                  if (!(_this2.isSessionExpired(response) && refreshDelegate)) {
                    _context3.next = 38;
                    break;
                  }

                  _context3.next = 37;
                  return refreshDelegate.refresh(requestTime);

                case 37:
                  return _context3.abrupt("return", _this2.request(_request));

                case 38:
                  if (!_this2.isErrorResponse(response)) {
                    _context3.next = 43;
                    break;
                  }

                  _context3.next = 41;
                  return _this2.getError(response);

                case 41:
                  err = _context3.sent;
                  throw err;

                case 43:
                  _context3.next = 45;
                  return _this2.getResponseBody(response);

                case 45:
                  body = _context3.sent;
                  return _context3.abrupt("return", body);

                case 47:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee, null, [[16, 22, 26, 30]]);
        }))();

        return {
          stream: stream,
          promise: promise
        };
      });
    }
    /**
     * @protected
     */

  }, {
    key: "getRefreshDelegate",
    value: function getRefreshDelegate() {
      return this._conn._refreshDelegate;
    }
    /**
     * @protected
     */

  }, {
    key: "beforeSend",
    value: function beforeSend(request) {
      /* eslint-disable no-param-reassign */
      var headers = request.headers || {};

      if (this._conn.accessToken) {
        headers.Authorization = "Bearer ".concat(this._conn.accessToken);
      }

      if (this._conn._callOptions) {
        var callOptions = [];

        for (var _i = 0, _Object$keys = _Object$keys2(this._conn._callOptions); _i < _Object$keys.length; _i++) {
          var _context4;

          var name = _Object$keys[_i];
          callOptions.push(_concatInstanceProperty(_context4 = "".concat(name, "=")).call(_context4, this._conn._callOptions[name]));
        }

        headers['Sforce-Call-Options'] = callOptions.join(', ');
      }

      request.headers = headers;
    }
    /**
     * Detect response content mime-type
     * @protected
     */

  }, {
    key: "getResponseContentType",
    value: function getResponseContentType(response) {
      return this._responseType || response.headers && response.headers['content-type'];
    }
    /**
     * @private
     */

  }, {
    key: "parseResponseBody",
    value: function () {
      var _parseResponseBody = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(response) {
        var contentType, parseBody;
        return _regeneratorRuntime.wrap(function _callee2$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                contentType = this.getResponseContentType(response) || '';
                parseBody = /^(text|application)\/xml(;|$)/.test(contentType) ? parseXML : /^application\/json(;|$)/.test(contentType) ? parseJSON : /^text\/csv(;|$)/.test(contentType) ? parseCSV : parseText;
                _context5.prev = 2;
                return _context5.abrupt("return", parseBody(response.body));

              case 6:
                _context5.prev = 6;
                _context5.t0 = _context5["catch"](2);
                return _context5.abrupt("return", response.body);

              case 9:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee2, this, [[2, 6]]);
      }));

      function parseResponseBody(_x2) {
        return _parseResponseBody.apply(this, arguments);
      }

      return parseResponseBody;
    }()
    /**
     * Get response body
     * @protected
     */

  }, {
    key: "getResponseBody",
    value: function () {
      var _getResponseBody = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(response) {
        var body, err;
        return _regeneratorRuntime.wrap(function _callee3$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (!(response.statusCode === 204)) {
                  _context6.next = 2;
                  break;
                }

                return _context6.abrupt("return", this._noContentResponse);

              case 2:
                _context6.next = 4;
                return this.parseResponseBody(response);

              case 4:
                body = _context6.sent;

                if (!this.hasErrorInResponseBody(body)) {
                  _context6.next = 10;
                  break;
                }

                _context6.next = 8;
                return this.getError(response, body);

              case 8:
                err = _context6.sent;
                throw err;

              case 10:
                if (!(response.statusCode === 300)) {
                  _context6.next = 12;
                  break;
                }

                throw new HttpApiError('Multiple records found', 'MULTIPLE_CHOICES', body);

              case 12:
                return _context6.abrupt("return", body);

              case 13:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee3, this);
      }));

      function getResponseBody(_x3) {
        return _getResponseBody.apply(this, arguments);
      }

      return getResponseBody;
    }()
    /**
     * Detect session expiry
     * @protected
     */

  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      return response.statusCode === 401;
    }
    /**
     * Detect error response
     * @protected
     */

  }, {
    key: "isErrorResponse",
    value: function isErrorResponse(response) {
      return response.statusCode >= 400;
    }
    /**
     * Detect error in response body
     * @protected
     */

  }, {
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(_body) {
      return false;
    }
    /**
     * Parsing error message in response
     * @protected
     */

  }, {
    key: "parseError",
    value: function parseError(body) {
      var errors = body;
      return _Array$isArray(errors) ? errors[0] : errors;
    }
    /**
     * Get error message in response
     * @protected
     */

  }, {
    key: "getError",
    value: function () {
      var _getError = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(response, body) {
        var error;
        return _regeneratorRuntime.wrap(function _callee4$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.prev = 0;
                _context7.t0 = this;
                _context7.t1 = body;

                if (_context7.t1) {
                  _context7.next = 7;
                  break;
                }

                _context7.next = 6;
                return this.parseResponseBody(response);

              case 6:
                _context7.t1 = _context7.sent;

              case 7:
                _context7.t2 = _context7.t1;
                error = _context7.t0.parseError.call(_context7.t0, _context7.t2);
                _context7.next = 13;
                break;

              case 11:
                _context7.prev = 11;
                _context7.t3 = _context7["catch"](0);

              case 13:
                error = _typeof(error) === 'object' && error !== null && typeof error.message === 'string' ? error : {
                  errorCode: "ERROR_HTTP_".concat(response.statusCode),
                  message: response.body
                };
                return _context7.abrupt("return", new HttpApiError(error.message, error.errorCode));

              case 15:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee4, this, [[0, 11]]);
      }));

      function getError(_x4, _x5) {
        return _getError.apply(this, arguments);
      }

      return getError;
    }()
  }]);

  return HttpApi;
}(EventEmitter);
/**
 *
 */

_defineProperty(HttpApi, "_logger", getLogger('http-api'));

var HttpApiError = /*#__PURE__*/function (_Error) {
  _inherits(HttpApiError, _Error);

  var _super2 = _createSuper(HttpApiError);

  function HttpApiError(message, errorCode, content) {
    var _this3;

    _classCallCheck(this, HttpApiError);

    _this3 = _super2.call(this, message);

    _defineProperty(_assertThisInitialized(_this3), "errorCode", void 0);

    _defineProperty(_assertThisInitialized(_this3), "content", void 0);

    _this3.name = errorCode || _this3.name;
    _this3.errorCode = _this3.name;
    _this3.content = content;
    return _this3;
  }

  return HttpApiError;
}( /*#__PURE__*/_wrapNativeSuper(Error));

export default HttpApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9odHRwLWFwaS50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJ4bWwyanMiLCJnZXRMb2dnZXIiLCJTdHJlYW1Qcm9taXNlIiwicGFyc2VDU1YiLCJjcmVhdGVMYXp5U3RyZWFtIiwicGFyc2VKU09OIiwic3RyIiwiSlNPTiIsInBhcnNlIiwicGFyc2VYTUwiLCJwYXJzZVN0cmluZ1Byb21pc2UiLCJleHBsaWNpdEFycmF5IiwicGFyc2VUZXh0IiwiSHR0cEFwaSIsImNvbm4iLCJvcHRpb25zIiwiX2Nvbm4iLCJfbG9nZ2VyIiwiX2xvZ0xldmVsIiwiY3JlYXRlSW5zdGFuY2UiLCJfcmVzcG9uc2VUeXBlIiwicmVzcG9uc2VUeXBlIiwiX3RyYW5zcG9ydCIsInRyYW5zcG9ydCIsIl9ub0NvbnRlbnRSZXNwb25zZSIsIm5vQ29udGVudFJlc3BvbnNlIiwicmVxdWVzdCIsImNyZWF0ZSIsInN0cmVhbSIsInNldFN0cmVhbSIsInByb21pc2UiLCJyZWZyZXNoRGVsZWdhdGUiLCJnZXRSZWZyZXNoRGVsZWdhdGUiLCJpc1JlZnJlc2hpbmciLCJ3YWl0UmVmcmVzaCIsImJvZHlQcm9taXNlIiwiYm9keSIsImJlZm9yZVNlbmQiLCJlbWl0IiwiZGVidWciLCJtZXRob2QiLCJ1cmwiLCJyZXF1ZXN0VGltZSIsInJlcXVlc3RQcm9taXNlIiwiaHR0cFJlcXVlc3QiLCJyZXNwb25zZSIsImVycm9yIiwicmVzcG9uc2VUaW1lIiwiU3RyaW5nIiwic3RhdHVzQ29kZSIsImlzU2Vzc2lvbkV4cGlyZWQiLCJyZWZyZXNoIiwiaXNFcnJvclJlc3BvbnNlIiwiZ2V0RXJyb3IiLCJlcnIiLCJnZXRSZXNwb25zZUJvZHkiLCJfcmVmcmVzaERlbGVnYXRlIiwiaGVhZGVycyIsImFjY2Vzc1Rva2VuIiwiQXV0aG9yaXphdGlvbiIsIl9jYWxsT3B0aW9ucyIsImNhbGxPcHRpb25zIiwibmFtZSIsInB1c2giLCJqb2luIiwiY29udGVudFR5cGUiLCJnZXRSZXNwb25zZUNvbnRlbnRUeXBlIiwicGFyc2VCb2R5IiwidGVzdCIsInBhcnNlUmVzcG9uc2VCb2R5IiwiaGFzRXJyb3JJblJlc3BvbnNlQm9keSIsIkh0dHBBcGlFcnJvciIsIl9ib2R5IiwiZXJyb3JzIiwicGFyc2VFcnJvciIsIm1lc3NhZ2UiLCJlcnJvckNvZGUiLCJjb250ZW50IiwiRXJyb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFDQSxPQUFPQyxNQUFQLE1BQW1CLFFBQW5CO0FBQ0EsU0FBaUJDLFNBQWpCLFFBQWtDLGVBQWxDO0FBQ0EsU0FBU0MsYUFBVCxRQUE4QixnQkFBOUI7QUFHQSxTQUFTQyxRQUFULFFBQXlCLE9BQXpCO0FBRUEsU0FBU0MsZ0JBQVQsUUFBaUMsZUFBakM7QUFFQTs7QUFDQSxTQUFTQyxTQUFULENBQW1CQyxHQUFuQixFQUFnQztBQUM5QixTQUFPQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsR0FBWCxDQUFQO0FBQ0Q7QUFFRDs7O1NBQ2VHLFE7OztBQUlmOzs7O3VFQUpBLGtCQUF3QkgsR0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhDQUNTTixNQUFNLENBQUNVLGtCQUFQLENBQTBCSixHQUExQixFQUErQjtBQUFFSyxjQUFBQSxhQUFhLEVBQUU7QUFBakIsYUFBL0IsQ0FEVDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBS0EsU0FBU0MsU0FBVCxDQUFtQk4sR0FBbkIsRUFBZ0M7QUFDOUIsU0FBT0EsR0FBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxXQUFhTyxPQUFiO0FBQUE7O0FBQUE7O0FBU0UsbUJBQVlDLElBQVosRUFBaUNDLE9BQWpDLEVBQStDO0FBQUE7O0FBQUE7O0FBQzdDOztBQUQ2Qzs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFFN0MsVUFBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0EsVUFBS0csT0FBTCxHQUFlSCxJQUFJLENBQUNJLFNBQUwsR0FDWEwsT0FBTyxDQUFDSSxPQUFSLENBQWdCRSxjQUFoQixDQUErQkwsSUFBSSxDQUFDSSxTQUFwQyxDQURXLEdBRVhMLE9BQU8sQ0FBQ0ksT0FGWjtBQUdBLFVBQUtHLGFBQUwsR0FBcUJMLE9BQU8sQ0FBQ00sWUFBN0I7QUFDQSxVQUFLQyxVQUFMLEdBQWtCUCxPQUFPLENBQUNRLFNBQVIsSUFBcUJULElBQUksQ0FBQ1EsVUFBNUM7QUFDQSxVQUFLRSxrQkFBTCxHQUEwQlQsT0FBTyxDQUFDVSxpQkFBbEM7QUFSNkM7QUFTOUM7QUFFRDtBQUNGO0FBQ0E7OztBQXRCQTtBQUFBO0FBQUEsNEJBdUJ1QkMsUUF2QnZCLEVBdUIrRDtBQUFBOztBQUMzRCxhQUFPeEIsYUFBYSxDQUFDeUIsTUFBZCxDQUF3QixZQUFNO0FBQUEsZ0NBQ0x2QixnQkFBZ0IsRUFEWDtBQUFBLFlBQzNCd0IsTUFEMkIscUJBQzNCQSxNQUQyQjtBQUFBLFlBQ25CQyxTQURtQixxQkFDbkJBLFNBRG1COztBQUVuQyxZQUFNQyxPQUFPLEdBQUcseURBQUM7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNUQyxrQkFBQUEsZUFEUyxHQUNTLE1BQUksQ0FBQ0Msa0JBQUwsRUFEVDtBQUVmOztBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBYnVCLHdCQWVYRCxlQUFlLElBQUlBLGVBQWUsQ0FBQ0UsWUFBaEIsRUFmUjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQWdCUEYsZUFBZSxDQUFDRyxXQUFoQixFQWhCTzs7QUFBQTtBQWlCUEMsa0JBQUFBLFdBakJPLEdBaUJPLE1BQUksQ0FBQ1QsT0FBTCxDQUFhQSxRQUFiLENBakJQO0FBa0JiRyxrQkFBQUEsU0FBUyxDQUFDTSxXQUFXLENBQUNQLE1BQVosRUFBRCxDQUFUO0FBbEJhO0FBQUEseUJBbUJNTyxXQW5CTjs7QUFBQTtBQW1CUEMsa0JBQUFBLE1BbkJPO0FBQUEsb0RBb0JOQSxNQXBCTTs7QUFBQTtBQXVCZjtBQUNBLGtCQUFBLE1BQUksQ0FBQ0MsVUFBTCxDQUFnQlgsUUFBaEI7O0FBRUEsa0JBQUEsTUFBSSxDQUFDWSxJQUFMLENBQVUsU0FBVixFQUFxQlosUUFBckI7O0FBQ0Esa0JBQUEsTUFBSSxDQUFDVCxPQUFMLENBQWFzQixLQUFiLCtEQUNzQmIsUUFBTyxDQUFDYyxNQUQ5Qiw0QkFDNkNkLFFBQU8sQ0FBQ2UsR0FEckQ7O0FBR01DLGtCQUFBQSxXQTlCUyxHQThCSyxXQTlCTDtBQStCVEMsa0JBQUFBLGNBL0JTLEdBK0JRLE1BQUksQ0FBQ3JCLFVBQUwsQ0FBZ0JzQixXQUFoQixDQUE0QmxCLFFBQTVCLENBL0JSO0FBaUNmRyxrQkFBQUEsU0FBUyxDQUFDYyxjQUFjLENBQUNmLE1BQWYsRUFBRCxDQUFUO0FBakNlO0FBQUE7QUFBQSx5QkFxQ0llLGNBckNKOztBQUFBO0FBcUNiRSxrQkFBQUEsUUFyQ2E7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUF1Q2Isa0JBQUEsTUFBSSxDQUFDNUIsT0FBTCxDQUFhNkIsS0FBYjs7QUF2Q2E7O0FBQUE7QUFBQTtBQTBDUEMsa0JBQUFBLFlBMUNPLEdBMENRLFdBMUNSOztBQTJDYixrQkFBQSxNQUFJLENBQUM5QixPQUFMLENBQWFzQixLQUFiLHlCQUNtQlEsWUFBWSxHQUFHTCxXQURsQzs7QUEzQ2E7O0FBQUE7QUFBQSxzQkErQ1ZHLFFBL0NVO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBa0RmLGtCQUFBLE1BQUksQ0FBQzVCLE9BQUwsQ0FBYXNCLEtBQWIsaUVBQ3VCUyxNQUFNLENBQUNILFFBQVEsQ0FBQ0ksVUFBVixDQUQ3Qiw2QkFFSXZCLFFBQU8sQ0FBQ2UsR0FGWjs7QUFLQSxrQkFBQSxNQUFJLENBQUNILElBQUwsQ0FBVSxVQUFWLEVBQXNCTyxRQUF0QixFQXZEZSxDQXdEZjtBQUNBOzs7QUF6RGUsd0JBMERYLE1BQUksQ0FBQ0ssZ0JBQUwsQ0FBc0JMLFFBQXRCLEtBQW1DZCxlQTFEeEI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkEyRFBBLGVBQWUsQ0FBQ29CLE9BQWhCLENBQXdCVCxXQUF4QixDQTNETzs7QUFBQTtBQUFBLG9EQTRETixNQUFJLENBQUNoQixPQUFMLENBQWFBLFFBQWIsQ0E1RE07O0FBQUE7QUFBQSx1QkE4RFgsTUFBSSxDQUFDMEIsZUFBTCxDQUFxQlAsUUFBckIsQ0E5RFc7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkErREssTUFBSSxDQUFDUSxRQUFMLENBQWNSLFFBQWQsQ0EvREw7O0FBQUE7QUErRFBTLGtCQUFBQSxHQS9ETztBQUFBLHdCQWdFUEEsR0FoRU87O0FBQUE7QUFBQTtBQUFBLHlCQWtFSSxNQUFJLENBQUNDLGVBQUwsQ0FBcUJWLFFBQXJCLENBbEVKOztBQUFBO0FBa0VUVCxrQkFBQUEsSUFsRVM7QUFBQSxvREFtRVJBLElBbkVROztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUQsSUFBaEI7O0FBcUVBLGVBQU87QUFBRVIsVUFBQUEsTUFBTSxFQUFOQSxNQUFGO0FBQVVFLFVBQUFBLE9BQU8sRUFBUEE7QUFBVixTQUFQO0FBQ0QsT0F4RU0sQ0FBUDtBQXlFRDtBQUVEO0FBQ0Y7QUFDQTs7QUFyR0E7QUFBQTtBQUFBLHlDQXNHdUI7QUFDbkIsYUFBTyxLQUFLZCxLQUFMLENBQVd3QyxnQkFBbEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE1R0E7QUFBQTtBQUFBLCtCQTZHYTlCLE9BN0diLEVBNkdtQztBQUMvQjtBQUNBLFVBQU0rQixPQUFPLEdBQUcvQixPQUFPLENBQUMrQixPQUFSLElBQW1CLEVBQW5DOztBQUNBLFVBQUksS0FBS3pDLEtBQUwsQ0FBVzBDLFdBQWYsRUFBNEI7QUFDMUJELFFBQUFBLE9BQU8sQ0FBQ0UsYUFBUixvQkFBa0MsS0FBSzNDLEtBQUwsQ0FBVzBDLFdBQTdDO0FBQ0Q7O0FBQ0QsVUFBSSxLQUFLMUMsS0FBTCxDQUFXNEMsWUFBZixFQUE2QjtBQUMzQixZQUFNQyxXQUFXLEdBQUcsRUFBcEI7O0FBQ0Esd0NBQW1CLGNBQVksS0FBSzdDLEtBQUwsQ0FBVzRDLFlBQXZCLENBQW5CLGtDQUF5RDtBQUFBOztBQUFwRCxjQUFNRSxJQUFJLG1CQUFWO0FBQ0hELFVBQUFBLFdBQVcsQ0FBQ0UsSUFBWiwrQ0FBb0JELElBQXBCLHdCQUE0QixLQUFLOUMsS0FBTCxDQUFXNEMsWUFBWCxDQUF3QkUsSUFBeEIsQ0FBNUI7QUFDRDs7QUFDREwsUUFBQUEsT0FBTyxDQUFDLHFCQUFELENBQVAsR0FBaUNJLFdBQVcsQ0FBQ0csSUFBWixDQUFpQixJQUFqQixDQUFqQztBQUNEOztBQUNEdEMsTUFBQUEsT0FBTyxDQUFDK0IsT0FBUixHQUFrQkEsT0FBbEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOztBQWhJQTtBQUFBO0FBQUEsMkNBaUl5QlosUUFqSXpCLEVBaUltRTtBQUMvRCxhQUNFLEtBQUt6QixhQUFMLElBQ0N5QixRQUFRLENBQUNZLE9BQVQsSUFBb0JaLFFBQVEsQ0FBQ1ksT0FBVCxDQUFpQixjQUFqQixDQUZ2QjtBQUlEO0FBRUQ7QUFDRjtBQUNBOztBQTFJQTtBQUFBO0FBQUE7QUFBQSwwR0EySTBCWixRQTNJMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNElVb0IsZ0JBQUFBLFdBNUlWLEdBNEl3QixLQUFLQyxzQkFBTCxDQUE0QnJCLFFBQTVCLEtBQXlDLEVBNUlqRTtBQTZJVXNCLGdCQUFBQSxTQTdJVixHQTZJc0IsZ0NBQWdDQyxJQUFoQyxDQUFxQ0gsV0FBckMsSUFDZHhELFFBRGMsR0FFZCwwQkFBMEIyRCxJQUExQixDQUErQkgsV0FBL0IsSUFDQTVELFNBREEsR0FFQSxrQkFBa0IrRCxJQUFsQixDQUF1QkgsV0FBdkIsSUFDQTlELFFBREEsR0FFQVMsU0FuSlI7QUFBQTtBQUFBLGtEQXFKYXVELFNBQVMsQ0FBQ3RCLFFBQVEsQ0FBQ1QsSUFBVixDQXJKdEI7O0FBQUE7QUFBQTtBQUFBO0FBQUEsa0RBdUphUyxRQUFRLENBQUNULElBdkp0Qjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTJKRTtBQUNGO0FBQ0E7QUFDQTs7QUE5SkE7QUFBQTtBQUFBO0FBQUEsd0dBK0p3QlMsUUEvSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWdLUUEsUUFBUSxDQUFDSSxVQUFULEtBQXdCLEdBaEtoQztBQUFBO0FBQUE7QUFBQTs7QUFBQSxrREFrS2EsS0FBS3pCLGtCQWxLbEI7O0FBQUE7QUFBQTtBQUFBLHVCQW9LdUIsS0FBSzZDLGlCQUFMLENBQXVCeEIsUUFBdkIsQ0FwS3ZCOztBQUFBO0FBb0tVVCxnQkFBQUEsSUFwS1Y7O0FBQUEscUJBc0tRLEtBQUtrQyxzQkFBTCxDQUE0QmxDLElBQTVCLENBdEtSO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBdUtrQixLQUFLaUIsUUFBTCxDQUFjUixRQUFkLEVBQXdCVCxJQUF4QixDQXZLbEI7O0FBQUE7QUF1S01rQixnQkFBQUEsR0F2S047QUFBQSxzQkF3S1lBLEdBeEtaOztBQUFBO0FBQUEsc0JBMEtRVCxRQUFRLENBQUNJLFVBQVQsS0FBd0IsR0ExS2hDO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTRLWSxJQUFJc0IsWUFBSixDQUNKLHdCQURJLEVBRUosa0JBRkksRUFHSm5DLElBSEksQ0E1S1o7O0FBQUE7QUFBQSxrREFrTFdBLElBbExYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBcUxFO0FBQ0Y7QUFDQTtBQUNBOztBQXhMQTtBQUFBO0FBQUEscUNBeUxtQlMsUUF6TG5CLEVBeUwyQztBQUN2QyxhQUFPQSxRQUFRLENBQUNJLFVBQVQsS0FBd0IsR0FBL0I7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOztBQWhNQTtBQUFBO0FBQUEsb0NBaU1rQkosUUFqTWxCLEVBaU0wQztBQUN0QyxhQUFPQSxRQUFRLENBQUNJLFVBQVQsSUFBdUIsR0FBOUI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOztBQXhNQTtBQUFBO0FBQUEsMkNBeU15QnVCLEtBek16QixFQXlNa0Q7QUFDOUMsYUFBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7QUFoTkE7QUFBQTtBQUFBLCtCQWlOYXBDLElBak5iLEVBaU53QjtBQUNwQixVQUFNcUMsTUFBTSxHQUFHckMsSUFBZjtBQUNBLGFBQU8sZUFBY3FDLE1BQWQsSUFBd0JBLE1BQU0sQ0FBQyxDQUFELENBQTlCLEdBQW9DQSxNQUEzQztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7O0FBek5BO0FBQUE7QUFBQTtBQUFBLGlHQTBOaUI1QixRQTFOakIsRUEwTnlDVCxJQTFOekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkE2TmMsSUE3TmQ7QUFBQSwrQkE2TjhCQSxJQTdOOUI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx1QkE2TjZDLEtBQUtpQyxpQkFBTCxDQUF1QnhCLFFBQXZCLENBN043Qzs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE2Tk1DLGdCQUFBQSxLQTdOTixnQkE2Tm1CNEIsVUE3Tm5CO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFpT0k1QixnQkFBQUEsS0FBSyxHQUNILFFBQU9BLEtBQVAsTUFBaUIsUUFBakIsSUFDQUEsS0FBSyxLQUFLLElBRFYsSUFFQSxPQUFPQSxLQUFLLENBQUM2QixPQUFiLEtBQXlCLFFBRnpCLEdBR0k3QixLQUhKLEdBSUk7QUFDRThCLGtCQUFBQSxTQUFTLHVCQUFnQi9CLFFBQVEsQ0FBQ0ksVUFBekIsQ0FEWDtBQUVFMEIsa0JBQUFBLE9BQU8sRUFBRTlCLFFBQVEsQ0FBQ1Q7QUFGcEIsaUJBTE47QUFqT0osa0RBME9XLElBQUltQyxZQUFKLENBQWlCekIsS0FBSyxDQUFDNkIsT0FBdkIsRUFBZ0M3QixLQUFLLENBQUM4QixTQUF0QyxDQTFPWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsRUFBK0M3RSxZQUEvQztBQThPQTtBQUNBO0FBQ0E7O2dCQWhQYWMsTyxhQUNNWixTQUFTLENBQUMsVUFBRCxDOztJQWdQdEJzRSxZOzs7OztBQUdKLHdCQUFZSSxPQUFaLEVBQTZCQyxTQUE3QixFQUE2REMsT0FBN0QsRUFBNEU7QUFBQTs7QUFBQTs7QUFDMUUsZ0NBQU1GLE9BQU47O0FBRDBFOztBQUFBOztBQUUxRSxXQUFLYixJQUFMLEdBQVljLFNBQVMsSUFBSSxPQUFLZCxJQUE5QjtBQUNBLFdBQUtjLFNBQUwsR0FBaUIsT0FBS2QsSUFBdEI7QUFDQSxXQUFLZSxPQUFMLEdBQWVBLE9BQWY7QUFKMEU7QUFLM0U7OztpQ0FSd0JDLEs7O0FBVzNCLGVBQWVqRSxPQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHhtbDJqcyBmcm9tICd4bWwyanMnO1xuaW1wb3J0IHsgTG9nZ2VyLCBnZXRMb2dnZXIgfSBmcm9tICcuL3V0aWwvbG9nZ2VyJztcbmltcG9ydCB7IFN0cmVhbVByb21pc2UgfSBmcm9tICcuL3V0aWwvcHJvbWlzZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IFRyYW5zcG9ydCBmcm9tICcuL3RyYW5zcG9ydCc7XG5pbXBvcnQgeyBwYXJzZUNTViB9IGZyb20gJy4vY3N2JztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBIdHRwUmVzcG9uc2UsIE9wdGlvbmFsLCBTY2hlbWEgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IGNyZWF0ZUxhenlTdHJlYW0gfSBmcm9tICcuL3V0aWwvc3RyZWFtJztcblxuLyoqIEBwcml2YXRlICovXG5mdW5jdGlvbiBwYXJzZUpTT04oc3RyOiBzdHJpbmcpIHtcbiAgcmV0dXJuIEpTT04ucGFyc2Uoc3RyKTtcbn1cblxuLyoqIEBwcml2YXRlICovXG5hc3luYyBmdW5jdGlvbiBwYXJzZVhNTChzdHI6IHN0cmluZykge1xuICByZXR1cm4geG1sMmpzLnBhcnNlU3RyaW5nUHJvbWlzZShzdHIsIHsgZXhwbGljaXRBcnJheTogZmFsc2UgfSk7XG59XG5cbi8qKiBAcHJpdmF0ZSAqL1xuZnVuY3Rpb24gcGFyc2VUZXh0KHN0cjogc3RyaW5nKSB7XG4gIHJldHVybiBzdHI7XG59XG5cbi8qKlxuICogSFRUUCBiYXNlZCBBUEkgY2xhc3Mgd2l0aCBhdXRob3JpemF0aW9uIGhvb2tcbiAqL1xuZXhwb3J0IGNsYXNzIEh0dHBBcGk8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBzdGF0aWMgX2xvZ2dlciA9IGdldExvZ2dlcignaHR0cC1hcGknKTtcblxuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcbiAgX2xvZ2dlcjogTG9nZ2VyO1xuICBfdHJhbnNwb3J0OiBUcmFuc3BvcnQ7XG4gIF9yZXNwb25zZVR5cGU6IHN0cmluZyB8IHZvaWQ7XG4gIF9ub0NvbnRlbnRSZXNwb25zZTogc3RyaW5nIHwgdm9pZDtcblxuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBvcHRpb25zOiBhbnkpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuX2xvZ2dlciA9IGNvbm4uX2xvZ0xldmVsXG4gICAgICA/IEh0dHBBcGkuX2xvZ2dlci5jcmVhdGVJbnN0YW5jZShjb25uLl9sb2dMZXZlbClcbiAgICAgIDogSHR0cEFwaS5fbG9nZ2VyO1xuICAgIHRoaXMuX3Jlc3BvbnNlVHlwZSA9IG9wdGlvbnMucmVzcG9uc2VUeXBlO1xuICAgIHRoaXMuX3RyYW5zcG9ydCA9IG9wdGlvbnMudHJhbnNwb3J0IHx8IGNvbm4uX3RyYW5zcG9ydDtcbiAgICB0aGlzLl9ub0NvbnRlbnRSZXNwb25zZSA9IG9wdGlvbnMubm9Db250ZW50UmVzcG9uc2U7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbG91dCB0byBBUEkgZW5kcG9pbnQgdXNpbmcgaHR0cFxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4ocmVxdWVzdDogSHR0cFJlcXVlc3QpOiBTdHJlYW1Qcm9taXNlPFI+IHtcbiAgICByZXR1cm4gU3RyZWFtUHJvbWlzZS5jcmVhdGU8Uj4oKCkgPT4ge1xuICAgICAgY29uc3QgeyBzdHJlYW0sIHNldFN0cmVhbSB9ID0gY3JlYXRlTGF6eVN0cmVhbSgpO1xuICAgICAgY29uc3QgcHJvbWlzZSA9IChhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlZnJlc2hEZWxlZ2F0ZSA9IHRoaXMuZ2V0UmVmcmVzaERlbGVnYXRlKCk7XG4gICAgICAgIC8qIFRPRE8gZGVjaWRlIHJlbW92ZSBvciBub3QgdGhpcyBzZWN0aW9uICovXG4gICAgICAgIC8qXG4gICAgICAgIC8vIHJlbWVtYmVyIHByZXZpb3VzIGluc3RhbmNlIHVybCBpbiBjYXNlIGl0IGNoYW5nZXMgYWZ0ZXIgYSByZWZyZXNoXG4gICAgICAgIGNvbnN0IGxhc3RJbnN0YW5jZVVybCA9IGNvbm4uaW5zdGFuY2VVcmw7XG5cbiAgICAgICAgLy8gY2hlY2sgdG8gc2VlIGlmIHRoZSB0b2tlbiByZWZyZXNoIGhhcyBjaGFuZ2VkIHRoZSBpbnN0YW5jZSB1cmxcbiAgICAgICAgaWYobGFzdEluc3RhbmNlVXJsICE9PSBjb25uLmluc3RhbmNlVXJsKXtcbiAgICAgICAgICAvLyBpZiB0aGUgaW5zdGFuY2UgdXJsIGhhcyBjaGFuZ2VkXG4gICAgICAgICAgLy8gdGhlbiByZXBsYWNlIHRoZSBjdXJyZW50IHJlcXVlc3QgdXJscyBpbnN0YW5jZSB1cmwgZnJhZ21lbnRcbiAgICAgICAgICAvLyB3aXRoIHRoZSB1cGRhdGVkIGluc3RhbmNlIHVybFxuICAgICAgICAgIHJlcXVlc3QudXJsID0gcmVxdWVzdC51cmwucmVwbGFjZShsYXN0SW5zdGFuY2VVcmwsY29ubi5pbnN0YW5jZVVybCk7XG4gICAgICAgIH1cbiAgICAgICAgKi9cbiAgICAgICAgaWYgKHJlZnJlc2hEZWxlZ2F0ZSAmJiByZWZyZXNoRGVsZWdhdGUuaXNSZWZyZXNoaW5nKCkpIHtcbiAgICAgICAgICBhd2FpdCByZWZyZXNoRGVsZWdhdGUud2FpdFJlZnJlc2goKTtcbiAgICAgICAgICBjb25zdCBib2R5UHJvbWlzZSA9IHRoaXMucmVxdWVzdChyZXF1ZXN0KTtcbiAgICAgICAgICBzZXRTdHJlYW0oYm9keVByb21pc2Uuc3RyZWFtKCkpO1xuICAgICAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCBib2R5UHJvbWlzZTtcbiAgICAgICAgICByZXR1cm4gYm9keTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGhvb2sgYmVmb3JlIHNlbmRpbmdcbiAgICAgICAgdGhpcy5iZWZvcmVTZW5kKHJlcXVlc3QpO1xuXG4gICAgICAgIHRoaXMuZW1pdCgncmVxdWVzdCcsIHJlcXVlc3QpO1xuICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoXG4gICAgICAgICAgYDxyZXF1ZXN0PiBtZXRob2Q9JHtyZXF1ZXN0Lm1ldGhvZH0sIHVybD0ke3JlcXVlc3QudXJsfWAsXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdFByb21pc2UgPSB0aGlzLl90cmFuc3BvcnQuaHR0cFJlcXVlc3QocmVxdWVzdCk7XG5cbiAgICAgICAgc2V0U3RyZWFtKHJlcXVlc3RQcm9taXNlLnN0cmVhbSgpKTtcblxuICAgICAgICBsZXQgcmVzcG9uc2U6IEh0dHBSZXNwb25zZSB8IHZvaWQ7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCByZXF1ZXN0UHJvbWlzZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgdGhpcy5fbG9nZ2VyLmVycm9yKGVycik7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlVGltZSA9IERhdGUubm93KCk7XG4gICAgICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgICAgICAgYGVsYXBzZWQgdGltZTogJHtyZXNwb25zZVRpbWUgLSByZXF1ZXN0VGltZX0gbXNlY2AsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgICBgPHJlc3BvbnNlPiBzdGF0dXM9JHtTdHJpbmcocmVzcG9uc2Uuc3RhdHVzQ29kZSl9LCB1cmw9JHtcbiAgICAgICAgICAgIHJlcXVlc3QudXJsXG4gICAgICAgICAgfWAsXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMuZW1pdCgncmVzcG9uc2UnLCByZXNwb25zZSk7XG4gICAgICAgIC8vIFJlZnJlc2ggdG9rZW4gaWYgc2Vzc2lvbiBoYXMgYmVlbiBleHBpcmVkIGFuZCByZXF1aXJlcyBhdXRoZW50aWNhdGlvblxuICAgICAgICAvLyB3aGVuIHNlc3Npb24gcmVmcmVzaCBkZWxlZ2F0ZSBpcyBhdmFpbGFibGVcbiAgICAgICAgaWYgKHRoaXMuaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZSkgJiYgcmVmcmVzaERlbGVnYXRlKSB7XG4gICAgICAgICAgYXdhaXQgcmVmcmVzaERlbGVnYXRlLnJlZnJlc2gocmVxdWVzdFRpbWUpO1xuICAgICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QocmVxdWVzdCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaXNFcnJvclJlc3BvbnNlKHJlc3BvbnNlKSkge1xuICAgICAgICAgIGNvbnN0IGVyciA9IGF3YWl0IHRoaXMuZ2V0RXJyb3IocmVzcG9uc2UpO1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5nZXRSZXNwb25zZUJvZHkocmVzcG9uc2UpO1xuICAgICAgICByZXR1cm4gYm9keTtcbiAgICAgIH0pKCk7XG4gICAgICByZXR1cm4geyBzdHJlYW0sIHByb21pc2UgfTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBnZXRSZWZyZXNoRGVsZWdhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4uX3JlZnJlc2hEZWxlZ2F0ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBiZWZvcmVTZW5kKHJlcXVlc3Q6IEh0dHBSZXF1ZXN0KSB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICBjb25zdCBoZWFkZXJzID0gcmVxdWVzdC5oZWFkZXJzIHx8IHt9O1xuICAgIGlmICh0aGlzLl9jb25uLmFjY2Vzc1Rva2VuKSB7XG4gICAgICBoZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dGhpcy5fY29ubi5hY2Nlc3NUb2tlbn1gO1xuICAgIH1cbiAgICBpZiAodGhpcy5fY29ubi5fY2FsbE9wdGlvbnMpIHtcbiAgICAgIGNvbnN0IGNhbGxPcHRpb25zID0gW107XG4gICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXModGhpcy5fY29ubi5fY2FsbE9wdGlvbnMpKSB7XG4gICAgICAgIGNhbGxPcHRpb25zLnB1c2goYCR7bmFtZX09JHt0aGlzLl9jb25uLl9jYWxsT3B0aW9uc1tuYW1lXX1gKTtcbiAgICAgIH1cbiAgICAgIGhlYWRlcnNbJ1Nmb3JjZS1DYWxsLU9wdGlvbnMnXSA9IGNhbGxPcHRpb25zLmpvaW4oJywgJyk7XG4gICAgfVxuICAgIHJlcXVlc3QuaGVhZGVycyA9IGhlYWRlcnM7XG4gIH1cblxuICAvKipcbiAgICogRGV0ZWN0IHJlc3BvbnNlIGNvbnRlbnQgbWltZS10eXBlXG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGdldFJlc3BvbnNlQ29udGVudFR5cGUocmVzcG9uc2U6IEh0dHBSZXNwb25zZSk6IE9wdGlvbmFsPHN0cmluZz4ge1xuICAgIHJldHVybiAoXG4gICAgICB0aGlzLl9yZXNwb25zZVR5cGUgfHxcbiAgICAgIChyZXNwb25zZS5oZWFkZXJzICYmIHJlc3BvbnNlLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddKVxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIHBhcnNlUmVzcG9uc2VCb2R5KHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHRoaXMuZ2V0UmVzcG9uc2VDb250ZW50VHlwZShyZXNwb25zZSkgfHwgJyc7XG4gICAgY29uc3QgcGFyc2VCb2R5ID0gL14odGV4dHxhcHBsaWNhdGlvbilcXC94bWwoO3wkKS8udGVzdChjb250ZW50VHlwZSlcbiAgICAgID8gcGFyc2VYTUxcbiAgICAgIDogL15hcHBsaWNhdGlvblxcL2pzb24oO3wkKS8udGVzdChjb250ZW50VHlwZSlcbiAgICAgID8gcGFyc2VKU09OXG4gICAgICA6IC9edGV4dFxcL2Nzdig7fCQpLy50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgPyBwYXJzZUNTVlxuICAgICAgOiBwYXJzZVRleHQ7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBwYXJzZUJvZHkocmVzcG9uc2UuYm9keSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmJvZHk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZXNwb25zZSBib2R5XG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGFzeW5jIGdldFJlc3BvbnNlQm9keShyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDIwNCkge1xuICAgICAgLy8gTm8gQ29udGVudFxuICAgICAgcmV0dXJuIHRoaXMuX25vQ29udGVudFJlc3BvbnNlO1xuICAgIH1cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5wYXJzZVJlc3BvbnNlQm9keShyZXNwb25zZSk7XG4gICAgbGV0IGVycjtcbiAgICBpZiAodGhpcy5oYXNFcnJvckluUmVzcG9uc2VCb2R5KGJvZHkpKSB7XG4gICAgICBlcnIgPSBhd2FpdCB0aGlzLmdldEVycm9yKHJlc3BvbnNlLCBib2R5KTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDMwMCkge1xuICAgICAgLy8gTXVsdGlwbGUgQ2hvaWNlc1xuICAgICAgdGhyb3cgbmV3IEh0dHBBcGlFcnJvcihcbiAgICAgICAgJ011bHRpcGxlIHJlY29yZHMgZm91bmQnLFxuICAgICAgICAnTVVMVElQTEVfQ0hPSUNFUycsXG4gICAgICAgIGJvZHksXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gYm9keTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3Qgc2Vzc2lvbiBleHBpcnlcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgcmV0dXJuIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDQwMTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3QgZXJyb3IgcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaXNFcnJvclJlc3BvbnNlKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICByZXR1cm4gcmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDA7XG4gIH1cblxuICAvKipcbiAgICogRGV0ZWN0IGVycm9yIGluIHJlc3BvbnNlIGJvZHlcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaGFzRXJyb3JJblJlc3BvbnNlQm9keShfYm9keTogT3B0aW9uYWw8c3RyaW5nPikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQYXJzaW5nIGVycm9yIG1lc3NhZ2UgaW4gcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgcGFyc2VFcnJvcihib2R5OiBhbnkpIHtcbiAgICBjb25zdCBlcnJvcnMgPSBib2R5O1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KGVycm9ycykgPyBlcnJvcnNbMF0gOiBlcnJvcnM7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGVycm9yIG1lc3NhZ2UgaW4gcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgYXN5bmMgZ2V0RXJyb3IocmVzcG9uc2U6IEh0dHBSZXNwb25zZSwgYm9keT86IGFueSk6IFByb21pc2U8RXJyb3I+IHtcbiAgICBsZXQgZXJyb3I7XG4gICAgdHJ5IHtcbiAgICAgIGVycm9yID0gdGhpcy5wYXJzZUVycm9yKGJvZHkgfHwgKGF3YWl0IHRoaXMucGFyc2VSZXNwb25zZUJvZHkocmVzcG9uc2UpKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUgbm8tZW1wdHlcbiAgICB9XG4gICAgZXJyb3IgPVxuICAgICAgdHlwZW9mIGVycm9yID09PSAnb2JqZWN0JyAmJlxuICAgICAgZXJyb3IgIT09IG51bGwgJiZcbiAgICAgIHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSAnc3RyaW5nJ1xuICAgICAgICA/IGVycm9yXG4gICAgICAgIDoge1xuICAgICAgICAgICAgZXJyb3JDb2RlOiBgRVJST1JfSFRUUF8ke3Jlc3BvbnNlLnN0YXR1c0NvZGV9YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLmJvZHksXG4gICAgICAgICAgfTtcbiAgICByZXR1cm4gbmV3IEh0dHBBcGlFcnJvcihlcnJvci5tZXNzYWdlLCBlcnJvci5lcnJvckNvZGUpO1xuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuY2xhc3MgSHR0cEFwaUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBlcnJvckNvZGU6IHN0cmluZztcbiAgY29udGVudDogYW55O1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIGVycm9yQ29kZT86IHN0cmluZyB8IHVuZGVmaW5lZCwgY29udGVudD86IGFueSkge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9IGVycm9yQ29kZSB8fCB0aGlzLm5hbWU7XG4gICAgdGhpcy5lcnJvckNvZGUgPSB0aGlzLm5hbWU7XG4gICAgdGhpcy5jb250ZW50ID0gY29udGVudDtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBIdHRwQXBpO1xuIl19