import _Symbol$toPrimitive from "@babel/runtime-corejs3/core-js-stable/symbol/to-primitive";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.promise";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.iterator";
import "core-js/modules/es.string.match";
import "core-js/modules/es.string.replace";
import "core-js/modules/es.string.split";
import "core-js/modules/web.dom-collections.iterator";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";

function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }

function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[_Symbol$toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context51; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context51 = Object.prototype.toString.call(o)).call(_context51, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context49; _forEachInstanceProperty(_context49 = ownKeys(Object(source), true)).call(_context49, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context50; _forEachInstanceProperty(_context50 = ownKeys(Object(source))).call(_context50, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 *
 */
import { EventEmitter } from 'events';
import jsforce from './jsforce';
import Transport, { CanvasTransport, XdProxyTransport, HttpProxyTransport } from './transport';
import { getLogger } from './util/logger';
import OAuth2 from './oauth2';
import Cache from './cache';
import HttpApi from './http-api';
import SessionRefreshDelegate from './session-refresh-delegate';
import Query from './query';
import SObject from './sobject';
import QuickAction from './quick-action';
import Process from './process';
import { formatDate } from './util/formatter';

/**
 *
 */
var defaultConnectionConfig = {
  loginUrl: 'https://login.salesforce.com',
  instanceUrl: '',
  version: '50.0',
  logLevel: 'NONE',
  maxRequest: 10
};
/**
 *
 */

function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
/**
 *
 */


function parseSignedRequest(sr) {
  if (typeof sr === 'string') {
    if (sr[0] === '{') {
      // might be JSON
      return JSON.parse(sr);
    } // might be original base64-encoded signed request


    var msg = sr.split('.').pop(); // retrieve latter part

    if (!msg) {
      throw new Error('Invalid signed request');
    }

    var json = Buffer.from(msg, 'base64').toString('utf-8');
    return JSON.parse(json);
  }

  return sr;
}
/** @private **/


function parseIdUrl(url) {
  var _context;

  var _url$split$slice = _sliceInstanceProperty(_context = url.split('/')).call(_context, -2),
      _url$split$slice2 = _slicedToArray(_url$split$slice, 2),
      organizationId = _url$split$slice2[0],
      id = _url$split$slice2[1];

  return {
    id: id,
    organizationId: organizationId,
    url: url
  };
}
/**
 * Session Refresh delegate function for OAuth2 authz code flow
 * @private
 */


function oauthRefreshFn(_x, _x2) {
  return _oauthRefreshFn.apply(this, arguments);
}
/**
 * Session Refresh delegate function for username/password login
 * @private
 */


function _oauthRefreshFn() {
  _oauthRefreshFn = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee35(conn, callback) {
    var res, userInfo;
    return _regeneratorRuntime.wrap(function _callee35$(_context48) {
      while (1) {
        switch (_context48.prev = _context48.next) {
          case 0:
            _context48.prev = 0;

            if (conn.refreshToken) {
              _context48.next = 3;
              break;
            }

            throw new Error('No refresh token found in the connection');

          case 3:
            _context48.next = 5;
            return conn.oauth2.refreshToken(conn.refreshToken);

          case 5:
            res = _context48.sent;
            userInfo = parseIdUrl(res.id);

            conn._establish({
              instanceUrl: res.instance_url,
              accessToken: res.access_token,
              userInfo: userInfo
            });

            callback(undefined, res.access_token, res);
            _context48.next = 18;
            break;

          case 11:
            _context48.prev = 11;
            _context48.t0 = _context48["catch"](0);

            if (!(_context48.t0 instanceof Error)) {
              _context48.next = 17;
              break;
            }

            callback(_context48.t0);
            _context48.next = 18;
            break;

          case 17:
            throw _context48.t0;

          case 18:
          case "end":
            return _context48.stop();
        }
      }
    }, _callee35, null, [[0, 11]]);
  }));
  return _oauthRefreshFn.apply(this, arguments);
}

function createUsernamePasswordRefreshFn(username, password) {
  return /*#__PURE__*/function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(conn, callback) {
      return _regeneratorRuntime.wrap(function _callee$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return conn.login(username, password);

            case 3:
              if (conn.accessToken) {
                _context2.next = 5;
                break;
              }

              throw new Error('Access token not found after login');

            case 5:
              callback(null, conn.accessToken);
              _context2.next = 15;
              break;

            case 8:
              _context2.prev = 8;
              _context2.t0 = _context2["catch"](0);

              if (!(_context2.t0 instanceof Error)) {
                _context2.next = 14;
                break;
              }

              callback(_context2.t0);
              _context2.next = 15;
              break;

            case 14:
              throw _context2.t0;

            case 15:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee, null, [[0, 8]]);
    }));

    return function (_x3, _x4) {
      return _ref.apply(this, arguments);
    };
  }();
}
/**
 * @private
 */


function toSaveResult(err) {
  return {
    success: false,
    errors: [err]
  };
}
/**
 *
 */


function raiseNoModuleError(name) {
  var _context3;

  throw new Error(_concatInstanceProperty(_context3 = "API module '".concat(name, "' is not loaded, load 'jsforce/api/")).call(_context3, name, "' explicitly"));
}
/*
 * Constant of maximum records num in DML operation (update/delete)
 */


var MAX_DML_COUNT = 200;
/**
 *
 */

export var Connection = /*#__PURE__*/function (_EventEmitter) {
  _inherits(Connection, _EventEmitter);

  var _super = _createSuper(Connection);

  _createClass(Connection, [{
    key: "analytics",
    // describe: (name: string) => Promise<DescribeSObjectResult>;
    // describeGlobal: () => Promise<DescribeGlobalResult>;
    // API libs are not instantiated here so that core module to remain without dependencies to them
    // It is responsible for developers to import api libs explicitly if they are using 'jsforce/core' instead of 'jsforce'.
    get: function get() {
      return raiseNoModuleError('analytics');
    }
  }, {
    key: "apex",
    get: function get() {
      return raiseNoModuleError('apex');
    }
  }, {
    key: "bulk",
    get: function get() {
      return raiseNoModuleError('bulk');
    }
  }, {
    key: "bulk2",
    get: function get() {
      return raiseNoModuleError('bulk2');
    }
  }, {
    key: "chatter",
    get: function get() {
      return raiseNoModuleError('chatter');
    }
  }, {
    key: "metadata",
    get: function get() {
      return raiseNoModuleError('metadata');
    }
  }, {
    key: "soap",
    get: function get() {
      return raiseNoModuleError('soap');
    }
  }, {
    key: "streaming",
    get: function get() {
      return raiseNoModuleError('streaming');
    }
  }, {
    key: "tooling",
    get: function get() {
      return raiseNoModuleError('tooling');
    }
    /**
     *
     */

  }]);

  function Connection() {
    var _this;

    var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, Connection);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "version", void 0);

    _defineProperty(_assertThisInitialized(_this), "loginUrl", void 0);

    _defineProperty(_assertThisInitialized(_this), "instanceUrl", void 0);

    _defineProperty(_assertThisInitialized(_this), "accessToken", void 0);

    _defineProperty(_assertThisInitialized(_this), "refreshToken", void 0);

    _defineProperty(_assertThisInitialized(_this), "userInfo", void 0);

    _defineProperty(_assertThisInitialized(_this), "limitInfo", {});

    _defineProperty(_assertThisInitialized(_this), "oauth2", void 0);

    _defineProperty(_assertThisInitialized(_this), "sobjects", {});

    _defineProperty(_assertThisInitialized(_this), "cache", void 0);

    _defineProperty(_assertThisInitialized(_this), "_callOptions", void 0);

    _defineProperty(_assertThisInitialized(_this), "_maxRequest", void 0);

    _defineProperty(_assertThisInitialized(_this), "_logger", void 0);

    _defineProperty(_assertThisInitialized(_this), "_logLevel", void 0);

    _defineProperty(_assertThisInitialized(_this), "_transport", void 0);

    _defineProperty(_assertThisInitialized(_this), "_sessionType", void 0);

    _defineProperty(_assertThisInitialized(_this), "_refreshDelegate", void 0);

    _defineProperty(_assertThisInitialized(_this), "describe$", void 0);

    _defineProperty(_assertThisInitialized(_this), "describe$$", void 0);

    _defineProperty(_assertThisInitialized(_this), "describeSObject", void 0);

    _defineProperty(_assertThisInitialized(_this), "describeSObject$", void 0);

    _defineProperty(_assertThisInitialized(_this), "describeSObject$$", void 0);

    _defineProperty(_assertThisInitialized(_this), "describeGlobal$", void 0);

    _defineProperty(_assertThisInitialized(_this), "describeGlobal$$", void 0);

    _defineProperty(_assertThisInitialized(_this), "insert", _this.create);

    _defineProperty(_assertThisInitialized(_this), "delete", _this.destroy);

    _defineProperty(_assertThisInitialized(_this), "del", _this.destroy);

    _defineProperty(_assertThisInitialized(_this), "process", new Process(_assertThisInitialized(_this)));

    var loginUrl = config.loginUrl,
        instanceUrl = config.instanceUrl,
        version = config.version,
        oauth2 = config.oauth2,
        maxRequest = config.maxRequest,
        logLevel = config.logLevel,
        proxyUrl = config.proxyUrl,
        httpProxy = config.httpProxy;
    _this.loginUrl = loginUrl || defaultConnectionConfig.loginUrl;
    _this.instanceUrl = instanceUrl || defaultConnectionConfig.instanceUrl;
    _this.version = version || defaultConnectionConfig.version;
    _this.oauth2 = oauth2 instanceof OAuth2 ? oauth2 : new OAuth2(_objectSpread({
      loginUrl: _this.loginUrl,
      proxyUrl: proxyUrl,
      httpProxy: httpProxy
    }, oauth2));
    var refreshFn = config.refreshFn;

    if (!refreshFn && _this.oauth2.clientId) {
      refreshFn = oauthRefreshFn;
    }

    if (refreshFn) {
      _this._refreshDelegate = new SessionRefreshDelegate(_assertThisInitialized(_this), refreshFn);
    }

    _this._maxRequest = maxRequest || defaultConnectionConfig.maxRequest;
    _this._logger = logLevel ? Connection._logger.createInstance(logLevel) : Connection._logger;
    _this._logLevel = logLevel;
    _this._transport = proxyUrl ? new XdProxyTransport(proxyUrl) : httpProxy ? new HttpProxyTransport(httpProxy) : new Transport();
    _this._callOptions = config.callOptions;
    _this.cache = new Cache();

    var describeCacheKey = function describeCacheKey(type) {
      return type ? "describe.".concat(type) : 'describe';
    };

    var describe = Connection.prototype.describe;
    _this.describe = _this.cache.createCachedFunction(describe, _assertThisInitialized(_this), {
      key: describeCacheKey,
      strategy: 'NOCACHE'
    });
    _this.describe$ = _this.cache.createCachedFunction(describe, _assertThisInitialized(_this), {
      key: describeCacheKey,
      strategy: 'HIT'
    });
    _this.describe$$ = _this.cache.createCachedFunction(describe, _assertThisInitialized(_this), {
      key: describeCacheKey,
      strategy: 'IMMEDIATE'
    });
    _this.describeSObject = _this.describe;
    _this.describeSObject$ = _this.describe$;
    _this.describeSObject$$ = _this.describe$$;
    var describeGlobal = Connection.prototype.describeGlobal;
    _this.describeGlobal = _this.cache.createCachedFunction(describeGlobal, _assertThisInitialized(_this), {
      key: 'describeGlobal',
      strategy: 'NOCACHE'
    });
    _this.describeGlobal$ = _this.cache.createCachedFunction(describeGlobal, _assertThisInitialized(_this), {
      key: 'describeGlobal',
      strategy: 'HIT'
    });
    _this.describeGlobal$$ = _this.cache.createCachedFunction(describeGlobal, _assertThisInitialized(_this), {
      key: 'describeGlobal',
      strategy: 'IMMEDIATE'
    });
    var accessToken = config.accessToken,
        refreshToken = config.refreshToken,
        sessionId = config.sessionId,
        serverUrl = config.serverUrl,
        signedRequest = config.signedRequest;

    _this._establish({
      accessToken: accessToken,
      refreshToken: refreshToken,
      instanceUrl: instanceUrl,
      sessionId: sessionId,
      serverUrl: serverUrl,
      signedRequest: signedRequest
    });

    jsforce.emit('connection:new', _assertThisInitialized(_this));
    return _this;
  }
  /* @private */


  _createClass(Connection, [{
    key: "_establish",
    value: function _establish(options) {
      var _context4;

      var accessToken = options.accessToken,
          refreshToken = options.refreshToken,
          instanceUrl = options.instanceUrl,
          sessionId = options.sessionId,
          serverUrl = options.serverUrl,
          signedRequest = options.signedRequest,
          userInfo = options.userInfo;
      this.instanceUrl = serverUrl ? _sliceInstanceProperty(_context4 = serverUrl.split('/')).call(_context4, 0, 3).join('/') : instanceUrl || this.instanceUrl;
      this.accessToken = sessionId || accessToken || this.accessToken;
      this.refreshToken = refreshToken || this.refreshToken;

      if (this.refreshToken && !this._refreshDelegate) {
        throw new Error('Refresh token is specified without oauth2 client information or refresh function');
      }

      var signedRequestObject = signedRequest && parseSignedRequest(signedRequest);

      if (signedRequestObject) {
        this.accessToken = signedRequestObject.client.oauthToken;

        if (CanvasTransport.supported) {
          this._transport = new CanvasTransport(signedRequestObject);
        }
      }

      this.userInfo = userInfo || this.userInfo;
      this._sessionType = sessionId ? 'soap' : 'oauth2';

      this._resetInstance();
    }
    /* @priveate */

  }, {
    key: "_clearSession",
    value: function _clearSession() {
      this.accessToken = null;
      this.refreshToken = null;
      this.instanceUrl = defaultConnectionConfig.instanceUrl;
      this.userInfo = null;
      this._sessionType = null;
    }
    /* @priveate */

  }, {
    key: "_resetInstance",
    value: function _resetInstance() {
      var _this2 = this;

      this.limitInfo = {};
      this.sobjects = {}; // TODO impl cache

      this.cache.clear();
      this.cache.get('describeGlobal').removeAllListeners('value');
      this.cache.get('describeGlobal').on('value', function (_ref2) {
        var result = _ref2.result;

        if (result) {
          var _iterator = _createForOfIteratorHelper(result.sobjects),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var so = _step.value;

              _this2.sobject(so.name);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      });
      /*
      if (this.tooling) {
        this.tooling._resetInstance();
      }
      */
    }
    /**
     * Authorize (using oauth2 web server flow)
     */

  }, {
    key: "authorize",
    value: function () {
      var _authorize = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(code) {
        var _context5;

        var params,
            res,
            userInfo,
            _args2 = arguments;
        return _regeneratorRuntime.wrap(function _callee2$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                params = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
                _context6.next = 3;
                return this.oauth2.requestToken(code, params);

              case 3:
                res = _context6.sent;
                userInfo = parseIdUrl(res.id);

                this._establish({
                  instanceUrl: res.instance_url,
                  accessToken: res.access_token,
                  refreshToken: res.refresh_token,
                  userInfo: userInfo
                });

                this._logger.debug(_concatInstanceProperty(_context5 = "<login> completed. user id = ".concat(userInfo.id, ", org id = ")).call(_context5, userInfo.organizationId));

                return _context6.abrupt("return", userInfo);

              case 8:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee2, this);
      }));

      function authorize(_x5) {
        return _authorize.apply(this, arguments);
      }

      return authorize;
    }()
    /**
     *
     */

  }, {
    key: "login",
    value: function () {
      var _login = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        return _regeneratorRuntime.wrap(function _callee3$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                this._refreshDelegate = new SessionRefreshDelegate(this, createUsernamePasswordRefreshFn(username, password));

                if (!(this.oauth2 && this.oauth2.clientId && this.oauth2.clientSecret)) {
                  _context7.next = 3;
                  break;
                }

                return _context7.abrupt("return", this.loginByOAuth2(username, password));

              case 3:
                return _context7.abrupt("return", this.loginBySoap(username, password));

              case 4:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee3, this);
      }));

      function login(_x6, _x7) {
        return _login.apply(this, arguments);
      }

      return login;
    }()
    /**
     * Login by OAuth2 username & password flow
     */

  }, {
    key: "loginByOAuth2",
    value: function () {
      var _loginByOAuth = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(username, password) {
        var _context8;

        var res, userInfo;
        return _regeneratorRuntime.wrap(function _callee4$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _context9.next = 2;
                return this.oauth2.authenticate(username, password);

              case 2:
                res = _context9.sent;
                userInfo = parseIdUrl(res.id);

                this._establish({
                  instanceUrl: res.instance_url,
                  accessToken: res.access_token,
                  userInfo: userInfo
                });

                this._logger.info(_concatInstanceProperty(_context8 = "<login> completed. user id = ".concat(userInfo.id, ", org id = ")).call(_context8, userInfo.organizationId));

                return _context9.abrupt("return", userInfo);

              case 7:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee4, this);
      }));

      function loginByOAuth2(_x8, _x9) {
        return _loginByOAuth.apply(this, arguments);
      }

      return loginByOAuth2;
    }()
    /**
     *
     */

  }, {
    key: "loginBySoap",
    value: function () {
      var _loginBySoap = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(username, password) {
        var _context10, _context11;

        var body, soapLoginEndpoint, response, m, faultstring, serverUrl, sessionId, userId, organizationId, idUrl, userInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                if (!(!username || !password)) {
                  _context12.next = 2;
                  break;
                }

                return _context12.abrupt("return", _Promise.reject(new Error('no username password given')));

              case 2:
                body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header/>', '<se:Body>', '<login xmlns="urn:partner.soap.sforce.com">', "<username>".concat(esc(username), "</username>"), "<password>".concat(esc(password), "</password>"), '</login>', '</se:Body>', '</se:Envelope>'].join('');
                soapLoginEndpoint = [this.loginUrl, 'services/Soap/u', this.version].join('/');
                _context12.next = 6;
                return this._transport.httpRequest({
                  method: 'POST',
                  url: soapLoginEndpoint,
                  body: body,
                  headers: {
                    'Content-Type': 'text/xml',
                    SOAPAction: '""'
                  }
                });

              case 6:
                response = _context12.sent;

                if (!(response.statusCode >= 400)) {
                  _context12.next = 11;
                  break;
                }

                m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
                faultstring = m && m[1];
                throw new Error(faultstring || response.body);

              case 11:
                this._logger.debug("SOAP response = ".concat(response.body));

                m = response.body.match(/<serverUrl>([^<]+)<\/serverUrl>/);
                serverUrl = m && m[1];
                m = response.body.match(/<sessionId>([^<]+)<\/sessionId>/);
                sessionId = m && m[1];
                m = response.body.match(/<userId>([^<]+)<\/userId>/);
                userId = m && m[1];
                m = response.body.match(/<organizationId>([^<]+)<\/organizationId>/);
                organizationId = m && m[1];

                if (!(!serverUrl || !sessionId || !userId || !organizationId)) {
                  _context12.next = 22;
                  break;
                }

                throw new Error('could not extract session information from login response');

              case 22:
                idUrl = [this.loginUrl, 'id', organizationId, userId].join('/');
                userInfo = {
                  id: userId,
                  organizationId: organizationId,
                  url: idUrl
                };

                this._establish({
                  serverUrl: _sliceInstanceProperty(_context10 = serverUrl.split('/')).call(_context10, 0, 3).join('/'),
                  sessionId: sessionId,
                  userInfo: userInfo
                });

                this._logger.info(_concatInstanceProperty(_context11 = "<login> completed. user id = ".concat(userId, ", org id = ")).call(_context11, organizationId));

                return _context12.abrupt("return", userInfo);

              case 27:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee5, this);
      }));

      function loginBySoap(_x10, _x11) {
        return _loginBySoap.apply(this, arguments);
      }

      return loginBySoap;
    }()
    /**
     * Logout the current session
     */

  }, {
    key: "logout",
    value: function () {
      var _logout = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6(revoke) {
        return _regeneratorRuntime.wrap(function _callee6$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                this._refreshDelegate = undefined;

                if (!(this._sessionType === 'oauth2')) {
                  _context13.next = 3;
                  break;
                }

                return _context13.abrupt("return", this.logoutByOAuth2(revoke));

              case 3:
                return _context13.abrupt("return", this.logoutBySoap(revoke));

              case 4:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee6, this);
      }));

      function logout(_x12) {
        return _logout.apply(this, arguments);
      }

      return logout;
    }()
    /**
     * Logout the current session by revoking access token via OAuth2 session revoke
     */

  }, {
    key: "logoutByOAuth2",
    value: function () {
      var _logoutByOAuth = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(revoke) {
        var token;
        return _regeneratorRuntime.wrap(function _callee7$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                token = revoke ? this.refreshToken : this.accessToken;

                if (!token) {
                  _context14.next = 4;
                  break;
                }

                _context14.next = 4;
                return this.oauth2.revokeToken(token);

              case 4:
                // Destroy the session bound to this connection
                this._clearSession();

                this._resetInstance();

              case 6:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee7, this);
      }));

      function logoutByOAuth2(_x13) {
        return _logoutByOAuth.apply(this, arguments);
      }

      return logoutByOAuth2;
    }()
    /**
     * Logout the session by using SOAP web service API
     */

  }, {
    key: "logoutBySoap",
    value: function () {
      var _logoutBySoap = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8(revoke) {
        var _context15;

        var body, response, m, faultstring;
        return _regeneratorRuntime.wrap(function _callee8$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header>', '<SessionHeader xmlns="urn:partner.soap.sforce.com">', "<sessionId>".concat(esc(revoke ? this.refreshToken : this.accessToken), "</sessionId>"), '</SessionHeader>', '</se:Header>', '<se:Body>', '<logout xmlns="urn:partner.soap.sforce.com"/>', '</se:Body>', '</se:Envelope>'].join('');
                _context16.next = 3;
                return this._transport.httpRequest({
                  method: 'POST',
                  url: [this.instanceUrl, 'services/Soap/u', this.version].join('/'),
                  body: body,
                  headers: {
                    'Content-Type': 'text/xml',
                    SOAPAction: '""'
                  }
                });

              case 3:
                response = _context16.sent;

                this._logger.debug(_concatInstanceProperty(_context15 = "SOAP statusCode = ".concat(response.statusCode, ", response = ")).call(_context15, response.body));

                if (!(response.statusCode >= 400)) {
                  _context16.next = 9;
                  break;
                }

                m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
                faultstring = m && m[1];
                throw new Error(faultstring || response.body);

              case 9:
                // Destroy the session bound to this connection
                this._clearSession();

                this._resetInstance();

              case 11:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee8, this);
      }));

      function logoutBySoap(_x14) {
        return _logoutBySoap.apply(this, arguments);
      }

      return logoutBySoap;
    }()
    /**
     * Send REST API request with given HTTP request info, with connected session information.
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "request",
    value: function request(_request) {
      var _this3 = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      // if request is simple string, regard it as url in GET method
      var request_ = typeof _request === 'string' ? {
        method: 'GET',
        url: _request
      } : _request; // if url is given in relative path, prepend base url or instance url before.

      request_ = _objectSpread(_objectSpread({}, request_), {}, {
        url: this._normalizeUrl(request_.url)
      });
      var httpApi = new HttpApi(this, options); // log api usage and its quota

      httpApi.on('response', function (response) {
        if (response.headers && response.headers['sforce-limit-info']) {
          var apiUsage = response.headers['sforce-limit-info'].match(/api-usage=(\d+)\/(\d+)/);

          if (apiUsage) {
            _this3.limitInfo = {
              apiUsage: {
                used: _parseInt(apiUsage[1], 10),
                limit: _parseInt(apiUsage[2], 10)
              }
            };
          }
        }
      });
      return httpApi.request(request_);
    }
    /**
     * Send HTTP GET request
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "requestGet",
    value: function requestGet(url, options) {
      var request = {
        method: 'GET',
        url: url
      };
      return this.request(request, options);
    }
    /**
     * Send HTTP POST request with JSON body, with connected session information
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "requestPost",
    value: function requestPost(url, body, options) {
      var request = {
        method: 'POST',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }
    /**
     * Send HTTP PUT request with JSON body, with connected session information
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "requestPut",
    value: function requestPut(url, body, options) {
      var request = {
        method: 'PUT',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }
    /**
     * Send HTTP PATCH request with JSON body
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "requestPatch",
    value: function requestPatch(url, body, options) {
      var request = {
        method: 'PATCH',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }
    /**
     * Send HTTP DELETE request
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */

  }, {
    key: "requestDelete",
    value: function requestDelete(url, options) {
      var request = {
        method: 'DELETE',
        url: url
      };
      return this.request(request, options);
    }
    /** @private **/

  }, {
    key: "_baseUrl",
    value: function _baseUrl() {
      return [this.instanceUrl, 'services/data', "v".concat(this.version)].join('/');
    }
    /**
     * Convert path to absolute url
     * @private
     */

  }, {
    key: "_normalizeUrl",
    value: function _normalizeUrl(url) {
      if (url[0] === '/') {
        if (_indexOfInstanceProperty(url).call(url, this.instanceUrl + '/services/') === 0) {
          return url;
        }

        if (_indexOfInstanceProperty(url).call(url, '/services/') === 0) {
          return this.instanceUrl + url;
        }

        return this._baseUrl() + url;
      }

      return url;
    }
    /**
     *
     */

  }, {
    key: "query",
    value: function query(soql, options) {
      return new Query(this, soql, options);
    }
    /**
     * Execute search by SOSL
     *
     * @param {String} sosl - SOSL string
     * @param {Callback.<Array.<RecordResult>>} [callback] - Callback function
     * @returns {Promise.<Array.<RecordResult>>}
     */

  }, {
    key: "search",
    value: function search(sosl) {
      var url = this._baseUrl() + '/search?q=' + encodeURIComponent(sosl);
      return this.request(url);
    }
    /**
     *
     */

  }, {
    key: "queryMore",
    value: function queryMore(locator, options) {
      return new Query(this, {
        locator: locator
      }, options);
    }
    /* */

  }, {
    key: "_ensureVersion",
    value: function _ensureVersion(majorVersion) {
      var versions = this.version.split('.');
      return _parseInt(versions[0], 10) >= majorVersion;
    }
    /* */

  }, {
    key: "_supports",
    value: function _supports(feature) {
      switch (feature) {
        case 'sobject-collection':
          // sobject collection is available only in API ver 42.0+
          return this._ensureVersion(42);

        default:
          return false;
      }
    }
    /**
     * Retrieve specified records
     */

  }, {
    key: "retrieve",
    value: function () {
      var _retrieve = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(type, ids) {
        var options,
            _args9 = arguments;
        return _regeneratorRuntime.wrap(function _callee9$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
                options = _args9.length > 2 && _args9[2] !== undefined ? _args9[2] : {};
                return _context17.abrupt("return", _Array$isArray(ids) ? // check the version whether SObject collection API is supported (42.0)
                this._ensureVersion(42) ? this._retrieveMany(type, ids, options) : this._retrieveParallel(type, ids, options) : this._retrieveSingle(type, ids, options));

              case 2:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee9, this);
      }));

      function retrieve(_x15, _x16) {
        return _retrieve.apply(this, arguments);
      }

      return retrieve;
    }()
    /** @private */

  }, {
    key: "_retrieveSingle",
    value: function () {
      var _retrieveSingle2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee10(type, id, options) {
        var url, fields, headers;
        return _regeneratorRuntime.wrap(function _callee10$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                if (id) {
                  _context18.next = 2;
                  break;
                }

                throw new Error('Invalid record ID. Specify valid record ID value');

              case 2:
                url = [this._baseUrl(), 'sobjects', type, id].join('/');
                fields = options.fields, headers = options.headers;

                if (fields) {
                  url += "?fields=".concat(fields.join(','));
                }

                return _context18.abrupt("return", this.request({
                  method: 'GET',
                  url: url,
                  headers: headers
                }));

              case 6:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee10, this);
      }));

      function _retrieveSingle(_x17, _x18, _x19) {
        return _retrieveSingle2.apply(this, arguments);
      }

      return _retrieveSingle;
    }()
    /** @private */

  }, {
    key: "_retrieveParallel",
    value: function () {
      var _retrieveParallel2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee11(type, ids, options) {
        var _this4 = this;

        return _regeneratorRuntime.wrap(function _callee11$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                if (!(ids.length > this._maxRequest)) {
                  _context19.next = 2;
                  break;
                }

                throw new Error('Exceeded max limit of concurrent call');

              case 2:
                return _context19.abrupt("return", _Promise.all(_mapInstanceProperty(ids).call(ids, function (id) {
                  return _this4._retrieveSingle(type, id, options).catch(function (err) {
                    if (options.allOrNone || err.errorCode !== 'NOT_FOUND') {
                      throw err;
                    }

                    return null;
                  });
                })));

              case 3:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee11, this);
      }));

      function _retrieveParallel(_x20, _x21, _x22) {
        return _retrieveParallel2.apply(this, arguments);
      }

      return _retrieveParallel;
    }()
    /** @private */

  }, {
    key: "_retrieveMany",
    value: function () {
      var _retrieveMany2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee12(type, ids, options) {
        var _context20;

        var url, fields;
        return _regeneratorRuntime.wrap(function _callee12$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                if (!(ids.length === 0)) {
                  _context21.next = 2;
                  break;
                }

                return _context21.abrupt("return", []);

              case 2:
                url = [this._baseUrl(), 'composite', 'sobjects', type].join('/');
                _context21.t0 = options.fields;

                if (_context21.t0) {
                  _context21.next = 10;
                  break;
                }

                _context21.t1 = _mapInstanceProperty;
                _context21.next = 8;
                return this.describe$(type);

              case 8:
                _context21.t2 = _context20 = _context21.sent.fields;
                _context21.t0 = (0, _context21.t1)(_context21.t2).call(_context20, function (field) {
                  return field.name;
                });

              case 10:
                fields = _context21.t0;
                return _context21.abrupt("return", this.request({
                  method: 'POST',
                  url: url,
                  body: _JSON$stringify({
                    ids: ids,
                    fields: fields
                  }),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }));

              case 12:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee12, this);
      }));

      function _retrieveMany(_x23, _x24, _x25) {
        return _retrieveMany2.apply(this, arguments);
      }

      return _retrieveMany;
    }()
    /**
     * Create records
     */

  }, {
    key: "create",

    /**
     * @param type
     * @param records
     * @param options
     */
    value: function () {
      var _create = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee13(type, records) {
        var options,
            ret,
            _args13 = arguments;
        return _regeneratorRuntime.wrap(function _callee13$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                options = _args13.length > 2 && _args13[2] !== undefined ? _args13[2] : {};

                if (!_Array$isArray(records)) {
                  _context22.next = 14;
                  break;
                }

                if (!this._ensureVersion(42)) {
                  _context22.next = 8;
                  break;
                }

                _context22.next = 5;
                return this._createMany(type, records, options);

              case 5:
                _context22.t1 = _context22.sent;
                _context22.next = 11;
                break;

              case 8:
                _context22.next = 10;
                return this._createParallel(type, records, options);

              case 10:
                _context22.t1 = _context22.sent;

              case 11:
                _context22.t0 = _context22.t1;
                _context22.next = 17;
                break;

              case 14:
                _context22.next = 16;
                return this._createSingle(type, records, options);

              case 16:
                _context22.t0 = _context22.sent;

              case 17:
                ret = _context22.t0;
                return _context22.abrupt("return", ret);

              case 19:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee13, this);
      }));

      function create(_x26, _x27) {
        return _create.apply(this, arguments);
      }

      return create;
    }()
    /** @private */

  }, {
    key: "_createSingle",
    value: function () {
      var _createSingle2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee14(type, record, options) {
        var Id, rtype, attributes, rec, sobjectType, url;
        return _regeneratorRuntime.wrap(function _callee14$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                Id = record.Id, rtype = record.type, attributes = record.attributes, rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);
                sobjectType = type || attributes && attributes.type || rtype;

                if (sobjectType) {
                  _context23.next = 4;
                  break;
                }

                throw new Error('No SObject Type defined in record');

              case 4:
                url = [this._baseUrl(), 'sobjects', sobjectType].join('/');
                return _context23.abrupt("return", this.request({
                  method: 'POST',
                  url: url,
                  body: _JSON$stringify(rec),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }));

              case 6:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee14, this);
      }));

      function _createSingle(_x28, _x29, _x30) {
        return _createSingle2.apply(this, arguments);
      }

      return _createSingle;
    }()
    /** @private */

  }, {
    key: "_createParallel",
    value: function () {
      var _createParallel2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee15(type, records, options) {
        var _this5 = this;

        return _regeneratorRuntime.wrap(function _callee15$(_context24) {
          while (1) {
            switch (_context24.prev = _context24.next) {
              case 0:
                if (!(records.length > this._maxRequest)) {
                  _context24.next = 2;
                  break;
                }

                throw new Error('Exceeded max limit of concurrent call');

              case 2:
                return _context24.abrupt("return", _Promise.all(_mapInstanceProperty(records).call(records, function (record) {
                  return _this5._createSingle(type, record, options).catch(function (err) {
                    // be aware that allOrNone in parallel mode will not revert the other successful requests
                    // it only raises error when met at least one failed request.
                    if (options.allOrNone || !err.errorCode) {
                      throw err;
                    }

                    return toSaveResult(err);
                  });
                })));

              case 3:
              case "end":
                return _context24.stop();
            }
          }
        }, _callee15, this);
      }));

      function _createParallel(_x31, _x32, _x33) {
        return _createParallel2.apply(this, arguments);
      }

      return _createParallel;
    }()
    /** @private */

  }, {
    key: "_createMany",
    value: function () {
      var _createMany2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee16(type, records, options) {
        var _context25, _records, url;

        return _regeneratorRuntime.wrap(function _callee16$(_context26) {
          while (1) {
            switch (_context26.prev = _context26.next) {
              case 0:
                if (!(records.length === 0)) {
                  _context26.next = 2;
                  break;
                }

                return _context26.abrupt("return", _Promise.resolve([]));

              case 2:
                if (!(records.length > MAX_DML_COUNT && options.allowRecursive)) {
                  _context26.next = 16;
                  break;
                }

                _context26.t0 = _concatInstanceProperty(_context25 = []);
                _context26.t1 = _context25;
                _context26.t2 = _toConsumableArray;
                _context26.next = 8;
                return this._createMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options);

              case 8:
                _context26.t3 = _context26.sent;
                _context26.t4 = (0, _context26.t2)(_context26.t3);
                _context26.t5 = _toConsumableArray;
                _context26.next = 13;
                return this._createMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options);

              case 13:
                _context26.t6 = _context26.sent;
                _context26.t7 = (0, _context26.t5)(_context26.t6);
                return _context26.abrupt("return", _context26.t0.call.call(_context26.t0, _context26.t1, _context26.t4, _context26.t7));

              case 16:
                _records = _mapInstanceProperty(records).call(records, function (record) {
                  var Id = record.Id,
                      rtype = record.type,
                      attributes = record.attributes,
                      rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

                  var sobjectType = type || attributes && attributes.type || rtype;

                  if (!sobjectType) {
                    throw new Error('No SObject Type defined in record');
                  }

                  return _objectSpread({
                    attributes: {
                      type: sobjectType
                    }
                  }, rec);
                });
                url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
                return _context26.abrupt("return", this.request({
                  method: 'POST',
                  url: url,
                  body: _JSON$stringify({
                    allOrNone: options.allOrNone || false,
                    records: _records
                  }),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }));

              case 19:
              case "end":
                return _context26.stop();
            }
          }
        }, _callee16, this);
      }));

      function _createMany(_x34, _x35, _x36) {
        return _createMany2.apply(this, arguments);
      }

      return _createMany;
    }()
    /**
     * Synonym of Connection#create()
     */

  }, {
    key: "update",

    /**
     * @param type
     * @param records
     * @param options
     */
    value: function update(type, records) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return _Array$isArray(records) ? // check the version whether SObject collection API is supported (42.0)
      this._ensureVersion(42) ? this._updateMany(type, records, options) : this._updateParallel(type, records, options) : this._updateSingle(type, records, options);
    }
    /** @private */

  }, {
    key: "_updateSingle",
    value: function () {
      var _updateSingle2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee17(type, record, options) {
        var id, rtype, attributes, rec, sobjectType, url;
        return _regeneratorRuntime.wrap(function _callee17$(_context27) {
          while (1) {
            switch (_context27.prev = _context27.next) {
              case 0:
                id = record.Id, rtype = record.type, attributes = record.attributes, rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

                if (id) {
                  _context27.next = 3;
                  break;
                }

                throw new Error('Record id is not found in record.');

              case 3:
                sobjectType = type || attributes && attributes.type || rtype;

                if (sobjectType) {
                  _context27.next = 6;
                  break;
                }

                throw new Error('No SObject Type defined in record');

              case 6:
                url = [this._baseUrl(), 'sobjects', sobjectType, id].join('/');
                return _context27.abrupt("return", this.request({
                  method: 'PATCH',
                  url: url,
                  body: _JSON$stringify(rec),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }, {
                  noContentResponse: {
                    id: id,
                    success: true,
                    errors: []
                  }
                }));

              case 8:
              case "end":
                return _context27.stop();
            }
          }
        }, _callee17, this);
      }));

      function _updateSingle(_x37, _x38, _x39) {
        return _updateSingle2.apply(this, arguments);
      }

      return _updateSingle;
    }()
    /** @private */

  }, {
    key: "_updateParallel",
    value: function () {
      var _updateParallel2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee18(type, records, options) {
        var _this6 = this;

        return _regeneratorRuntime.wrap(function _callee18$(_context28) {
          while (1) {
            switch (_context28.prev = _context28.next) {
              case 0:
                if (!(records.length > this._maxRequest)) {
                  _context28.next = 2;
                  break;
                }

                throw new Error('Exceeded max limit of concurrent call');

              case 2:
                return _context28.abrupt("return", _Promise.all(_mapInstanceProperty(records).call(records, function (record) {
                  return _this6._updateSingle(type, record, options).catch(function (err) {
                    // be aware that allOrNone in parallel mode will not revert the other successful requests
                    // it only raises error when met at least one failed request.
                    if (options.allOrNone || !err.errorCode) {
                      throw err;
                    }

                    return toSaveResult(err);
                  });
                })));

              case 3:
              case "end":
                return _context28.stop();
            }
          }
        }, _callee18, this);
      }));

      function _updateParallel(_x40, _x41, _x42) {
        return _updateParallel2.apply(this, arguments);
      }

      return _updateParallel;
    }()
    /** @private */

  }, {
    key: "_updateMany",
    value: function () {
      var _updateMany2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee19(type, records, options) {
        var _context29, _records, url;

        return _regeneratorRuntime.wrap(function _callee19$(_context30) {
          while (1) {
            switch (_context30.prev = _context30.next) {
              case 0:
                if (!(records.length === 0)) {
                  _context30.next = 2;
                  break;
                }

                return _context30.abrupt("return", []);

              case 2:
                if (!(records.length > MAX_DML_COUNT && options.allowRecursive)) {
                  _context30.next = 16;
                  break;
                }

                _context30.t0 = _concatInstanceProperty(_context29 = []);
                _context30.t1 = _context29;
                _context30.t2 = _toConsumableArray;
                _context30.next = 8;
                return this._updateMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options);

              case 8:
                _context30.t3 = _context30.sent;
                _context30.t4 = (0, _context30.t2)(_context30.t3);
                _context30.t5 = _toConsumableArray;
                _context30.next = 13;
                return this._updateMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options);

              case 13:
                _context30.t6 = _context30.sent;
                _context30.t7 = (0, _context30.t5)(_context30.t6);
                return _context30.abrupt("return", _context30.t0.call.call(_context30.t0, _context30.t1, _context30.t4, _context30.t7));

              case 16:
                _records = _mapInstanceProperty(records).call(records, function (record) {
                  var id = record.Id,
                      rtype = record.type,
                      attributes = record.attributes,
                      rec = _objectWithoutProperties(record, ["Id", "type", "attributes"]);

                  if (!id) {
                    throw new Error('Record id is not found in record.');
                  }

                  var sobjectType = type || attributes && attributes.type || rtype;

                  if (!sobjectType) {
                    throw new Error('No SObject Type defined in record');
                  }

                  return _objectSpread({
                    id: id,
                    attributes: {
                      type: sobjectType
                    }
                  }, rec);
                });
                url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
                return _context30.abrupt("return", this.request({
                  method: 'PATCH',
                  url: url,
                  body: _JSON$stringify({
                    allOrNone: options.allOrNone || false,
                    records: _records
                  }),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }));

              case 19:
              case "end":
                return _context30.stop();
            }
          }
        }, _callee19, this);
      }));

      function _updateMany(_x43, _x44, _x45) {
        return _updateMany2.apply(this, arguments);
      }

      return _updateMany;
    }()
    /**
     * Upsert records
     */

  }, {
    key: "upsert",

    /**
     *
     * @param type
     * @param records
     * @param extIdField
     * @param options
     */
    value: function () {
      var _upsert = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee20(type, records, extIdField) {
        var _this7 = this;

        var options,
            isArray,
            _records,
            results,
            _args20 = arguments;

        return _regeneratorRuntime.wrap(function _callee20$(_context32) {
          while (1) {
            switch (_context32.prev = _context32.next) {
              case 0:
                options = _args20.length > 3 && _args20[3] !== undefined ? _args20[3] : {};
                isArray = _Array$isArray(records);
                _records = _Array$isArray(records) ? records : [records];

                if (!(_records.length > this._maxRequest)) {
                  _context32.next = 5;
                  break;
                }

                throw new Error('Exceeded max limit of concurrent call');

              case 5:
                _context32.next = 7;
                return _Promise.all(_mapInstanceProperty(_records).call(_records, function (record) {
                  var _context31;

                  var extId = record[extIdField],
                      rtype = record.type,
                      attributes = record.attributes,
                      rec = _objectWithoutProperties(record, _mapInstanceProperty(_context31 = [extIdField, "type", "attributes"]).call(_context31, _toPropertyKey));

                  var url = [_this7._baseUrl(), 'sobjects', type, extIdField, extId].join('/');
                  return _this7.request({
                    method: 'PATCH',
                    url: url,
                    body: _JSON$stringify(rec),
                    headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                      'content-type': 'application/json'
                    })
                  }, {
                    noContentResponse: {
                      success: true,
                      errors: []
                    }
                  }).catch(function (err) {
                    // Be aware that `allOrNone` option in upsert method
                    // will not revert the other successful requests.
                    // It only raises error when met at least one failed request.
                    if (!isArray || options.allOrNone || !err.errorCode) {
                      throw err;
                    }

                    return toSaveResult(err);
                  });
                }));

              case 7:
                results = _context32.sent;
                return _context32.abrupt("return", isArray ? results : results[0]);

              case 9:
              case "end":
                return _context32.stop();
            }
          }
        }, _callee20, this);
      }));

      function upsert(_x46, _x47, _x48) {
        return _upsert.apply(this, arguments);
      }

      return upsert;
    }()
    /**
     * Delete records
     */

  }, {
    key: "destroy",

    /**
     * @param type
     * @param ids
     * @param options
     */
    value: function () {
      var _destroy = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee21(type, ids) {
        var options,
            _args21 = arguments;
        return _regeneratorRuntime.wrap(function _callee21$(_context33) {
          while (1) {
            switch (_context33.prev = _context33.next) {
              case 0:
                options = _args21.length > 2 && _args21[2] !== undefined ? _args21[2] : {};
                return _context33.abrupt("return", _Array$isArray(ids) ? // check the version whether SObject collection API is supported (42.0)
                this._ensureVersion(42) ? this._destroyMany(type, ids, options) : this._destroyParallel(type, ids, options) : this._destroySingle(type, ids, options));

              case 2:
              case "end":
                return _context33.stop();
            }
          }
        }, _callee21, this);
      }));

      function destroy(_x49, _x50) {
        return _destroy.apply(this, arguments);
      }

      return destroy;
    }()
    /** @private */

  }, {
    key: "_destroySingle",
    value: function () {
      var _destroySingle2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee22(type, id, options) {
        var url;
        return _regeneratorRuntime.wrap(function _callee22$(_context34) {
          while (1) {
            switch (_context34.prev = _context34.next) {
              case 0:
                url = [this._baseUrl(), 'sobjects', type, id].join('/');
                return _context34.abrupt("return", this.request({
                  method: 'DELETE',
                  url: url,
                  headers: options.headers || {}
                }, {
                  noContentResponse: {
                    id: id,
                    success: true,
                    errors: []
                  }
                }));

              case 2:
              case "end":
                return _context34.stop();
            }
          }
        }, _callee22, this);
      }));

      function _destroySingle(_x51, _x52, _x53) {
        return _destroySingle2.apply(this, arguments);
      }

      return _destroySingle;
    }()
    /** @private */

  }, {
    key: "_destroyParallel",
    value: function () {
      var _destroyParallel2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee23(type, ids, options) {
        var _this8 = this;

        return _regeneratorRuntime.wrap(function _callee23$(_context35) {
          while (1) {
            switch (_context35.prev = _context35.next) {
              case 0:
                if (!(ids.length > this._maxRequest)) {
                  _context35.next = 2;
                  break;
                }

                throw new Error('Exceeded max limit of concurrent call');

              case 2:
                return _context35.abrupt("return", _Promise.all(_mapInstanceProperty(ids).call(ids, function (id) {
                  return _this8._destroySingle(type, id, options).catch(function (err) {
                    // Be aware that `allOrNone` option in parallel mode
                    // will not revert the other successful requests.
                    // It only raises error when met at least one failed request.
                    if (options.allOrNone || !err.errorCode) {
                      throw err;
                    }

                    return toSaveResult(err);
                  });
                })));

              case 3:
              case "end":
                return _context35.stop();
            }
          }
        }, _callee23, this);
      }));

      function _destroyParallel(_x54, _x55, _x56) {
        return _destroyParallel2.apply(this, arguments);
      }

      return _destroyParallel;
    }()
    /** @private */

  }, {
    key: "_destroyMany",
    value: function () {
      var _destroyMany2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee24(type, ids, options) {
        var _context36, url;

        return _regeneratorRuntime.wrap(function _callee24$(_context37) {
          while (1) {
            switch (_context37.prev = _context37.next) {
              case 0:
                if (!(ids.length === 0)) {
                  _context37.next = 2;
                  break;
                }

                return _context37.abrupt("return", []);

              case 2:
                if (!(ids.length > MAX_DML_COUNT && options.allowRecursive)) {
                  _context37.next = 16;
                  break;
                }

                _context37.t0 = _concatInstanceProperty(_context36 = []);
                _context37.t1 = _context36;
                _context37.t2 = _toConsumableArray;
                _context37.next = 8;
                return this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, 0, MAX_DML_COUNT), options);

              case 8:
                _context37.t3 = _context37.sent;
                _context37.t4 = (0, _context37.t2)(_context37.t3);
                _context37.t5 = _toConsumableArray;
                _context37.next = 13;
                return this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, MAX_DML_COUNT), options);

              case 13:
                _context37.t6 = _context37.sent;
                _context37.t7 = (0, _context37.t5)(_context37.t6);
                return _context37.abrupt("return", _context37.t0.call.call(_context37.t0, _context37.t1, _context37.t4, _context37.t7));

              case 16:
                url = [this._baseUrl(), 'composite', 'sobjects?ids='].join('/') + ids.join(',');

                if (options.allOrNone) {
                  url += '&allOrNone=true';
                }

                return _context37.abrupt("return", this.request({
                  method: 'DELETE',
                  url: url,
                  headers: options.headers || {}
                }));

              case 19:
              case "end":
                return _context37.stop();
            }
          }
        }, _callee24, this);
      }));

      function _destroyMany(_x57, _x58, _x59) {
        return _destroyMany2.apply(this, arguments);
      }

      return _destroyMany;
    }()
    /**
     * Synonym of Connection#destroy()
     */

  }, {
    key: "describe",

    /**
     * Describe SObject metadata
     */
    value: function () {
      var _describe = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee25(type) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee25$(_context38) {
          while (1) {
            switch (_context38.prev = _context38.next) {
              case 0:
                url = [this._baseUrl(), 'sobjects', type, 'describe'].join('/');
                _context38.next = 3;
                return this.request(url);

              case 3:
                body = _context38.sent;
                return _context38.abrupt("return", body);

              case 5:
              case "end":
                return _context38.stop();
            }
          }
        }, _callee25, this);
      }));

      function describe(_x60) {
        return _describe.apply(this, arguments);
      }

      return describe;
    }()
    /**
     * Describe global SObjects
     */

  }, {
    key: "describeGlobal",
    value: function () {
      var _describeGlobal = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee26() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee26$(_context39) {
          while (1) {
            switch (_context39.prev = _context39.next) {
              case 0:
                url = "".concat(this._baseUrl(), "/sobjects");
                _context39.next = 3;
                return this.request(url);

              case 3:
                body = _context39.sent;
                return _context39.abrupt("return", body);

              case 5:
              case "end":
                return _context39.stop();
            }
          }
        }, _callee26, this);
      }));

      function describeGlobal() {
        return _describeGlobal.apply(this, arguments);
      }

      return describeGlobal;
    }()
    /**
     * Get SObject instance
     */

  }, {
    key: "sobject",
    value: function sobject(type) {
      var so = this.sobjects[type] || new SObject(this, type);
      this.sobjects[type] = so;
      return so;
    }
    /**
     * Get identity information of current user
     */

  }, {
    key: "identity",
    value: function () {
      var _identity = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee27() {
        var options,
            url,
            _res,
            res,
            _args27 = arguments;

        return _regeneratorRuntime.wrap(function _callee27$(_context40) {
          while (1) {
            switch (_context40.prev = _context40.next) {
              case 0:
                options = _args27.length > 0 && _args27[0] !== undefined ? _args27[0] : {};
                url = this.userInfo && this.userInfo.url;

                if (url) {
                  _context40.next = 7;
                  break;
                }

                _context40.next = 5;
                return this.request({
                  method: 'GET',
                  url: this._baseUrl(),
                  headers: options.headers
                });

              case 5:
                _res = _context40.sent;
                url = _res.identity;

              case 7:
                url += '?format=json';

                if (this.accessToken) {
                  url += "&oauth_token=".concat(encodeURIComponent(this.accessToken));
                }

                _context40.next = 11;
                return this.request({
                  method: 'GET',
                  url: url
                });

              case 11:
                res = _context40.sent;
                this.userInfo = {
                  id: res.user_id,
                  organizationId: res.organization_id,
                  url: res.id
                };
                return _context40.abrupt("return", res);

              case 14:
              case "end":
                return _context40.stop();
            }
          }
        }, _callee27, this);
      }));

      function identity() {
        return _identity.apply(this, arguments);
      }

      return identity;
    }()
    /**
     * List recently viewed records
     */

  }, {
    key: "recent",
    value: function () {
      var _recent = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee28(type, limit) {
        var url, _yield$this$request, recentItems;

        return _regeneratorRuntime.wrap(function _callee28$(_context41) {
          while (1) {
            switch (_context41.prev = _context41.next) {
              case 0:
                /* eslint-disable no-param-reassign */
                if (typeof type === 'number') {
                  limit = type;
                  type = undefined;
                }

                if (!type) {
                  _context41.next = 8;
                  break;
                }

                url = [this._baseUrl(), 'sobjects', type].join('/');
                _context41.next = 5;
                return this.request(url);

              case 5:
                _yield$this$request = _context41.sent;
                recentItems = _yield$this$request.recentItems;
                return _context41.abrupt("return", limit ? _sliceInstanceProperty(recentItems).call(recentItems, 0, limit) : recentItems);

              case 8:
                url = "".concat(this._baseUrl(), "/recent");

                if (limit) {
                  url += "?limit=".concat(limit);
                }

                return _context41.abrupt("return", this.request(url));

              case 11:
              case "end":
                return _context41.stop();
            }
          }
        }, _callee28, this);
      }));

      function recent(_x61, _x62) {
        return _recent.apply(this, arguments);
      }

      return recent;
    }()
    /**
     * Retrieve updated records
     */

  }, {
    key: "updated",
    value: function () {
      var _updated = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee29(type, start, end) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee29$(_context42) {
          while (1) {
            switch (_context42.prev = _context42.next) {
              case 0:
                /* eslint-disable no-param-reassign */
                url = [this._baseUrl(), 'sobjects', type, 'updated'].join('/');

                if (typeof start === 'string') {
                  start = new Date(start);
                }

                start = formatDate(start);
                url += "?start=".concat(encodeURIComponent(start));

                if (typeof end === 'string') {
                  end = new Date(end);
                }

                end = formatDate(end);
                url += "&end=".concat(encodeURIComponent(end));
                _context42.next = 9;
                return this.request(url);

              case 9:
                body = _context42.sent;
                return _context42.abrupt("return", body);

              case 11:
              case "end":
                return _context42.stop();
            }
          }
        }, _callee29, this);
      }));

      function updated(_x63, _x64, _x65) {
        return _updated.apply(this, arguments);
      }

      return updated;
    }()
    /**
     * Retrieve deleted records
     */

  }, {
    key: "deleted",
    value: function () {
      var _deleted = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee30(type, start, end) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee30$(_context43) {
          while (1) {
            switch (_context43.prev = _context43.next) {
              case 0:
                /* eslint-disable no-param-reassign */
                url = [this._baseUrl(), 'sobjects', type, 'deleted'].join('/');

                if (typeof start === 'string') {
                  start = new Date(start);
                }

                start = formatDate(start);
                url += "?start=".concat(encodeURIComponent(start));

                if (typeof end === 'string') {
                  end = new Date(end);
                }

                end = formatDate(end);
                url += "&end=".concat(encodeURIComponent(end));
                _context43.next = 9;
                return this.request(url);

              case 9:
                body = _context43.sent;
                return _context43.abrupt("return", body);

              case 11:
              case "end":
                return _context43.stop();
            }
          }
        }, _callee30, this);
      }));

      function deleted(_x66, _x67, _x68) {
        return _deleted.apply(this, arguments);
      }

      return deleted;
    }()
    /**
     * Returns a list of all tabs
     */

  }, {
    key: "tabs",
    value: function () {
      var _tabs = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee31() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee31$(_context44) {
          while (1) {
            switch (_context44.prev = _context44.next) {
              case 0:
                url = [this._baseUrl(), 'tabs'].join('/');
                _context44.next = 3;
                return this.request(url);

              case 3:
                body = _context44.sent;
                return _context44.abrupt("return", body);

              case 5:
              case "end":
                return _context44.stop();
            }
          }
        }, _callee31, this);
      }));

      function tabs() {
        return _tabs.apply(this, arguments);
      }

      return tabs;
    }()
    /**
     * Returns current system limit in the organization
     */

  }, {
    key: "limits",
    value: function () {
      var _limits = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee32() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee32$(_context45) {
          while (1) {
            switch (_context45.prev = _context45.next) {
              case 0:
                url = [this._baseUrl(), 'limits'].join('/');
                _context45.next = 3;
                return this.request(url);

              case 3:
                body = _context45.sent;
                return _context45.abrupt("return", body);

              case 5:
              case "end":
                return _context45.stop();
            }
          }
        }, _callee32, this);
      }));

      function limits() {
        return _limits.apply(this, arguments);
      }

      return limits;
    }()
    /**
     * Returns a theme info
     */

  }, {
    key: "theme",
    value: function () {
      var _theme = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee33() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee33$(_context46) {
          while (1) {
            switch (_context46.prev = _context46.next) {
              case 0:
                url = [this._baseUrl(), 'theme'].join('/');
                _context46.next = 3;
                return this.request(url);

              case 3:
                body = _context46.sent;
                return _context46.abrupt("return", body);

              case 5:
              case "end":
                return _context46.stop();
            }
          }
        }, _callee33, this);
      }));

      function theme() {
        return _theme.apply(this, arguments);
      }

      return theme;
    }()
    /**
     * Returns all registered global quick actions
     */

  }, {
    key: "quickActions",
    value: function () {
      var _quickActions = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee34() {
        var body;
        return _regeneratorRuntime.wrap(function _callee34$(_context47) {
          while (1) {
            switch (_context47.prev = _context47.next) {
              case 0:
                _context47.next = 2;
                return this.request('/quickActions');

              case 2:
                body = _context47.sent;
                return _context47.abrupt("return", body);

              case 4:
              case "end":
                return _context47.stop();
            }
          }
        }, _callee34, this);
      }));

      function quickActions() {
        return _quickActions.apply(this, arguments);
      }

      return quickActions;
    }()
    /**
     * Get reference for specified global quick action
     */

  }, {
    key: "quickAction",
    value: function quickAction(actionName) {
      return new QuickAction(this, "/quickActions/".concat(actionName));
    }
    /**
     * Module which manages process rules and approval processes
     */

  }]);

  return Connection;
}(EventEmitter);

_defineProperty(Connection, "_logger", getLogger('connection'));

export default Connection;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9jb25uZWN0aW9uLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsImpzZm9yY2UiLCJUcmFuc3BvcnQiLCJDYW52YXNUcmFuc3BvcnQiLCJYZFByb3h5VHJhbnNwb3J0IiwiSHR0cFByb3h5VHJhbnNwb3J0IiwiZ2V0TG9nZ2VyIiwiT0F1dGgyIiwiQ2FjaGUiLCJIdHRwQXBpIiwiU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSIsIlF1ZXJ5IiwiU09iamVjdCIsIlF1aWNrQWN0aW9uIiwiUHJvY2VzcyIsImZvcm1hdERhdGUiLCJkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZyIsImxvZ2luVXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwibG9nTGV2ZWwiLCJtYXhSZXF1ZXN0IiwiZXNjIiwic3RyIiwiU3RyaW5nIiwicmVwbGFjZSIsInBhcnNlU2lnbmVkUmVxdWVzdCIsInNyIiwiSlNPTiIsInBhcnNlIiwibXNnIiwic3BsaXQiLCJwb3AiLCJFcnJvciIsImpzb24iLCJCdWZmZXIiLCJmcm9tIiwidG9TdHJpbmciLCJwYXJzZUlkVXJsIiwidXJsIiwib3JnYW5pemF0aW9uSWQiLCJpZCIsIm9hdXRoUmVmcmVzaEZuIiwiY29ubiIsImNhbGxiYWNrIiwicmVmcmVzaFRva2VuIiwib2F1dGgyIiwicmVzIiwidXNlckluZm8iLCJfZXN0YWJsaXNoIiwiaW5zdGFuY2VfdXJsIiwiYWNjZXNzVG9rZW4iLCJhY2Nlc3NfdG9rZW4iLCJ1bmRlZmluZWQiLCJjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsImxvZ2luIiwidG9TYXZlUmVzdWx0IiwiZXJyIiwic3VjY2VzcyIsImVycm9ycyIsInJhaXNlTm9Nb2R1bGVFcnJvciIsIm5hbWUiLCJNQVhfRE1MX0NPVU5UIiwiQ29ubmVjdGlvbiIsImNvbmZpZyIsImNyZWF0ZSIsImRlc3Ryb3kiLCJwcm94eVVybCIsImh0dHBQcm94eSIsInJlZnJlc2hGbiIsImNsaWVudElkIiwiX3JlZnJlc2hEZWxlZ2F0ZSIsIl9tYXhSZXF1ZXN0IiwiX2xvZ2dlciIsImNyZWF0ZUluc3RhbmNlIiwiX2xvZ0xldmVsIiwiX3RyYW5zcG9ydCIsIl9jYWxsT3B0aW9ucyIsImNhbGxPcHRpb25zIiwiY2FjaGUiLCJkZXNjcmliZUNhY2hlS2V5IiwidHlwZSIsImRlc2NyaWJlIiwicHJvdG90eXBlIiwiY3JlYXRlQ2FjaGVkRnVuY3Rpb24iLCJrZXkiLCJzdHJhdGVneSIsImRlc2NyaWJlJCIsImRlc2NyaWJlJCQiLCJkZXNjcmliZVNPYmplY3QiLCJkZXNjcmliZVNPYmplY3QkIiwiZGVzY3JpYmVTT2JqZWN0JCQiLCJkZXNjcmliZUdsb2JhbCIsImRlc2NyaWJlR2xvYmFsJCIsImRlc2NyaWJlR2xvYmFsJCQiLCJzZXNzaW9uSWQiLCJzZXJ2ZXJVcmwiLCJzaWduZWRSZXF1ZXN0IiwiZW1pdCIsIm9wdGlvbnMiLCJqb2luIiwic2lnbmVkUmVxdWVzdE9iamVjdCIsImNsaWVudCIsIm9hdXRoVG9rZW4iLCJzdXBwb3J0ZWQiLCJfc2Vzc2lvblR5cGUiLCJfcmVzZXRJbnN0YW5jZSIsImxpbWl0SW5mbyIsInNvYmplY3RzIiwiY2xlYXIiLCJnZXQiLCJyZW1vdmVBbGxMaXN0ZW5lcnMiLCJvbiIsInJlc3VsdCIsInNvIiwic29iamVjdCIsImNvZGUiLCJwYXJhbXMiLCJyZXF1ZXN0VG9rZW4iLCJyZWZyZXNoX3Rva2VuIiwiZGVidWciLCJjbGllbnRTZWNyZXQiLCJsb2dpbkJ5T0F1dGgyIiwibG9naW5CeVNvYXAiLCJhdXRoZW50aWNhdGUiLCJpbmZvIiwicmVqZWN0IiwiYm9keSIsInNvYXBMb2dpbkVuZHBvaW50IiwiaHR0cFJlcXVlc3QiLCJtZXRob2QiLCJoZWFkZXJzIiwiU09BUEFjdGlvbiIsInJlc3BvbnNlIiwic3RhdHVzQ29kZSIsIm0iLCJtYXRjaCIsImZhdWx0c3RyaW5nIiwidXNlcklkIiwiaWRVcmwiLCJyZXZva2UiLCJsb2dvdXRCeU9BdXRoMiIsImxvZ291dEJ5U29hcCIsInRva2VuIiwicmV2b2tlVG9rZW4iLCJfY2xlYXJTZXNzaW9uIiwicmVxdWVzdCIsInJlcXVlc3RfIiwiX25vcm1hbGl6ZVVybCIsImh0dHBBcGkiLCJhcGlVc2FnZSIsInVzZWQiLCJsaW1pdCIsIl9iYXNlVXJsIiwic29xbCIsInNvc2wiLCJlbmNvZGVVUklDb21wb25lbnQiLCJsb2NhdG9yIiwibWFqb3JWZXJzaW9uIiwidmVyc2lvbnMiLCJmZWF0dXJlIiwiX2Vuc3VyZVZlcnNpb24iLCJpZHMiLCJfcmV0cmlldmVNYW55IiwiX3JldHJpZXZlUGFyYWxsZWwiLCJfcmV0cmlldmVTaW5nbGUiLCJmaWVsZHMiLCJsZW5ndGgiLCJhbGwiLCJjYXRjaCIsImFsbE9yTm9uZSIsImVycm9yQ29kZSIsImZpZWxkIiwicmVjb3JkcyIsIl9jcmVhdGVNYW55IiwiX2NyZWF0ZVBhcmFsbGVsIiwiX2NyZWF0ZVNpbmdsZSIsInJldCIsInJlY29yZCIsIklkIiwicnR5cGUiLCJhdHRyaWJ1dGVzIiwicmVjIiwic29iamVjdFR5cGUiLCJyZXNvbHZlIiwiYWxsb3dSZWN1cnNpdmUiLCJfcmVjb3JkcyIsIl91cGRhdGVNYW55IiwiX3VwZGF0ZVBhcmFsbGVsIiwiX3VwZGF0ZVNpbmdsZSIsIm5vQ29udGVudFJlc3BvbnNlIiwiZXh0SWRGaWVsZCIsImlzQXJyYXkiLCJleHRJZCIsInJlc3VsdHMiLCJfZGVzdHJveU1hbnkiLCJfZGVzdHJveVBhcmFsbGVsIiwiX2Rlc3Ryb3lTaW5nbGUiLCJpZGVudGl0eSIsInVzZXJfaWQiLCJvcmdhbml6YXRpb25faWQiLCJyZWNlbnRJdGVtcyIsInN0YXJ0IiwiZW5kIiwiRGF0ZSIsImFjdGlvbk5hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsT0FBT0MsT0FBUCxNQUFvQixXQUFwQjtBQWdDQSxPQUFPQyxTQUFQLElBQ0VDLGVBREYsRUFFRUMsZ0JBRkYsRUFHRUMsa0JBSEYsUUFJTyxhQUpQO0FBS0EsU0FBaUJDLFNBQWpCLFFBQWtDLGVBQWxDO0FBRUEsT0FBT0MsTUFBUCxNQUFzQyxVQUF0QztBQUVBLE9BQU9DLEtBQVAsTUFBc0MsU0FBdEM7QUFDQSxPQUFPQyxPQUFQLE1BQW9CLFlBQXBCO0FBQ0EsT0FBT0Msc0JBQVAsTUFFTyw0QkFGUDtBQUdBLE9BQU9DLEtBQVAsTUFBa0IsU0FBbEI7QUFFQSxPQUFPQyxPQUFQLE1BQW9CLFdBQXBCO0FBQ0EsT0FBT0MsV0FBUCxNQUF3QixnQkFBeEI7QUFDQSxPQUFPQyxPQUFQLE1BQW9CLFdBQXBCO0FBQ0EsU0FBU0MsVUFBVCxRQUEyQixrQkFBM0I7O0FBMkNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHVCQU1MLEdBQUc7QUFDRkMsRUFBQUEsUUFBUSxFQUFFLDhCQURSO0FBRUZDLEVBQUFBLFdBQVcsRUFBRSxFQUZYO0FBR0ZDLEVBQUFBLE9BQU8sRUFBRSxNQUhQO0FBSUZDLEVBQUFBLFFBQVEsRUFBRSxNQUpSO0FBS0ZDLEVBQUFBLFVBQVUsRUFBRTtBQUxWLENBTko7QUFjQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0MsR0FBVCxDQUFhQyxHQUFiLEVBQTRDO0FBQzFDLFNBQU9DLE1BQU0sQ0FBQ0QsR0FBRyxJQUFJLEVBQVIsQ0FBTixDQUNKRSxPQURJLENBQ0ksSUFESixFQUNVLE9BRFYsRUFFSkEsT0FGSSxDQUVJLElBRkosRUFFVSxNQUZWLEVBR0pBLE9BSEksQ0FHSSxJQUhKLEVBR1UsTUFIVixFQUlKQSxPQUpJLENBSUksSUFKSixFQUlVLFFBSlYsQ0FBUDtBQUtEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxTQUFTQyxrQkFBVCxDQUE0QkMsRUFBNUIsRUFBc0U7QUFDcEUsTUFBSSxPQUFPQSxFQUFQLEtBQWMsUUFBbEIsRUFBNEI7QUFDMUIsUUFBSUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLEdBQWQsRUFBbUI7QUFDakI7QUFDQSxhQUFPQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsRUFBWCxDQUFQO0FBQ0QsS0FKeUIsQ0FJeEI7OztBQUNGLFFBQU1HLEdBQUcsR0FBR0gsRUFBRSxDQUFDSSxLQUFILENBQVMsR0FBVCxFQUFjQyxHQUFkLEVBQVosQ0FMMEIsQ0FLTzs7QUFDakMsUUFBSSxDQUFDRixHQUFMLEVBQVU7QUFDUixZQUFNLElBQUlHLEtBQUosQ0FBVSx3QkFBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFBTUMsSUFBSSxHQUFHQyxNQUFNLENBQUNDLElBQVAsQ0FBWU4sR0FBWixFQUFpQixRQUFqQixFQUEyQk8sUUFBM0IsQ0FBb0MsT0FBcEMsQ0FBYjtBQUNBLFdBQU9ULElBQUksQ0FBQ0MsS0FBTCxDQUFXSyxJQUFYLENBQVA7QUFDRDs7QUFDRCxTQUFPUCxFQUFQO0FBQ0Q7QUFFRDs7O0FBQ0EsU0FBU1csVUFBVCxDQUFvQkMsR0FBcEIsRUFBaUM7QUFBQTs7QUFBQSx5QkFDRixrQ0FBQUEsR0FBRyxDQUFDUixLQUFKLENBQVUsR0FBVixrQkFBcUIsQ0FBQyxDQUF0QixDQURFO0FBQUE7QUFBQSxNQUN4QlMsY0FEd0I7QUFBQSxNQUNSQyxFQURROztBQUUvQixTQUFPO0FBQUVBLElBQUFBLEVBQUUsRUFBRkEsRUFBRjtBQUFNRCxJQUFBQSxjQUFjLEVBQWRBLGNBQU47QUFBc0JELElBQUFBLEdBQUcsRUFBSEE7QUFBdEIsR0FBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7OztTQUNlRyxjOzs7QUF5QmY7QUFDQTtBQUNBO0FBQ0E7Ozs7NkVBNUJBLG1CQUNFQyxJQURGLEVBRUVDLFFBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUEsZ0JBS1NELElBQUksQ0FBQ0UsWUFMZDtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFNWSxJQUFJWixLQUFKLENBQVUsMENBQVYsQ0FOWjs7QUFBQTtBQUFBO0FBQUEsbUJBUXNCVSxJQUFJLENBQUNHLE1BQUwsQ0FBWUQsWUFBWixDQUF5QkYsSUFBSSxDQUFDRSxZQUE5QixDQVJ0Qjs7QUFBQTtBQVFVRSxZQUFBQSxHQVJWO0FBU1VDLFlBQUFBLFFBVFYsR0FTcUJWLFVBQVUsQ0FBQ1MsR0FBRyxDQUFDTixFQUFMLENBVC9COztBQVVJRSxZQUFBQSxJQUFJLENBQUNNLFVBQUwsQ0FBZ0I7QUFDZC9CLGNBQUFBLFdBQVcsRUFBRTZCLEdBQUcsQ0FBQ0csWUFESDtBQUVkQyxjQUFBQSxXQUFXLEVBQUVKLEdBQUcsQ0FBQ0ssWUFGSDtBQUdkSixjQUFBQSxRQUFRLEVBQVJBO0FBSGMsYUFBaEI7O0FBS0FKLFlBQUFBLFFBQVEsQ0FBQ1MsU0FBRCxFQUFZTixHQUFHLENBQUNLLFlBQWhCLEVBQThCTCxHQUE5QixDQUFSO0FBZko7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0JBaUJRLHlCQUFlZCxLQWpCdkI7QUFBQTtBQUFBO0FBQUE7O0FBa0JNVyxZQUFBQSxRQUFRLGVBQVI7QUFsQk47QUFBQTs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7QUE2QkEsU0FBU1UsK0JBQVQsQ0FDRUMsUUFERixFQUVFQyxRQUZGLEVBR0U7QUFDQTtBQUFBLHdFQUFPLGlCQUNMYixJQURLLEVBRUxDLFFBRks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLR0QsSUFBSSxDQUFDYyxLQUFMLENBQVdGLFFBQVgsRUFBcUJDLFFBQXJCLENBTEg7O0FBQUE7QUFBQSxrQkFNRWIsSUFBSSxDQUFDUSxXQU5QO0FBQUE7QUFBQTtBQUFBOztBQUFBLG9CQU9LLElBQUlsQixLQUFKLENBQVUsb0NBQVYsQ0FQTDs7QUFBQTtBQVNIVyxjQUFBQSxRQUFRLENBQUMsSUFBRCxFQUFPRCxJQUFJLENBQUNRLFdBQVosQ0FBUjtBQVRHO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBLG9CQVdDLHdCQUFlbEIsS0FYaEI7QUFBQTtBQUFBO0FBQUE7O0FBWURXLGNBQUFBLFFBQVEsY0FBUjtBQVpDO0FBQUE7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFQOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBa0JEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxTQUFTYyxZQUFULENBQXNCQyxHQUF0QixFQUFrRDtBQUNoRCxTQUFPO0FBQ0xDLElBQUFBLE9BQU8sRUFBRSxLQURKO0FBRUxDLElBQUFBLE1BQU0sRUFBRSxDQUFDRixHQUFEO0FBRkgsR0FBUDtBQUlEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxTQUFTRyxrQkFBVCxDQUE0QkMsSUFBNUIsRUFBaUQ7QUFBQTs7QUFDL0MsUUFBTSxJQUFJOUIsS0FBSiwyREFDVzhCLElBRFgsMERBQ3FEQSxJQURyRCxrQkFBTjtBQUdEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxJQUFNQyxhQUFhLEdBQUcsR0FBdEI7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsV0FBYUMsVUFBYjtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFxQkU7QUFRQTtBQUlBO0FBQ0E7QUFsQ0Ysd0JBbUNnQztBQUM1QixhQUFPSCxrQkFBa0IsQ0FBQyxXQUFELENBQXpCO0FBQ0Q7QUFyQ0g7QUFBQTtBQUFBLHdCQXVDc0I7QUFDbEIsYUFBT0Esa0JBQWtCLENBQUMsTUFBRCxDQUF6QjtBQUNEO0FBekNIO0FBQUE7QUFBQSx3QkEyQ3NCO0FBQ2xCLGFBQU9BLGtCQUFrQixDQUFDLE1BQUQsQ0FBekI7QUFDRDtBQTdDSDtBQUFBO0FBQUEsd0JBK0N5QjtBQUNyQixhQUFPQSxrQkFBa0IsQ0FBQyxPQUFELENBQXpCO0FBQ0Q7QUFqREg7QUFBQTtBQUFBLHdCQW1ENEI7QUFDeEIsYUFBT0Esa0JBQWtCLENBQUMsU0FBRCxDQUF6QjtBQUNEO0FBckRIO0FBQUE7QUFBQSx3QkF1RDhCO0FBQzFCLGFBQU9BLGtCQUFrQixDQUFDLFVBQUQsQ0FBekI7QUFDRDtBQXpESDtBQUFBO0FBQUEsd0JBMkR5QjtBQUNyQixhQUFPQSxrQkFBa0IsQ0FBQyxNQUFELENBQXpCO0FBQ0Q7QUE3REg7QUFBQTtBQUFBLHdCQStEZ0M7QUFDNUIsYUFBT0Esa0JBQWtCLENBQUMsV0FBRCxDQUF6QjtBQUNEO0FBakVIO0FBQUE7QUFBQSx3QkFtRTRCO0FBQ3hCLGFBQU9BLGtCQUFrQixDQUFDLFNBQUQsQ0FBekI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF6RUE7O0FBMEVFLHdCQUE4QztBQUFBOztBQUFBLFFBQWxDSSxNQUFrQyx1RUFBSixFQUFJOztBQUFBOztBQUM1Qzs7QUFENEM7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsZ0VBakV2QixFQWlFdUI7O0FBQUE7O0FBQUEsK0RBL0RTLEVBK0RUOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLDZEQXF1QnJDLE1BQUtDLE1BcnVCZ0M7O0FBQUEsNkRBb2pDckMsTUFBS0MsT0FwakNnQzs7QUFBQSwwREF5akN4QyxNQUFLQSxPQXpqQ21DOztBQUFBLDhEQTB1Q3BDLElBQUl0RCxPQUFKLCtCQTF1Q29DOztBQUFBLFFBRzFDRyxRQUgwQyxHQVd4Q2lELE1BWHdDLENBRzFDakQsUUFIMEM7QUFBQSxRQUkxQ0MsV0FKMEMsR0FXeENnRCxNQVh3QyxDQUkxQ2hELFdBSjBDO0FBQUEsUUFLMUNDLE9BTDBDLEdBV3hDK0MsTUFYd0MsQ0FLMUMvQyxPQUwwQztBQUFBLFFBTTFDMkIsTUFOMEMsR0FXeENvQixNQVh3QyxDQU0xQ3BCLE1BTjBDO0FBQUEsUUFPMUN6QixVQVAwQyxHQVd4QzZDLE1BWHdDLENBTzFDN0MsVUFQMEM7QUFBQSxRQVExQ0QsUUFSMEMsR0FXeEM4QyxNQVh3QyxDQVExQzlDLFFBUjBDO0FBQUEsUUFTMUNpRCxRQVQwQyxHQVd4Q0gsTUFYd0MsQ0FTMUNHLFFBVDBDO0FBQUEsUUFVMUNDLFNBVjBDLEdBV3hDSixNQVh3QyxDQVUxQ0ksU0FWMEM7QUFZNUMsVUFBS3JELFFBQUwsR0FBZ0JBLFFBQVEsSUFBSUQsdUJBQXVCLENBQUNDLFFBQXBEO0FBQ0EsVUFBS0MsV0FBTCxHQUFtQkEsV0FBVyxJQUFJRix1QkFBdUIsQ0FBQ0UsV0FBMUQ7QUFDQSxVQUFLQyxPQUFMLEdBQWVBLE9BQU8sSUFBSUgsdUJBQXVCLENBQUNHLE9BQWxEO0FBQ0EsVUFBSzJCLE1BQUwsR0FDRUEsTUFBTSxZQUFZdkMsTUFBbEIsR0FDSXVDLE1BREosR0FFSSxJQUFJdkMsTUFBSjtBQUNFVSxNQUFBQSxRQUFRLEVBQUUsTUFBS0EsUUFEakI7QUFFRW9ELE1BQUFBLFFBQVEsRUFBUkEsUUFGRjtBQUdFQyxNQUFBQSxTQUFTLEVBQVRBO0FBSEYsT0FJS3hCLE1BSkwsRUFITjtBQVNBLFFBQUl5QixTQUFTLEdBQUdMLE1BQU0sQ0FBQ0ssU0FBdkI7O0FBQ0EsUUFBSSxDQUFDQSxTQUFELElBQWMsTUFBS3pCLE1BQUwsQ0FBWTBCLFFBQTlCLEVBQXdDO0FBQ3RDRCxNQUFBQSxTQUFTLEdBQUc3QixjQUFaO0FBQ0Q7O0FBQ0QsUUFBSTZCLFNBQUosRUFBZTtBQUNiLFlBQUtFLGdCQUFMLEdBQXdCLElBQUkvRCxzQkFBSixnQ0FBaUM2RCxTQUFqQyxDQUF4QjtBQUNEOztBQUNELFVBQUtHLFdBQUwsR0FBbUJyRCxVQUFVLElBQUlMLHVCQUF1QixDQUFDSyxVQUF6RDtBQUNBLFVBQUtzRCxPQUFMLEdBQWV2RCxRQUFRLEdBQ25CNkMsVUFBVSxDQUFDVSxPQUFYLENBQW1CQyxjQUFuQixDQUFrQ3hELFFBQWxDLENBRG1CLEdBRW5CNkMsVUFBVSxDQUFDVSxPQUZmO0FBR0EsVUFBS0UsU0FBTCxHQUFpQnpELFFBQWpCO0FBQ0EsVUFBSzBELFVBQUwsR0FBa0JULFFBQVEsR0FDdEIsSUFBSWpFLGdCQUFKLENBQXFCaUUsUUFBckIsQ0FEc0IsR0FFdEJDLFNBQVMsR0FDVCxJQUFJakUsa0JBQUosQ0FBdUJpRSxTQUF2QixDQURTLEdBRVQsSUFBSXBFLFNBQUosRUFKSjtBQUtBLFVBQUs2RSxZQUFMLEdBQW9CYixNQUFNLENBQUNjLFdBQTNCO0FBQ0EsVUFBS0MsS0FBTCxHQUFhLElBQUl6RSxLQUFKLEVBQWI7O0FBQ0EsUUFBTTBFLGdCQUFnQixHQUFHLFNBQW5CQSxnQkFBbUIsQ0FBQ0MsSUFBRDtBQUFBLGFBQ3ZCQSxJQUFJLHNCQUFlQSxJQUFmLElBQXdCLFVBREw7QUFBQSxLQUF6Qjs7QUFFQSxRQUFNQyxRQUFRLEdBQUduQixVQUFVLENBQUNvQixTQUFYLENBQXFCRCxRQUF0QztBQUNBLFVBQUtBLFFBQUwsR0FBZ0IsTUFBS0gsS0FBTCxDQUFXSyxvQkFBWCxDQUFnQ0YsUUFBaEMsaUNBQWdEO0FBQzlERyxNQUFBQSxHQUFHLEVBQUVMLGdCQUR5RDtBQUU5RE0sTUFBQUEsUUFBUSxFQUFFO0FBRm9ELEtBQWhELENBQWhCO0FBSUEsVUFBS0MsU0FBTCxHQUFpQixNQUFLUixLQUFMLENBQVdLLG9CQUFYLENBQWdDRixRQUFoQyxpQ0FBZ0Q7QUFDL0RHLE1BQUFBLEdBQUcsRUFBRUwsZ0JBRDBEO0FBRS9ETSxNQUFBQSxRQUFRLEVBQUU7QUFGcUQsS0FBaEQsQ0FBakI7QUFJQSxVQUFLRSxVQUFMLEdBQWtCLE1BQUtULEtBQUwsQ0FBV0ssb0JBQVgsQ0FBZ0NGLFFBQWhDLGlDQUFnRDtBQUNoRUcsTUFBQUEsR0FBRyxFQUFFTCxnQkFEMkQ7QUFFaEVNLE1BQUFBLFFBQVEsRUFBRTtBQUZzRCxLQUFoRCxDQUFsQjtBQUlBLFVBQUtHLGVBQUwsR0FBdUIsTUFBS1AsUUFBNUI7QUFDQSxVQUFLUSxnQkFBTCxHQUF3QixNQUFLSCxTQUE3QjtBQUNBLFVBQUtJLGlCQUFMLEdBQXlCLE1BQUtILFVBQTlCO0FBQ0EsUUFBTUksY0FBYyxHQUFHN0IsVUFBVSxDQUFDb0IsU0FBWCxDQUFxQlMsY0FBNUM7QUFDQSxVQUFLQSxjQUFMLEdBQXNCLE1BQUtiLEtBQUwsQ0FBV0ssb0JBQVgsQ0FDcEJRLGNBRG9CLGlDQUdwQjtBQUFFUCxNQUFBQSxHQUFHLEVBQUUsZ0JBQVA7QUFBeUJDLE1BQUFBLFFBQVEsRUFBRTtBQUFuQyxLQUhvQixDQUF0QjtBQUtBLFVBQUtPLGVBQUwsR0FBdUIsTUFBS2QsS0FBTCxDQUFXSyxvQkFBWCxDQUNyQlEsY0FEcUIsaUNBR3JCO0FBQUVQLE1BQUFBLEdBQUcsRUFBRSxnQkFBUDtBQUF5QkMsTUFBQUEsUUFBUSxFQUFFO0FBQW5DLEtBSHFCLENBQXZCO0FBS0EsVUFBS1EsZ0JBQUwsR0FBd0IsTUFBS2YsS0FBTCxDQUFXSyxvQkFBWCxDQUN0QlEsY0FEc0IsaUNBR3RCO0FBQUVQLE1BQUFBLEdBQUcsRUFBRSxnQkFBUDtBQUF5QkMsTUFBQUEsUUFBUSxFQUFFO0FBQW5DLEtBSHNCLENBQXhCO0FBeEU0QyxRQThFMUNyQyxXQTlFMEMsR0FtRnhDZSxNQW5Gd0MsQ0E4RTFDZixXQTlFMEM7QUFBQSxRQStFMUNOLFlBL0UwQyxHQW1GeENxQixNQW5Gd0MsQ0ErRTFDckIsWUEvRTBDO0FBQUEsUUFnRjFDb0QsU0FoRjBDLEdBbUZ4Qy9CLE1BbkZ3QyxDQWdGMUMrQixTQWhGMEM7QUFBQSxRQWlGMUNDLFNBakYwQyxHQW1GeENoQyxNQW5Gd0MsQ0FpRjFDZ0MsU0FqRjBDO0FBQUEsUUFrRjFDQyxhQWxGMEMsR0FtRnhDakMsTUFuRndDLENBa0YxQ2lDLGFBbEYwQzs7QUFvRjVDLFVBQUtsRCxVQUFMLENBQWdCO0FBQ2RFLE1BQUFBLFdBQVcsRUFBWEEsV0FEYztBQUVkTixNQUFBQSxZQUFZLEVBQVpBLFlBRmM7QUFHZDNCLE1BQUFBLFdBQVcsRUFBWEEsV0FIYztBQUlkK0UsTUFBQUEsU0FBUyxFQUFUQSxTQUpjO0FBS2RDLE1BQUFBLFNBQVMsRUFBVEEsU0FMYztBQU1kQyxNQUFBQSxhQUFhLEVBQWJBO0FBTmMsS0FBaEI7O0FBU0FsRyxJQUFBQSxPQUFPLENBQUNtRyxJQUFSLENBQWEsZ0JBQWI7QUE3RjRDO0FBOEY3QztBQUVEOzs7QUExS0Y7QUFBQTtBQUFBLCtCQTJLYUMsT0EzS2IsRUEyS2tEO0FBQUE7O0FBQUEsVUFFNUNsRCxXQUY0QyxHQVMxQ2tELE9BVDBDLENBRTVDbEQsV0FGNEM7QUFBQSxVQUc1Q04sWUFINEMsR0FTMUN3RCxPQVQwQyxDQUc1Q3hELFlBSDRDO0FBQUEsVUFJNUMzQixXQUo0QyxHQVMxQ21GLE9BVDBDLENBSTVDbkYsV0FKNEM7QUFBQSxVQUs1QytFLFNBTDRDLEdBUzFDSSxPQVQwQyxDQUs1Q0osU0FMNEM7QUFBQSxVQU01Q0MsU0FONEMsR0FTMUNHLE9BVDBDLENBTTVDSCxTQU40QztBQUFBLFVBTzVDQyxhQVA0QyxHQVMxQ0UsT0FUMEMsQ0FPNUNGLGFBUDRDO0FBQUEsVUFRNUNuRCxRQVI0QyxHQVMxQ3FELE9BVDBDLENBUTVDckQsUUFSNEM7QUFVOUMsV0FBSzlCLFdBQUwsR0FBbUJnRixTQUFTLEdBQ3hCLG1DQUFBQSxTQUFTLENBQUNuRSxLQUFWLENBQWdCLEdBQWhCLG1CQUEyQixDQUEzQixFQUE4QixDQUE5QixFQUFpQ3VFLElBQWpDLENBQXNDLEdBQXRDLENBRHdCLEdBRXhCcEYsV0FBVyxJQUFJLEtBQUtBLFdBRnhCO0FBR0EsV0FBS2lDLFdBQUwsR0FBbUI4QyxTQUFTLElBQUk5QyxXQUFiLElBQTRCLEtBQUtBLFdBQXBEO0FBQ0EsV0FBS04sWUFBTCxHQUFvQkEsWUFBWSxJQUFJLEtBQUtBLFlBQXpDOztBQUNBLFVBQUksS0FBS0EsWUFBTCxJQUFxQixDQUFDLEtBQUs0QixnQkFBL0IsRUFBaUQ7QUFDL0MsY0FBTSxJQUFJeEMsS0FBSixDQUNKLGtGQURJLENBQU47QUFHRDs7QUFDRCxVQUFNc0UsbUJBQW1CLEdBQ3ZCSixhQUFhLElBQUl6RSxrQkFBa0IsQ0FBQ3lFLGFBQUQsQ0FEckM7O0FBRUEsVUFBSUksbUJBQUosRUFBeUI7QUFDdkIsYUFBS3BELFdBQUwsR0FBbUJvRCxtQkFBbUIsQ0FBQ0MsTUFBcEIsQ0FBMkJDLFVBQTlDOztBQUNBLFlBQUl0RyxlQUFlLENBQUN1RyxTQUFwQixFQUErQjtBQUM3QixlQUFLNUIsVUFBTCxHQUFrQixJQUFJM0UsZUFBSixDQUFvQm9HLG1CQUFwQixDQUFsQjtBQUNEO0FBQ0Y7O0FBQ0QsV0FBS3ZELFFBQUwsR0FBZ0JBLFFBQVEsSUFBSSxLQUFLQSxRQUFqQztBQUNBLFdBQUsyRCxZQUFMLEdBQW9CVixTQUFTLEdBQUcsTUFBSCxHQUFZLFFBQXpDOztBQUNBLFdBQUtXLGNBQUw7QUFDRDtBQUVEOztBQTVNRjtBQUFBO0FBQUEsb0NBNk1rQjtBQUNkLFdBQUt6RCxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsV0FBS04sWUFBTCxHQUFvQixJQUFwQjtBQUNBLFdBQUszQixXQUFMLEdBQW1CRix1QkFBdUIsQ0FBQ0UsV0FBM0M7QUFDQSxXQUFLOEIsUUFBTCxHQUFnQixJQUFoQjtBQUNBLFdBQUsyRCxZQUFMLEdBQW9CLElBQXBCO0FBQ0Q7QUFFRDs7QUFyTkY7QUFBQTtBQUFBLHFDQXNObUI7QUFBQTs7QUFDZixXQUFLRSxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsV0FBS0MsUUFBTCxHQUFnQixFQUFoQixDQUZlLENBR2Y7O0FBQ0EsV0FBSzdCLEtBQUwsQ0FBVzhCLEtBQVg7QUFDQSxXQUFLOUIsS0FBTCxDQUFXK0IsR0FBWCxDQUFlLGdCQUFmLEVBQWlDQyxrQkFBakMsQ0FBb0QsT0FBcEQ7QUFDQSxXQUFLaEMsS0FBTCxDQUFXK0IsR0FBWCxDQUFlLGdCQUFmLEVBQWlDRSxFQUFqQyxDQUFvQyxPQUFwQyxFQUE2QyxpQkFBZ0I7QUFBQSxZQUFiQyxNQUFhLFNBQWJBLE1BQWE7O0FBQzNELFlBQUlBLE1BQUosRUFBWTtBQUFBLHFEQUNPQSxNQUFNLENBQUNMLFFBRGQ7QUFBQTs7QUFBQTtBQUNWLGdFQUFrQztBQUFBLGtCQUF2Qk0sRUFBdUI7O0FBQ2hDLGNBQUEsTUFBSSxDQUFDQyxPQUFMLENBQWFELEVBQUUsQ0FBQ3JELElBQWhCO0FBQ0Q7QUFIUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSVg7QUFDRixPQU5EO0FBT0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNHO0FBRUQ7QUFDRjtBQUNBOztBQTVPQTtBQUFBO0FBQUE7QUFBQSxrR0E4T0l1RCxJQTlPSjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUErT0lDLGdCQUFBQSxNQS9PSiw4REErT3lDLEVBL096QztBQUFBO0FBQUEsdUJBaVBzQixLQUFLekUsTUFBTCxDQUFZMEUsWUFBWixDQUF5QkYsSUFBekIsRUFBK0JDLE1BQS9CLENBalB0Qjs7QUFBQTtBQWlQVXhFLGdCQUFBQSxHQWpQVjtBQWtQVUMsZ0JBQUFBLFFBbFBWLEdBa1BxQlYsVUFBVSxDQUFDUyxHQUFHLENBQUNOLEVBQUwsQ0FsUC9COztBQW1QSSxxQkFBS1EsVUFBTCxDQUFnQjtBQUNkL0Isa0JBQUFBLFdBQVcsRUFBRTZCLEdBQUcsQ0FBQ0csWUFESDtBQUVkQyxrQkFBQUEsV0FBVyxFQUFFSixHQUFHLENBQUNLLFlBRkg7QUFHZFAsa0JBQUFBLFlBQVksRUFBRUUsR0FBRyxDQUFDMEUsYUFISjtBQUlkekUsa0JBQUFBLFFBQVEsRUFBUkE7QUFKYyxpQkFBaEI7O0FBTUEscUJBQUsyQixPQUFMLENBQWErQyxLQUFiLDRFQUNrQzFFLFFBQVEsQ0FBQ1AsRUFEM0Msa0NBQzJETyxRQUFRLENBQUNSLGNBRHBFOztBQXpQSixrREE0UFdRLFFBNVBYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBK1BFO0FBQ0Y7QUFDQTs7QUFqUUE7QUFBQTtBQUFBO0FBQUEsOEZBa1FjTyxRQWxRZCxFQWtRZ0NDLFFBbFFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbVFJLHFCQUFLaUIsZ0JBQUwsR0FBd0IsSUFBSS9ELHNCQUFKLENBQ3RCLElBRHNCLEVBRXRCNEMsK0JBQStCLENBQUNDLFFBQUQsRUFBV0MsUUFBWCxDQUZULENBQXhCOztBQW5RSixzQkF1UVEsS0FBS1YsTUFBTCxJQUFlLEtBQUtBLE1BQUwsQ0FBWTBCLFFBQTNCLElBQXVDLEtBQUsxQixNQUFMLENBQVk2RSxZQXZRM0Q7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0RBd1FhLEtBQUtDLGFBQUwsQ0FBbUJyRSxRQUFuQixFQUE2QkMsUUFBN0IsQ0F4UWI7O0FBQUE7QUFBQSxrREEwUVcsS0FBS3FFLFdBQUwsQ0FBaUJ0RSxRQUFqQixFQUEyQkMsUUFBM0IsQ0ExUVg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE2UUU7QUFDRjtBQUNBOztBQS9RQTtBQUFBO0FBQUE7QUFBQSxxR0FnUnNCRCxRQWhSdEIsRUFnUndDQyxRQWhSeEM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpUnNCLEtBQUtWLE1BQUwsQ0FBWWdGLFlBQVosQ0FBeUJ2RSxRQUF6QixFQUFtQ0MsUUFBbkMsQ0FqUnRCOztBQUFBO0FBaVJVVCxnQkFBQUEsR0FqUlY7QUFrUlVDLGdCQUFBQSxRQWxSVixHQWtScUJWLFVBQVUsQ0FBQ1MsR0FBRyxDQUFDTixFQUFMLENBbFIvQjs7QUFtUkkscUJBQUtRLFVBQUwsQ0FBZ0I7QUFDZC9CLGtCQUFBQSxXQUFXLEVBQUU2QixHQUFHLENBQUNHLFlBREg7QUFFZEMsa0JBQUFBLFdBQVcsRUFBRUosR0FBRyxDQUFDSyxZQUZIO0FBR2RKLGtCQUFBQSxRQUFRLEVBQVJBO0FBSGMsaUJBQWhCOztBQUtBLHFCQUFLMkIsT0FBTCxDQUFhb0QsSUFBYiw0RUFDa0MvRSxRQUFRLENBQUNQLEVBRDNDLGtDQUMyRE8sUUFBUSxDQUFDUixjQURwRTs7QUF4Ukosa0RBMlJXUSxRQTNSWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQThSRTtBQUNGO0FBQ0E7O0FBaFNBO0FBQUE7QUFBQTtBQUFBLG9HQWlTb0JPLFFBalNwQixFQWlTc0NDLFFBalN0QztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFrU1EsQ0FBQ0QsUUFBRCxJQUFhLENBQUNDLFFBbFN0QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxtREFtU2EsU0FBUXdFLE1BQVIsQ0FBZSxJQUFJL0YsS0FBSixDQUFVLDRCQUFWLENBQWYsQ0FuU2I7O0FBQUE7QUFxU1VnRyxnQkFBQUEsSUFyU1YsR0FxU2lCLENBQ1gsb0VBRFcsRUFFWCxjQUZXLEVBR1gsV0FIVyxFQUlYLDZDQUpXLHNCQUtFM0csR0FBRyxDQUFDaUMsUUFBRCxDQUxMLHNDQU1FakMsR0FBRyxDQUFDa0MsUUFBRCxDQU5MLGtCQU9YLFVBUFcsRUFRWCxZQVJXLEVBU1gsZ0JBVFcsRUFVWDhDLElBVlcsQ0FVTixFQVZNLENBclNqQjtBQWlUVTRCLGdCQUFBQSxpQkFqVFYsR0FpVDhCLENBQ3hCLEtBQUtqSCxRQURtQixFQUV4QixpQkFGd0IsRUFHeEIsS0FBS0UsT0FIbUIsRUFJeEJtRixJQUp3QixDQUluQixHQUptQixDQWpUOUI7QUFBQTtBQUFBLHVCQXNUMkIsS0FBS3hCLFVBQUwsQ0FBZ0JxRCxXQUFoQixDQUE0QjtBQUNqREMsa0JBQUFBLE1BQU0sRUFBRSxNQUR5QztBQUVqRDdGLGtCQUFBQSxHQUFHLEVBQUUyRixpQkFGNEM7QUFHakRELGtCQUFBQSxJQUFJLEVBQUpBLElBSGlEO0FBSWpESSxrQkFBQUEsT0FBTyxFQUFFO0FBQ1Asb0NBQWdCLFVBRFQ7QUFFUEMsb0JBQUFBLFVBQVUsRUFBRTtBQUZMO0FBSndDLGlCQUE1QixDQXRUM0I7O0FBQUE7QUFzVFVDLGdCQUFBQSxRQXRUVjs7QUFBQSxzQkFnVVFBLFFBQVEsQ0FBQ0MsVUFBVCxJQUF1QixHQWhVL0I7QUFBQTtBQUFBO0FBQUE7O0FBaVVNQyxnQkFBQUEsQ0FBQyxHQUFHRixRQUFRLENBQUNOLElBQVQsQ0FBY1MsS0FBZCxDQUFvQixxQ0FBcEIsQ0FBSjtBQUNNQyxnQkFBQUEsV0FsVVosR0FrVTBCRixDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFELENBbFVoQztBQUFBLHNCQW1VWSxJQUFJeEcsS0FBSixDQUFVMEcsV0FBVyxJQUFJSixRQUFRLENBQUNOLElBQWxDLENBblVaOztBQUFBO0FBcVVJLHFCQUFLdEQsT0FBTCxDQUFhK0MsS0FBYiwyQkFBc0NhLFFBQVEsQ0FBQ04sSUFBL0M7O0FBQ0FRLGdCQUFBQSxDQUFDLEdBQUdGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjUyxLQUFkLENBQW9CLGlDQUFwQixDQUFKO0FBQ014QyxnQkFBQUEsU0F2VVYsR0F1VXNCdUMsQ0FBQyxJQUFJQSxDQUFDLENBQUMsQ0FBRCxDQXZVNUI7QUF3VUlBLGdCQUFBQSxDQUFDLEdBQUdGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjUyxLQUFkLENBQW9CLGlDQUFwQixDQUFKO0FBQ016QyxnQkFBQUEsU0F6VVYsR0F5VXNCd0MsQ0FBQyxJQUFJQSxDQUFDLENBQUMsQ0FBRCxDQXpVNUI7QUEwVUlBLGdCQUFBQSxDQUFDLEdBQUdGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjUyxLQUFkLENBQW9CLDJCQUFwQixDQUFKO0FBQ01FLGdCQUFBQSxNQTNVVixHQTJVbUJILENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0EzVXpCO0FBNFVJQSxnQkFBQUEsQ0FBQyxHQUFHRixRQUFRLENBQUNOLElBQVQsQ0FBY1MsS0FBZCxDQUFvQiwyQ0FBcEIsQ0FBSjtBQUNNbEcsZ0JBQUFBLGNBN1VWLEdBNlUyQmlHLENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0E3VWpDOztBQUFBLHNCQThVUSxDQUFDdkMsU0FBRCxJQUFjLENBQUNELFNBQWYsSUFBNEIsQ0FBQzJDLE1BQTdCLElBQXVDLENBQUNwRyxjQTlVaEQ7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBK1VZLElBQUlQLEtBQUosQ0FDSiwyREFESSxDQS9VWjs7QUFBQTtBQW1WVTRHLGdCQUFBQSxLQW5WVixHQW1Wa0IsQ0FBQyxLQUFLNUgsUUFBTixFQUFnQixJQUFoQixFQUFzQnVCLGNBQXRCLEVBQXNDb0csTUFBdEMsRUFBOEN0QyxJQUE5QyxDQUFtRCxHQUFuRCxDQW5WbEI7QUFvVlV0RCxnQkFBQUEsUUFwVlYsR0FvVnFCO0FBQUVQLGtCQUFBQSxFQUFFLEVBQUVtRyxNQUFOO0FBQWNwRyxrQkFBQUEsY0FBYyxFQUFkQSxjQUFkO0FBQThCRCxrQkFBQUEsR0FBRyxFQUFFc0c7QUFBbkMsaUJBcFZyQjs7QUFxVkkscUJBQUs1RixVQUFMLENBQWdCO0FBQ2RpRCxrQkFBQUEsU0FBUyxFQUFFLG9DQUFBQSxTQUFTLENBQUNuRSxLQUFWLENBQWdCLEdBQWhCLG9CQUEyQixDQUEzQixFQUE4QixDQUE5QixFQUFpQ3VFLElBQWpDLENBQXNDLEdBQXRDLENBREc7QUFFZEwsa0JBQUFBLFNBQVMsRUFBVEEsU0FGYztBQUdkakQsa0JBQUFBLFFBQVEsRUFBUkE7QUFIYyxpQkFBaEI7O0FBS0EscUJBQUsyQixPQUFMLENBQWFvRCxJQUFiLDZFQUNrQ2EsTUFEbEMsbUNBQ3NEcEcsY0FEdEQ7O0FBMVZKLG1EQTZWV1EsUUE3Vlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFnV0U7QUFDRjtBQUNBOztBQWxXQTtBQUFBO0FBQUE7QUFBQSwrRkFtV2U4RixNQW5XZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBb1dJLHFCQUFLckUsZ0JBQUwsR0FBd0JwQixTQUF4Qjs7QUFwV0osc0JBcVdRLEtBQUtzRCxZQUFMLEtBQXNCLFFBclc5QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxtREFzV2EsS0FBS29DLGNBQUwsQ0FBb0JELE1BQXBCLENBdFdiOztBQUFBO0FBQUEsbURBd1dXLEtBQUtFLFlBQUwsQ0FBa0JGLE1BQWxCLENBeFdYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMldFO0FBQ0Y7QUFDQTs7QUE3V0E7QUFBQTtBQUFBO0FBQUEsc0dBOFd1QkEsTUE5V3ZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQStXVUcsZ0JBQUFBLEtBL1dWLEdBK1drQkgsTUFBTSxHQUFHLEtBQUtqRyxZQUFSLEdBQXVCLEtBQUtNLFdBL1dwRDs7QUFBQSxxQkFnWFE4RixLQWhYUjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVCQWlYWSxLQUFLbkcsTUFBTCxDQUFZb0csV0FBWixDQUF3QkQsS0FBeEIsQ0FqWFo7O0FBQUE7QUFtWEk7QUFDQSxxQkFBS0UsYUFBTDs7QUFDQSxxQkFBS3ZDLGNBQUw7O0FBclhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd1hFO0FBQ0Y7QUFDQTs7QUExWEE7QUFBQTtBQUFBO0FBQUEscUdBMlhxQmtDLE1BM1hyQjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE0WFViLGdCQUFBQSxJQTVYVixHQTRYaUIsQ0FDWCxvRUFEVyxFQUVYLGFBRlcsRUFHWCxxREFIVyx1QkFJRzNHLEdBQUcsQ0FDZndILE1BQU0sR0FBRyxLQUFLakcsWUFBUixHQUF1QixLQUFLTSxXQURuQixDQUpOLG1CQU9YLGtCQVBXLEVBUVgsY0FSVyxFQVNYLFdBVFcsRUFVWCwrQ0FWVyxFQVdYLFlBWFcsRUFZWCxnQkFaVyxFQWFYbUQsSUFiVyxDQWFOLEVBYk0sQ0E1WGpCO0FBQUE7QUFBQSx1QkEwWTJCLEtBQUt4QixVQUFMLENBQWdCcUQsV0FBaEIsQ0FBNEI7QUFDakRDLGtCQUFBQSxNQUFNLEVBQUUsTUFEeUM7QUFFakQ3RixrQkFBQUEsR0FBRyxFQUFFLENBQUMsS0FBS3JCLFdBQU4sRUFBbUIsaUJBQW5CLEVBQXNDLEtBQUtDLE9BQTNDLEVBQW9EbUYsSUFBcEQsQ0FBeUQsR0FBekQsQ0FGNEM7QUFHakQyQixrQkFBQUEsSUFBSSxFQUFKQSxJQUhpRDtBQUlqREksa0JBQUFBLE9BQU8sRUFBRTtBQUNQLG9DQUFnQixVQURUO0FBRVBDLG9CQUFBQSxVQUFVLEVBQUU7QUFGTDtBQUp3QyxpQkFBNUIsQ0ExWTNCOztBQUFBO0FBMFlVQyxnQkFBQUEsUUExWVY7O0FBbVpJLHFCQUFLNUQsT0FBTCxDQUFhK0MsS0FBYixrRUFDdUJhLFFBQVEsQ0FBQ0MsVUFEaEMscUNBQzBERCxRQUFRLENBQUNOLElBRG5FOztBQW5aSixzQkFzWlFNLFFBQVEsQ0FBQ0MsVUFBVCxJQUF1QixHQXRaL0I7QUFBQTtBQUFBO0FBQUE7O0FBdVpZQyxnQkFBQUEsQ0F2WlosR0F1WmdCRixRQUFRLENBQUNOLElBQVQsQ0FBY1MsS0FBZCxDQUFvQixxQ0FBcEIsQ0F2WmhCO0FBd1pZQyxnQkFBQUEsV0F4WlosR0F3WjBCRixDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFELENBeFpoQztBQUFBLHNCQXlaWSxJQUFJeEcsS0FBSixDQUFVMEcsV0FBVyxJQUFJSixRQUFRLENBQUNOLElBQWxDLENBelpaOztBQUFBO0FBMlpJO0FBQ0EscUJBQUtrQixhQUFMOztBQUNBLHFCQUFLdkMsY0FBTDs7QUE3Wko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFnYUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBdGFBO0FBQUE7QUFBQSw0QkF3YUl3QyxRQXhhSixFQTBhc0I7QUFBQTs7QUFBQSxVQURsQi9DLE9BQ2tCLHVFQURBLEVBQ0E7QUFDbEI7QUFDQSxVQUFJZ0QsUUFBcUIsR0FDdkIsT0FBT0QsUUFBUCxLQUFtQixRQUFuQixHQUE4QjtBQUFFaEIsUUFBQUEsTUFBTSxFQUFFLEtBQVY7QUFBaUI3RixRQUFBQSxHQUFHLEVBQUU2RztBQUF0QixPQUE5QixHQUFnRUEsUUFEbEUsQ0FGa0IsQ0FJbEI7O0FBQ0FDLE1BQUFBLFFBQVEsbUNBQ0hBLFFBREc7QUFFTjlHLFFBQUFBLEdBQUcsRUFBRSxLQUFLK0csYUFBTCxDQUFtQkQsUUFBUSxDQUFDOUcsR0FBNUI7QUFGQyxRQUFSO0FBSUEsVUFBTWdILE9BQU8sR0FBRyxJQUFJOUksT0FBSixDQUFZLElBQVosRUFBa0I0RixPQUFsQixDQUFoQixDQVRrQixDQVVsQjs7QUFDQWtELE1BQUFBLE9BQU8sQ0FBQ3JDLEVBQVIsQ0FBVyxVQUFYLEVBQXVCLFVBQUNxQixRQUFELEVBQTRCO0FBQ2pELFlBQUlBLFFBQVEsQ0FBQ0YsT0FBVCxJQUFvQkUsUUFBUSxDQUFDRixPQUFULENBQWlCLG1CQUFqQixDQUF4QixFQUErRDtBQUM3RCxjQUFNbUIsUUFBUSxHQUFHakIsUUFBUSxDQUFDRixPQUFULENBQWlCLG1CQUFqQixFQUFzQ0ssS0FBdEMsQ0FDZix3QkFEZSxDQUFqQjs7QUFHQSxjQUFJYyxRQUFKLEVBQWM7QUFDWixZQUFBLE1BQUksQ0FBQzNDLFNBQUwsR0FBaUI7QUFDZjJDLGNBQUFBLFFBQVEsRUFBRTtBQUNSQyxnQkFBQUEsSUFBSSxFQUFFLFVBQVNELFFBQVEsQ0FBQyxDQUFELENBQWpCLEVBQXNCLEVBQXRCLENBREU7QUFFUkUsZ0JBQUFBLEtBQUssRUFBRSxVQUFTRixRQUFRLENBQUMsQ0FBRCxDQUFqQixFQUFzQixFQUF0QjtBQUZDO0FBREssYUFBakI7QUFNRDtBQUNGO0FBQ0YsT0FkRDtBQWVBLGFBQU9ELE9BQU8sQ0FBQ0gsT0FBUixDQUFtQkMsUUFBbkIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBN2NBO0FBQUE7QUFBQSwrQkE4YzBCOUcsR0E5YzFCLEVBOGN1QzhELE9BOWN2QyxFQThjeUQ7QUFDckQsVUFBTStDLE9BQW9CLEdBQUc7QUFBRWhCLFFBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCN0YsUUFBQUEsR0FBRyxFQUFIQTtBQUFqQixPQUE3QjtBQUNBLGFBQU8sS0FBSzZHLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCL0MsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBemRBO0FBQUE7QUFBQSxnQ0EwZDJCOUQsR0ExZDNCLEVBMGR3QzBGLElBMWR4QyxFQTBkc0Q1QixPQTFkdEQsRUEwZHdFO0FBQ3BFLFVBQU0rQyxPQUFvQixHQUFHO0FBQzNCaEIsUUFBQUEsTUFBTSxFQUFFLE1BRG1CO0FBRTNCN0YsUUFBQUEsR0FBRyxFQUFIQSxHQUYyQjtBQUczQjBGLFFBQUFBLElBQUksRUFBRSxnQkFBZUEsSUFBZixDQUhxQjtBQUkzQkksUUFBQUEsT0FBTyxFQUFFO0FBQUUsMEJBQWdCO0FBQWxCO0FBSmtCLE9BQTdCO0FBTUEsYUFBTyxLQUFLZSxPQUFMLENBQWdCQSxPQUFoQixFQUF5Qi9DLE9BQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQTFlQTtBQUFBO0FBQUEsK0JBMmVnQjlELEdBM2VoQixFQTJlNkIwRixJQTNlN0IsRUEyZTJDNUIsT0EzZTNDLEVBMmU2RDtBQUN6RCxVQUFNK0MsT0FBb0IsR0FBRztBQUMzQmhCLFFBQUFBLE1BQU0sRUFBRSxLQURtQjtBQUUzQjdGLFFBQUFBLEdBQUcsRUFBSEEsR0FGMkI7QUFHM0IwRixRQUFBQSxJQUFJLEVBQUUsZ0JBQWVBLElBQWYsQ0FIcUI7QUFJM0JJLFFBQUFBLE9BQU8sRUFBRTtBQUFFLDBCQUFnQjtBQUFsQjtBQUprQixPQUE3QjtBQU1BLGFBQU8sS0FBS2UsT0FBTCxDQUFnQkEsT0FBaEIsRUFBeUIvQyxPQUF6QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUEzZkE7QUFBQTtBQUFBLGlDQTRmNEI5RCxHQTVmNUIsRUE0ZnlDMEYsSUE1ZnpDLEVBNGZ1RDVCLE9BNWZ2RCxFQTRmeUU7QUFDckUsVUFBTStDLE9BQW9CLEdBQUc7QUFDM0JoQixRQUFBQSxNQUFNLEVBQUUsT0FEbUI7QUFFM0I3RixRQUFBQSxHQUFHLEVBQUhBLEdBRjJCO0FBRzNCMEYsUUFBQUEsSUFBSSxFQUFFLGdCQUFlQSxJQUFmLENBSHFCO0FBSTNCSSxRQUFBQSxPQUFPLEVBQUU7QUFBRSwwQkFBZ0I7QUFBbEI7QUFKa0IsT0FBN0I7QUFNQSxhQUFPLEtBQUtlLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCL0MsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBNWdCQTtBQUFBO0FBQUEsa0NBNmdCbUI5RCxHQTdnQm5CLEVBNmdCZ0M4RCxPQTdnQmhDLEVBNmdCa0Q7QUFDOUMsVUFBTStDLE9BQW9CLEdBQUc7QUFBRWhCLFFBQUFBLE1BQU0sRUFBRSxRQUFWO0FBQW9CN0YsUUFBQUEsR0FBRyxFQUFIQTtBQUFwQixPQUE3QjtBQUNBLGFBQU8sS0FBSzZHLE9BQUwsQ0FBZ0JBLE9BQWhCLEVBQXlCL0MsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7O0FBbGhCRjtBQUFBO0FBQUEsK0JBbWhCYTtBQUNULGFBQU8sQ0FBQyxLQUFLbkYsV0FBTixFQUFtQixlQUFuQixhQUF3QyxLQUFLQyxPQUE3QyxHQUF3RG1GLElBQXhELENBQTZELEdBQTdELENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOztBQTFoQkE7QUFBQTtBQUFBLGtDQTJoQmdCL0QsR0EzaEJoQixFQTJoQjZCO0FBQ3pCLFVBQUlBLEdBQUcsQ0FBQyxDQUFELENBQUgsS0FBVyxHQUFmLEVBQW9CO0FBQ2xCLFlBQUkseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsS0FBS3JCLFdBQUwsR0FBbUIsWUFBNUIsQ0FBSCxLQUFpRCxDQUFyRCxFQUF3RDtBQUN0RCxpQkFBT3FCLEdBQVA7QUFDRDs7QUFDRCxZQUFJLHlCQUFBQSxHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFTLFlBQVQsQ0FBSCxLQUE4QixDQUFsQyxFQUFxQztBQUNuQyxpQkFBTyxLQUFLckIsV0FBTCxHQUFtQnFCLEdBQTFCO0FBQ0Q7O0FBQ0QsZUFBTyxLQUFLb0gsUUFBTCxLQUFrQnBILEdBQXpCO0FBQ0Q7O0FBQ0QsYUFBT0EsR0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTFpQkE7QUFBQTtBQUFBLDBCQTRpQklxSCxJQTVpQkosRUE2aUJJdkQsT0E3aUJKLEVBOGlCaUQ7QUFDN0MsYUFBTyxJQUFJMUYsS0FBSixDQUFnRCxJQUFoRCxFQUFzRGlKLElBQXRELEVBQTREdkQsT0FBNUQsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBeGpCQTtBQUFBO0FBQUEsMkJBeWpCU3dELElBempCVCxFQXlqQnVCO0FBQ25CLFVBQUl0SCxHQUFHLEdBQUcsS0FBS29ILFFBQUwsS0FBa0IsWUFBbEIsR0FBaUNHLGtCQUFrQixDQUFDRCxJQUFELENBQTdEO0FBQ0EsYUFBTyxLQUFLVCxPQUFMLENBQTJCN0csR0FBM0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWhrQkE7QUFBQTtBQUFBLDhCQWlrQll3SCxPQWprQlosRUFpa0I2QjFELE9BamtCN0IsRUFpa0JxRDtBQUNqRCxhQUFPLElBQUkxRixLQUFKLENBQ0wsSUFESyxFQUVMO0FBQUVvSixRQUFBQSxPQUFPLEVBQVBBO0FBQUYsT0FGSyxFQUdMMUQsT0FISyxDQUFQO0FBS0Q7QUFFRDs7QUF6a0JGO0FBQUE7QUFBQSxtQ0Ewa0JpQjJELFlBMWtCakIsRUEwa0J1QztBQUNuQyxVQUFNQyxRQUFRLEdBQUcsS0FBSzlJLE9BQUwsQ0FBYVksS0FBYixDQUFtQixHQUFuQixDQUFqQjtBQUNBLGFBQU8sVUFBU2tJLFFBQVEsQ0FBQyxDQUFELENBQWpCLEVBQXNCLEVBQXRCLEtBQTZCRCxZQUFwQztBQUNEO0FBRUQ7O0FBL2tCRjtBQUFBO0FBQUEsOEJBZ2xCWUUsT0FobEJaLEVBZ2xCNkI7QUFDekIsY0FBUUEsT0FBUjtBQUNFLGFBQUssb0JBQUw7QUFBMkI7QUFDekIsaUJBQU8sS0FBS0MsY0FBTCxDQUFvQixFQUFwQixDQUFQOztBQUNGO0FBQ0UsaUJBQU8sS0FBUDtBQUpKO0FBTUQ7QUFFRDtBQUNGO0FBQ0E7O0FBM2xCQTtBQUFBO0FBQUE7QUFBQSxpR0E0bUJJaEYsSUE1bUJKLEVBNm1CSWlGLEdBN21CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQThtQkkvRCxnQkFBQUEsT0E5bUJKLDhEQThtQitCLEVBOW1CL0I7QUFBQSxtREFnbkJXLGVBQWMrRCxHQUFkLElBQ0g7QUFDQSxxQkFBS0QsY0FBTCxDQUFvQixFQUFwQixJQUNFLEtBQUtFLGFBQUwsQ0FBbUJsRixJQUFuQixFQUF5QmlGLEdBQXpCLEVBQThCL0QsT0FBOUIsQ0FERixHQUVFLEtBQUtpRSxpQkFBTCxDQUF1Qm5GLElBQXZCLEVBQTZCaUYsR0FBN0IsRUFBa0MvRCxPQUFsQyxDQUpDLEdBS0gsS0FBS2tFLGVBQUwsQ0FBcUJwRixJQUFyQixFQUEyQmlGLEdBQTNCLEVBQWdDL0QsT0FBaEMsQ0FybkJSOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd25CRTs7QUF4bkJGO0FBQUE7QUFBQTtBQUFBLHlHQXluQndCbEIsSUF6bkJ4QixFQXluQnNDMUMsRUF6bkJ0QyxFQXluQmtENEQsT0F6bkJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEwbkJTNUQsRUExbkJUO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTJuQlksSUFBSVIsS0FBSixDQUFVLGtEQUFWLENBM25CWjs7QUFBQTtBQTZuQlFNLGdCQUFBQSxHQTduQlIsR0E2bkJjLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4QnhFLElBQTlCLEVBQW9DMUMsRUFBcEMsRUFBd0M2RCxJQUF4QyxDQUE2QyxHQUE3QyxDQTduQmQ7QUE4bkJZa0UsZ0JBQUFBLE1BOW5CWixHQThuQmdDbkUsT0E5bkJoQyxDQThuQlltRSxNQTluQlosRUE4bkJvQm5DLE9BOW5CcEIsR0E4bkJnQ2hDLE9BOW5CaEMsQ0E4bkJvQmdDLE9BOW5CcEI7O0FBK25CSSxvQkFBSW1DLE1BQUosRUFBWTtBQUNWakksa0JBQUFBLEdBQUcsc0JBQWVpSSxNQUFNLENBQUNsRSxJQUFQLENBQVksR0FBWixDQUFmLENBQUg7QUFDRDs7QUFqb0JMLG1EQWtvQlcsS0FBSzhDLE9BQUwsQ0FBYTtBQUFFaEIsa0JBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCN0Ysa0JBQUFBLEdBQUcsRUFBSEEsR0FBakI7QUFBc0I4RixrQkFBQUEsT0FBTyxFQUFQQTtBQUF0QixpQkFBYixDQWxvQlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFxb0JFOztBQXJvQkY7QUFBQTtBQUFBO0FBQUEsMkdBdW9CSWxELElBdm9CSixFQXdvQklpRixHQXhvQkosRUF5b0JJL0QsT0F6b0JKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkEyb0JRK0QsR0FBRyxDQUFDSyxNQUFKLEdBQWEsS0FBSy9GLFdBM29CMUI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBNG9CWSxJQUFJekMsS0FBSixDQUFVLHVDQUFWLENBNW9CWjs7QUFBQTtBQUFBLG1EQThvQlcsU0FBUXlJLEdBQVIsQ0FDTCxxQkFBQU4sR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBSyxVQUFDM0gsRUFBRDtBQUFBLHlCQUNOLE1BQUksQ0FBQzhILGVBQUwsQ0FBcUJwRixJQUFyQixFQUEyQjFDLEVBQTNCLEVBQStCNEQsT0FBL0IsRUFBd0NzRSxLQUF4QyxDQUE4QyxVQUFDaEgsR0FBRCxFQUFTO0FBQ3JELHdCQUFJMEMsT0FBTyxDQUFDdUUsU0FBUixJQUFxQmpILEdBQUcsQ0FBQ2tILFNBQUosS0FBa0IsV0FBM0MsRUFBd0Q7QUFDdEQsNEJBQU1sSCxHQUFOO0FBQ0Q7O0FBQ0QsMkJBQU8sSUFBUDtBQUNELG1CQUxELENBRE07QUFBQSxpQkFBTCxDQURFLENBOW9CWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTBwQkU7O0FBMXBCRjtBQUFBO0FBQUE7QUFBQSx1R0EycEJzQndCLElBM3BCdEIsRUEycEJvQ2lGLEdBM3BCcEMsRUEycEJtRC9ELE9BM3BCbkQ7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNHBCUStELEdBQUcsQ0FBQ0ssTUFBSixLQUFlLENBNXBCdkI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsbURBNnBCYSxFQTdwQmI7O0FBQUE7QUErcEJVbEksZ0JBQUFBLEdBL3BCVixHQStwQmdCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixXQUFsQixFQUErQixVQUEvQixFQUEyQ3hFLElBQTNDLEVBQWlEbUIsSUFBakQsQ0FBc0QsR0FBdEQsQ0EvcEJoQjtBQUFBLGdDQWlxQk1ELE9BQU8sQ0FBQ21FLE1BanFCZDs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsdUJBa3FCYSxLQUFLL0UsU0FBTCxDQUFlTixJQUFmLENBbHFCYjs7QUFBQTtBQUFBLDZEQWtxQm1DcUYsTUFscUJuQztBQUFBLG1GQWtxQjhDLFVBQUNNLEtBQUQ7QUFBQSx5QkFBV0EsS0FBSyxDQUFDL0csSUFBakI7QUFBQSxpQkFscUI5Qzs7QUFBQTtBQWdxQlV5RyxnQkFBQUEsTUFocUJWO0FBQUEsbURBbXFCVyxLQUFLcEIsT0FBTCxDQUFhO0FBQ2xCaEIsa0JBQUFBLE1BQU0sRUFBRSxNQURVO0FBRWxCN0Ysa0JBQUFBLEdBQUcsRUFBSEEsR0FGa0I7QUFHbEIwRixrQkFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQUVtQyxvQkFBQUEsR0FBRyxFQUFIQSxHQUFGO0FBQU9JLG9CQUFBQSxNQUFNLEVBQU5BO0FBQVAsbUJBQWYsQ0FIWTtBQUlsQm5DLGtCQUFBQSxPQUFPLGtDQUNEaEMsT0FBTyxDQUFDZ0MsT0FBUixJQUFtQixFQURsQjtBQUVMLG9DQUFnQjtBQUZYO0FBSlcsaUJBQWIsQ0FucUJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBOHFCRTtBQUNGO0FBQ0E7O0FBaHJCQTtBQUFBOztBQXFzQkU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQXpzQkE7QUFBQSxnR0Eyc0JJbEQsSUEzc0JKLEVBNHNCSTRGLE9BNXNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNnNCSTFFLGdCQUFBQSxPQTdzQkosaUVBNnNCMEIsRUE3c0IxQjs7QUFBQSxxQkErc0JnQixlQUFjMEUsT0FBZCxDQS9zQmhCO0FBQUE7QUFBQTtBQUFBOztBQUFBLHFCQWl0QlEsS0FBS1osY0FBTCxDQUFvQixFQUFwQixDQWp0QlI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx1QkFrdEJnQixLQUFLYSxXQUFMLENBQWlCN0YsSUFBakIsRUFBdUI0RixPQUF2QixFQUFnQzFFLE9BQWhDLENBbHRCaEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLHVCQW10QmdCLEtBQUs0RSxlQUFMLENBQXFCOUYsSUFBckIsRUFBMkI0RixPQUEzQixFQUFvQzFFLE9BQXBDLENBbnRCaEI7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsdUJBb3RCYyxLQUFLNkUsYUFBTCxDQUFtQi9GLElBQW5CLEVBQXlCNEYsT0FBekIsRUFBa0MxRSxPQUFsQyxDQXB0QmQ7O0FBQUE7QUFBQTs7QUFBQTtBQStzQlU4RSxnQkFBQUEsR0Evc0JWO0FBQUEsbURBcXRCV0EsR0FydEJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd3RCRTs7QUF4dEJGO0FBQUE7QUFBQTtBQUFBLHVHQXl0QnNCaEcsSUF6dEJ0QixFQXl0Qm9DaUcsTUF6dEJwQyxFQXl0Qm9EL0UsT0F6dEJwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEwdEJZZ0YsZ0JBQUFBLEVBMXRCWixHQTB0Qm9ERCxNQTF0QnBELENBMHRCWUMsRUExdEJaLEVBMHRCc0JDLEtBMXRCdEIsR0EwdEJvREYsTUExdEJwRCxDQTB0QmdCakcsSUExdEJoQixFQTB0QjZCb0csVUExdEI3QixHQTB0Qm9ESCxNQTF0QnBELENBMHRCNkJHLFVBMXRCN0IsRUEwdEI0Q0MsR0ExdEI1Qyw0QkEwdEJvREosTUExdEJwRDtBQTJ0QlVLLGdCQUFBQSxXQTN0QlYsR0EydEJ3QnRHLElBQUksSUFBS29HLFVBQVUsSUFBSUEsVUFBVSxDQUFDcEcsSUFBbEMsSUFBMkNtRyxLQTN0Qm5FOztBQUFBLG9CQTR0QlNHLFdBNXRCVDtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkE2dEJZLElBQUl4SixLQUFKLENBQVUsbUNBQVYsQ0E3dEJaOztBQUFBO0FBK3RCVU0sZ0JBQUFBLEdBL3RCVixHQSt0QmdCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4QjhCLFdBQTlCLEVBQTJDbkYsSUFBM0MsQ0FBZ0QsR0FBaEQsQ0EvdEJoQjtBQUFBLG1EQWd1QlcsS0FBSzhDLE9BQUwsQ0FBYTtBQUNsQmhCLGtCQUFBQSxNQUFNLEVBQUUsTUFEVTtBQUVsQjdGLGtCQUFBQSxHQUFHLEVBQUhBLEdBRmtCO0FBR2xCMEYsa0JBQUFBLElBQUksRUFBRSxnQkFBZXVELEdBQWYsQ0FIWTtBQUlsQm5ELGtCQUFBQSxPQUFPLGtDQUNEaEMsT0FBTyxDQUFDZ0MsT0FBUixJQUFtQixFQURsQjtBQUVMLG9DQUFnQjtBQUZYO0FBSlcsaUJBQWIsQ0FodUJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMnVCRTs7QUEzdUJGO0FBQUE7QUFBQTtBQUFBLHlHQTR1QndCbEQsSUE1dUJ4QixFQTR1QnNDNEYsT0E1dUJ0QyxFQTR1QnlEMUUsT0E1dUJ6RDtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNnVCUTBFLE9BQU8sQ0FBQ04sTUFBUixHQUFpQixLQUFLL0YsV0E3dUI5QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkE4dUJZLElBQUl6QyxLQUFKLENBQVUsdUNBQVYsQ0E5dUJaOztBQUFBO0FBQUEsbURBZ3ZCVyxTQUFReUksR0FBUixDQUNMLHFCQUFBSyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFLLFVBQUNLLE1BQUQ7QUFBQSx5QkFDVixNQUFJLENBQUNGLGFBQUwsQ0FBbUIvRixJQUFuQixFQUF5QmlHLE1BQXpCLEVBQWlDL0UsT0FBakMsRUFBMENzRSxLQUExQyxDQUFnRCxVQUFDaEgsR0FBRCxFQUFTO0FBQ3ZEO0FBQ0E7QUFDQSx3QkFBSTBDLE9BQU8sQ0FBQ3VFLFNBQVIsSUFBcUIsQ0FBQ2pILEdBQUcsQ0FBQ2tILFNBQTlCLEVBQXlDO0FBQ3ZDLDRCQUFNbEgsR0FBTjtBQUNEOztBQUNELDJCQUFPRCxZQUFZLENBQUNDLEdBQUQsQ0FBbkI7QUFDRCxtQkFQRCxDQURVO0FBQUEsaUJBQUwsQ0FERixDQWh2Qlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE4dkJFOztBQTl2QkY7QUFBQTtBQUFBO0FBQUEscUdBZ3dCSXdCLElBaHdCSixFQWl3Qkk0RixPQWp3QkosRUFrd0JJMUUsT0Fsd0JKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFvd0JRMEUsT0FBTyxDQUFDTixNQUFSLEtBQW1CLENBcHdCM0I7QUFBQTtBQUFBO0FBQUE7O0FBQUEsbURBcXdCYSxTQUFRaUIsT0FBUixDQUFnQixFQUFoQixDQXJ3QmI7O0FBQUE7QUFBQSxzQkF1d0JRWCxPQUFPLENBQUNOLE1BQVIsR0FBaUJ6RyxhQUFqQixJQUFrQ3FDLE9BQU8sQ0FBQ3NGLGNBdndCbEQ7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5d0JrQixLQUFLWCxXQUFMLENBQ1I3RixJQURRLEVBRVIsdUJBQUE0RixPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFPLENBQVAsRUFBVS9HLGFBQVYsQ0FGQyxFQUdScUMsT0FIUSxDQXp3QmxCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4d0JrQixLQUFLMkUsV0FBTCxDQUNSN0YsSUFEUSxFQUVSLHVCQUFBNEYsT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBTy9HLGFBQVAsQ0FGQyxFQUdScUMsT0FIUSxDQTl3QmxCOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBcXhCVXVGLGdCQUFBQSxRQXJ4QlYsR0FxeEJxQixxQkFBQWIsT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBSyxVQUFDSyxNQUFELEVBQVk7QUFBQSxzQkFDL0JDLEVBRCtCLEdBQ1NELE1BRFQsQ0FDL0JDLEVBRCtCO0FBQUEsc0JBQ3JCQyxLQURxQixHQUNTRixNQURULENBQzNCakcsSUFEMkI7QUFBQSxzQkFDZG9HLFVBRGMsR0FDU0gsTUFEVCxDQUNkRyxVQURjO0FBQUEsc0JBQ0NDLEdBREQsNEJBQ1NKLE1BRFQ7O0FBRXZDLHNCQUFNSyxXQUFXLEdBQUd0RyxJQUFJLElBQUtvRyxVQUFVLElBQUlBLFVBQVUsQ0FBQ3BHLElBQWxDLElBQTJDbUcsS0FBL0Q7O0FBQ0Esc0JBQUksQ0FBQ0csV0FBTCxFQUFrQjtBQUNoQiwwQkFBTSxJQUFJeEosS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDs7QUFDRDtBQUFTc0osb0JBQUFBLFVBQVUsRUFBRTtBQUFFcEcsc0JBQUFBLElBQUksRUFBRXNHO0FBQVI7QUFBckIscUJBQStDRCxHQUEvQztBQUNELGlCQVB1QixDQXJ4QjVCO0FBNnhCVWpKLGdCQUFBQSxHQTd4QlYsR0E2eEJnQixDQUFDLEtBQUtvSCxRQUFMLEVBQUQsRUFBa0IsV0FBbEIsRUFBK0IsVUFBL0IsRUFBMkNyRCxJQUEzQyxDQUFnRCxHQUFoRCxDQTd4QmhCO0FBQUEsbURBOHhCVyxLQUFLOEMsT0FBTCxDQUFhO0FBQ2xCaEIsa0JBQUFBLE1BQU0sRUFBRSxNQURVO0FBRWxCN0Ysa0JBQUFBLEdBQUcsRUFBSEEsR0FGa0I7QUFHbEIwRixrQkFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQ25CMkMsb0JBQUFBLFNBQVMsRUFBRXZFLE9BQU8sQ0FBQ3VFLFNBQVIsSUFBcUIsS0FEYjtBQUVuQkcsb0JBQUFBLE9BQU8sRUFBRWE7QUFGVSxtQkFBZixDQUhZO0FBT2xCdkQsa0JBQUFBLE9BQU8sa0NBQ0RoQyxPQUFPLENBQUNnQyxPQUFSLElBQW1CLEVBRGxCO0FBRUwsb0NBQWdCO0FBRlg7QUFQVyxpQkFBYixDQTl4Qlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE0eUJFO0FBQ0Y7QUFDQTs7QUE5eUJBO0FBQUE7O0FBdzBCRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBNTBCQSwyQkE4MEJJbEQsSUE5MEJKLEVBKzBCSTRGLE9BLzBCSixFQWkxQndDO0FBQUEsVUFEcEMxRSxPQUNvQyx1RUFEZCxFQUNjO0FBQ3BDLGFBQU8sZUFBYzBFLE9BQWQsSUFDSDtBQUNBLFdBQUtaLGNBQUwsQ0FBb0IsRUFBcEIsSUFDRSxLQUFLMEIsV0FBTCxDQUFpQjFHLElBQWpCLEVBQXVCNEYsT0FBdkIsRUFBZ0MxRSxPQUFoQyxDQURGLEdBRUUsS0FBS3lGLGVBQUwsQ0FBcUIzRyxJQUFyQixFQUEyQjRGLE9BQTNCLEVBQW9DMUUsT0FBcEMsQ0FKQyxHQUtILEtBQUswRixhQUFMLENBQW1CNUcsSUFBbkIsRUFBeUI0RixPQUF6QixFQUFrQzFFLE9BQWxDLENBTEo7QUFNRDtBQUVEOztBQTExQkY7QUFBQTtBQUFBO0FBQUEsdUdBNDFCSWxCLElBNTFCSixFQTYxQklpRyxNQTcxQkosRUE4MUJJL0UsT0E5MUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWcyQmdCNUQsZ0JBQUFBLEVBaDJCaEIsR0FnMkJ3RDJJLE1BaDJCeEQsQ0FnMkJZQyxFQWgyQlosRUFnMkIwQkMsS0FoMkIxQixHQWcyQndERixNQWgyQnhELENBZzJCb0JqRyxJQWgyQnBCLEVBZzJCaUNvRyxVQWgyQmpDLEdBZzJCd0RILE1BaDJCeEQsQ0FnMkJpQ0csVUFoMkJqQyxFQWcyQmdEQyxHQWgyQmhELDRCQWcyQndESixNQWgyQnhEOztBQUFBLG9CQWkyQlMzSSxFQWoyQlQ7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBazJCWSxJQUFJUixLQUFKLENBQVUsbUNBQVYsQ0FsMkJaOztBQUFBO0FBbzJCVXdKLGdCQUFBQSxXQXAyQlYsR0FvMkJ3QnRHLElBQUksSUFBS29HLFVBQVUsSUFBSUEsVUFBVSxDQUFDcEcsSUFBbEMsSUFBMkNtRyxLQXAyQm5FOztBQUFBLG9CQXEyQlNHLFdBcjJCVDtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkFzMkJZLElBQUl4SixLQUFKLENBQVUsbUNBQVYsQ0F0MkJaOztBQUFBO0FBdzJCVU0sZ0JBQUFBLEdBeDJCVixHQXcyQmdCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4QjhCLFdBQTlCLEVBQTJDaEosRUFBM0MsRUFBK0M2RCxJQUEvQyxDQUFvRCxHQUFwRCxDQXgyQmhCO0FBQUEsbURBeTJCVyxLQUFLOEMsT0FBTCxDQUNMO0FBQ0VoQixrQkFBQUEsTUFBTSxFQUFFLE9BRFY7QUFFRTdGLGtCQUFBQSxHQUFHLEVBQUhBLEdBRkY7QUFHRTBGLGtCQUFBQSxJQUFJLEVBQUUsZ0JBQWV1RCxHQUFmLENBSFI7QUFJRW5ELGtCQUFBQSxPQUFPLGtDQUNEaEMsT0FBTyxDQUFDZ0MsT0FBUixJQUFtQixFQURsQjtBQUVMLG9DQUFnQjtBQUZYO0FBSlQsaUJBREssRUFVTDtBQUNFMkQsa0JBQUFBLGlCQUFpQixFQUFFO0FBQUV2SixvQkFBQUEsRUFBRSxFQUFGQSxFQUFGO0FBQU1tQixvQkFBQUEsT0FBTyxFQUFFLElBQWY7QUFBcUJDLG9CQUFBQSxNQUFNLEVBQUU7QUFBN0I7QUFEckIsaUJBVkssQ0F6MkJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBeTNCRTs7QUF6M0JGO0FBQUE7QUFBQTtBQUFBLHlHQTAzQndCc0IsSUExM0J4QixFQTAzQnNDNEYsT0ExM0J0QyxFQTAzQnlEMUUsT0ExM0J6RDtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBMjNCUTBFLE9BQU8sQ0FBQ04sTUFBUixHQUFpQixLQUFLL0YsV0EzM0I5QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkE0M0JZLElBQUl6QyxLQUFKLENBQVUsdUNBQVYsQ0E1M0JaOztBQUFBO0FBQUEsbURBODNCVyxTQUFReUksR0FBUixDQUNMLHFCQUFBSyxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFLLFVBQUNLLE1BQUQ7QUFBQSx5QkFDVixNQUFJLENBQUNXLGFBQUwsQ0FBbUI1RyxJQUFuQixFQUF5QmlHLE1BQXpCLEVBQWlDL0UsT0FBakMsRUFBMENzRSxLQUExQyxDQUFnRCxVQUFDaEgsR0FBRCxFQUFTO0FBQ3ZEO0FBQ0E7QUFDQSx3QkFBSTBDLE9BQU8sQ0FBQ3VFLFNBQVIsSUFBcUIsQ0FBQ2pILEdBQUcsQ0FBQ2tILFNBQTlCLEVBQXlDO0FBQ3ZDLDRCQUFNbEgsR0FBTjtBQUNEOztBQUNELDJCQUFPRCxZQUFZLENBQUNDLEdBQUQsQ0FBbkI7QUFDRCxtQkFQRCxDQURVO0FBQUEsaUJBQUwsQ0FERixDQTkzQlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE0NEJFOztBQTU0QkY7QUFBQTtBQUFBO0FBQUEscUdBODRCSXdCLElBOTRCSixFQSs0Qkk0RixPQS80QkosRUFnNUJJMUUsT0FoNUJKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFrNUJRMEUsT0FBTyxDQUFDTixNQUFSLEtBQW1CLENBbDVCM0I7QUFBQTtBQUFBO0FBQUE7O0FBQUEsbURBbTVCYSxFQW41QmI7O0FBQUE7QUFBQSxzQkFxNUJRTSxPQUFPLENBQUNOLE1BQVIsR0FBaUJ6RyxhQUFqQixJQUFrQ3FDLE9BQU8sQ0FBQ3NGLGNBcjVCbEQ7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1NUJrQixLQUFLRSxXQUFMLENBQ1IxRyxJQURRLEVBRVIsdUJBQUE0RixPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFPLENBQVAsRUFBVS9HLGFBQVYsQ0FGQyxFQUdScUMsT0FIUSxDQXY1QmxCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0NUJrQixLQUFLd0YsV0FBTCxDQUNSMUcsSUFEUSxFQUVSLHVCQUFBNEYsT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBTy9HLGFBQVAsQ0FGQyxFQUdScUMsT0FIUSxDQTU1QmxCOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBbTZCVXVGLGdCQUFBQSxRQW42QlYsR0FtNkJxQixxQkFBQWIsT0FBTyxNQUFQLENBQUFBLE9BQU8sRUFBSyxVQUFDSyxNQUFELEVBQVk7QUFBQSxzQkFDM0IzSSxFQUQyQixHQUNhMkksTUFEYixDQUMvQkMsRUFEK0I7QUFBQSxzQkFDakJDLEtBRGlCLEdBQ2FGLE1BRGIsQ0FDdkJqRyxJQUR1QjtBQUFBLHNCQUNWb0csVUFEVSxHQUNhSCxNQURiLENBQ1ZHLFVBRFU7QUFBQSxzQkFDS0MsR0FETCw0QkFDYUosTUFEYjs7QUFFdkMsc0JBQUksQ0FBQzNJLEVBQUwsRUFBUztBQUNQLDBCQUFNLElBQUlSLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0Qsc0JBQU13SixXQUFXLEdBQUd0RyxJQUFJLElBQUtvRyxVQUFVLElBQUlBLFVBQVUsQ0FBQ3BHLElBQWxDLElBQTJDbUcsS0FBL0Q7O0FBQ0Esc0JBQUksQ0FBQ0csV0FBTCxFQUFrQjtBQUNoQiwwQkFBTSxJQUFJeEosS0FBSixDQUFVLG1DQUFWLENBQU47QUFDRDs7QUFDRDtBQUFTUSxvQkFBQUEsRUFBRSxFQUFGQSxFQUFUO0FBQWE4SSxvQkFBQUEsVUFBVSxFQUFFO0FBQUVwRyxzQkFBQUEsSUFBSSxFQUFFc0c7QUFBUjtBQUF6QixxQkFBbURELEdBQW5EO0FBQ0QsaUJBVnVCLENBbjZCNUI7QUE4NkJVakosZ0JBQUFBLEdBOTZCVixHQTg2QmdCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixXQUFsQixFQUErQixVQUEvQixFQUEyQ3JELElBQTNDLENBQWdELEdBQWhELENBOTZCaEI7QUFBQSxtREErNkJXLEtBQUs4QyxPQUFMLENBQWE7QUFDbEJoQixrQkFBQUEsTUFBTSxFQUFFLE9BRFU7QUFFbEI3RixrQkFBQUEsR0FBRyxFQUFIQSxHQUZrQjtBQUdsQjBGLGtCQUFBQSxJQUFJLEVBQUUsZ0JBQWU7QUFDbkIyQyxvQkFBQUEsU0FBUyxFQUFFdkUsT0FBTyxDQUFDdUUsU0FBUixJQUFxQixLQURiO0FBRW5CRyxvQkFBQUEsT0FBTyxFQUFFYTtBQUZVLG1CQUFmLENBSFk7QUFPbEJ2RCxrQkFBQUEsT0FBTyxrQ0FDRGhDLE9BQU8sQ0FBQ2dDLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCxvQ0FBZ0I7QUFGWDtBQVBXLGlCQUFiLENBLzZCWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTY3QkU7QUFDRjtBQUNBOztBQS83QkE7QUFBQTs7QUE4OUJFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBcCtCQTtBQUFBLGdHQXMrQklsRCxJQXQrQkosRUF1K0JJNEYsT0F2K0JKLEVBdytCSWtCLFVBeCtCSjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5K0JJNUYsZ0JBQUFBLE9BeitCSixpRUF5K0IwQixFQXorQjFCO0FBMitCVTZGLGdCQUFBQSxPQTMrQlYsR0EyK0JvQixlQUFjbkIsT0FBZCxDQTMrQnBCO0FBNCtCVWEsZ0JBQUFBLFFBNStCVixHQTQrQnFCLGVBQWNiLE9BQWQsSUFBeUJBLE9BQXpCLEdBQW1DLENBQUNBLE9BQUQsQ0E1K0J4RDs7QUFBQSxzQkE2K0JRYSxRQUFRLENBQUNuQixNQUFULEdBQWtCLEtBQUsvRixXQTcrQi9CO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTgrQlksSUFBSXpDLEtBQUosQ0FBVSx1Q0FBVixDQTkrQlo7O0FBQUE7QUFBQTtBQUFBLHVCQWcvQjBCLFNBQVF5SSxHQUFSLENBQ3BCLHFCQUFBa0IsUUFBUSxNQUFSLENBQUFBLFFBQVEsRUFBSyxVQUFDUixNQUFELEVBQVk7QUFBQTs7QUFBQSxzQkFDRGUsS0FEQyxHQUMwQ2YsTUFEMUMsQ0FDZGEsVUFEYztBQUFBLHNCQUNZWCxLQURaLEdBQzBDRixNQUQxQyxDQUNNakcsSUFETjtBQUFBLHNCQUNtQm9HLFVBRG5CLEdBQzBDSCxNQUQxQyxDQUNtQkcsVUFEbkI7QUFBQSxzQkFDa0NDLEdBRGxDLDRCQUMwQ0osTUFEMUMscUNBQ2RhLFVBRGM7O0FBRXZCLHNCQUFNMUosR0FBRyxHQUFHLENBQUMsTUFBSSxDQUFDb0gsUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCeEUsSUFBOUIsRUFBb0M4RyxVQUFwQyxFQUFnREUsS0FBaEQsRUFBdUQ3RixJQUF2RCxDQUNWLEdBRFUsQ0FBWjtBQUdBLHlCQUFPLE1BQUksQ0FBQzhDLE9BQUwsQ0FDTDtBQUNFaEIsb0JBQUFBLE1BQU0sRUFBRSxPQURWO0FBRUU3RixvQkFBQUEsR0FBRyxFQUFIQSxHQUZGO0FBR0UwRixvQkFBQUEsSUFBSSxFQUFFLGdCQUFldUQsR0FBZixDQUhSO0FBSUVuRCxvQkFBQUEsT0FBTyxrQ0FDRGhDLE9BQU8sQ0FBQ2dDLE9BQVIsSUFBbUIsRUFEbEI7QUFFTCxzQ0FBZ0I7QUFGWDtBQUpULG1CQURLLEVBVUw7QUFDRTJELG9CQUFBQSxpQkFBaUIsRUFBRTtBQUFFcEksc0JBQUFBLE9BQU8sRUFBRSxJQUFYO0FBQWlCQyxzQkFBQUEsTUFBTSxFQUFFO0FBQXpCO0FBRHJCLG1CQVZLLEVBYUw4RyxLQWJLLENBYUMsVUFBQ2hILEdBQUQsRUFBUztBQUNmO0FBQ0E7QUFDQTtBQUNBLHdCQUFJLENBQUN1SSxPQUFELElBQVk3RixPQUFPLENBQUN1RSxTQUFwQixJQUFpQyxDQUFDakgsR0FBRyxDQUFDa0gsU0FBMUMsRUFBcUQ7QUFDbkQsNEJBQU1sSCxHQUFOO0FBQ0Q7O0FBQ0QsMkJBQU9ELFlBQVksQ0FBQ0MsR0FBRCxDQUFuQjtBQUNELG1CQXJCTSxDQUFQO0FBc0JELGlCQTNCTyxDQURZLENBaC9CMUI7O0FBQUE7QUFnL0JVeUksZ0JBQUFBLE9BaC9CVjtBQUFBLG1EQThnQ1dGLE9BQU8sR0FBR0UsT0FBSCxHQUFhQSxPQUFPLENBQUMsQ0FBRCxDQTlnQ3RDOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaWhDRTtBQUNGO0FBQ0E7O0FBbmhDQTtBQUFBOztBQW1pQ0U7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQXZpQ0E7QUFBQSxpR0F5aUNJakgsSUF6aUNKLEVBMGlDSWlGLEdBMWlDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTJpQ0kvRCxnQkFBQUEsT0EzaUNKLGlFQTJpQzBCLEVBM2lDMUI7QUFBQSxtREE2aUNXLGVBQWMrRCxHQUFkLElBQ0g7QUFDQSxxQkFBS0QsY0FBTCxDQUFvQixFQUFwQixJQUNFLEtBQUtrQyxZQUFMLENBQWtCbEgsSUFBbEIsRUFBd0JpRixHQUF4QixFQUE2Qi9ELE9BQTdCLENBREYsR0FFRSxLQUFLaUcsZ0JBQUwsQ0FBc0JuSCxJQUF0QixFQUE0QmlGLEdBQTVCLEVBQWlDL0QsT0FBakMsQ0FKQyxHQUtILEtBQUtrRyxjQUFMLENBQW9CcEgsSUFBcEIsRUFBMEJpRixHQUExQixFQUErQi9ELE9BQS9CLENBbGpDUjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXFqQ0U7O0FBcmpDRjtBQUFBO0FBQUE7QUFBQSx3R0F1akNJbEIsSUF2akNKLEVBd2pDSTFDLEVBeGpDSixFQXlqQ0k0RCxPQXpqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBMmpDVTlELGdCQUFBQSxHQTNqQ1YsR0EyakNnQixDQUFDLEtBQUtvSCxRQUFMLEVBQUQsRUFBa0IsVUFBbEIsRUFBOEJ4RSxJQUE5QixFQUFvQzFDLEVBQXBDLEVBQXdDNkQsSUFBeEMsQ0FBNkMsR0FBN0MsQ0EzakNoQjtBQUFBLG1EQTRqQ1csS0FBSzhDLE9BQUwsQ0FDTDtBQUNFaEIsa0JBQUFBLE1BQU0sRUFBRSxRQURWO0FBRUU3RixrQkFBQUEsR0FBRyxFQUFIQSxHQUZGO0FBR0U4RixrQkFBQUEsT0FBTyxFQUFFaEMsT0FBTyxDQUFDZ0MsT0FBUixJQUFtQjtBQUg5QixpQkFESyxFQU1MO0FBQ0UyRCxrQkFBQUEsaUJBQWlCLEVBQUU7QUFBRXZKLG9CQUFBQSxFQUFFLEVBQUZBLEVBQUY7QUFBTW1CLG9CQUFBQSxPQUFPLEVBQUUsSUFBZjtBQUFxQkMsb0JBQUFBLE1BQU0sRUFBRTtBQUE3QjtBQURyQixpQkFOSyxDQTVqQ1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3a0NFOztBQXhrQ0Y7QUFBQTtBQUFBO0FBQUEsMEdBeWtDeUJzQixJQXprQ3pCLEVBeWtDdUNpRixHQXprQ3ZDLEVBeWtDc0QvRCxPQXprQ3REO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkEwa0NRK0QsR0FBRyxDQUFDSyxNQUFKLEdBQWEsS0FBSy9GLFdBMWtDMUI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBMmtDWSxJQUFJekMsS0FBSixDQUFVLHVDQUFWLENBM2tDWjs7QUFBQTtBQUFBLG1EQTZrQ1csU0FBUXlJLEdBQVIsQ0FDTCxxQkFBQU4sR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBSyxVQUFDM0gsRUFBRDtBQUFBLHlCQUNOLE1BQUksQ0FBQzhKLGNBQUwsQ0FBb0JwSCxJQUFwQixFQUEwQjFDLEVBQTFCLEVBQThCNEQsT0FBOUIsRUFBdUNzRSxLQUF2QyxDQUE2QyxVQUFDaEgsR0FBRCxFQUFTO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBLHdCQUFJMEMsT0FBTyxDQUFDdUUsU0FBUixJQUFxQixDQUFDakgsR0FBRyxDQUFDa0gsU0FBOUIsRUFBeUM7QUFDdkMsNEJBQU1sSCxHQUFOO0FBQ0Q7O0FBQ0QsMkJBQU9ELFlBQVksQ0FBQ0MsR0FBRCxDQUFuQjtBQUNELG1CQVJELENBRE07QUFBQSxpQkFBTCxDQURFLENBN2tDWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTRsQ0U7O0FBNWxDRjtBQUFBO0FBQUE7QUFBQSxzR0E4bENJd0IsSUE5bENKLEVBK2xDSWlGLEdBL2xDSixFQWdtQ0kvRCxPQWhtQ0o7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWttQ1ErRCxHQUFHLENBQUNLLE1BQUosS0FBZSxDQWxtQ3ZCO0FBQUE7QUFBQTtBQUFBOztBQUFBLG1EQW1tQ2EsRUFubUNiOztBQUFBO0FBQUEsc0JBcW1DUUwsR0FBRyxDQUFDSyxNQUFKLEdBQWF6RyxhQUFiLElBQThCcUMsT0FBTyxDQUFDc0YsY0FybUM5QztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVtQ2tCLEtBQUtVLFlBQUwsQ0FDUmxILElBRFEsRUFFUix1QkFBQWlGLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQU8sQ0FBUCxFQUFVcEcsYUFBVixDQUZLLEVBR1JxQyxPQUhRLENBdm1DbEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRtQ2tCLEtBQUtnRyxZQUFMLENBQWtCbEgsSUFBbEIsRUFBd0IsdUJBQUFpRixHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFPcEcsYUFBUCxDQUEzQixFQUFrRHFDLE9BQWxELENBNW1DbEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUErbUNROUQsZ0JBQUFBLEdBL21DUixHQWduQ00sQ0FBQyxLQUFLb0gsUUFBTCxFQUFELEVBQWtCLFdBQWxCLEVBQStCLGVBQS9CLEVBQWdEckQsSUFBaEQsQ0FBcUQsR0FBckQsSUFBNEQ4RCxHQUFHLENBQUM5RCxJQUFKLENBQVMsR0FBVCxDQWhuQ2xFOztBQWluQ0ksb0JBQUlELE9BQU8sQ0FBQ3VFLFNBQVosRUFBdUI7QUFDckJySSxrQkFBQUEsR0FBRyxJQUFJLGlCQUFQO0FBQ0Q7O0FBbm5DTCxtREFvbkNXLEtBQUs2RyxPQUFMLENBQWE7QUFDbEJoQixrQkFBQUEsTUFBTSxFQUFFLFFBRFU7QUFFbEI3RixrQkFBQUEsR0FBRyxFQUFIQSxHQUZrQjtBQUdsQjhGLGtCQUFBQSxPQUFPLEVBQUVoQyxPQUFPLENBQUNnQyxPQUFSLElBQW1CO0FBSFYsaUJBQWIsQ0FwbkNYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMm5DRTtBQUNGO0FBQ0E7O0FBN25DQTtBQUFBOztBQXFvQ0U7QUFDRjtBQUNBO0FBdm9DQTtBQUFBLGtHQXdvQ2lCbEQsSUF4b0NqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5b0NVNUMsZ0JBQUFBLEdBem9DVixHQXlvQ2dCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4QnhFLElBQTlCLEVBQW9DLFVBQXBDLEVBQWdEbUIsSUFBaEQsQ0FBcUQsR0FBckQsQ0F6b0NoQjtBQUFBO0FBQUEsdUJBMG9DdUIsS0FBSzhDLE9BQUwsQ0FBYTdHLEdBQWIsQ0Exb0N2Qjs7QUFBQTtBQTBvQ1UwRixnQkFBQUEsSUExb0NWO0FBQUEsbURBMm9DV0EsSUEzb0NYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBOG9DRTtBQUNGO0FBQ0E7O0FBaHBDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFrcENVMUYsZ0JBQUFBLEdBbHBDVixhQWtwQ21CLEtBQUtvSCxRQUFMLEVBbHBDbkI7QUFBQTtBQUFBLHVCQW1wQ3VCLEtBQUtQLE9BQUwsQ0FBYTdHLEdBQWIsQ0FucEN2Qjs7QUFBQTtBQW1wQ1UwRixnQkFBQUEsSUFucENWO0FBQUEsbURBb3BDV0EsSUFwcENYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBdXBDRTtBQUNGO0FBQ0E7O0FBenBDQTtBQUFBO0FBQUEsNEJBNHBDcUM5QyxJQTVwQ3JDLEVBNHBDc0U7QUFDbEUsVUFBTWlDLEVBQUUsR0FDTCxLQUFLTixRQUFMLENBQWMzQixJQUFkLENBQUQsSUFDQSxJQUFJdkUsT0FBSixDQUFZLElBQVosRUFBa0J1RSxJQUFsQixDQUZGO0FBR0EsV0FBSzJCLFFBQUwsQ0FBYzNCLElBQWQsSUFBMkJpQyxFQUEzQjtBQUNBLGFBQU9BLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0cUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVxQ2lCZixnQkFBQUEsT0F2cUNqQixpRUF1cUNxRSxFQXZxQ3JFO0FBd3FDUTlELGdCQUFBQSxHQXhxQ1IsR0F3cUNjLEtBQUtTLFFBQUwsSUFBaUIsS0FBS0EsUUFBTCxDQUFjVCxHQXhxQzdDOztBQUFBLG9CQXlxQ1NBLEdBenFDVDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVCQTBxQ3dCLEtBQUs2RyxPQUFMLENBQW1DO0FBQ25EaEIsa0JBQUFBLE1BQU0sRUFBRSxLQUQyQztBQUVuRDdGLGtCQUFBQSxHQUFHLEVBQUUsS0FBS29ILFFBQUwsRUFGOEM7QUFHbkR0QixrQkFBQUEsT0FBTyxFQUFFaEMsT0FBTyxDQUFDZ0M7QUFIa0MsaUJBQW5DLENBMXFDeEI7O0FBQUE7QUEwcUNZdEYsZ0JBQUFBLElBMXFDWjtBQStxQ01SLGdCQUFBQSxHQUFHLEdBQUdRLElBQUcsQ0FBQ3lKLFFBQVY7O0FBL3FDTjtBQWlyQ0lqSyxnQkFBQUEsR0FBRyxJQUFJLGNBQVA7O0FBQ0Esb0JBQUksS0FBS1ksV0FBVCxFQUFzQjtBQUNwQlosa0JBQUFBLEdBQUcsMkJBQW9CdUgsa0JBQWtCLENBQUMsS0FBSzNHLFdBQU4sQ0FBdEMsQ0FBSDtBQUNEOztBQXByQ0w7QUFBQSx1QkFxckNzQixLQUFLaUcsT0FBTCxDQUEyQjtBQUFFaEIsa0JBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCN0Ysa0JBQUFBLEdBQUcsRUFBSEE7QUFBakIsaUJBQTNCLENBcnJDdEI7O0FBQUE7QUFxckNVUSxnQkFBQUEsR0FyckNWO0FBc3JDSSxxQkFBS0MsUUFBTCxHQUFnQjtBQUNkUCxrQkFBQUEsRUFBRSxFQUFFTSxHQUFHLENBQUMwSixPQURNO0FBRWRqSyxrQkFBQUEsY0FBYyxFQUFFTyxHQUFHLENBQUMySixlQUZOO0FBR2RuSyxrQkFBQUEsR0FBRyxFQUFFUSxHQUFHLENBQUNOO0FBSEssaUJBQWhCO0FBdHJDSixtREEyckNXTSxHQTNyQ1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE4ckNFO0FBQ0Y7QUFDQTs7QUFoc0NBO0FBQUE7QUFBQTtBQUFBLGdHQWlzQ2VvQyxJQWpzQ2YsRUFpc0N1Q3VFLEtBanNDdkM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWtzQ0k7QUFDQSxvQkFBSSxPQUFPdkUsSUFBUCxLQUFnQixRQUFwQixFQUE4QjtBQUM1QnVFLGtCQUFBQSxLQUFLLEdBQUd2RSxJQUFSO0FBQ0FBLGtCQUFBQSxJQUFJLEdBQUc5QixTQUFQO0FBQ0Q7O0FBdHNDTCxxQkF3c0NROEIsSUF4c0NSO0FBQUE7QUFBQTtBQUFBOztBQXlzQ001QyxnQkFBQUEsR0FBRyxHQUFHLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixVQUFsQixFQUE4QnhFLElBQTlCLEVBQW9DbUIsSUFBcEMsQ0FBeUMsR0FBekMsQ0FBTjtBQXpzQ047QUFBQSx1QkEwc0NvQyxLQUFLOEMsT0FBTCxDQUM1QjdHLEdBRDRCLENBMXNDcEM7O0FBQUE7QUFBQTtBQTBzQ2NvSyxnQkFBQUEsV0Exc0NkLHVCQTBzQ2NBLFdBMXNDZDtBQUFBLG1EQTZzQ2FqRCxLQUFLLEdBQUcsdUJBQUFpRCxXQUFXLE1BQVgsQ0FBQUEsV0FBVyxFQUFPLENBQVAsRUFBVWpELEtBQVYsQ0FBZCxHQUFpQ2lELFdBN3NDbkQ7O0FBQUE7QUErc0NJcEssZ0JBQUFBLEdBQUcsYUFBTSxLQUFLb0gsUUFBTCxFQUFOLFlBQUg7O0FBQ0Esb0JBQUlELEtBQUosRUFBVztBQUNUbkgsa0JBQUFBLEdBQUcscUJBQWNtSCxLQUFkLENBQUg7QUFDRDs7QUFsdENMLG1EQW10Q1csS0FBS04sT0FBTCxDQUF1QjdHLEdBQXZCLENBbnRDWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXN0Q0U7QUFDRjtBQUNBOztBQXh0Q0E7QUFBQTtBQUFBO0FBQUEsaUdBMHRDSTRDLElBMXRDSixFQTJ0Q0l5SCxLQTN0Q0osRUE0dENJQyxHQTV0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBOHRDSTtBQUNJdEssZ0JBQUFBLEdBL3RDUixHQSt0Q2MsQ0FBQyxLQUFLb0gsUUFBTCxFQUFELEVBQWtCLFVBQWxCLEVBQThCeEUsSUFBOUIsRUFBb0MsU0FBcEMsRUFBK0NtQixJQUEvQyxDQUFvRCxHQUFwRCxDQS90Q2Q7O0FBZ3VDSSxvQkFBSSxPQUFPc0csS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUM3QkEsa0JBQUFBLEtBQUssR0FBRyxJQUFJRSxJQUFKLENBQVNGLEtBQVQsQ0FBUjtBQUNEOztBQUNEQSxnQkFBQUEsS0FBSyxHQUFHN0wsVUFBVSxDQUFDNkwsS0FBRCxDQUFsQjtBQUNBckssZ0JBQUFBLEdBQUcscUJBQWN1SCxrQkFBa0IsQ0FBQzhDLEtBQUQsQ0FBaEMsQ0FBSDs7QUFDQSxvQkFBSSxPQUFPQyxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0JBLGtCQUFBQSxHQUFHLEdBQUcsSUFBSUMsSUFBSixDQUFTRCxHQUFULENBQU47QUFDRDs7QUFDREEsZ0JBQUFBLEdBQUcsR0FBRzlMLFVBQVUsQ0FBQzhMLEdBQUQsQ0FBaEI7QUFDQXRLLGdCQUFBQSxHQUFHLG1CQUFZdUgsa0JBQWtCLENBQUMrQyxHQUFELENBQTlCLENBQUg7QUF6dUNKO0FBQUEsdUJBMHVDdUIsS0FBS3pELE9BQUwsQ0FBYTdHLEdBQWIsQ0ExdUN2Qjs7QUFBQTtBQTB1Q1UwRixnQkFBQUEsSUExdUNWO0FBQUEsbURBMnVDV0EsSUEzdUNYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBOHVDRTtBQUNGO0FBQ0E7O0FBaHZDQTtBQUFBO0FBQUE7QUFBQSxpR0FrdkNJOUMsSUFsdkNKLEVBbXZDSXlILEtBbnZDSixFQW92Q0lDLEdBcHZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFzdkNJO0FBQ0l0SyxnQkFBQUEsR0F2dkNSLEdBdXZDYyxDQUFDLEtBQUtvSCxRQUFMLEVBQUQsRUFBa0IsVUFBbEIsRUFBOEJ4RSxJQUE5QixFQUFvQyxTQUFwQyxFQUErQ21CLElBQS9DLENBQW9ELEdBQXBELENBdnZDZDs7QUF3dkNJLG9CQUFJLE9BQU9zRyxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzdCQSxrQkFBQUEsS0FBSyxHQUFHLElBQUlFLElBQUosQ0FBU0YsS0FBVCxDQUFSO0FBQ0Q7O0FBQ0RBLGdCQUFBQSxLQUFLLEdBQUc3TCxVQUFVLENBQUM2TCxLQUFELENBQWxCO0FBQ0FySyxnQkFBQUEsR0FBRyxxQkFBY3VILGtCQUFrQixDQUFDOEMsS0FBRCxDQUFoQyxDQUFIOztBQUVBLG9CQUFJLE9BQU9DLEdBQVAsS0FBZSxRQUFuQixFQUE2QjtBQUMzQkEsa0JBQUFBLEdBQUcsR0FBRyxJQUFJQyxJQUFKLENBQVNELEdBQVQsQ0FBTjtBQUNEOztBQUNEQSxnQkFBQUEsR0FBRyxHQUFHOUwsVUFBVSxDQUFDOEwsR0FBRCxDQUFoQjtBQUNBdEssZ0JBQUFBLEdBQUcsbUJBQVl1SCxrQkFBa0IsQ0FBQytDLEdBQUQsQ0FBOUIsQ0FBSDtBQWx3Q0o7QUFBQSx1QkFtd0N1QixLQUFLekQsT0FBTCxDQUFhN0csR0FBYixDQW53Q3ZCOztBQUFBO0FBbXdDVTBGLGdCQUFBQSxJQW53Q1Y7QUFBQSxtREFvd0NXQSxJQXB3Q1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF1d0NFO0FBQ0Y7QUFDQTs7QUF6d0NBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTJ3Q1UxRixnQkFBQUEsR0Ezd0NWLEdBMndDZ0IsQ0FBQyxLQUFLb0gsUUFBTCxFQUFELEVBQWtCLE1BQWxCLEVBQTBCckQsSUFBMUIsQ0FBK0IsR0FBL0IsQ0Ezd0NoQjtBQUFBO0FBQUEsdUJBNHdDdUIsS0FBSzhDLE9BQUwsQ0FBYTdHLEdBQWIsQ0E1d0N2Qjs7QUFBQTtBQTR3Q1UwRixnQkFBQUEsSUE1d0NWO0FBQUEsbURBNndDV0EsSUE3d0NYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZ3hDRTtBQUNGO0FBQ0E7O0FBbHhDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFveENVMUYsZ0JBQUFBLEdBcHhDVixHQW94Q2dCLENBQUMsS0FBS29ILFFBQUwsRUFBRCxFQUFrQixRQUFsQixFQUE0QnJELElBQTVCLENBQWlDLEdBQWpDLENBcHhDaEI7QUFBQTtBQUFBLHVCQXF4Q3VCLEtBQUs4QyxPQUFMLENBQWE3RyxHQUFiLENBcnhDdkI7O0FBQUE7QUFxeENVMEYsZ0JBQUFBLElBcnhDVjtBQUFBLG1EQXN4Q1dBLElBdHhDWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXl4Q0U7QUFDRjtBQUNBOztBQTN4Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNnhDVTFGLGdCQUFBQSxHQTd4Q1YsR0E2eENnQixDQUFDLEtBQUtvSCxRQUFMLEVBQUQsRUFBa0IsT0FBbEIsRUFBMkJyRCxJQUEzQixDQUFnQyxHQUFoQyxDQTd4Q2hCO0FBQUE7QUFBQSx1QkE4eEN1QixLQUFLOEMsT0FBTCxDQUFhN0csR0FBYixDQTl4Q3ZCOztBQUFBO0FBOHhDVTBGLGdCQUFBQSxJQTl4Q1Y7QUFBQSxtREEreENXQSxJQS94Q1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFreUNFO0FBQ0Y7QUFDQTs7QUFweUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc3lDdUIsS0FBS21CLE9BQUwsQ0FBYSxlQUFiLENBdHlDdkI7O0FBQUE7QUFzeUNVbkIsZ0JBQUFBLElBdHlDVjtBQUFBLG1EQXV5Q1dBLElBdnlDWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTB5Q0U7QUFDRjtBQUNBOztBQTV5Q0E7QUFBQTtBQUFBLGdDQTZ5Q2M4RSxVQTd5Q2QsRUE2eUNrRDtBQUM5QyxhQUFPLElBQUlsTSxXQUFKLENBQWdCLElBQWhCLDBCQUF1Q2tNLFVBQXZDLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFuekNBOztBQUFBO0FBQUEsRUFBMkQvTSxZQUEzRDs7Z0JBQWFpRSxVLGFBQ00zRCxTQUFTLENBQUMsWUFBRCxDOztBQXN6QzVCLGVBQWUyRCxVQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IGpzZm9yY2UgZnJvbSAnLi9qc2ZvcmNlJztcbmltcG9ydCB7XG4gIEh0dHBSZXF1ZXN0LFxuICBIdHRwUmVzcG9uc2UsXG4gIENhbGxiYWNrLFxuICBSZWNvcmQsXG4gIFNhdmVSZXN1bHQsXG4gIFVwc2VydFJlc3VsdCxcbiAgRGVzY3JpYmVHbG9iYWxSZXN1bHQsXG4gIERlc2NyaWJlU09iamVjdFJlc3VsdCxcbiAgRGVzY3JpYmVUYWIsXG4gIERlc2NyaWJlVGhlbWUsXG4gIERlc2NyaWJlUXVpY2tBY3Rpb25SZXN1bHQsXG4gIFVwZGF0ZWRSZXN1bHQsXG4gIERlbGV0ZWRSZXN1bHQsXG4gIFNlYXJjaFJlc3VsdCxcbiAgT3JnYW5pemF0aW9uTGltaXRzSW5mbyxcbiAgT3B0aW9uYWwsXG4gIFNpZ25lZFJlcXVlc3RPYmplY3QsXG4gIFNhdmVFcnJvcixcbiAgRG1sT3B0aW9ucyxcbiAgUmV0cmlldmVPcHRpb25zLFxuICBTY2hlbWEsXG4gIFNPYmplY3ROYW1lcyxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxuICBTT2JqZWN0RmllbGROYW1lcyxcbiAgVXNlckluZm8sXG4gIElkZW50aXR5SW5mbyxcbiAgTGltaXRJbmZvLFxufSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IFN0cmVhbVByb21pc2UgfSBmcm9tICcuL3V0aWwvcHJvbWlzZSc7XG5pbXBvcnQgVHJhbnNwb3J0LCB7XG4gIENhbnZhc1RyYW5zcG9ydCxcbiAgWGRQcm94eVRyYW5zcG9ydCxcbiAgSHR0cFByb3h5VHJhbnNwb3J0LFxufSBmcm9tICcuL3RyYW5zcG9ydCc7XG5pbXBvcnQgeyBMb2dnZXIsIGdldExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgTG9nTGV2ZWxDb25maWcgfSBmcm9tICcuL3V0aWwvbG9nZ2VyJztcbmltcG9ydCBPQXV0aDIsIHsgVG9rZW5SZXNwb25zZSB9IGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCB7IE9BdXRoMkNvbmZpZyB9IGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCBDYWNoZSwgeyBDYWNoZWRGdW5jdGlvbiB9IGZyb20gJy4vY2FjaGUnO1xuaW1wb3J0IEh0dHBBcGkgZnJvbSAnLi9odHRwLWFwaSc7XG5pbXBvcnQgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSwge1xuICBTZXNzaW9uUmVmcmVzaEZ1bmMsXG59IGZyb20gJy4vc2Vzc2lvbi1yZWZyZXNoLWRlbGVnYXRlJztcbmltcG9ydCBRdWVyeSBmcm9tICcuL3F1ZXJ5JztcbmltcG9ydCB7IFF1ZXJ5T3B0aW9ucyB9IGZyb20gJy4vcXVlcnknO1xuaW1wb3J0IFNPYmplY3QgZnJvbSAnLi9zb2JqZWN0JztcbmltcG9ydCBRdWlja0FjdGlvbiBmcm9tICcuL3F1aWNrLWFjdGlvbic7XG5pbXBvcnQgUHJvY2VzcyBmcm9tICcuL3Byb2Nlc3MnO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4vdXRpbC9mb3JtYXR0ZXInO1xuaW1wb3J0IEFuYWx5dGljcyBmcm9tICcuL2FwaS9hbmFseXRpY3MnO1xuaW1wb3J0IEFwZXggZnJvbSAnLi9hcGkvYXBleCc7XG5pbXBvcnQgeyBCdWxrLCBCdWxrVjIgfSBmcm9tICcuL2FwaS9idWxrJztcbmltcG9ydCBDaGF0dGVyIGZyb20gJy4vYXBpL2NoYXR0ZXInO1xuaW1wb3J0IE1ldGFkYXRhIGZyb20gJy4vYXBpL21ldGFkYXRhJztcbmltcG9ydCBTb2FwQXBpIGZyb20gJy4vYXBpL3NvYXAnO1xuaW1wb3J0IFN0cmVhbWluZyBmcm9tICcuL2FwaS9zdHJlYW1pbmcnO1xuaW1wb3J0IFRvb2xpbmcgZnJvbSAnLi9hcGkvdG9vbGluZyc7XG5pbXBvcnQgeyBKd3RPQXV0aDJDb25maWcsIEp3dE9BdXRoMiB9IGZyb20gJy4vand0T0F1dGgyJztcblxuLyoqXG4gKiB0eXBlIGRlZmluaXRpb25zXG4gKi9cbmV4cG9ydCB0eXBlIENvbm5lY3Rpb25Db25maWc8UyBleHRlbmRzIFNjaGVtYSA9IFNjaGVtYT4gPSB7XG4gIHZlcnNpb24/OiBzdHJpbmc7XG4gIGxvZ2luVXJsPzogc3RyaW5nO1xuICBhY2Nlc3NUb2tlbj86IHN0cmluZztcbiAgcmVmcmVzaFRva2VuPzogc3RyaW5nO1xuICBpbnN0YW5jZVVybD86IHN0cmluZztcbiAgc2Vzc2lvbklkPzogc3RyaW5nO1xuICBzZXJ2ZXJVcmw/OiBzdHJpbmc7XG4gIHNpZ25lZFJlcXVlc3Q/OiBzdHJpbmc7XG4gIG9hdXRoMj86IE9BdXRoMiB8IE9BdXRoMkNvbmZpZztcbiAgand0T0F1dGgyPzogSnd0T0F1dGgyIHwgSnd0T0F1dGgyQ29uZmlnO1xuICBtYXhSZXF1ZXN0PzogbnVtYmVyO1xuICBwcm94eVVybD86IHN0cmluZztcbiAgaHR0cFByb3h5Pzogc3RyaW5nO1xuICBsb2dMZXZlbD86IExvZ0xldmVsQ29uZmlnO1xuICBjYWxsT3B0aW9ucz86IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9O1xuICByZWZyZXNoRm4/OiBTZXNzaW9uUmVmcmVzaEZ1bmM8Uz47XG59O1xuXG5leHBvcnQgdHlwZSBDb25uZWN0aW9uRXN0YWJsaXNoT3B0aW9ucyA9IHtcbiAgYWNjZXNzVG9rZW4/OiBPcHRpb25hbDxzdHJpbmc+O1xuICByZWZyZXNoVG9rZW4/OiBPcHRpb25hbDxzdHJpbmc+O1xuICBpbnN0YW5jZVVybD86IE9wdGlvbmFsPHN0cmluZz47XG4gIHNlc3Npb25JZD86IE9wdGlvbmFsPHN0cmluZz47XG4gIHNlcnZlclVybD86IE9wdGlvbmFsPHN0cmluZz47XG4gIHNpZ25lZFJlcXVlc3Q/OiBPcHRpb25hbDxzdHJpbmcgfCBTaWduZWRSZXF1ZXN0T2JqZWN0PjtcbiAgdXNlckluZm8/OiBPcHRpb25hbDxVc2VySW5mbz47XG59O1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnOiB7XG4gIGxvZ2luVXJsOiBzdHJpbmc7XG4gIGluc3RhbmNlVXJsOiBzdHJpbmc7XG4gIHZlcnNpb246IHN0cmluZztcbiAgbG9nTGV2ZWw6IExvZ0xldmVsQ29uZmlnO1xuICBtYXhSZXF1ZXN0OiBudW1iZXI7XG59ID0ge1xuICBsb2dpblVybDogJ2h0dHBzOi8vbG9naW4uc2FsZXNmb3JjZS5jb20nLFxuICBpbnN0YW5jZVVybDogJycsXG4gIHZlcnNpb246ICc1MC4wJyxcbiAgbG9nTGV2ZWw6ICdOT05FJyxcbiAgbWF4UmVxdWVzdDogMTAsXG59O1xuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIGVzYyhzdHI6IE9wdGlvbmFsPHN0cmluZz4pOiBzdHJpbmcge1xuICByZXR1cm4gU3RyaW5nKHN0ciB8fCAnJylcbiAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxuICAgIC5yZXBsYWNlKC88L2csICcmbHQ7JylcbiAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpXG4gICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKTtcbn1cblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiBwYXJzZVNpZ25lZFJlcXVlc3Qoc3I6IHN0cmluZyB8IE9iamVjdCk6IFNpZ25lZFJlcXVlc3RPYmplY3Qge1xuICBpZiAodHlwZW9mIHNyID09PSAnc3RyaW5nJykge1xuICAgIGlmIChzclswXSA9PT0gJ3snKSB7XG4gICAgICAvLyBtaWdodCBiZSBKU09OXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShzcik7XG4gICAgfSAvLyBtaWdodCBiZSBvcmlnaW5hbCBiYXNlNjQtZW5jb2RlZCBzaWduZWQgcmVxdWVzdFxuICAgIGNvbnN0IG1zZyA9IHNyLnNwbGl0KCcuJykucG9wKCk7IC8vIHJldHJpZXZlIGxhdHRlciBwYXJ0XG4gICAgaWYgKCFtc2cpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBzaWduZWQgcmVxdWVzdCcpO1xuICAgIH1cbiAgICBjb25zdCBqc29uID0gQnVmZmVyLmZyb20obXNnLCAnYmFzZTY0JykudG9TdHJpbmcoJ3V0Zi04Jyk7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UoanNvbik7XG4gIH1cbiAgcmV0dXJuIHNyIGFzIFNpZ25lZFJlcXVlc3RPYmplY3Q7XG59XG5cbi8qKiBAcHJpdmF0ZSAqKi9cbmZ1bmN0aW9uIHBhcnNlSWRVcmwodXJsOiBzdHJpbmcpIHtcbiAgY29uc3QgW29yZ2FuaXphdGlvbklkLCBpZF0gPSB1cmwuc3BsaXQoJy8nKS5zbGljZSgtMik7XG4gIHJldHVybiB7IGlkLCBvcmdhbml6YXRpb25JZCwgdXJsIH07XG59XG5cbi8qKlxuICogU2Vzc2lvbiBSZWZyZXNoIGRlbGVnYXRlIGZ1bmN0aW9uIGZvciBPQXV0aDIgYXV0aHogY29kZSBmbG93XG4gKiBAcHJpdmF0ZVxuICovXG5hc3luYyBmdW5jdGlvbiBvYXV0aFJlZnJlc2hGbjxTIGV4dGVuZHMgU2NoZW1hPihcbiAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgY2FsbGJhY2s6IENhbGxiYWNrPHN0cmluZywgVG9rZW5SZXNwb25zZT4sXG4pIHtcbiAgdHJ5IHtcbiAgICBpZiAoIWNvbm4ucmVmcmVzaFRva2VuKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHJlZnJlc2ggdG9rZW4gZm91bmQgaW4gdGhlIGNvbm5lY3Rpb24nKTtcbiAgICB9XG4gICAgY29uc3QgcmVzID0gYXdhaXQgY29ubi5vYXV0aDIucmVmcmVzaFRva2VuKGNvbm4ucmVmcmVzaFRva2VuKTtcbiAgICBjb25zdCB1c2VySW5mbyA9IHBhcnNlSWRVcmwocmVzLmlkKTtcbiAgICBjb25uLl9lc3RhYmxpc2goe1xuICAgICAgaW5zdGFuY2VVcmw6IHJlcy5pbnN0YW5jZV91cmwsXG4gICAgICBhY2Nlc3NUb2tlbjogcmVzLmFjY2Vzc190b2tlbixcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIGNhbGxiYWNrKHVuZGVmaW5lZCwgcmVzLmFjY2Vzc190b2tlbiwgcmVzKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICBjYWxsYmFjayhlcnIpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogU2Vzc2lvbiBSZWZyZXNoIGRlbGVnYXRlIGZ1bmN0aW9uIGZvciB1c2VybmFtZS9wYXNzd29yZCBsb2dpblxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gY3JlYXRlVXNlcm5hbWVQYXNzd29yZFJlZnJlc2hGbjxTIGV4dGVuZHMgU2NoZW1hPihcbiAgdXNlcm5hbWU6IHN0cmluZyxcbiAgcGFzc3dvcmQ6IHN0cmluZyxcbikge1xuICByZXR1cm4gYXN5bmMgKFxuICAgIGNvbm46IENvbm5lY3Rpb248Uz4sXG4gICAgY2FsbGJhY2s6IENhbGxiYWNrPHN0cmluZywgVG9rZW5SZXNwb25zZT4sXG4gICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjb25uLmxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICBpZiAoIWNvbm4uYWNjZXNzVG9rZW4pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBY2Nlc3MgdG9rZW4gbm90IGZvdW5kIGFmdGVyIGxvZ2luJyk7XG4gICAgICB9XG4gICAgICBjYWxsYmFjayhudWxsLCBjb25uLmFjY2Vzc1Rva2VuKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICBjYWxsYmFjayhlcnIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiB0b1NhdmVSZXN1bHQoZXJyOiBTYXZlRXJyb3IpOiBTYXZlUmVzdWx0IHtcbiAgcmV0dXJuIHtcbiAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICBlcnJvcnM6IFtlcnJdLFxuICB9O1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHJhaXNlTm9Nb2R1bGVFcnJvcihuYW1lOiBzdHJpbmcpOiBuZXZlciB7XG4gIHRocm93IG5ldyBFcnJvcihcbiAgICBgQVBJIG1vZHVsZSAnJHtuYW1lfScgaXMgbm90IGxvYWRlZCwgbG9hZCAnanNmb3JjZS9hcGkvJHtuYW1lfScgZXhwbGljaXRseWAsXG4gICk7XG59XG5cbi8qXG4gKiBDb25zdGFudCBvZiBtYXhpbXVtIHJlY29yZHMgbnVtIGluIERNTCBvcGVyYXRpb24gKHVwZGF0ZS9kZWxldGUpXG4gKi9cbmNvbnN0IE1BWF9ETUxfQ09VTlQgPSAyMDA7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGNsYXNzIENvbm5lY3Rpb248UyBleHRlbmRzIFNjaGVtYSA9IFNjaGVtYT4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBzdGF0aWMgX2xvZ2dlciA9IGdldExvZ2dlcignY29ubmVjdGlvbicpO1xuXG4gIHZlcnNpb246IHN0cmluZztcbiAgbG9naW5Vcmw6IHN0cmluZztcbiAgaW5zdGFuY2VVcmw6IHN0cmluZztcbiAgYWNjZXNzVG9rZW46IE9wdGlvbmFsPHN0cmluZz47XG4gIHJlZnJlc2hUb2tlbjogT3B0aW9uYWw8c3RyaW5nPjtcbiAgdXNlckluZm86IE9wdGlvbmFsPFVzZXJJbmZvPjtcbiAgbGltaXRJbmZvOiBMaW1pdEluZm8gPSB7fTtcbiAgb2F1dGgyOiBPQXV0aDI7XG4gIHNvYmplY3RzOiB7IFtOIGluIFNPYmplY3ROYW1lczxTPl0/OiBTT2JqZWN0PFMsIE4+IH0gPSB7fTtcbiAgY2FjaGU6IENhY2hlO1xuICBfY2FsbE9wdGlvbnM6IE9wdGlvbmFsPHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9PjtcbiAgX21heFJlcXVlc3Q6IG51bWJlcjtcbiAgX2xvZ2dlcjogTG9nZ2VyO1xuICBfbG9nTGV2ZWw6IE9wdGlvbmFsPExvZ0xldmVsQ29uZmlnPjtcbiAgX3RyYW5zcG9ydDogVHJhbnNwb3J0O1xuICBfc2Vzc2lvblR5cGU6IE9wdGlvbmFsPCdzb2FwJyB8ICdvYXV0aDInPjtcbiAgX3JlZnJlc2hEZWxlZ2F0ZTogT3B0aW9uYWw8U2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTxTPj47XG5cbiAgLy8gZGVzY3JpYmU6IChuYW1lOiBzdHJpbmcpID0+IFByb21pc2U8RGVzY3JpYmVTT2JqZWN0UmVzdWx0PjtcbiAgZGVzY3JpYmUkOiBDYWNoZWRGdW5jdGlvbjwobmFtZTogc3RyaW5nKSA9PiBQcm9taXNlPERlc2NyaWJlU09iamVjdFJlc3VsdD4+O1xuICBkZXNjcmliZSQkOiBDYWNoZWRGdW5jdGlvbjwobmFtZTogc3RyaW5nKSA9PiBEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICBkZXNjcmliZVNPYmplY3Q6IChuYW1lOiBzdHJpbmcpID0+IFByb21pc2U8RGVzY3JpYmVTT2JqZWN0UmVzdWx0PjtcbiAgZGVzY3JpYmVTT2JqZWN0JDogQ2FjaGVkRnVuY3Rpb248XG4gICAgKG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+XG4gID47XG4gIGRlc2NyaWJlU09iamVjdCQkOiBDYWNoZWRGdW5jdGlvbjwobmFtZTogc3RyaW5nKSA9PiBEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICAvLyBkZXNjcmliZUdsb2JhbDogKCkgPT4gUHJvbWlzZTxEZXNjcmliZUdsb2JhbFJlc3VsdD47XG4gIGRlc2NyaWJlR2xvYmFsJDogQ2FjaGVkRnVuY3Rpb248KCkgPT4gUHJvbWlzZTxEZXNjcmliZUdsb2JhbFJlc3VsdD4+O1xuICBkZXNjcmliZUdsb2JhbCQkOiBDYWNoZWRGdW5jdGlvbjwoKSA9PiBEZXNjcmliZUdsb2JhbFJlc3VsdD47XG5cbiAgLy8gQVBJIGxpYnMgYXJlIG5vdCBpbnN0YW50aWF0ZWQgaGVyZSBzbyB0aGF0IGNvcmUgbW9kdWxlIHRvIHJlbWFpbiB3aXRob3V0IGRlcGVuZGVuY2llcyB0byB0aGVtXG4gIC8vIEl0IGlzIHJlc3BvbnNpYmxlIGZvciBkZXZlbG9wZXJzIHRvIGltcG9ydCBhcGkgbGlicyBleHBsaWNpdGx5IGlmIHRoZXkgYXJlIHVzaW5nICdqc2ZvcmNlL2NvcmUnIGluc3RlYWQgb2YgJ2pzZm9yY2UnLlxuICBnZXQgYW5hbHl0aWNzKCk6IEFuYWx5dGljczxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcignYW5hbHl0aWNzJyk7XG4gIH1cblxuICBnZXQgYXBleCgpOiBBcGV4PFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdhcGV4Jyk7XG4gIH1cblxuICBnZXQgYnVsaygpOiBCdWxrPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdidWxrJyk7XG4gIH1cblxuICBnZXQgYnVsazIoKTogQnVsa1YyPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdidWxrMicpO1xuICB9XG5cbiAgZ2V0IGNoYXR0ZXIoKTogQ2hhdHRlcjxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcignY2hhdHRlcicpO1xuICB9XG5cbiAgZ2V0IG1ldGFkYXRhKCk6IE1ldGFkYXRhPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdtZXRhZGF0YScpO1xuICB9XG5cbiAgZ2V0IHNvYXAoKTogU29hcEFwaTxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcignc29hcCcpO1xuICB9XG5cbiAgZ2V0IHN0cmVhbWluZygpOiBTdHJlYW1pbmc8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ3N0cmVhbWluZycpO1xuICB9XG5cbiAgZ2V0IHRvb2xpbmcoKTogVG9vbGluZzxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcigndG9vbGluZycpO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25maWc6IENvbm5lY3Rpb25Db25maWc8Uz4gPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gICAgY29uc3Qge1xuICAgICAgbG9naW5VcmwsXG4gICAgICBpbnN0YW5jZVVybCxcbiAgICAgIHZlcnNpb24sXG4gICAgICBvYXV0aDIsXG4gICAgICBtYXhSZXF1ZXN0LFxuICAgICAgbG9nTGV2ZWwsXG4gICAgICBwcm94eVVybCxcbiAgICAgIGh0dHBQcm94eSxcbiAgICB9ID0gY29uZmlnO1xuICAgIHRoaXMubG9naW5VcmwgPSBsb2dpblVybCB8fCBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy5sb2dpblVybDtcbiAgICB0aGlzLmluc3RhbmNlVXJsID0gaW5zdGFuY2VVcmwgfHwgZGVmYXVsdENvbm5lY3Rpb25Db25maWcuaW5zdGFuY2VVcmw7XG4gICAgdGhpcy52ZXJzaW9uID0gdmVyc2lvbiB8fCBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy52ZXJzaW9uO1xuICAgIHRoaXMub2F1dGgyID1cbiAgICAgIG9hdXRoMiBpbnN0YW5jZW9mIE9BdXRoMlxuICAgICAgICA/IG9hdXRoMlxuICAgICAgICA6IG5ldyBPQXV0aDIoe1xuICAgICAgICAgICAgbG9naW5Vcmw6IHRoaXMubG9naW5VcmwsXG4gICAgICAgICAgICBwcm94eVVybCxcbiAgICAgICAgICAgIGh0dHBQcm94eSxcbiAgICAgICAgICAgIC4uLm9hdXRoMixcbiAgICAgICAgICB9KTtcbiAgICBsZXQgcmVmcmVzaEZuID0gY29uZmlnLnJlZnJlc2hGbjtcbiAgICBpZiAoIXJlZnJlc2hGbiAmJiB0aGlzLm9hdXRoMi5jbGllbnRJZCkge1xuICAgICAgcmVmcmVzaEZuID0gb2F1dGhSZWZyZXNoRm47XG4gICAgfVxuICAgIGlmIChyZWZyZXNoRm4pIHtcbiAgICAgIHRoaXMuX3JlZnJlc2hEZWxlZ2F0ZSA9IG5ldyBTZXNzaW9uUmVmcmVzaERlbGVnYXRlKHRoaXMsIHJlZnJlc2hGbik7XG4gICAgfVxuICAgIHRoaXMuX21heFJlcXVlc3QgPSBtYXhSZXF1ZXN0IHx8IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLm1heFJlcXVlc3Q7XG4gICAgdGhpcy5fbG9nZ2VyID0gbG9nTGV2ZWxcbiAgICAgID8gQ29ubmVjdGlvbi5fbG9nZ2VyLmNyZWF0ZUluc3RhbmNlKGxvZ0xldmVsKVxuICAgICAgOiBDb25uZWN0aW9uLl9sb2dnZXI7XG4gICAgdGhpcy5fbG9nTGV2ZWwgPSBsb2dMZXZlbDtcbiAgICB0aGlzLl90cmFuc3BvcnQgPSBwcm94eVVybFxuICAgICAgPyBuZXcgWGRQcm94eVRyYW5zcG9ydChwcm94eVVybClcbiAgICAgIDogaHR0cFByb3h5XG4gICAgICA/IG5ldyBIdHRwUHJveHlUcmFuc3BvcnQoaHR0cFByb3h5KVxuICAgICAgOiBuZXcgVHJhbnNwb3J0KCk7XG4gICAgdGhpcy5fY2FsbE9wdGlvbnMgPSBjb25maWcuY2FsbE9wdGlvbnM7XG4gICAgdGhpcy5jYWNoZSA9IG5ldyBDYWNoZSgpO1xuICAgIGNvbnN0IGRlc2NyaWJlQ2FjaGVLZXkgPSAodHlwZT86IHN0cmluZykgPT5cbiAgICAgIHR5cGUgPyBgZGVzY3JpYmUuJHt0eXBlfWAgOiAnZGVzY3JpYmUnO1xuICAgIGNvbnN0IGRlc2NyaWJlID0gQ29ubmVjdGlvbi5wcm90b3R5cGUuZGVzY3JpYmU7XG4gICAgdGhpcy5kZXNjcmliZSA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oZGVzY3JpYmUsIHRoaXMsIHtcbiAgICAgIGtleTogZGVzY3JpYmVDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnTk9DQUNIRScsXG4gICAgfSk7XG4gICAgdGhpcy5kZXNjcmliZSQgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlLCB0aGlzLCB7XG4gICAgICBrZXk6IGRlc2NyaWJlQ2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ0hJVCcsXG4gICAgfSk7XG4gICAgdGhpcy5kZXNjcmliZSQkID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihkZXNjcmliZSwgdGhpcywge1xuICAgICAga2V5OiBkZXNjcmliZUNhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdJTU1FRElBVEUnLFxuICAgIH0pIGFzIGFueTtcbiAgICB0aGlzLmRlc2NyaWJlU09iamVjdCA9IHRoaXMuZGVzY3JpYmU7XG4gICAgdGhpcy5kZXNjcmliZVNPYmplY3QkID0gdGhpcy5kZXNjcmliZSQ7XG4gICAgdGhpcy5kZXNjcmliZVNPYmplY3QkJCA9IHRoaXMuZGVzY3JpYmUkJDtcbiAgICBjb25zdCBkZXNjcmliZUdsb2JhbCA9IENvbm5lY3Rpb24ucHJvdG90eXBlLmRlc2NyaWJlR2xvYmFsO1xuICAgIHRoaXMuZGVzY3JpYmVHbG9iYWwgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKFxuICAgICAgZGVzY3JpYmVHbG9iYWwsXG4gICAgICB0aGlzLFxuICAgICAgeyBrZXk6ICdkZXNjcmliZUdsb2JhbCcsIHN0cmF0ZWd5OiAnTk9DQUNIRScgfSxcbiAgICApO1xuICAgIHRoaXMuZGVzY3JpYmVHbG9iYWwkID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihcbiAgICAgIGRlc2NyaWJlR2xvYmFsLFxuICAgICAgdGhpcyxcbiAgICAgIHsga2V5OiAnZGVzY3JpYmVHbG9iYWwnLCBzdHJhdGVneTogJ0hJVCcgfSxcbiAgICApO1xuICAgIHRoaXMuZGVzY3JpYmVHbG9iYWwkJCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oXG4gICAgICBkZXNjcmliZUdsb2JhbCxcbiAgICAgIHRoaXMsXG4gICAgICB7IGtleTogJ2Rlc2NyaWJlR2xvYmFsJywgc3RyYXRlZ3k6ICdJTU1FRElBVEUnIH0sXG4gICAgKSBhcyBhbnk7XG4gICAgY29uc3Qge1xuICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICByZWZyZXNoVG9rZW4sXG4gICAgICBzZXNzaW9uSWQsXG4gICAgICBzZXJ2ZXJVcmwsXG4gICAgICBzaWduZWRSZXF1ZXN0LFxuICAgIH0gPSBjb25maWc7XG4gICAgdGhpcy5fZXN0YWJsaXNoKHtcbiAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgcmVmcmVzaFRva2VuLFxuICAgICAgaW5zdGFuY2VVcmwsXG4gICAgICBzZXNzaW9uSWQsXG4gICAgICBzZXJ2ZXJVcmwsXG4gICAgICBzaWduZWRSZXF1ZXN0LFxuICAgIH0pO1xuXG4gICAganNmb3JjZS5lbWl0KCdjb25uZWN0aW9uOm5ldycsIHRoaXMpO1xuICB9XG5cbiAgLyogQHByaXZhdGUgKi9cbiAgX2VzdGFibGlzaChvcHRpb25zOiBDb25uZWN0aW9uRXN0YWJsaXNoT3B0aW9ucykge1xuICAgIGNvbnN0IHtcbiAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgcmVmcmVzaFRva2VuLFxuICAgICAgaW5zdGFuY2VVcmwsXG4gICAgICBzZXNzaW9uSWQsXG4gICAgICBzZXJ2ZXJVcmwsXG4gICAgICBzaWduZWRSZXF1ZXN0LFxuICAgICAgdXNlckluZm8sXG4gICAgfSA9IG9wdGlvbnM7XG4gICAgdGhpcy5pbnN0YW5jZVVybCA9IHNlcnZlclVybFxuICAgICAgPyBzZXJ2ZXJVcmwuc3BsaXQoJy8nKS5zbGljZSgwLCAzKS5qb2luKCcvJylcbiAgICAgIDogaW5zdGFuY2VVcmwgfHwgdGhpcy5pbnN0YW5jZVVybDtcbiAgICB0aGlzLmFjY2Vzc1Rva2VuID0gc2Vzc2lvbklkIHx8IGFjY2Vzc1Rva2VuIHx8IHRoaXMuYWNjZXNzVG9rZW47XG4gICAgdGhpcy5yZWZyZXNoVG9rZW4gPSByZWZyZXNoVG9rZW4gfHwgdGhpcy5yZWZyZXNoVG9rZW47XG4gICAgaWYgKHRoaXMucmVmcmVzaFRva2VuICYmICF0aGlzLl9yZWZyZXNoRGVsZWdhdGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ1JlZnJlc2ggdG9rZW4gaXMgc3BlY2lmaWVkIHdpdGhvdXQgb2F1dGgyIGNsaWVudCBpbmZvcm1hdGlvbiBvciByZWZyZXNoIGZ1bmN0aW9uJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IHNpZ25lZFJlcXVlc3RPYmplY3QgPVxuICAgICAgc2lnbmVkUmVxdWVzdCAmJiBwYXJzZVNpZ25lZFJlcXVlc3Qoc2lnbmVkUmVxdWVzdCk7XG4gICAgaWYgKHNpZ25lZFJlcXVlc3RPYmplY3QpIHtcbiAgICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBzaWduZWRSZXF1ZXN0T2JqZWN0LmNsaWVudC5vYXV0aFRva2VuO1xuICAgICAgaWYgKENhbnZhc1RyYW5zcG9ydC5zdXBwb3J0ZWQpIHtcbiAgICAgICAgdGhpcy5fdHJhbnNwb3J0ID0gbmV3IENhbnZhc1RyYW5zcG9ydChzaWduZWRSZXF1ZXN0T2JqZWN0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy51c2VySW5mbyA9IHVzZXJJbmZvIHx8IHRoaXMudXNlckluZm87XG4gICAgdGhpcy5fc2Vzc2lvblR5cGUgPSBzZXNzaW9uSWQgPyAnc29hcCcgOiAnb2F1dGgyJztcbiAgICB0aGlzLl9yZXNldEluc3RhbmNlKCk7XG4gIH1cblxuICAvKiBAcHJpdmVhdGUgKi9cbiAgX2NsZWFyU2Vzc2lvbigpIHtcbiAgICB0aGlzLmFjY2Vzc1Rva2VuID0gbnVsbDtcbiAgICB0aGlzLnJlZnJlc2hUb2tlbiA9IG51bGw7XG4gICAgdGhpcy5pbnN0YW5jZVVybCA9IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLmluc3RhbmNlVXJsO1xuICAgIHRoaXMudXNlckluZm8gPSBudWxsO1xuICAgIHRoaXMuX3Nlc3Npb25UeXBlID0gbnVsbDtcbiAgfVxuXG4gIC8qIEBwcml2ZWF0ZSAqL1xuICBfcmVzZXRJbnN0YW5jZSgpIHtcbiAgICB0aGlzLmxpbWl0SW5mbyA9IHt9O1xuICAgIHRoaXMuc29iamVjdHMgPSB7fTtcbiAgICAvLyBUT0RPIGltcGwgY2FjaGVcbiAgICB0aGlzLmNhY2hlLmNsZWFyKCk7XG4gICAgdGhpcy5jYWNoZS5nZXQoJ2Rlc2NyaWJlR2xvYmFsJykucmVtb3ZlQWxsTGlzdGVuZXJzKCd2YWx1ZScpO1xuICAgIHRoaXMuY2FjaGUuZ2V0KCdkZXNjcmliZUdsb2JhbCcpLm9uKCd2YWx1ZScsICh7IHJlc3VsdCB9KSA9PiB7XG4gICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIGZvciAoY29uc3Qgc28gb2YgcmVzdWx0LnNvYmplY3RzKSB7XG4gICAgICAgICAgdGhpcy5zb2JqZWN0KHNvLm5hbWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgLypcbiAgICBpZiAodGhpcy50b29saW5nKSB7XG4gICAgICB0aGlzLnRvb2xpbmcuX3Jlc2V0SW5zdGFuY2UoKTtcbiAgICB9XG4gICAgKi9cbiAgfVxuXG4gIC8qKlxuICAgKiBBdXRob3JpemUgKHVzaW5nIG9hdXRoMiB3ZWIgc2VydmVyIGZsb3cpXG4gICAqL1xuICBhc3luYyBhdXRob3JpemUoXG4gICAgY29kZTogc3RyaW5nLFxuICAgIHBhcmFtczogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSxcbiAgKTogUHJvbWlzZTxVc2VySW5mbz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMub2F1dGgyLnJlcXVlc3RUb2tlbihjb2RlLCBwYXJhbXMpO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gcGFyc2VJZFVybChyZXMuaWQpO1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBpbnN0YW5jZVVybDogcmVzLmluc3RhbmNlX3VybCxcbiAgICAgIGFjY2Vzc1Rva2VuOiByZXMuYWNjZXNzX3Rva2VuLFxuICAgICAgcmVmcmVzaFRva2VuOiByZXMucmVmcmVzaF90b2tlbixcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGA8bG9naW4+IGNvbXBsZXRlZC4gdXNlciBpZCA9ICR7dXNlckluZm8uaWR9LCBvcmcgaWQgPSAke3VzZXJJbmZvLm9yZ2FuaXphdGlvbklkfWAsXG4gICAgKTtcbiAgICByZXR1cm4gdXNlckluZm87XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxvZ2luKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPFVzZXJJbmZvPiB7XG4gICAgdGhpcy5fcmVmcmVzaERlbGVnYXRlID0gbmV3IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUoXG4gICAgICB0aGlzLFxuICAgICAgY3JlYXRlVXNlcm5hbWVQYXNzd29yZFJlZnJlc2hGbih1c2VybmFtZSwgcGFzc3dvcmQpLFxuICAgICk7XG4gICAgaWYgKHRoaXMub2F1dGgyICYmIHRoaXMub2F1dGgyLmNsaWVudElkICYmIHRoaXMub2F1dGgyLmNsaWVudFNlY3JldCkge1xuICAgICAgcmV0dXJuIHRoaXMubG9naW5CeU9BdXRoMih1c2VybmFtZSwgcGFzc3dvcmQpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5sb2dpbkJ5U29hcCh1c2VybmFtZSwgcGFzc3dvcmQpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ2luIGJ5IE9BdXRoMiB1c2VybmFtZSAmIHBhc3N3b3JkIGZsb3dcbiAgICovXG4gIGFzeW5jIGxvZ2luQnlPQXV0aDIodXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8VXNlckluZm8+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm9hdXRoMi5hdXRoZW50aWNhdGUodXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICBjb25zdCB1c2VySW5mbyA9IHBhcnNlSWRVcmwocmVzLmlkKTtcbiAgICB0aGlzLl9lc3RhYmxpc2goe1xuICAgICAgaW5zdGFuY2VVcmw6IHJlcy5pbnN0YW5jZV91cmwsXG4gICAgICBhY2Nlc3NUb2tlbjogcmVzLmFjY2Vzc190b2tlbixcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5pbmZvKFxuICAgICAgYDxsb2dpbj4gY29tcGxldGVkLiB1c2VyIGlkID0gJHt1c2VySW5mby5pZH0sIG9yZyBpZCA9ICR7dXNlckluZm8ub3JnYW5pemF0aW9uSWR9YCxcbiAgICApO1xuICAgIHJldHVybiB1c2VySW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgbG9naW5CeVNvYXAodXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8VXNlckluZm8+IHtcbiAgICBpZiAoIXVzZXJuYW1lIHx8ICFwYXNzd29yZCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignbm8gdXNlcm5hbWUgcGFzc3dvcmQgZ2l2ZW4nKSk7XG4gICAgfVxuICAgIGNvbnN0IGJvZHkgPSBbXG4gICAgICAnPHNlOkVudmVsb3BlIHhtbG5zOnNlPVwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvc29hcC9lbnZlbG9wZS9cIj4nLFxuICAgICAgJzxzZTpIZWFkZXIvPicsXG4gICAgICAnPHNlOkJvZHk+JyxcbiAgICAgICc8bG9naW4geG1sbnM9XCJ1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb21cIj4nLFxuICAgICAgYDx1c2VybmFtZT4ke2VzYyh1c2VybmFtZSl9PC91c2VybmFtZT5gLFxuICAgICAgYDxwYXNzd29yZD4ke2VzYyhwYXNzd29yZCl9PC9wYXNzd29yZD5gLFxuICAgICAgJzwvbG9naW4+JyxcbiAgICAgICc8L3NlOkJvZHk+JyxcbiAgICAgICc8L3NlOkVudmVsb3BlPicsXG4gICAgXS5qb2luKCcnKTtcblxuICAgIGNvbnN0IHNvYXBMb2dpbkVuZHBvaW50ID0gW1xuICAgICAgdGhpcy5sb2dpblVybCxcbiAgICAgICdzZXJ2aWNlcy9Tb2FwL3UnLFxuICAgICAgdGhpcy52ZXJzaW9uLFxuICAgIF0uam9pbignLycpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fdHJhbnNwb3J0Lmh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiBzb2FwTG9naW5FbmRwb2ludCxcbiAgICAgIGJvZHksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC94bWwnLFxuICAgICAgICBTT0FQQWN0aW9uOiAnXCJcIicsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGxldCBtO1xuICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID49IDQwMCkge1xuICAgICAgbSA9IHJlc3BvbnNlLmJvZHkubWF0Y2goLzxmYXVsdHN0cmluZz4oW148XSspPFxcL2ZhdWx0c3RyaW5nPi8pO1xuICAgICAgY29uc3QgZmF1bHRzdHJpbmcgPSBtICYmIG1bMV07XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoZmF1bHRzdHJpbmcgfHwgcmVzcG9uc2UuYm9keSk7XG4gICAgfVxuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhgU09BUCByZXNwb25zZSA9ICR7cmVzcG9uc2UuYm9keX1gKTtcbiAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPHNlcnZlclVybD4oW148XSspPFxcL3NlcnZlclVybD4vKTtcbiAgICBjb25zdCBzZXJ2ZXJVcmwgPSBtICYmIG1bMV07XG4gICAgbSA9IHJlc3BvbnNlLmJvZHkubWF0Y2goLzxzZXNzaW9uSWQ+KFtePF0rKTxcXC9zZXNzaW9uSWQ+Lyk7XG4gICAgY29uc3Qgc2Vzc2lvbklkID0gbSAmJiBtWzFdO1xuICAgIG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88dXNlcklkPihbXjxdKyk8XFwvdXNlcklkPi8pO1xuICAgIGNvbnN0IHVzZXJJZCA9IG0gJiYgbVsxXTtcbiAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPG9yZ2FuaXphdGlvbklkPihbXjxdKyk8XFwvb3JnYW5pemF0aW9uSWQ+Lyk7XG4gICAgY29uc3Qgb3JnYW5pemF0aW9uSWQgPSBtICYmIG1bMV07XG4gICAgaWYgKCFzZXJ2ZXJVcmwgfHwgIXNlc3Npb25JZCB8fCAhdXNlcklkIHx8ICFvcmdhbml6YXRpb25JZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnY291bGQgbm90IGV4dHJhY3Qgc2Vzc2lvbiBpbmZvcm1hdGlvbiBmcm9tIGxvZ2luIHJlc3BvbnNlJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGlkVXJsID0gW3RoaXMubG9naW5VcmwsICdpZCcsIG9yZ2FuaXphdGlvbklkLCB1c2VySWRdLmpvaW4oJy8nKTtcbiAgICBjb25zdCB1c2VySW5mbyA9IHsgaWQ6IHVzZXJJZCwgb3JnYW5pemF0aW9uSWQsIHVybDogaWRVcmwgfTtcbiAgICB0aGlzLl9lc3RhYmxpc2goe1xuICAgICAgc2VydmVyVXJsOiBzZXJ2ZXJVcmwuc3BsaXQoJy8nKS5zbGljZSgwLCAzKS5qb2luKCcvJyksXG4gICAgICBzZXNzaW9uSWQsXG4gICAgICB1c2VySW5mbyxcbiAgICB9KTtcbiAgICB0aGlzLl9sb2dnZXIuaW5mbyhcbiAgICAgIGA8bG9naW4+IGNvbXBsZXRlZC4gdXNlciBpZCA9ICR7dXNlcklkfSwgb3JnIGlkID0gJHtvcmdhbml6YXRpb25JZH1gLFxuICAgICk7XG4gICAgcmV0dXJuIHVzZXJJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ291dCB0aGUgY3VycmVudCBzZXNzaW9uXG4gICAqL1xuICBhc3luYyBsb2dvdXQocmV2b2tlPzogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuX3JlZnJlc2hEZWxlZ2F0ZSA9IHVuZGVmaW5lZDtcbiAgICBpZiAodGhpcy5fc2Vzc2lvblR5cGUgPT09ICdvYXV0aDInKSB7XG4gICAgICByZXR1cm4gdGhpcy5sb2dvdXRCeU9BdXRoMihyZXZva2UpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5sb2dvdXRCeVNvYXAocmV2b2tlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2dvdXQgdGhlIGN1cnJlbnQgc2Vzc2lvbiBieSByZXZva2luZyBhY2Nlc3MgdG9rZW4gdmlhIE9BdXRoMiBzZXNzaW9uIHJldm9rZVxuICAgKi9cbiAgYXN5bmMgbG9nb3V0QnlPQXV0aDIocmV2b2tlPzogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHRva2VuID0gcmV2b2tlID8gdGhpcy5yZWZyZXNoVG9rZW4gOiB0aGlzLmFjY2Vzc1Rva2VuO1xuICAgIGlmICh0b2tlbikge1xuICAgICAgYXdhaXQgdGhpcy5vYXV0aDIucmV2b2tlVG9rZW4odG9rZW4pO1xuICAgIH1cbiAgICAvLyBEZXN0cm95IHRoZSBzZXNzaW9uIGJvdW5kIHRvIHRoaXMgY29ubmVjdGlvblxuICAgIHRoaXMuX2NsZWFyU2Vzc2lvbigpO1xuICAgIHRoaXMuX3Jlc2V0SW5zdGFuY2UoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2dvdXQgdGhlIHNlc3Npb24gYnkgdXNpbmcgU09BUCB3ZWIgc2VydmljZSBBUElcbiAgICovXG4gIGFzeW5jIGxvZ291dEJ5U29hcChyZXZva2U/OiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgYm9keSA9IFtcbiAgICAgICc8c2U6RW52ZWxvcGUgeG1sbnM6c2U9XCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlL1wiPicsXG4gICAgICAnPHNlOkhlYWRlcj4nLFxuICAgICAgJzxTZXNzaW9uSGVhZGVyIHhtbG5zPVwidXJuOnBhcnRuZXIuc29hcC5zZm9yY2UuY29tXCI+JyxcbiAgICAgIGA8c2Vzc2lvbklkPiR7ZXNjKFxuICAgICAgICByZXZva2UgPyB0aGlzLnJlZnJlc2hUb2tlbiA6IHRoaXMuYWNjZXNzVG9rZW4sXG4gICAgICApfTwvc2Vzc2lvbklkPmAsXG4gICAgICAnPC9TZXNzaW9uSGVhZGVyPicsXG4gICAgICAnPC9zZTpIZWFkZXI+JyxcbiAgICAgICc8c2U6Qm9keT4nLFxuICAgICAgJzxsb2dvdXQgeG1sbnM9XCJ1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb21cIi8+JyxcbiAgICAgICc8L3NlOkJvZHk+JyxcbiAgICAgICc8L3NlOkVudmVsb3BlPicsXG4gICAgXS5qb2luKCcnKTtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuX3RyYW5zcG9ydC5odHRwUmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybDogW3RoaXMuaW5zdGFuY2VVcmwsICdzZXJ2aWNlcy9Tb2FwL3UnLCB0aGlzLnZlcnNpb25dLmpvaW4oJy8nKSxcbiAgICAgIGJvZHksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC94bWwnLFxuICAgICAgICBTT0FQQWN0aW9uOiAnXCJcIicsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGBTT0FQIHN0YXR1c0NvZGUgPSAke3Jlc3BvbnNlLnN0YXR1c0NvZGV9LCByZXNwb25zZSA9ICR7cmVzcG9uc2UuYm9keX1gLFxuICAgICk7XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPj0gNDAwKSB7XG4gICAgICBjb25zdCBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPGZhdWx0c3RyaW5nPihbXjxdKyk8XFwvZmF1bHRzdHJpbmc+Lyk7XG4gICAgICBjb25zdCBmYXVsdHN0cmluZyA9IG0gJiYgbVsxXTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihmYXVsdHN0cmluZyB8fCByZXNwb25zZS5ib2R5KTtcbiAgICB9XG4gICAgLy8gRGVzdHJveSB0aGUgc2Vzc2lvbiBib3VuZCB0byB0aGlzIGNvbm5lY3Rpb25cbiAgICB0aGlzLl9jbGVhclNlc3Npb24oKTtcbiAgICB0aGlzLl9yZXNldEluc3RhbmNlKCk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBSRVNUIEFQSSByZXF1ZXN0IHdpdGggZ2l2ZW4gSFRUUCByZXF1ZXN0IGluZm8sIHdpdGggY29ubmVjdGVkIHNlc3Npb24gaW5mb3JtYXRpb24uXG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4oXG4gICAgcmVxdWVzdDogc3RyaW5nIHwgSHR0cFJlcXVlc3QsXG4gICAgb3B0aW9uczogT2JqZWN0ID0ge30sXG4gICk6IFN0cmVhbVByb21pc2U8Uj4ge1xuICAgIC8vIGlmIHJlcXVlc3QgaXMgc2ltcGxlIHN0cmluZywgcmVnYXJkIGl0IGFzIHVybCBpbiBHRVQgbWV0aG9kXG4gICAgbGV0IHJlcXVlc3RfOiBIdHRwUmVxdWVzdCA9XG4gICAgICB0eXBlb2YgcmVxdWVzdCA9PT0gJ3N0cmluZycgPyB7IG1ldGhvZDogJ0dFVCcsIHVybDogcmVxdWVzdCB9IDogcmVxdWVzdDtcbiAgICAvLyBpZiB1cmwgaXMgZ2l2ZW4gaW4gcmVsYXRpdmUgcGF0aCwgcHJlcGVuZCBiYXNlIHVybCBvciBpbnN0YW5jZSB1cmwgYmVmb3JlLlxuICAgIHJlcXVlc3RfID0ge1xuICAgICAgLi4ucmVxdWVzdF8sXG4gICAgICB1cmw6IHRoaXMuX25vcm1hbGl6ZVVybChyZXF1ZXN0Xy51cmwpLFxuICAgIH07XG4gICAgY29uc3QgaHR0cEFwaSA9IG5ldyBIdHRwQXBpKHRoaXMsIG9wdGlvbnMpO1xuICAgIC8vIGxvZyBhcGkgdXNhZ2UgYW5kIGl0cyBxdW90YVxuICAgIGh0dHBBcGkub24oJ3Jlc3BvbnNlJywgKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpID0+IHtcbiAgICAgIGlmIChyZXNwb25zZS5oZWFkZXJzICYmIHJlc3BvbnNlLmhlYWRlcnNbJ3Nmb3JjZS1saW1pdC1pbmZvJ10pIHtcbiAgICAgICAgY29uc3QgYXBpVXNhZ2UgPSByZXNwb25zZS5oZWFkZXJzWydzZm9yY2UtbGltaXQtaW5mbyddLm1hdGNoKFxuICAgICAgICAgIC9hcGktdXNhZ2U9KFxcZCspXFwvKFxcZCspLyxcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKGFwaVVzYWdlKSB7XG4gICAgICAgICAgdGhpcy5saW1pdEluZm8gPSB7XG4gICAgICAgICAgICBhcGlVc2FnZToge1xuICAgICAgICAgICAgICB1c2VkOiBwYXJzZUludChhcGlVc2FnZVsxXSwgMTApLFxuICAgICAgICAgICAgICBsaW1pdDogcGFyc2VJbnQoYXBpVXNhZ2VbMl0sIDEwKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBodHRwQXBpLnJlcXVlc3Q8Uj4ocmVxdWVzdF8pO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgSFRUUCBHRVQgcmVxdWVzdFxuICAgKlxuICAgKiBFbmRwb2ludCBVUkwgY2FuIGJlIGFic29sdXRlIFVSTCAoJ2h0dHBzOi8vbmExLnNhbGVzZm9yY2UuY29tL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgcmVsYXRpdmUgcGF0aCBmcm9tIHJvb3QgKCcvc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCBvciByZWxhdGl2ZSBwYXRoIGZyb20gdmVyc2lvbiByb290ICgnL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKS5cbiAgICovXG4gIHJlcXVlc3RHZXQ8UiA9IHVua25vd24+KHVybDogc3RyaW5nLCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7IG1ldGhvZDogJ0dFVCcsIHVybCB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIFBPU1QgcmVxdWVzdCB3aXRoIEpTT04gYm9keSwgd2l0aCBjb25uZWN0ZWQgc2Vzc2lvbiBpbmZvcm1hdGlvblxuICAgKlxuICAgKiBFbmRwb2ludCBVUkwgY2FuIGJlIGFic29sdXRlIFVSTCAoJ2h0dHBzOi8vbmExLnNhbGVzZm9yY2UuY29tL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgcmVsYXRpdmUgcGF0aCBmcm9tIHJvb3QgKCcvc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCBvciByZWxhdGl2ZSBwYXRoIGZyb20gdmVyc2lvbiByb290ICgnL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKS5cbiAgICovXG4gIHJlcXVlc3RQb3N0PFIgPSB1bmtub3duPih1cmw6IHN0cmluZywgYm9keTogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpLFxuICAgICAgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFI+KHJlcXVlc3QsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgSFRUUCBQVVQgcmVxdWVzdCB3aXRoIEpTT04gYm9keSwgd2l0aCBjb25uZWN0ZWQgc2Vzc2lvbiBpbmZvcm1hdGlvblxuICAgKlxuICAgKiBFbmRwb2ludCBVUkwgY2FuIGJlIGFic29sdXRlIFVSTCAoJ2h0dHBzOi8vbmExLnNhbGVzZm9yY2UuY29tL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgcmVsYXRpdmUgcGF0aCBmcm9tIHJvb3QgKCcvc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCBvciByZWxhdGl2ZSBwYXRoIGZyb20gdmVyc2lvbiByb290ICgnL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKS5cbiAgICovXG4gIHJlcXVlc3RQdXQ8Uj4odXJsOiBzdHJpbmcsIGJvZHk6IE9iamVjdCwgb3B0aW9ucz86IE9iamVjdCkge1xuICAgIGNvbnN0IHJlcXVlc3Q6IEh0dHBSZXF1ZXN0ID0ge1xuICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpLFxuICAgICAgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFI+KHJlcXVlc3QsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgSFRUUCBQQVRDSCByZXF1ZXN0IHdpdGggSlNPTiBib2R5XG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdFBhdGNoPFIgPSB1bmtub3duPih1cmw6IHN0cmluZywgYm9keTogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7XG4gICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSxcbiAgICAgIGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSPihyZXF1ZXN0LCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kIEhUVFAgREVMRVRFIHJlcXVlc3RcbiAgICpcbiAgICogRW5kcG9pbnQgVVJMIGNhbiBiZSBhYnNvbHV0ZSBVUkwgKCdodHRwczovL25hMS5zYWxlc2ZvcmNlLmNvbS9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIHJlbGF0aXZlIHBhdGggZnJvbSByb290ICgnL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgb3IgcmVsYXRpdmUgcGF0aCBmcm9tIHZlcnNpb24gcm9vdCAoJy9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJykuXG4gICAqL1xuICByZXF1ZXN0RGVsZXRlPFI+KHVybDogc3RyaW5nLCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7IG1ldGhvZDogJ0RFTEVURScsIHVybCB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKiovXG4gIF9iYXNlVXJsKCkge1xuICAgIHJldHVybiBbdGhpcy5pbnN0YW5jZVVybCwgJ3NlcnZpY2VzL2RhdGEnLCBgdiR7dGhpcy52ZXJzaW9ufWBdLmpvaW4oJy8nKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb252ZXJ0IHBhdGggdG8gYWJzb2x1dGUgdXJsXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfbm9ybWFsaXplVXJsKHVybDogc3RyaW5nKSB7XG4gICAgaWYgKHVybFswXSA9PT0gJy8nKSB7XG4gICAgICBpZiAodXJsLmluZGV4T2YodGhpcy5pbnN0YW5jZVVybCArICcvc2VydmljZXMvJykgPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHVybDtcbiAgICAgIH1cbiAgICAgIGlmICh1cmwuaW5kZXhPZignL3NlcnZpY2VzLycpID09PSAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmluc3RhbmNlVXJsICsgdXJsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuX2Jhc2VVcmwoKSArIHVybDtcbiAgICB9XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgcXVlcnk8VCBleHRlbmRzIFJlY29yZD4oXG4gICAgc29xbDogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBQYXJ0aWFsPFF1ZXJ5T3B0aW9ucz4sXG4gICk6IFF1ZXJ5PFMsIFNPYmplY3ROYW1lczxTPiwgVCwgJ1F1ZXJ5UmVzdWx0Jz4ge1xuICAgIHJldHVybiBuZXcgUXVlcnk8UywgU09iamVjdE5hbWVzPFM+LCBULCAnUXVlcnlSZXN1bHQnPih0aGlzLCBzb3FsLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIHNlYXJjaCBieSBTT1NMXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzb3NsIC0gU09TTCBzdHJpbmdcbiAgICogQHBhcmFtIHtDYWxsYmFjay48QXJyYXkuPFJlY29yZFJlc3VsdD4+fSBbY2FsbGJhY2tdIC0gQ2FsbGJhY2sgZnVuY3Rpb25cbiAgICogQHJldHVybnMge1Byb21pc2UuPEFycmF5LjxSZWNvcmRSZXN1bHQ+Pn1cbiAgICovXG4gIHNlYXJjaChzb3NsOiBzdHJpbmcpIHtcbiAgICB2YXIgdXJsID0gdGhpcy5fYmFzZVVybCgpICsgJy9zZWFyY2g/cT0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHNvc2wpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8U2VhcmNoUmVzdWx0Pih1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBxdWVyeU1vcmUobG9jYXRvcjogc3RyaW5nLCBvcHRpb25zPzogUXVlcnlPcHRpb25zKSB7XG4gICAgcmV0dXJuIG5ldyBRdWVyeTxTLCBTT2JqZWN0TmFtZXM8Uz4sIFJlY29yZCwgJ1F1ZXJ5UmVzdWx0Jz4oXG4gICAgICB0aGlzLFxuICAgICAgeyBsb2NhdG9yIH0sXG4gICAgICBvcHRpb25zLFxuICAgICk7XG4gIH1cblxuICAvKiAqL1xuICBfZW5zdXJlVmVyc2lvbihtYWpvclZlcnNpb246IG51bWJlcikge1xuICAgIGNvbnN0IHZlcnNpb25zID0gdGhpcy52ZXJzaW9uLnNwbGl0KCcuJyk7XG4gICAgcmV0dXJuIHBhcnNlSW50KHZlcnNpb25zWzBdLCAxMCkgPj0gbWFqb3JWZXJzaW9uO1xuICB9XG5cbiAgLyogKi9cbiAgX3N1cHBvcnRzKGZlYXR1cmU6IHN0cmluZykge1xuICAgIHN3aXRjaCAoZmVhdHVyZSkge1xuICAgICAgY2FzZSAnc29iamVjdC1jb2xsZWN0aW9uJzogLy8gc29iamVjdCBjb2xsZWN0aW9uIGlzIGF2YWlsYWJsZSBvbmx5IGluIEFQSSB2ZXIgNDIuMCtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDIpO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBzcGVjaWZpZWQgcmVjb3Jkc1xuICAgKi9cbiAgcmV0cmlldmU8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZyxcbiAgICBvcHRpb25zPzogUmV0cmlldmVPcHRpb25zLFxuICApOiBQcm9taXNlPFJlY29yZD47XG4gIHJldHJpZXZlPE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KFxuICAgIHR5cGU6IE4sXG4gICAgaWRzOiBzdHJpbmdbXSxcbiAgICBvcHRpb25zPzogUmV0cmlldmVPcHRpb25zLFxuICApOiBQcm9taXNlPFJlY29yZFtdPjtcbiAgcmV0cmlldmU8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM/OiBSZXRyaWV2ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8UmVjb3JkIHwgUmVjb3JkW10+O1xuICBhc3luYyByZXRyaWV2ZShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICBvcHRpb25zOiBSZXRyaWV2ZU9wdGlvbnMgPSB7fSxcbiAgKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoaWRzKVxuICAgICAgPyAvLyBjaGVjayB0aGUgdmVyc2lvbiB3aGV0aGVyIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgaXMgc3VwcG9ydGVkICg0Mi4wKVxuICAgICAgICB0aGlzLl9lbnN1cmVWZXJzaW9uKDQyKVxuICAgICAgICA/IHRoaXMuX3JldHJpZXZlTWFueSh0eXBlLCBpZHMsIG9wdGlvbnMpXG4gICAgICAgIDogdGhpcy5fcmV0cmlldmVQYXJhbGxlbCh0eXBlLCBpZHMsIG9wdGlvbnMpXG4gICAgICA6IHRoaXMuX3JldHJpZXZlU2luZ2xlKHR5cGUsIGlkcywgb3B0aW9ucyk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3JldHJpZXZlU2luZ2xlKHR5cGU6IHN0cmluZywgaWQ6IHN0cmluZywgb3B0aW9uczogUmV0cmlldmVPcHRpb25zKSB7XG4gICAgaWYgKCFpZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHJlY29yZCBJRC4gU3BlY2lmeSB2YWxpZCByZWNvcmQgSUQgdmFsdWUnKTtcbiAgICB9XG4gICAgbGV0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsIGlkXS5qb2luKCcvJyk7XG4gICAgY29uc3QgeyBmaWVsZHMsIGhlYWRlcnMgfSA9IG9wdGlvbnM7XG4gICAgaWYgKGZpZWxkcykge1xuICAgICAgdXJsICs9IGA/ZmllbGRzPSR7ZmllbGRzLmpvaW4oJywnKX1gO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KHsgbWV0aG9kOiAnR0VUJywgdXJsLCBoZWFkZXJzIH0pO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9yZXRyaWV2ZVBhcmFsbGVsKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZHM6IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM6IFJldHJpZXZlT3B0aW9ucyxcbiAgKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiB0aGlzLl9tYXhSZXF1ZXN0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4Y2VlZGVkIG1heCBsaW1pdCBvZiBjb25jdXJyZW50IGNhbGwnKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgaWRzLm1hcCgoaWQpID0+XG4gICAgICAgIHRoaXMuX3JldHJpZXZlU2luZ2xlKHR5cGUsIGlkLCBvcHRpb25zKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgaWYgKG9wdGlvbnMuYWxsT3JOb25lIHx8IGVyci5lcnJvckNvZGUgIT09ICdOT1RfRk9VTkQnKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfcmV0cmlldmVNYW55KHR5cGU6IHN0cmluZywgaWRzOiBzdHJpbmdbXSwgb3B0aW9uczogUmV0cmlldmVPcHRpb25zKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ2NvbXBvc2l0ZScsICdzb2JqZWN0cycsIHR5cGVdLmpvaW4oJy8nKTtcbiAgICBjb25zdCBmaWVsZHMgPVxuICAgICAgb3B0aW9ucy5maWVsZHMgfHxcbiAgICAgIChhd2FpdCB0aGlzLmRlc2NyaWJlJCh0eXBlKSkuZmllbGRzLm1hcCgoZmllbGQpID0+IGZpZWxkLm5hbWUpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGlkcywgZmllbGRzIH0pLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIHJlY29yZHNcbiAgICovXG4gIGNyZWF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBJbnB1dFJlY29yZFtdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIGNyZWF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+XG4gID4odHlwZTogTiwgcmVjb3JkOiBJbnB1dFJlY29yZCwgb3B0aW9ucz86IERtbE9wdGlvbnMpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICBjcmVhdGU8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkczogSW5wdXRSZWNvcmQgfCBJbnB1dFJlY29yZFtdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICAvKipcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHBhcmFtIHJlY29yZHNcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICovXG4gIGFzeW5jIGNyZWF0ZShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcmVjb3JkczogUmVjb3JkIHwgUmVjb3JkW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyA9IHt9LFxuICApIHtcbiAgICBjb25zdCByZXQgPSBBcnJheS5pc0FycmF5KHJlY29yZHMpXG4gICAgICA/IC8vIGNoZWNrIHRoZSB2ZXJzaW9uIHdoZXRoZXIgU09iamVjdCBjb2xsZWN0aW9uIEFQSSBpcyBzdXBwb3J0ZWQgKDQyLjApXG4gICAgICAgIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gYXdhaXQgdGhpcy5fY3JlYXRlTWFueSh0eXBlLCByZWNvcmRzLCBvcHRpb25zKVxuICAgICAgICA6IGF3YWl0IHRoaXMuX2NyZWF0ZVBhcmFsbGVsKHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpXG4gICAgICA6IGF3YWl0IHRoaXMuX2NyZWF0ZVNpbmdsZSh0eXBlLCByZWNvcmRzLCBvcHRpb25zKTtcbiAgICByZXR1cm4gcmV0O1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9jcmVhdGVTaW5nbGUodHlwZTogc3RyaW5nLCByZWNvcmQ6IFJlY29yZCwgb3B0aW9uczogRG1sT3B0aW9ucykge1xuICAgIGNvbnN0IHsgSWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICBjb25zdCBzb2JqZWN0VHlwZSA9IHR5cGUgfHwgKGF0dHJpYnV0ZXMgJiYgYXR0cmlidXRlcy50eXBlKSB8fCBydHlwZTtcbiAgICBpZiAoIXNvYmplY3RUeXBlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIFNPYmplY3QgVHlwZSBkZWZpbmVkIGluIHJlY29yZCcpO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCBzb2JqZWN0VHlwZV0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZWMpLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2NyZWF0ZVBhcmFsbGVsKHR5cGU6IHN0cmluZywgcmVjb3JkczogUmVjb3JkW10sIG9wdGlvbnM6IERtbE9wdGlvbnMpIHtcbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiB0aGlzLl9tYXhSZXF1ZXN0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4Y2VlZGVkIG1heCBsaW1pdCBvZiBjb25jdXJyZW50IGNhbGwnKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT5cbiAgICAgICAgdGhpcy5fY3JlYXRlU2luZ2xlKHR5cGUsIHJlY29yZCwgb3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIC8vIGJlIGF3YXJlIHRoYXQgYWxsT3JOb25lIGluIHBhcmFsbGVsIG1vZGUgd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzXG4gICAgICAgICAgLy8gaXQgb25seSByYWlzZXMgZXJyb3Igd2hlbiBtZXQgYXQgbGVhc3Qgb25lIGZhaWxlZCByZXF1ZXN0LlxuICAgICAgICAgIGlmIChvcHRpb25zLmFsbE9yTm9uZSB8fCAhZXJyLmVycm9yQ29kZSkge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdG9TYXZlUmVzdWx0KGVycik7XG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9jcmVhdGVNYW55KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmRzOiBSZWNvcmRbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT4ge1xuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShbXSk7XG4gICAgfVxuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA+IE1BWF9ETUxfQ09VTlQgJiYgb3B0aW9ucy5hbGxvd1JlY3Vyc2l2ZSkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX2NyZWF0ZU1hbnkoXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICByZWNvcmRzLnNsaWNlKDAsIE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fY3JlYXRlTWFueShcbiAgICAgICAgICB0eXBlLFxuICAgICAgICAgIHJlY29yZHMuc2xpY2UoTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgKSksXG4gICAgICBdO1xuICAgIH1cbiAgICBjb25zdCBfcmVjb3JkcyA9IHJlY29yZHMubWFwKChyZWNvcmQpID0+IHtcbiAgICAgIGNvbnN0IHsgSWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICAgIGNvbnN0IHNvYmplY3RUeXBlID0gdHlwZSB8fCAoYXR0cmlidXRlcyAmJiBhdHRyaWJ1dGVzLnR5cGUpIHx8IHJ0eXBlO1xuICAgICAgaWYgKCFzb2JqZWN0VHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIFNPYmplY3QgVHlwZSBkZWZpbmVkIGluIHJlY29yZCcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgYXR0cmlidXRlczogeyB0eXBlOiBzb2JqZWN0VHlwZSB9LCAuLi5yZWMgfTtcbiAgICB9KTtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnY29tcG9zaXRlJywgJ3NvYmplY3RzJ10uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGFsbE9yTm9uZTogb3B0aW9ucy5hbGxPck5vbmUgfHwgZmFsc2UsXG4gICAgICAgIHJlY29yZHM6IF9yZWNvcmRzLFxuICAgICAgfSksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIENvbm5lY3Rpb24jY3JlYXRlKClcbiAgICovXG4gIGluc2VydCA9IHRoaXMuY3JlYXRlO1xuXG4gIC8qKlxuICAgKiBVcGRhdGUgcmVjb3Jkc1xuICAgKi9cbiAgdXBkYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgVXBkYXRlUmVjb3JkIGV4dGVuZHMgU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPiA9IFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IFVwZGF0ZVJlY29yZFtdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIFVwZGF0ZVJlY29yZCBleHRlbmRzIFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj4gPSBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+XG4gID4odHlwZTogTiwgcmVjb3JkOiBVcGRhdGVSZWNvcmQsIG9wdGlvbnM/OiBEbWxPcHRpb25zKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgdXBkYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgVXBkYXRlUmVjb3JkIGV4dGVuZHMgU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPiA9IFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IFVwZGF0ZVJlY29yZCB8IFVwZGF0ZVJlY29yZFtdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICAvKipcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHBhcmFtIHJlY29yZHNcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICovXG4gIHVwZGF0ZTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IFJlY29yZCB8IFJlY29yZFtdLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMgPSB7fSxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPiB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkocmVjb3JkcylcbiAgICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDIuMClcbiAgICAgICAgdGhpcy5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyB0aGlzLl91cGRhdGVNYW55KHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpXG4gICAgICAgIDogdGhpcy5fdXBkYXRlUGFyYWxsZWwodHlwZSwgcmVjb3Jkcywgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fdXBkYXRlU2luZ2xlKHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF91cGRhdGVTaW5nbGUoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZDogUmVjb3JkLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD4ge1xuICAgIGNvbnN0IHsgSWQ6IGlkLCB0eXBlOiBydHlwZSwgYXR0cmlidXRlcywgLi4ucmVjIH0gPSByZWNvcmQ7XG4gICAgaWYgKCFpZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdSZWNvcmQgaWQgaXMgbm90IGZvdW5kIGluIHJlY29yZC4nKTtcbiAgICB9XG4gICAgY29uc3Qgc29iamVjdFR5cGUgPSB0eXBlIHx8IChhdHRyaWJ1dGVzICYmIGF0dHJpYnV0ZXMudHlwZSkgfHwgcnR5cGU7XG4gICAgaWYgKCFzb2JqZWN0VHlwZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBTT2JqZWN0IFR5cGUgZGVmaW5lZCBpbiByZWNvcmQnKTtcbiAgICB9XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgc29iamVjdFR5cGUsIGlkXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgIHtcbiAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxuICAgICAgICB1cmwsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlYyksXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbm9Db250ZW50UmVzcG9uc2U6IHsgaWQsIHN1Y2Nlc3M6IHRydWUsIGVycm9yczogW10gfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfdXBkYXRlUGFyYWxsZWwodHlwZTogc3RyaW5nLCByZWNvcmRzOiBSZWNvcmRbXSwgb3B0aW9uczogRG1sT3B0aW9ucykge1xuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICByZWNvcmRzLm1hcCgocmVjb3JkKSA9PlxuICAgICAgICB0aGlzLl91cGRhdGVTaW5nbGUodHlwZSwgcmVjb3JkLCBvcHRpb25zKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgLy8gYmUgYXdhcmUgdGhhdCBhbGxPck5vbmUgaW4gcGFyYWxsZWwgbW9kZSB3aWxsIG5vdCByZXZlcnQgdGhlIG90aGVyIHN1Y2Nlc3NmdWwgcmVxdWVzdHNcbiAgICAgICAgICAvLyBpdCBvbmx5IHJhaXNlcyBlcnJvciB3aGVuIG1ldCBhdCBsZWFzdCBvbmUgZmFpbGVkIHJlcXVlc3QuXG4gICAgICAgICAgaWYgKG9wdGlvbnMuYWxsT3JOb25lIHx8ICFlcnIuZXJyb3JDb2RlKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0b1NhdmVSZXN1bHQoZXJyKTtcbiAgICAgICAgfSksXG4gICAgICApLFxuICAgICk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3VwZGF0ZU1hbnkoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZHM6IFJlY29yZFtdLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPiB7XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA+IE1BWF9ETUxfQ09VTlQgJiYgb3B0aW9ucy5hbGxvd1JlY3Vyc2l2ZSkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX3VwZGF0ZU1hbnkoXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICByZWNvcmRzLnNsaWNlKDAsIE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fdXBkYXRlTWFueShcbiAgICAgICAgICB0eXBlLFxuICAgICAgICAgIHJlY29yZHMuc2xpY2UoTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgKSksXG4gICAgICBdO1xuICAgIH1cbiAgICBjb25zdCBfcmVjb3JkcyA9IHJlY29yZHMubWFwKChyZWNvcmQpID0+IHtcbiAgICAgIGNvbnN0IHsgSWQ6IGlkLCB0eXBlOiBydHlwZSwgYXR0cmlidXRlcywgLi4ucmVjIH0gPSByZWNvcmQ7XG4gICAgICBpZiAoIWlkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmVjb3JkIGlkIGlzIG5vdCBmb3VuZCBpbiByZWNvcmQuJyk7XG4gICAgICB9XG4gICAgICBjb25zdCBzb2JqZWN0VHlwZSA9IHR5cGUgfHwgKGF0dHJpYnV0ZXMgJiYgYXR0cmlidXRlcy50eXBlKSB8fCBydHlwZTtcbiAgICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBTT2JqZWN0IFR5cGUgZGVmaW5lZCBpbiByZWNvcmQnKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IGlkLCBhdHRyaWJ1dGVzOiB7IHR5cGU6IHNvYmplY3RUeXBlIH0sIC4uLnJlYyB9O1xuICAgIH0pO1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdjb21wb3NpdGUnLCAnc29iamVjdHMnXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGFsbE9yTm9uZTogb3B0aW9ucy5hbGxPck5vbmUgfHwgZmFsc2UsXG4gICAgICAgIHJlY29yZHM6IF9yZWNvcmRzLFxuICAgICAgfSksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcHNlcnQgcmVjb3Jkc1xuICAgKi9cbiAgdXBzZXJ0PFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4sXG4gICAgRmllbGROYW1lcyBleHRlbmRzIFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+ID0gU09iamVjdEZpZWxkTmFtZXM8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkW10sXG4gICAgZXh0SWRGaWVsZDogRmllbGROYW1lcyxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxVcHNlcnRSZXN1bHRbXT47XG4gIHVwc2VydDxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+LFxuICAgIEZpZWxkTmFtZXMgZXh0ZW5kcyBTT2JqZWN0RmllbGROYW1lczxTLCBOPiA9IFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmQ6IElucHV0UmVjb3JkLFxuICAgIGV4dElkRmllbGQ6IEZpZWxkTmFtZXMsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0PjtcbiAgdXBzZXJ0PFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4sXG4gICAgRmllbGROYW1lcyBleHRlbmRzIFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+ID0gU09iamVjdEZpZWxkTmFtZXM8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkIHwgSW5wdXRSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdCB8IFVwc2VydFJlc3VsdFtdPjtcbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB0eXBlXG4gICAqIEBwYXJhbSByZWNvcmRzXG4gICAqIEBwYXJhbSBleHRJZEZpZWxkXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqL1xuICBhc3luYyB1cHNlcnQoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZHM6IFJlY29yZCB8IFJlY29yZFtdLFxuICAgIGV4dElkRmllbGQ6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KHJlY29yZHMpO1xuICAgIGNvbnN0IF9yZWNvcmRzID0gQXJyYXkuaXNBcnJheShyZWNvcmRzKSA/IHJlY29yZHMgOiBbcmVjb3Jkc107XG4gICAgaWYgKF9yZWNvcmRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICBfcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT4ge1xuICAgICAgICBjb25zdCB7IFtleHRJZEZpZWxkXTogZXh0SWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICAgICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgZXh0SWRGaWVsZCwgZXh0SWRdLmpvaW4oXG4gICAgICAgICAgJy8nLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFNhdmVSZXN1bHQ+KFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlYyksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5vQ29udGVudFJlc3BvbnNlOiB7IHN1Y2Nlc3M6IHRydWUsIGVycm9yczogW10gfSxcbiAgICAgICAgICB9LFxuICAgICAgICApLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBCZSBhd2FyZSB0aGF0IGBhbGxPck5vbmVgIG9wdGlvbiBpbiB1cHNlcnQgbWV0aG9kXG4gICAgICAgICAgLy8gd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzLlxuICAgICAgICAgIC8vIEl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAoIWlzQXJyYXkgfHwgb3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KTtcbiAgICAgIH0pLFxuICAgICk7XG4gICAgcmV0dXJuIGlzQXJyYXkgPyByZXN1bHRzIDogcmVzdWx0c1swXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgcmVjb3Jkc1xuICAgKi9cbiAgZGVzdHJveTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVzdHJveTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIGRlc3Ryb3k8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICAvKipcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHBhcmFtIGlkc1xuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgYXN5bmMgZGVzdHJveShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KGlkcylcbiAgICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDIuMClcbiAgICAgICAgdGhpcy5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyB0aGlzLl9kZXN0cm95TWFueSh0eXBlLCBpZHMsIG9wdGlvbnMpXG4gICAgICAgIDogdGhpcy5fZGVzdHJveVBhcmFsbGVsKHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fZGVzdHJveVNpbmdsZSh0eXBlLCBpZHMsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9kZXN0cm95U2luZ2xlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsIGlkXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgIHtcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgdXJsLFxuICAgICAgICBoZWFkZXJzOiBvcHRpb25zLmhlYWRlcnMgfHwge30sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBub0NvbnRlbnRSZXNwb25zZTogeyBpZCwgc3VjY2VzczogdHJ1ZSwgZXJyb3JzOiBbXSB9LFxuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9kZXN0cm95UGFyYWxsZWwodHlwZTogc3RyaW5nLCBpZHM6IHN0cmluZ1tdLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiB0aGlzLl9tYXhSZXF1ZXN0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4Y2VlZGVkIG1heCBsaW1pdCBvZiBjb25jdXJyZW50IGNhbGwnKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgaWRzLm1hcCgoaWQpID0+XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3lTaW5nbGUodHlwZSwgaWQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBCZSBhd2FyZSB0aGF0IGBhbGxPck5vbmVgIG9wdGlvbiBpbiBwYXJhbGxlbCBtb2RlXG4gICAgICAgICAgLy8gd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzLlxuICAgICAgICAgIC8vIEl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfZGVzdHJveU1hbnkoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+IHtcbiAgICBpZiAoaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoaWRzLmxlbmd0aCA+IE1BWF9ETUxfQ09VTlQgJiYgb3B0aW9ucy5hbGxvd1JlY3Vyc2l2ZSkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX2Rlc3Ryb3lNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgaWRzLnNsaWNlKDAsIE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fZGVzdHJveU1hbnkodHlwZSwgaWRzLnNsaWNlKE1BWF9ETUxfQ09VTlQpLCBvcHRpb25zKSksXG4gICAgICBdO1xuICAgIH1cbiAgICBsZXQgdXJsID1cbiAgICAgIFt0aGlzLl9iYXNlVXJsKCksICdjb21wb3NpdGUnLCAnc29iamVjdHM/aWRzPSddLmpvaW4oJy8nKSArIGlkcy5qb2luKCcsJyk7XG4gICAgaWYgKG9wdGlvbnMuYWxsT3JOb25lKSB7XG4gICAgICB1cmwgKz0gJyZhbGxPck5vbmU9dHJ1ZSc7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgIHVybCxcbiAgICAgIGhlYWRlcnM6IG9wdGlvbnMuaGVhZGVycyB8fCB7fSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIENvbm5lY3Rpb24jZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQ29ubmVjdGlvbiNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogRGVzY3JpYmUgU09iamVjdCBtZXRhZGF0YVxuICAgKi9cbiAgYXN5bmMgZGVzY3JpYmUodHlwZTogc3RyaW5nKTogUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlLCAnZGVzY3JpYmUnXS5qb2luKCcvJyk7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlU09iamVjdFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXNjcmliZSBnbG9iYWwgU09iamVjdHNcbiAgICovXG4gIGFzeW5jIGRlc2NyaWJlR2xvYmFsKCkge1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuX2Jhc2VVcmwoKX0vc29iamVjdHNgO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZUdsb2JhbFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgU09iamVjdCBpbnN0YW5jZVxuICAgKi9cbiAgc29iamVjdDxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+Pih0eXBlOiBOKTogU09iamVjdDxTLCBOPjtcbiAgc29iamVjdDxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+Pih0eXBlOiBzdHJpbmcpOiBTT2JqZWN0PFMsIE4+O1xuICBzb2JqZWN0PE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+KHR5cGU6IE4gfCBzdHJpbmcpOiBTT2JqZWN0PFMsIE4+IHtcbiAgICBjb25zdCBzbyA9XG4gICAgICAodGhpcy5zb2JqZWN0c1t0eXBlIGFzIE5dIGFzIFNPYmplY3Q8UywgTj4gfCB1bmRlZmluZWQpIHx8XG4gICAgICBuZXcgU09iamVjdCh0aGlzLCB0eXBlIGFzIE4pO1xuICAgIHRoaXMuc29iamVjdHNbdHlwZSBhcyBOXSA9IHNvO1xuICAgIHJldHVybiBzbztcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgaWRlbnRpdHkgaW5mb3JtYXRpb24gb2YgY3VycmVudCB1c2VyXG4gICAqL1xuICBhc3luYyBpZGVudGl0eShvcHRpb25zOiB7IGhlYWRlcnM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSB9ID0ge30pIHtcbiAgICBsZXQgdXJsID0gdGhpcy51c2VySW5mbyAmJiB0aGlzLnVzZXJJbmZvLnVybDtcbiAgICBpZiAoIXVybCkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0PHsgaWRlbnRpdHk6IHN0cmluZyB9Pih7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIHVybDogdGhpcy5fYmFzZVVybCgpLFxuICAgICAgICBoZWFkZXJzOiBvcHRpb25zLmhlYWRlcnMsXG4gICAgICB9KTtcbiAgICAgIHVybCA9IHJlcy5pZGVudGl0eTtcbiAgICB9XG4gICAgdXJsICs9ICc/Zm9ybWF0PWpzb24nO1xuICAgIGlmICh0aGlzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICB1cmwgKz0gYCZvYXV0aF90b2tlbj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLmFjY2Vzc1Rva2VuKX1gO1xuICAgIH1cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3Q8SWRlbnRpdHlJbmZvPih7IG1ldGhvZDogJ0dFVCcsIHVybCB9KTtcbiAgICB0aGlzLnVzZXJJbmZvID0ge1xuICAgICAgaWQ6IHJlcy51c2VyX2lkLFxuICAgICAgb3JnYW5pemF0aW9uSWQ6IHJlcy5vcmdhbml6YXRpb25faWQsXG4gICAgICB1cmw6IHJlcy5pZCxcbiAgICB9O1xuICAgIHJldHVybiByZXM7XG4gIH1cblxuICAvKipcbiAgICogTGlzdCByZWNlbnRseSB2aWV3ZWQgcmVjb3Jkc1xuICAgKi9cbiAgYXN5bmMgcmVjZW50KHR5cGU/OiBzdHJpbmcgfCBudW1iZXIsIGxpbWl0PzogbnVtYmVyKSB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICBpZiAodHlwZW9mIHR5cGUgPT09ICdudW1iZXInKSB7XG4gICAgICBsaW1pdCA9IHR5cGU7XG4gICAgICB0eXBlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBsZXQgdXJsO1xuICAgIGlmICh0eXBlKSB7XG4gICAgICB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlXS5qb2luKCcvJyk7XG4gICAgICBjb25zdCB7IHJlY2VudEl0ZW1zIH0gPSBhd2FpdCB0aGlzLnJlcXVlc3Q8eyByZWNlbnRJdGVtczogUmVjb3JkW10gfT4oXG4gICAgICAgIHVybCxcbiAgICAgICk7XG4gICAgICByZXR1cm4gbGltaXQgPyByZWNlbnRJdGVtcy5zbGljZSgwLCBsaW1pdCkgOiByZWNlbnRJdGVtcztcbiAgICB9XG4gICAgdXJsID0gYCR7dGhpcy5fYmFzZVVybCgpfS9yZWNlbnRgO1xuICAgIGlmIChsaW1pdCkge1xuICAgICAgdXJsICs9IGA/bGltaXQ9JHtsaW1pdH1gO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFJlY29yZFtdPih1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHVwZGF0ZWQgcmVjb3Jkc1xuICAgKi9cbiAgYXN5bmMgdXBkYXRlZChcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgc3RhcnQ6IHN0cmluZyB8IERhdGUsXG4gICAgZW5kOiBzdHJpbmcgfCBEYXRlLFxuICApOiBQcm9taXNlPFVwZGF0ZWRSZXN1bHQ+IHtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1wYXJhbS1yZWFzc2lnbiAqL1xuICAgIGxldCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlLCAndXBkYXRlZCddLmpvaW4oJy8nKTtcbiAgICBpZiAodHlwZW9mIHN0YXJ0ID09PSAnc3RyaW5nJykge1xuICAgICAgc3RhcnQgPSBuZXcgRGF0ZShzdGFydCk7XG4gICAgfVxuICAgIHN0YXJ0ID0gZm9ybWF0RGF0ZShzdGFydCk7XG4gICAgdXJsICs9IGA/c3RhcnQ9JHtlbmNvZGVVUklDb21wb25lbnQoc3RhcnQpfWA7XG4gICAgaWYgKHR5cGVvZiBlbmQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBlbmQgPSBuZXcgRGF0ZShlbmQpO1xuICAgIH1cbiAgICBlbmQgPSBmb3JtYXREYXRlKGVuZCk7XG4gICAgdXJsICs9IGAmZW5kPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGVuZCl9YDtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgVXBkYXRlZFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBkZWxldGVkIHJlY29yZHNcbiAgICovXG4gIGFzeW5jIGRlbGV0ZWQoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHN0YXJ0OiBzdHJpbmcgfCBEYXRlLFxuICAgIGVuZDogc3RyaW5nIHwgRGF0ZSxcbiAgKTogUHJvbWlzZTxEZWxldGVkUmVzdWx0PiB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICBsZXQgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgJ2RlbGV0ZWQnXS5qb2luKCcvJyk7XG4gICAgaWYgKHR5cGVvZiBzdGFydCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHN0YXJ0ID0gbmV3IERhdGUoc3RhcnQpO1xuICAgIH1cbiAgICBzdGFydCA9IGZvcm1hdERhdGUoc3RhcnQpO1xuICAgIHVybCArPSBgP3N0YXJ0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHN0YXJ0KX1gO1xuXG4gICAgaWYgKHR5cGVvZiBlbmQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBlbmQgPSBuZXcgRGF0ZShlbmQpO1xuICAgIH1cbiAgICBlbmQgPSBmb3JtYXREYXRlKGVuZCk7XG4gICAgdXJsICs9IGAmZW5kPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGVuZCl9YDtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgRGVsZXRlZFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbGlzdCBvZiBhbGwgdGFic1xuICAgKi9cbiAgYXN5bmMgdGFicygpOiBQcm9taXNlPERlc2NyaWJlVGFiW10+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAndGFicyddLmpvaW4oJy8nKTtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgRGVzY3JpYmVUYWJbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGN1cnJlbnQgc3lzdGVtIGxpbWl0IGluIHRoZSBvcmdhbml6YXRpb25cbiAgICovXG4gIGFzeW5jIGxpbWl0cygpOiBQcm9taXNlPE9yZ2FuaXphdGlvbkxpbWl0c0luZm8+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnbGltaXRzJ10uam9pbignLycpO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBPcmdhbml6YXRpb25MaW1pdHNJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSB0aGVtZSBpbmZvXG4gICAqL1xuICBhc3luYyB0aGVtZSgpOiBQcm9taXNlPERlc2NyaWJlVGhlbWU+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAndGhlbWUnXS5qb2luKCcvJyk7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlVGhlbWU7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbGwgcmVnaXN0ZXJlZCBnbG9iYWwgcXVpY2sgYWN0aW9uc1xuICAgKi9cbiAgYXN5bmMgcXVpY2tBY3Rpb25zKCk6IFByb21pc2U8RGVzY3JpYmVRdWlja0FjdGlvblJlc3VsdFtdPiB7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCgnL3F1aWNrQWN0aW9ucycpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlUXVpY2tBY3Rpb25SZXN1bHRbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgcmVmZXJlbmNlIGZvciBzcGVjaWZpZWQgZ2xvYmFsIHF1aWNrIGFjdGlvblxuICAgKi9cbiAgcXVpY2tBY3Rpb24oYWN0aW9uTmFtZTogc3RyaW5nKTogUXVpY2tBY3Rpb248Uz4ge1xuICAgIHJldHVybiBuZXcgUXVpY2tBY3Rpb24odGhpcywgYC9xdWlja0FjdGlvbnMvJHthY3Rpb25OYW1lfWApO1xuICB9XG5cbiAgLyoqXG4gICAqIE1vZHVsZSB3aGljaCBtYW5hZ2VzIHByb2Nlc3MgcnVsZXMgYW5kIGFwcHJvdmFsIHByb2Nlc3Nlc1xuICAgKi9cbiAgcHJvY2VzcyA9IG5ldyBQcm9jZXNzKHRoaXMpO1xufVxuXG5leHBvcnQgZGVmYXVsdCBDb25uZWN0aW9uO1xuIl19