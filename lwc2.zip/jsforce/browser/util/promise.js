import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Promise2 from "@babel/runtime-corejs3/core-js-stable/promise";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 *
 */
import { Duplex } from 'stream';
/**
 *
 */

/**
 *
 */
export var StreamPromise = /*#__PURE__*/function (_Promise) {
  _inherits(StreamPromise, _Promise);

  var _super = _createSuper(StreamPromise);

  function StreamPromise() {
    _classCallCheck(this, StreamPromise);

    return _super.apply(this, arguments);
  }

  _createClass(StreamPromise, [{
    key: "stream",
    value: function stream() {
      // dummy
      return new Duplex();
    }
  }], [{
    key: "create",
    value: function create(builder) {
      var _builder = builder(),
          stream = _builder.stream,
          promise = _builder.promise;

      var streamPromise = new StreamPromise(function (resolve, reject) {
        promise.then(resolve, reject);
      });

      streamPromise.stream = function () {
        return stream;
      };

      return streamPromise;
    }
  }]);

  return StreamPromise;
}( /*#__PURE__*/_wrapNativeSuper(_Promise2));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL3Byb21pc2UudHMiXSwibmFtZXMiOlsiRHVwbGV4IiwiU3RyZWFtUHJvbWlzZSIsImJ1aWxkZXIiLCJzdHJlYW0iLCJwcm9taXNlIiwic3RyZWFtUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJ0aGVuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsTUFBVCxRQUF1QixRQUF2QjtBQUVBO0FBQ0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxhQUFiO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSw2QkFDVztBQUNQO0FBQ0EsYUFBTyxJQUFJRCxNQUFKLEVBQVA7QUFDRDtBQUpIO0FBQUE7QUFBQSwyQkFNbUJFLE9BTm5CLEVBTXFEO0FBQUEscUJBQ3JCQSxPQUFPLEVBRGM7QUFBQSxVQUN6Q0MsTUFEeUMsWUFDekNBLE1BRHlDO0FBQUEsVUFDakNDLE9BRGlDLFlBQ2pDQSxPQURpQzs7QUFFakQsVUFBTUMsYUFBYSxHQUFHLElBQUlKLGFBQUosQ0FBcUIsVUFBQ0ssT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQzlESCxRQUFBQSxPQUFPLENBQUNJLElBQVIsQ0FBYUYsT0FBYixFQUFzQkMsTUFBdEI7QUFDRCxPQUZxQixDQUF0Qjs7QUFHQUYsTUFBQUEsYUFBYSxDQUFDRixNQUFkLEdBQXVCO0FBQUEsZUFBTUEsTUFBTjtBQUFBLE9BQXZCOztBQUNBLGFBQU9FLGFBQVA7QUFDRDtBQWJIOztBQUFBO0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IER1cGxleCB9IGZyb20gJ3N0cmVhbSc7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU3RyZWFtUHJvbWlzZUJ1aWxkZXI8VD4gPSAoKSA9PiB7XG4gIHN0cmVhbTogRHVwbGV4O1xuICBwcm9taXNlOiBQcm9taXNlPFQ+O1xufTtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgU3RyZWFtUHJvbWlzZTxUPiBleHRlbmRzIFByb21pc2U8VD4ge1xuICBzdHJlYW0oKSB7XG4gICAgLy8gZHVtbXlcbiAgICByZXR1cm4gbmV3IER1cGxleCgpO1xuICB9XG5cbiAgc3RhdGljIGNyZWF0ZTxUPihidWlsZGVyOiBTdHJlYW1Qcm9taXNlQnVpbGRlcjxUPikge1xuICAgIGNvbnN0IHsgc3RyZWFtLCBwcm9taXNlIH0gPSBidWlsZGVyKCk7XG4gICAgY29uc3Qgc3RyZWFtUHJvbWlzZSA9IG5ldyBTdHJlYW1Qcm9taXNlPFQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHByb21pc2UudGhlbihyZXNvbHZlLCByZWplY3QpO1xuICAgIH0pO1xuICAgIHN0cmVhbVByb21pc2Uuc3RyZWFtID0gKCkgPT4gc3RyZWFtO1xuICAgIHJldHVybiBzdHJlYW1Qcm9taXNlO1xuICB9XG59XG4iXX0=