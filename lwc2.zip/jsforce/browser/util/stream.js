import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.to-string";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

import { Duplex, PassThrough, Writable } from 'stream';
export function createLazyStream() {
  var ins = new PassThrough();
  var outs = new PassThrough();
  var stream = concatStreamsAsDuplex(ins, outs);
  var piped = false;

  var setStream = function setStream(str) {
    if (piped) {
      throw new Error('stream is already piped to actual stream');
    }

    piped = true;
    ins.pipe(str).pipe(outs);
  };

  return {
    stream: stream,
    setStream: setStream
  };
}

var MemoryWriteStream = /*#__PURE__*/function (_Writable) {
  _inherits(MemoryWriteStream, _Writable);

  var _super = _createSuper(MemoryWriteStream);

  function MemoryWriteStream() {
    var _this;

    _classCallCheck(this, MemoryWriteStream);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_buf", void 0);

    _this._buf = Buffer.alloc(0);
    return _this;
  }

  _createClass(MemoryWriteStream, [{
    key: "_write",
    value: function _write(chunk, encoding, callback) {
      this._buf = _concatInstanceProperty(Buffer).call(Buffer, [this._buf, chunk]);
      callback();
    }
  }, {
    key: "_writev",
    value: function _writev(data, callback) {
      var _context;

      this._buf = _concatInstanceProperty(Buffer).call(Buffer, _concatInstanceProperty(_context = [this._buf]).call(_context, _toConsumableArray(_mapInstanceProperty(data).call(data, function (_ref) {
        var chunk = _ref.chunk;
        return chunk;
      }))));
      callback();
    }
  }, {
    key: "toString",
    value: function toString() {
      return this._buf.toString();
    }
  }]);

  return MemoryWriteStream;
}(Writable);

export function readAll(_x) {
  return _readAll.apply(this, arguments);
}

function _readAll() {
  _readAll = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(rs) {
    return _regeneratorRuntime.wrap(function _callee$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", new _Promise(function (resolve, reject) {
              var ws = new MemoryWriteStream();
              rs.on('error', reject).pipe(ws).on('finish', function () {
                return resolve(ws.toString());
              });
            }));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee);
  }));
  return _readAll.apply(this, arguments);
}

var DuplexifiedStream = /*#__PURE__*/function (_Duplex) {
  _inherits(DuplexifiedStream, _Duplex);

  var _super2 = _createSuper(DuplexifiedStream);

  function DuplexifiedStream(ws, rs) {
    var _opts$writableObjectM, _opts$readableObjectM;

    var _this2;

    var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    _classCallCheck(this, DuplexifiedStream);

    _this2 = _super2.call(this, {
      writableObjectMode: (_opts$writableObjectM = opts.writableObjectMode) !== null && _opts$writableObjectM !== void 0 ? _opts$writableObjectM : ws.writableObjectMode,
      readableObjectMode: (_opts$readableObjectM = opts.readableObjectMode) !== null && _opts$readableObjectM !== void 0 ? _opts$readableObjectM : rs.readableObjectMode
    });

    _defineProperty(_assertThisInitialized(_this2), "_writable", void 0);

    _defineProperty(_assertThisInitialized(_this2), "_readable", void 0);

    _this2._writable = ws;
    _this2._readable = rs;
    ws.once('finish', function () {
      _this2.end();
    });

    _this2.once('finish', function () {
      ws.end();
    });

    rs.on('readable', function () {
      _this2._readStream();
    });
    rs.once('end', function () {
      _this2.push(null);
    });
    ws.on('error', function (err) {
      return _this2.emit('error', err);
    });
    rs.on('error', function (err) {
      return _this2.emit('error', err);
    });
    return _this2;
  }

  _createClass(DuplexifiedStream, [{
    key: "_write",
    value: function _write(chunk, encoding, callback) {
      this._writable.write(chunk, encoding, callback);
    }
  }, {
    key: "_read",
    value: function _read(n) {
      this._readStream(n);
    }
  }, {
    key: "_readStream",
    value: function _readStream(n) {
      var data;

      while ((data = this._readable.read(n)) !== null) {
        this.push(data);
      }
    }
  }]);

  return DuplexifiedStream;
}(Duplex);

export function concatStreamsAsDuplex(ws, rs, opts) {
  return new DuplexifiedStream(ws, rs, opts);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL3N0cmVhbS50cyJdLCJuYW1lcyI6WyJEdXBsZXgiLCJQYXNzVGhyb3VnaCIsIldyaXRhYmxlIiwiY3JlYXRlTGF6eVN0cmVhbSIsImlucyIsIm91dHMiLCJzdHJlYW0iLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJwaXBlZCIsInNldFN0cmVhbSIsInN0ciIsIkVycm9yIiwicGlwZSIsIk1lbW9yeVdyaXRlU3RyZWFtIiwiX2J1ZiIsIkJ1ZmZlciIsImFsbG9jIiwiY2h1bmsiLCJlbmNvZGluZyIsImNhbGxiYWNrIiwiZGF0YSIsInRvU3RyaW5nIiwicmVhZEFsbCIsInJzIiwicmVzb2x2ZSIsInJlamVjdCIsIndzIiwib24iLCJEdXBsZXhpZmllZFN0cmVhbSIsIm9wdHMiLCJ3cml0YWJsZU9iamVjdE1vZGUiLCJyZWFkYWJsZU9iamVjdE1vZGUiLCJfd3JpdGFibGUiLCJfcmVhZGFibGUiLCJvbmNlIiwiZW5kIiwiX3JlYWRTdHJlYW0iLCJwdXNoIiwiZXJyIiwiZW1pdCIsIndyaXRlIiwibiIsInJlYWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxNQUFULEVBQWlCQyxXQUFqQixFQUF3Q0MsUUFBeEMsUUFBd0QsUUFBeEQ7QUFFQSxPQUFPLFNBQVNDLGdCQUFULEdBQTRCO0FBQ2pDLE1BQU1DLEdBQUcsR0FBRyxJQUFJSCxXQUFKLEVBQVo7QUFDQSxNQUFNSSxJQUFJLEdBQUcsSUFBSUosV0FBSixFQUFiO0FBQ0EsTUFBTUssTUFBTSxHQUFHQyxxQkFBcUIsQ0FBQ0gsR0FBRCxFQUFNQyxJQUFOLENBQXBDO0FBQ0EsTUFBSUcsS0FBSyxHQUFHLEtBQVo7O0FBQ0EsTUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsR0FBRCxFQUFpQjtBQUNqQyxRQUFJRixLQUFKLEVBQVc7QUFDVCxZQUFNLElBQUlHLEtBQUosQ0FBVSwwQ0FBVixDQUFOO0FBQ0Q7O0FBQ0RILElBQUFBLEtBQUssR0FBRyxJQUFSO0FBQ0FKLElBQUFBLEdBQUcsQ0FBQ1EsSUFBSixDQUFTRixHQUFULEVBQWNFLElBQWQsQ0FBbUJQLElBQW5CO0FBQ0QsR0FORDs7QUFPQSxTQUFPO0FBQUVDLElBQUFBLE1BQU0sRUFBTkEsTUFBRjtBQUFVRyxJQUFBQSxTQUFTLEVBQVRBO0FBQVYsR0FBUDtBQUNEOztJQUVLSSxpQjs7Ozs7QUFHSiwrQkFBYztBQUFBOztBQUFBOztBQUNaOztBQURZOztBQUVaLFVBQUtDLElBQUwsR0FBWUMsTUFBTSxDQUFDQyxLQUFQLENBQWEsQ0FBYixDQUFaO0FBRlk7QUFHYjs7OzsyQkFFTUMsSyxFQUFlQyxRLEVBQWtCQyxRLEVBQW9CO0FBQzFELFdBQUtMLElBQUwsR0FBWSx3QkFBQUMsTUFBTSxNQUFOLENBQUFBLE1BQU0sRUFBUSxDQUFDLEtBQUtELElBQU4sRUFBWUcsS0FBWixDQUFSLENBQWxCO0FBQ0FFLE1BQUFBLFFBQVE7QUFDVDs7OzRCQUdDQyxJLEVBQ0FELFEsRUFDQTtBQUFBOztBQUNBLFdBQUtMLElBQUwsR0FBWSx3QkFBQUMsTUFBTSxNQUFOLENBQUFBLE1BQU0sc0NBQVMsS0FBS0QsSUFBZCxxQ0FBdUIscUJBQUFNLElBQUksTUFBSixDQUFBQSxJQUFJLEVBQUs7QUFBQSxZQUFHSCxLQUFILFFBQUdBLEtBQUg7QUFBQSxlQUFlQSxLQUFmO0FBQUEsT0FBTCxDQUEzQixHQUFsQjtBQUNBRSxNQUFBQSxRQUFRO0FBQ1Q7OzsrQkFFVTtBQUNULGFBQU8sS0FBS0wsSUFBTCxDQUFVTyxRQUFWLEVBQVA7QUFDRDs7OztFQXZCNkJuQixROztBQTBCaEMsZ0JBQXNCb0IsT0FBdEI7QUFBQTtBQUFBOzs7c0VBQU8saUJBQXVCQyxFQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOENBQ0UsYUFBb0IsVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQzlDLGtCQUFNQyxFQUFFLEdBQUcsSUFBSWIsaUJBQUosRUFBWDtBQUNBVSxjQUFBQSxFQUFFLENBQUNJLEVBQUgsQ0FBTSxPQUFOLEVBQWVGLE1BQWYsRUFDR2IsSUFESCxDQUNRYyxFQURSLEVBRUdDLEVBRkgsQ0FFTSxRQUZOLEVBRWdCO0FBQUEsdUJBQU1ILE9BQU8sQ0FBQ0UsRUFBRSxDQUFDTCxRQUFILEVBQUQsQ0FBYjtBQUFBLGVBRmhCO0FBR0QsYUFMTSxDQURGOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7SUFTRE8saUI7Ozs7O0FBSUosNkJBQ0VGLEVBREYsRUFFRUgsRUFGRixFQUlFO0FBQUE7O0FBQUE7O0FBQUEsUUFEQU0sSUFDQSx1RUFEdUUsRUFDdkU7O0FBQUE7O0FBQ0EsZ0NBQU07QUFDSkMsTUFBQUEsa0JBQWtCLDJCQUFFRCxJQUFJLENBQUNDLGtCQUFQLHlFQUE2QkosRUFBRSxDQUFDSSxrQkFEOUM7QUFFSkMsTUFBQUEsa0JBQWtCLDJCQUFFRixJQUFJLENBQUNFLGtCQUFQLHlFQUE2QlIsRUFBRSxDQUFDUTtBQUY5QyxLQUFOOztBQURBOztBQUFBOztBQUtBLFdBQUtDLFNBQUwsR0FBaUJOLEVBQWpCO0FBQ0EsV0FBS08sU0FBTCxHQUFpQlYsRUFBakI7QUFDQUcsSUFBQUEsRUFBRSxDQUFDUSxJQUFILENBQVEsUUFBUixFQUFrQixZQUFNO0FBQ3RCLGFBQUtDLEdBQUw7QUFDRCxLQUZEOztBQUdBLFdBQUtELElBQUwsQ0FBVSxRQUFWLEVBQW9CLFlBQU07QUFDeEJSLE1BQUFBLEVBQUUsQ0FBQ1MsR0FBSDtBQUNELEtBRkQ7O0FBR0FaLElBQUFBLEVBQUUsQ0FBQ0ksRUFBSCxDQUFNLFVBQU4sRUFBa0IsWUFBTTtBQUN0QixhQUFLUyxXQUFMO0FBQ0QsS0FGRDtBQUdBYixJQUFBQSxFQUFFLENBQUNXLElBQUgsQ0FBUSxLQUFSLEVBQWUsWUFBTTtBQUNuQixhQUFLRyxJQUFMLENBQVUsSUFBVjtBQUNELEtBRkQ7QUFHQVgsSUFBQUEsRUFBRSxDQUFDQyxFQUFILENBQU0sT0FBTixFQUFlLFVBQUNXLEdBQUQ7QUFBQSxhQUFTLE9BQUtDLElBQUwsQ0FBVSxPQUFWLEVBQW1CRCxHQUFuQixDQUFUO0FBQUEsS0FBZjtBQUNBZixJQUFBQSxFQUFFLENBQUNJLEVBQUgsQ0FBTSxPQUFOLEVBQWUsVUFBQ1csR0FBRDtBQUFBLGFBQVMsT0FBS0MsSUFBTCxDQUFVLE9BQVYsRUFBbUJELEdBQW5CLENBQVQ7QUFBQSxLQUFmO0FBcEJBO0FBcUJEOzs7OzJCQUVNckIsSyxFQUFZQyxRLEVBQWVDLFEsRUFBZTtBQUMvQyxXQUFLYSxTQUFMLENBQWVRLEtBQWYsQ0FBcUJ2QixLQUFyQixFQUE0QkMsUUFBNUIsRUFBc0NDLFFBQXRDO0FBQ0Q7OzswQkFFS3NCLEMsRUFBVztBQUNmLFdBQUtMLFdBQUwsQ0FBaUJLLENBQWpCO0FBQ0Q7OztnQ0FFV0EsQyxFQUFZO0FBQ3RCLFVBQUlyQixJQUFKOztBQUNBLGFBQU8sQ0FBQ0EsSUFBSSxHQUFHLEtBQUthLFNBQUwsQ0FBZVMsSUFBZixDQUFvQkQsQ0FBcEIsQ0FBUixNQUFvQyxJQUEzQyxFQUFpRDtBQUMvQyxhQUFLSixJQUFMLENBQVVqQixJQUFWO0FBQ0Q7QUFDRjs7OztFQTVDNkJwQixNOztBQStDaEMsT0FBTyxTQUFTTyxxQkFBVCxDQUNMbUIsRUFESyxFQUVMSCxFQUZLLEVBR0xNLElBSEssRUFJRztBQUNSLFNBQU8sSUFBSUQsaUJBQUosQ0FBc0JGLEVBQXRCLEVBQTBCSCxFQUExQixFQUE4Qk0sSUFBOUIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRHVwbGV4LCBQYXNzVGhyb3VnaCwgUmVhZGFibGUsIFdyaXRhYmxlIH0gZnJvbSAnc3RyZWFtJztcblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUxhenlTdHJlYW0oKSB7XG4gIGNvbnN0IGlucyA9IG5ldyBQYXNzVGhyb3VnaCgpO1xuICBjb25zdCBvdXRzID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gIGNvbnN0IHN0cmVhbSA9IGNvbmNhdFN0cmVhbXNBc0R1cGxleChpbnMsIG91dHMpO1xuICBsZXQgcGlwZWQgPSBmYWxzZTtcbiAgY29uc3Qgc2V0U3RyZWFtID0gKHN0cjogRHVwbGV4KSA9PiB7XG4gICAgaWYgKHBpcGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3N0cmVhbSBpcyBhbHJlYWR5IHBpcGVkIHRvIGFjdHVhbCBzdHJlYW0nKTtcbiAgICB9XG4gICAgcGlwZWQgPSB0cnVlO1xuICAgIGlucy5waXBlKHN0cikucGlwZShvdXRzKTtcbiAgfTtcbiAgcmV0dXJuIHsgc3RyZWFtLCBzZXRTdHJlYW0gfTtcbn1cblxuY2xhc3MgTWVtb3J5V3JpdGVTdHJlYW0gZXh0ZW5kcyBXcml0YWJsZSB7XG4gIF9idWY6IEJ1ZmZlcjtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2J1ZiA9IEJ1ZmZlci5hbGxvYygwKTtcbiAgfVxuXG4gIF93cml0ZShjaHVuazogQnVmZmVyLCBlbmNvZGluZzogc3RyaW5nLCBjYWxsYmFjazogRnVuY3Rpb24pIHtcbiAgICB0aGlzLl9idWYgPSBCdWZmZXIuY29uY2F0KFt0aGlzLl9idWYsIGNodW5rXSk7XG4gICAgY2FsbGJhY2soKTtcbiAgfVxuXG4gIF93cml0ZXYoXG4gICAgZGF0YTogQXJyYXk8eyBjaHVuazogQnVmZmVyOyBlbmNvZGluZzogc3RyaW5nIH0+LFxuICAgIGNhbGxiYWNrOiBGdW5jdGlvbixcbiAgKSB7XG4gICAgdGhpcy5fYnVmID0gQnVmZmVyLmNvbmNhdChbdGhpcy5fYnVmLCAuLi5kYXRhLm1hcCgoeyBjaHVuayB9KSA9PiBjaHVuayldKTtcbiAgICBjYWxsYmFjaygpO1xuICB9XG5cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2J1Zi50b1N0cmluZygpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWFkQWxsKHJzOiBSZWFkYWJsZSkge1xuICByZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3Qgd3MgPSBuZXcgTWVtb3J5V3JpdGVTdHJlYW0oKTtcbiAgICBycy5vbignZXJyb3InLCByZWplY3QpXG4gICAgICAucGlwZSh3cylcbiAgICAgIC5vbignZmluaXNoJywgKCkgPT4gcmVzb2x2ZSh3cy50b1N0cmluZygpKSk7XG4gIH0pO1xufVxuXG5jbGFzcyBEdXBsZXhpZmllZFN0cmVhbSBleHRlbmRzIER1cGxleCB7XG4gIF93cml0YWJsZTogV3JpdGFibGU7XG4gIF9yZWFkYWJsZTogUmVhZGFibGU7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgd3M6IFdyaXRhYmxlLFxuICAgIHJzOiBSZWFkYWJsZSxcbiAgICBvcHRzOiB7IHdyaXRhYmxlT2JqZWN0TW9kZT86IGJvb2xlYW47IHJlYWRhYmxlT2JqZWN0TW9kZT86IGJvb2xlYW4gfSA9IHt9LFxuICApIHtcbiAgICBzdXBlcih7XG4gICAgICB3cml0YWJsZU9iamVjdE1vZGU6IG9wdHMud3JpdGFibGVPYmplY3RNb2RlID8/IHdzLndyaXRhYmxlT2JqZWN0TW9kZSxcbiAgICAgIHJlYWRhYmxlT2JqZWN0TW9kZTogb3B0cy5yZWFkYWJsZU9iamVjdE1vZGUgPz8gcnMucmVhZGFibGVPYmplY3RNb2RlLFxuICAgIH0pO1xuICAgIHRoaXMuX3dyaXRhYmxlID0gd3M7XG4gICAgdGhpcy5fcmVhZGFibGUgPSBycztcbiAgICB3cy5vbmNlKCdmaW5pc2gnLCAoKSA9PiB7XG4gICAgICB0aGlzLmVuZCgpO1xuICAgIH0pO1xuICAgIHRoaXMub25jZSgnZmluaXNoJywgKCkgPT4ge1xuICAgICAgd3MuZW5kKCk7XG4gICAgfSk7XG4gICAgcnMub24oJ3JlYWRhYmxlJywgKCkgPT4ge1xuICAgICAgdGhpcy5fcmVhZFN0cmVhbSgpO1xuICAgIH0pO1xuICAgIHJzLm9uY2UoJ2VuZCcsICgpID0+IHtcbiAgICAgIHRoaXMucHVzaChudWxsKTtcbiAgICB9KTtcbiAgICB3cy5vbignZXJyb3InLCAoZXJyKSA9PiB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKSk7XG4gICAgcnMub24oJ2Vycm9yJywgKGVycikgPT4gdGhpcy5lbWl0KCdlcnJvcicsIGVycikpO1xuICB9XG5cbiAgX3dyaXRlKGNodW5rOiBhbnksIGVuY29kaW5nOiBhbnksIGNhbGxiYWNrOiBhbnkpIHtcbiAgICB0aGlzLl93cml0YWJsZS53cml0ZShjaHVuaywgZW5jb2RpbmcsIGNhbGxiYWNrKTtcbiAgfVxuXG4gIF9yZWFkKG46IG51bWJlcikge1xuICAgIHRoaXMuX3JlYWRTdHJlYW0obik7XG4gIH1cblxuICBfcmVhZFN0cmVhbShuPzogbnVtYmVyKSB7XG4gICAgbGV0IGRhdGE7XG4gICAgd2hpbGUgKChkYXRhID0gdGhpcy5fcmVhZGFibGUucmVhZChuKSkgIT09IG51bGwpIHtcbiAgICAgIHRoaXMucHVzaChkYXRhKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNvbmNhdFN0cmVhbXNBc0R1cGxleChcbiAgd3M6IFdyaXRhYmxlLFxuICByczogUmVhZGFibGUsXG4gIG9wdHM/OiB7IHdyaXRhYmxlT2JqZWN0TW9kZT86IGJvb2xlYW47IHJlYWRhYmxlT2JqZWN0TW9kZT86IGJvb2xlYW4gfSxcbik6IER1cGxleCB7XG4gIHJldHVybiBuZXcgRHVwbGV4aWZpZWRTdHJlYW0od3MsIHJzLCBvcHRzKTtcbn1cbiJdfQ==