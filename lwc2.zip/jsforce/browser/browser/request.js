import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.promise";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.split";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _keysInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/keys";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _trimInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/trim";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context9; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context9 = Object.prototype.toString.call(o)).call(_context9, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context7; _forEachInstanceProperty(_context7 = ownKeys(Object(source), true)).call(_context7, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context8; _forEachInstanceProperty(_context8 = ownKeys(Object(source))).call(_context8, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import { createHttpRequestHandlerStreams, executeWithTimeout, isRedirect, performRedirectRequest } from '../request-helper';
import { readAll } from '../util/stream';

/**
 * As the request streming is not yet supported on major browsers,
 * it is set to false for now.
 */
var supportsReadableStream = false;
/*
(async () => {
  try {
    if (
      typeof fetch === 'function' &&
      typeof Request === 'function' &&
      typeof ReadableStream === 'function'
    ) {
      // this feature detection requires dummy POST request
      const req = new Request('data:text/plain,', {
        method: 'POST',
        body: new ReadableStream(),
      });
      // if it has content-type header it doesn't regard body as stream
      if (req.headers.has('Content-Type')) {
        return false;
      }
      await (await fetch(req)).text();
      return true;
    }
  } catch (e) {
    // error might occur in env with CSP without connect-src data:
    return false;
  }
  return false;
})();
*/

/**
 *
 */

function toWhatwgReadableStream(ins) {
  return new ReadableStream({
    start: function start(controller) {
      ins.on('data', function (chunk) {
        return controller.enqueue(chunk);
      });
      ins.on('end', function () {
        return controller.close();
      });
    }
  });
}
/**
 *
 */


function readWhatwgReadableStream(_x, _x2) {
  return _readWhatwgReadableStream.apply(this, arguments);
}
/**
 *
 */


function _readWhatwgReadableStream() {
  _readWhatwgReadableStream = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(rs, outs) {
    var reader, readAndWrite, _readAndWrite;

    return _regeneratorRuntime.wrap(function _callee2$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _readAndWrite = function _readAndWrite3() {
              _readAndWrite = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
                var _yield$reader$read, done, value;

                return _regeneratorRuntime.wrap(function _callee$(_context2) {
                  while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        _context2.next = 2;
                        return reader.read();

                      case 2:
                        _yield$reader$read = _context2.sent;
                        done = _yield$reader$read.done;
                        value = _yield$reader$read.value;

                        if (!done) {
                          _context2.next = 8;
                          break;
                        }

                        outs.end();
                        return _context2.abrupt("return", false);

                      case 8:
                        outs.write(value);
                        return _context2.abrupt("return", true);

                      case 10:
                      case "end":
                        return _context2.stop();
                    }
                  }
                }, _callee);
              }));
              return _readAndWrite.apply(this, arguments);
            };

            readAndWrite = function _readAndWrite2() {
              return _readAndWrite.apply(this, arguments);
            };

            reader = rs.getReader();

          case 3:
            _context3.next = 5;
            return readAndWrite();

          case 5:
            if (!_context3.sent) {
              _context3.next = 9;
              break;
            }

            ;
            _context3.next = 3;
            break;

          case 9:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee2);
  }));
  return _readWhatwgReadableStream.apply(this, arguments);
}

function startFetchRequest(_x3, _x4, _x5, _x6, _x7) {
  return _startFetchRequest.apply(this, arguments);
}
/**
 *
 */


function _startFetchRequest() {
  _startFetchRequest = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(request, options, input, output, emitter) {
    var _context4;

    var counter,
        followRedirect,
        url,
        reqBody,
        rreq,
        body,
        controller,
        res,
        headers,
        _iterator,
        _step,
        headerName,
        response,
        _args3 = arguments;

    return _regeneratorRuntime.wrap(function _callee3$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            counter = _args3.length > 5 && _args3[5] !== undefined ? _args3[5] : 0;
            followRedirect = options.followRedirect;
            url = request.url, reqBody = request.body, rreq = _objectWithoutProperties(request, ["url", "body"]);

            if (!(input && /^(post|put|patch)$/i.test(request.method))) {
              _context5.next = 14;
              break;
            }

            if (!supportsReadableStream) {
              _context5.next = 8;
              break;
            }

            _context5.t1 = toWhatwgReadableStream(input);
            _context5.next = 11;
            break;

          case 8:
            _context5.next = 10;
            return readAll(input);

          case 10:
            _context5.t1 = _context5.sent;

          case 11:
            _context5.t0 = _context5.t1;
            _context5.next = 15;
            break;

          case 14:
            _context5.t0 = undefined;

          case 15:
            body = _context5.t0;
            controller = typeof AbortController !== 'undefined' ? new AbortController() : undefined;
            _context5.next = 19;
            return executeWithTimeout(function () {
              return fetch(url, _objectSpread(_objectSpread(_objectSpread(_objectSpread({}, rreq), body ? {
                body: body
              } : {}), {}, {
                redirect: 'manual'
              }, controller ? {
                signal: controller.signal
              } : {}), {
                allowHTTP1ForStreamingUpload: true
              }));
            }, options.timeout, function () {
              return controller === null || controller === void 0 ? void 0 : controller.abort();
            });

          case 19:
            res = _context5.sent;
            headers = {};
            _iterator = _createForOfIteratorHelper(_keysInstanceProperty(_context4 = res.headers).call(_context4));

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                headerName = _step.value;
                headers[headerName.toLowerCase()] = res.headers.get(headerName);
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            response = {
              statusCode: res.status,
              headers: headers
            };

            if (!(followRedirect && isRedirect(response.statusCode))) {
              _context5.next = 27;
              break;
            }

            try {
              performRedirectRequest(request, response, followRedirect, counter, function (req) {
                return startFetchRequest(req, options, undefined, output, emitter, counter + 1);
              });
            } catch (err) {
              emitter.emit('error', err);
            }

            return _context5.abrupt("return");

          case 27:
            emitter.emit('response', response);

            if (res.body) {
              readWhatwgReadableStream(res.body, output);
            } else {
              output.end();
            }

          case 29:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee3);
  }));
  return _startFetchRequest.apply(this, arguments);
}

function getResponseHeaderNames(xhr) {
  var _context;

  var headerLines = _filterInstanceProperty(_context = (xhr.getAllResponseHeaders() || '').split(/[\r\n]+/)).call(_context, function (l) {
    return _trimInstanceProperty(l).call(l) !== '';
  });

  return _mapInstanceProperty(headerLines).call(headerLines, function (headerLine) {
    return headerLine.split(/\s*:/)[0].toLowerCase();
  });
}
/**
 *
 */


function startXmlHttpRequest(_x8, _x9, _x10, _x11, _x12) {
  return _startXmlHttpRequest.apply(this, arguments);
}
/**
 *
 */


function _startXmlHttpRequest() {
  _startXmlHttpRequest = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(request, options, input, output, emitter) {
    var counter,
        method,
        url,
        reqHeaders,
        followRedirect,
        reqBody,
        xhr,
        headerNames,
        headers,
        response,
        body,
        _args4 = arguments;
    return _regeneratorRuntime.wrap(function _callee4$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            counter = _args4.length > 5 && _args4[5] !== undefined ? _args4[5] : 0;
            method = request.method, url = request.url, reqHeaders = request.headers;
            followRedirect = options.followRedirect;

            if (!(input && /^(post|put|patch)$/i.test(method))) {
              _context6.next = 9;
              break;
            }

            _context6.next = 6;
            return readAll(input);

          case 6:
            _context6.t0 = _context6.sent;
            _context6.next = 10;
            break;

          case 9:
            _context6.t0 = null;

          case 10:
            reqBody = _context6.t0;
            xhr = new XMLHttpRequest();
            _context6.next = 14;
            return executeWithTimeout(function () {
              xhr.open(method, url);

              if (reqHeaders) {
                for (var header in reqHeaders) {
                  xhr.setRequestHeader(header, reqHeaders[header]);
                }
              }

              if (options.timeout) {
                xhr.timeout = options.timeout;
              }

              xhr.responseType = 'arraybuffer';
              xhr.send(reqBody);
              return new _Promise(function (resolve, reject) {
                xhr.onload = function () {
                  return resolve();
                };

                xhr.onerror = reject;
                xhr.ontimeout = reject;
                xhr.onabort = reject;
              });
            }, options.timeout, function () {
              return xhr.abort();
            });

          case 14:
            headerNames = getResponseHeaderNames(xhr);
            headers = _reduceInstanceProperty(headerNames).call(headerNames, function (headers, headerName) {
              return _objectSpread(_objectSpread({}, headers), {}, _defineProperty({}, headerName, xhr.getResponseHeader(headerName) || ''));
            }, {});
            response = {
              statusCode: xhr.status,
              headers: headers
            };

            if (!(followRedirect && isRedirect(response.statusCode))) {
              _context6.next = 20;
              break;
            }

            try {
              performRedirectRequest(request, response, followRedirect, counter, function (req) {
                return startXmlHttpRequest(req, options, undefined, output, emitter, counter + 1);
              });
            } catch (err) {
              emitter.emit('error', err);
            }

            return _context6.abrupt("return");

          case 20:
            if (!response.statusCode) {
              response.statusCode = 400;
              body = Buffer.from('Access Declined');
            } else {
              body = Buffer.from(xhr.response);
            }

            emitter.emit('response', response);
            output.write(body);
            output.end();

          case 24:
          case "end":
            return _context6.stop();
        }
      }
    }, _callee4);
  }));
  return _startXmlHttpRequest.apply(this, arguments);
}

var defaults = {};
/**
 *
 */

export function setDefaults(defaults_) {
  defaults = defaults_;
}
/**
 *
 */

export default function request(req) {
  var options_ = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = _objectSpread(_objectSpread({}, defaults), options_);

  var _createHttpRequestHan = createHttpRequestHandlerStreams(req),
      input = _createHttpRequestHan.input,
      output = _createHttpRequestHan.output,
      stream = _createHttpRequestHan.stream;

  if (typeof window !== 'undefined' && typeof window.fetch === 'function') {
    startFetchRequest(req, options, input, output, stream);
  } else {
    startXmlHttpRequest(req, options, input, output, stream);
  }

  return stream;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9icm93c2VyL3JlcXVlc3QudHMiXSwibmFtZXMiOlsiY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImlzUmVkaXJlY3QiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwicmVhZEFsbCIsInN1cHBvcnRzUmVhZGFibGVTdHJlYW0iLCJ0b1doYXR3Z1JlYWRhYmxlU3RyZWFtIiwiaW5zIiwiUmVhZGFibGVTdHJlYW0iLCJzdGFydCIsImNvbnRyb2xsZXIiLCJvbiIsImNodW5rIiwiZW5xdWV1ZSIsImNsb3NlIiwicmVhZFdoYXR3Z1JlYWRhYmxlU3RyZWFtIiwicnMiLCJvdXRzIiwicmVhZEFuZFdyaXRlIiwicmVhZGVyIiwicmVhZCIsImRvbmUiLCJ2YWx1ZSIsImVuZCIsIndyaXRlIiwiZ2V0UmVhZGVyIiwic3RhcnRGZXRjaFJlcXVlc3QiLCJyZXF1ZXN0Iiwib3B0aW9ucyIsImlucHV0Iiwib3V0cHV0IiwiZW1pdHRlciIsImNvdW50ZXIiLCJmb2xsb3dSZWRpcmVjdCIsInVybCIsInJlcUJvZHkiLCJib2R5IiwicnJlcSIsInRlc3QiLCJtZXRob2QiLCJ1bmRlZmluZWQiLCJBYm9ydENvbnRyb2xsZXIiLCJmZXRjaCIsInJlZGlyZWN0Iiwic2lnbmFsIiwiYWxsb3dIVFRQMUZvclN0cmVhbWluZ1VwbG9hZCIsInRpbWVvdXQiLCJhYm9ydCIsInJlcyIsImhlYWRlcnMiLCJoZWFkZXJOYW1lIiwidG9Mb3dlckNhc2UiLCJnZXQiLCJyZXNwb25zZSIsInN0YXR1c0NvZGUiLCJzdGF0dXMiLCJyZXEiLCJlcnIiLCJlbWl0IiwiZ2V0UmVzcG9uc2VIZWFkZXJOYW1lcyIsInhociIsImhlYWRlckxpbmVzIiwiZ2V0QWxsUmVzcG9uc2VIZWFkZXJzIiwic3BsaXQiLCJsIiwiaGVhZGVyTGluZSIsInN0YXJ0WG1sSHR0cFJlcXVlc3QiLCJyZXFIZWFkZXJzIiwiWE1MSHR0cFJlcXVlc3QiLCJvcGVuIiwiaGVhZGVyIiwic2V0UmVxdWVzdEhlYWRlciIsInJlc3BvbnNlVHlwZSIsInNlbmQiLCJyZXNvbHZlIiwicmVqZWN0Iiwib25sb2FkIiwib25lcnJvciIsIm9udGltZW91dCIsIm9uYWJvcnQiLCJoZWFkZXJOYW1lcyIsImdldFJlc3BvbnNlSGVhZGVyIiwiQnVmZmVyIiwiZnJvbSIsImRlZmF1bHRzIiwic2V0RGVmYXVsdHMiLCJkZWZhdWx0c18iLCJvcHRpb25zXyIsInN0cmVhbSIsIndpbmRvdyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsU0FDRUEsK0JBREYsRUFFRUMsa0JBRkYsRUFHRUMsVUFIRixFQUlFQyxzQkFKRixRQUtPLG1CQUxQO0FBTUEsU0FBU0MsT0FBVCxRQUF3QixnQkFBeEI7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxzQkFBc0IsR0FBRyxLQUEvQjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0Msc0JBQVQsQ0FBZ0NDLEdBQWhDLEVBQStEO0FBQzdELFNBQU8sSUFBSUMsY0FBSixDQUFtQjtBQUN4QkMsSUFBQUEsS0FEd0IsaUJBQ2xCQyxVQURrQixFQUNOO0FBQ2hCSCxNQUFBQSxHQUFHLENBQUNJLEVBQUosQ0FBTyxNQUFQLEVBQWUsVUFBQ0MsS0FBRDtBQUFBLGVBQVdGLFVBQVUsQ0FBQ0csT0FBWCxDQUFtQkQsS0FBbkIsQ0FBWDtBQUFBLE9BQWY7QUFDQUwsTUFBQUEsR0FBRyxDQUFDSSxFQUFKLENBQU8sS0FBUCxFQUFjO0FBQUEsZUFBTUQsVUFBVSxDQUFDSSxLQUFYLEVBQU47QUFBQSxPQUFkO0FBQ0Q7QUFKdUIsR0FBbkIsQ0FBUDtBQU1EO0FBRUQ7QUFDQTtBQUNBOzs7U0FDZUMsd0I7OztBQWNmO0FBQ0E7QUFDQTs7Ozt1RkFoQkEsa0JBQXdDQyxFQUF4QyxFQUE0REMsSUFBNUQ7QUFBQSxnQkFFaUJDLFlBRmpCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1RkFFRTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFDZ0NDLE1BQU0sQ0FBQ0MsSUFBUCxFQURoQzs7QUFBQTtBQUFBO0FBQ1VDLHdCQUFBQSxJQURWLHNCQUNVQSxJQURWO0FBQ2dCQyx3QkFBQUEsS0FEaEIsc0JBQ2dCQSxLQURoQjs7QUFBQSw2QkFFTUQsSUFGTjtBQUFBO0FBQUE7QUFBQTs7QUFHSUosd0JBQUFBLElBQUksQ0FBQ00sR0FBTDtBQUhKLDBEQUlXLEtBSlg7O0FBQUE7QUFNRU4sd0JBQUFBLElBQUksQ0FBQ08sS0FBTCxDQUFXRixLQUFYO0FBTkYsMERBT1MsSUFQVDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBQUE7QUFBQTs7QUFFaUJKLFlBQUFBLFlBRmpCO0FBQUE7QUFBQTs7QUFDUUMsWUFBQUEsTUFEUixHQUNpQkgsRUFBRSxDQUFDUyxTQUFILEVBRGpCOztBQUFBO0FBQUE7QUFBQSxtQkFXZVAsWUFBWSxFQVgzQjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVc4QjtBQVg5QjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7U0FpQmVRLGlCOzs7QUFvRWY7QUFDQTtBQUNBOzs7O2dGQXRFQSxrQkFDRUMsT0FERixFQUVFQyxPQUZGLEVBR0VDLEtBSEYsRUFJRUMsTUFKRixFQUtFQyxPQUxGO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1FQyxZQUFBQSxPQU5GLDhEQU1vQixDQU5wQjtBQVFVQyxZQUFBQSxjQVJWLEdBUTZCTCxPQVI3QixDQVFVSyxjQVJWO0FBU1VDLFlBQUFBLEdBVFYsR0FTMENQLE9BVDFDLENBU1VPLEdBVFYsRUFTcUJDLE9BVHJCLEdBUzBDUixPQVQxQyxDQVNlUyxJQVRmLEVBU2lDQyxJQVRqQyw0QkFTMENWLE9BVDFDOztBQUFBLGtCQVdJRSxLQUFLLElBQUksc0JBQXNCUyxJQUF0QixDQUEyQlgsT0FBTyxDQUFDWSxNQUFuQyxDQVhiO0FBQUE7QUFBQTtBQUFBOztBQUFBLGlCQVlRbEMsc0JBWlI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsMkJBYVVDLHNCQUFzQixDQUFDdUIsS0FBRCxDQWJoQztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLG1CQWNnQnpCLE9BQU8sQ0FBQ3lCLEtBQUQsQ0FkdkI7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJCQWVRVyxTQWZSOztBQUFBO0FBVVFKLFlBQUFBLElBVlI7QUFnQlExQixZQUFBQSxVQWhCUixHQWlCSSxPQUFPK0IsZUFBUCxLQUEyQixXQUEzQixHQUF5QyxJQUFJQSxlQUFKLEVBQXpDLEdBQWlFRCxTQWpCckU7QUFBQTtBQUFBLG1CQWtCb0J2QyxrQkFBa0IsQ0FDbEM7QUFBQSxxQkFDRXlDLEtBQUssQ0FBQ1IsR0FBRCw4REFDQUcsSUFEQSxHQUVDRCxJQUFJLEdBQUc7QUFBRUEsZ0JBQUFBLElBQUksRUFBSkE7QUFBRixlQUFILEdBQWMsRUFGbkI7QUFHSE8sZ0JBQUFBLFFBQVEsRUFBRTtBQUhQLGlCQUlDakMsVUFBVSxHQUFHO0FBQUVrQyxnQkFBQUEsTUFBTSxFQUFFbEMsVUFBVSxDQUFDa0M7QUFBckIsZUFBSCxHQUFtQyxFQUo5QyxHQUtDO0FBQUVDLGdCQUFBQSw0QkFBNEIsRUFBRTtBQUFoQyxlQUxELEVBRFA7QUFBQSxhQURrQyxFQVNsQ2pCLE9BQU8sQ0FBQ2tCLE9BVDBCLEVBVWxDO0FBQUEscUJBQU1wQyxVQUFOLGFBQU1BLFVBQU4sdUJBQU1BLFVBQVUsQ0FBRXFDLEtBQVosRUFBTjtBQUFBLGFBVmtDLENBbEJ0Qzs7QUFBQTtBQWtCUUMsWUFBQUEsR0FsQlI7QUE4QlFDLFlBQUFBLE9BOUJSLEdBOEIwQyxFQTlCMUM7QUFBQSxtREErQjJCLGtDQUFBRCxHQUFHLENBQUNDLE9BQUosaUJBL0IzQjs7QUFBQTtBQStCRSxrRUFBNkM7QUFBbENDLGdCQUFBQSxVQUFrQztBQUMzQ0QsZ0JBQUFBLE9BQU8sQ0FBQ0MsVUFBVSxDQUFDQyxXQUFYLEVBQUQsQ0FBUCxHQUFvQ0gsR0FBRyxDQUFDQyxPQUFKLENBQVlHLEdBQVosQ0FBZ0JGLFVBQWhCLENBQXBDO0FBQ0Q7QUFqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFrQ1FHLFlBQUFBLFFBbENSLEdBa0NtQjtBQUNmQyxjQUFBQSxVQUFVLEVBQUVOLEdBQUcsQ0FBQ08sTUFERDtBQUVmTixjQUFBQSxPQUFPLEVBQVBBO0FBRmUsYUFsQ25COztBQUFBLGtCQXNDTWhCLGNBQWMsSUFBSS9CLFVBQVUsQ0FBQ21ELFFBQVEsQ0FBQ0MsVUFBVixDQXRDbEM7QUFBQTtBQUFBO0FBQUE7O0FBdUNJLGdCQUFJO0FBQ0ZuRCxjQUFBQSxzQkFBc0IsQ0FDcEJ3QixPQURvQixFQUVwQjBCLFFBRm9CLEVBR3BCcEIsY0FIb0IsRUFJcEJELE9BSm9CLEVBS3BCLFVBQUN3QixHQUFEO0FBQUEsdUJBQ0U5QixpQkFBaUIsQ0FDZjhCLEdBRGUsRUFFZjVCLE9BRmUsRUFHZlksU0FIZSxFQUlmVixNQUplLEVBS2ZDLE9BTGUsRUFNZkMsT0FBTyxHQUFHLENBTkssQ0FEbkI7QUFBQSxlQUxvQixDQUF0QjtBQWVELGFBaEJELENBZ0JFLE9BQU95QixHQUFQLEVBQVk7QUFDWjFCLGNBQUFBLE9BQU8sQ0FBQzJCLElBQVIsQ0FBYSxPQUFiLEVBQXNCRCxHQUF0QjtBQUNEOztBQXpETDs7QUFBQTtBQTRERTFCLFlBQUFBLE9BQU8sQ0FBQzJCLElBQVIsQ0FBYSxVQUFiLEVBQXlCTCxRQUF6Qjs7QUFDQSxnQkFBSUwsR0FBRyxDQUFDWixJQUFSLEVBQWM7QUFDWnJCLGNBQUFBLHdCQUF3QixDQUFDaUMsR0FBRyxDQUFDWixJQUFMLEVBQVdOLE1BQVgsQ0FBeEI7QUFDRCxhQUZELE1BRU87QUFDTEEsY0FBQUEsTUFBTSxDQUFDUCxHQUFQO0FBQ0Q7O0FBakVIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7QUF1RUEsU0FBU29DLHNCQUFULENBQWdDQyxHQUFoQyxFQUFxRDtBQUFBOztBQUNuRCxNQUFNQyxXQUFXLEdBQUcsb0NBQUNELEdBQUcsQ0FBQ0UscUJBQUosTUFBK0IsRUFBaEMsRUFDakJDLEtBRGlCLENBQ1gsU0FEVyxrQkFFVixVQUFDQyxDQUFEO0FBQUEsV0FBTyxzQkFBQUEsQ0FBQyxNQUFELENBQUFBLENBQUMsTUFBWSxFQUFwQjtBQUFBLEdBRlUsQ0FBcEI7O0FBR0EsU0FBTyxxQkFBQUgsV0FBVyxNQUFYLENBQUFBLFdBQVcsRUFBSyxVQUFDSSxVQUFEO0FBQUEsV0FDckJBLFVBQVUsQ0FBQ0YsS0FBWCxDQUFpQixNQUFqQixFQUF5QixDQUF6QixFQUE0QlosV0FBNUIsRUFEcUI7QUFBQSxHQUFMLENBQWxCO0FBR0Q7QUFFRDtBQUNBO0FBQ0E7OztTQUNlZSxtQjs7O0FBa0ZmO0FBQ0E7QUFDQTs7OztrRkFwRkEsa0JBQ0V2QyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsS0FIRixFQUlFQyxNQUpGLEVBS0VDLE9BTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1FQyxZQUFBQSxPQU5GLDhEQU1vQixDQU5wQjtBQVFVTyxZQUFBQSxNQVJWLEdBUStDWixPQVIvQyxDQVFVWSxNQVJWLEVBUWtCTCxHQVJsQixHQVErQ1AsT0FSL0MsQ0FRa0JPLEdBUmxCLEVBUWdDaUMsVUFSaEMsR0FRK0N4QyxPQVIvQyxDQVF1QnNCLE9BUnZCO0FBU1VoQixZQUFBQSxjQVRWLEdBUzZCTCxPQVQ3QixDQVNVSyxjQVRWOztBQUFBLGtCQVdJSixLQUFLLElBQUksc0JBQXNCUyxJQUF0QixDQUEyQkMsTUFBM0IsQ0FYYjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLG1CQVd3RG5DLE9BQU8sQ0FBQ3lCLEtBQUQsQ0FYL0Q7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQkFXeUUsSUFYekU7O0FBQUE7QUFVUU0sWUFBQUEsT0FWUjtBQVlReUIsWUFBQUEsR0FaUixHQVljLElBQUlRLGNBQUosRUFaZDtBQUFBO0FBQUEsbUJBYVFuRSxrQkFBa0IsQ0FDdEIsWUFBTTtBQUNKMkQsY0FBQUEsR0FBRyxDQUFDUyxJQUFKLENBQVM5QixNQUFULEVBQWlCTCxHQUFqQjs7QUFDQSxrQkFBSWlDLFVBQUosRUFBZ0I7QUFDZCxxQkFBSyxJQUFNRyxNQUFYLElBQXFCSCxVQUFyQixFQUFpQztBQUMvQlAsa0JBQUFBLEdBQUcsQ0FBQ1csZ0JBQUosQ0FBcUJELE1BQXJCLEVBQTZCSCxVQUFVLENBQUNHLE1BQUQsQ0FBdkM7QUFDRDtBQUNGOztBQUNELGtCQUFJMUMsT0FBTyxDQUFDa0IsT0FBWixFQUFxQjtBQUNuQmMsZ0JBQUFBLEdBQUcsQ0FBQ2QsT0FBSixHQUFjbEIsT0FBTyxDQUFDa0IsT0FBdEI7QUFDRDs7QUFDRGMsY0FBQUEsR0FBRyxDQUFDWSxZQUFKLEdBQW1CLGFBQW5CO0FBQ0FaLGNBQUFBLEdBQUcsQ0FBQ2EsSUFBSixDQUFTdEMsT0FBVDtBQUNBLHFCQUFPLGFBQWtCLFVBQUN1QyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDNUNmLGdCQUFBQSxHQUFHLENBQUNnQixNQUFKLEdBQWE7QUFBQSx5QkFBTUYsT0FBTyxFQUFiO0FBQUEsaUJBQWI7O0FBQ0FkLGdCQUFBQSxHQUFHLENBQUNpQixPQUFKLEdBQWNGLE1BQWQ7QUFDQWYsZ0JBQUFBLEdBQUcsQ0FBQ2tCLFNBQUosR0FBZ0JILE1BQWhCO0FBQ0FmLGdCQUFBQSxHQUFHLENBQUNtQixPQUFKLEdBQWNKLE1BQWQ7QUFDRCxlQUxNLENBQVA7QUFNRCxhQW5CcUIsRUFvQnRCL0MsT0FBTyxDQUFDa0IsT0FwQmMsRUFxQnRCO0FBQUEscUJBQU1jLEdBQUcsQ0FBQ2IsS0FBSixFQUFOO0FBQUEsYUFyQnNCLENBYjFCOztBQUFBO0FBb0NRaUMsWUFBQUEsV0FwQ1IsR0FvQ3NCckIsc0JBQXNCLENBQUNDLEdBQUQsQ0FwQzVDO0FBcUNRWCxZQUFBQSxPQXJDUixHQXFDa0Isd0JBQUErQixXQUFXLE1BQVgsQ0FBQUEsV0FBVyxFQUN6QixVQUFDL0IsT0FBRCxFQUFVQyxVQUFWO0FBQUEscURBQ0tELE9BREwsMkJBRUdDLFVBRkgsRUFFZ0JVLEdBQUcsQ0FBQ3FCLGlCQUFKLENBQXNCL0IsVUFBdEIsS0FBcUMsRUFGckQ7QUFBQSxhQUR5QixFQUt6QixFQUx5QixDQXJDN0I7QUE0Q1FHLFlBQUFBLFFBNUNSLEdBNENtQjtBQUNmQyxjQUFBQSxVQUFVLEVBQUVNLEdBQUcsQ0FBQ0wsTUFERDtBQUVmTixjQUFBQSxPQUFPLEVBQUVBO0FBRk0sYUE1Q25COztBQUFBLGtCQWdETWhCLGNBQWMsSUFBSS9CLFVBQVUsQ0FBQ21ELFFBQVEsQ0FBQ0MsVUFBVixDQWhEbEM7QUFBQTtBQUFBO0FBQUE7O0FBaURJLGdCQUFJO0FBQ0ZuRCxjQUFBQSxzQkFBc0IsQ0FDcEJ3QixPQURvQixFQUVwQjBCLFFBRm9CLEVBR3BCcEIsY0FIb0IsRUFJcEJELE9BSm9CLEVBS3BCLFVBQUN3QixHQUFEO0FBQUEsdUJBQ0VVLG1CQUFtQixDQUNqQlYsR0FEaUIsRUFFakI1QixPQUZpQixFQUdqQlksU0FIaUIsRUFJakJWLE1BSmlCLEVBS2pCQyxPQUxpQixFQU1qQkMsT0FBTyxHQUFHLENBTk8sQ0FEckI7QUFBQSxlQUxvQixDQUF0QjtBQWVELGFBaEJELENBZ0JFLE9BQU95QixHQUFQLEVBQVk7QUFDWjFCLGNBQUFBLE9BQU8sQ0FBQzJCLElBQVIsQ0FBYSxPQUFiLEVBQXNCRCxHQUF0QjtBQUNEOztBQW5FTDs7QUFBQTtBQXVFRSxnQkFBSSxDQUFDSixRQUFRLENBQUNDLFVBQWQsRUFBMEI7QUFDeEJELGNBQUFBLFFBQVEsQ0FBQ0MsVUFBVCxHQUFzQixHQUF0QjtBQUNBbEIsY0FBQUEsSUFBSSxHQUFHOEMsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosQ0FBUDtBQUNELGFBSEQsTUFHTztBQUNML0MsY0FBQUEsSUFBSSxHQUFHOEMsTUFBTSxDQUFDQyxJQUFQLENBQVl2QixHQUFHLENBQUNQLFFBQWhCLENBQVA7QUFDRDs7QUFDRHRCLFlBQUFBLE9BQU8sQ0FBQzJCLElBQVIsQ0FBYSxVQUFiLEVBQXlCTCxRQUF6QjtBQUNBdkIsWUFBQUEsTUFBTSxDQUFDTixLQUFQLENBQWFZLElBQWI7QUFDQU4sWUFBQUEsTUFBTSxDQUFDUCxHQUFQOztBQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBcUZBLElBQUk2RCxRQUE0QixHQUFHLEVBQW5DO0FBRUE7QUFDQTtBQUNBOztBQUNBLE9BQU8sU0FBU0MsV0FBVCxDQUFxQkMsU0FBckIsRUFBb0Q7QUFDekRGLEVBQUFBLFFBQVEsR0FBR0UsU0FBWDtBQUNEO0FBRUQ7QUFDQTtBQUNBOztBQUNBLGVBQWUsU0FBUzNELE9BQVQsQ0FDYjZCLEdBRGEsRUFHYjtBQUFBLE1BREErQixRQUNBLHVFQUQrQixFQUMvQjs7QUFDQSxNQUFNM0QsT0FBTyxtQ0FBUXdELFFBQVIsR0FBcUJHLFFBQXJCLENBQWI7O0FBREEsOEJBRWtDdkYsK0JBQStCLENBQUN3RCxHQUFELENBRmpFO0FBQUEsTUFFUTNCLEtBRlIseUJBRVFBLEtBRlI7QUFBQSxNQUVlQyxNQUZmLHlCQUVlQSxNQUZmO0FBQUEsTUFFdUIwRCxNQUZ2Qix5QkFFdUJBLE1BRnZCOztBQUdBLE1BQUksT0FBT0MsTUFBUCxLQUFrQixXQUFsQixJQUFpQyxPQUFPQSxNQUFNLENBQUMvQyxLQUFkLEtBQXdCLFVBQTdELEVBQXlFO0FBQ3ZFaEIsSUFBQUEsaUJBQWlCLENBQUM4QixHQUFELEVBQU01QixPQUFOLEVBQWVDLEtBQWYsRUFBc0JDLE1BQXRCLEVBQThCMEQsTUFBOUIsQ0FBakI7QUFDRCxHQUZELE1BRU87QUFDTHRCLElBQUFBLG1CQUFtQixDQUFDVixHQUFELEVBQU01QixPQUFOLEVBQWVDLEtBQWYsRUFBc0JDLE1BQXRCLEVBQThCMEQsTUFBOUIsQ0FBbkI7QUFDRDs7QUFDRCxTQUFPQSxNQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgUmVhZGFibGUsIFdyaXRhYmxlIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCB7XG4gIGNyZWF0ZUh0dHBSZXF1ZXN0SGFuZGxlclN0cmVhbXMsXG4gIGV4ZWN1dGVXaXRoVGltZW91dCxcbiAgaXNSZWRpcmVjdCxcbiAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdCxcbn0gZnJvbSAnLi4vcmVxdWVzdC1oZWxwZXInO1xuaW1wb3J0IHsgcmVhZEFsbCB9IGZyb20gJy4uL3V0aWwvc3RyZWFtJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBIdHRwUmVxdWVzdE9wdGlvbnMgfSBmcm9tICcuLi90eXBlcyc7XG5cbi8qKlxuICogQXMgdGhlIHJlcXVlc3Qgc3RyZW1pbmcgaXMgbm90IHlldCBzdXBwb3J0ZWQgb24gbWFqb3IgYnJvd3NlcnMsXG4gKiBpdCBpcyBzZXQgdG8gZmFsc2UgZm9yIG5vdy5cbiAqL1xuY29uc3Qgc3VwcG9ydHNSZWFkYWJsZVN0cmVhbSA9IGZhbHNlO1xuXG4vKlxuKGFzeW5jICgpID0+IHtcbiAgdHJ5IHtcbiAgICBpZiAoXG4gICAgICB0eXBlb2YgZmV0Y2ggPT09ICdmdW5jdGlvbicgJiZcbiAgICAgIHR5cGVvZiBSZXF1ZXN0ID09PSAnZnVuY3Rpb24nICYmXG4gICAgICB0eXBlb2YgUmVhZGFibGVTdHJlYW0gPT09ICdmdW5jdGlvbidcbiAgICApIHtcbiAgICAgIC8vIHRoaXMgZmVhdHVyZSBkZXRlY3Rpb24gcmVxdWlyZXMgZHVtbXkgUE9TVCByZXF1ZXN0XG4gICAgICBjb25zdCByZXEgPSBuZXcgUmVxdWVzdCgnZGF0YTp0ZXh0L3BsYWluLCcsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IG5ldyBSZWFkYWJsZVN0cmVhbSgpLFxuICAgICAgfSk7XG4gICAgICAvLyBpZiBpdCBoYXMgY29udGVudC10eXBlIGhlYWRlciBpdCBkb2Vzbid0IHJlZ2FyZCBib2R5IGFzIHN0cmVhbVxuICAgICAgaWYgKHJlcS5oZWFkZXJzLmhhcygnQ29udGVudC1UeXBlJykpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgYXdhaXQgKGF3YWl0IGZldGNoKHJlcSkpLnRleHQoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIGVycm9yIG1pZ2h0IG9jY3VyIGluIGVudiB3aXRoIENTUCB3aXRob3V0IGNvbm5lY3Qtc3JjIGRhdGE6XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn0pKCk7XG4qL1xuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHRvV2hhdHdnUmVhZGFibGVTdHJlYW0oaW5zOiBSZWFkYWJsZSk6IFJlYWRhYmxlU3RyZWFtIHtcbiAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgc3RhcnQoY29udHJvbGxlcikge1xuICAgICAgaW5zLm9uKCdkYXRhJywgKGNodW5rKSA9PiBjb250cm9sbGVyLmVucXVldWUoY2h1bmspKTtcbiAgICAgIGlucy5vbignZW5kJywgKCkgPT4gY29udHJvbGxlci5jbG9zZSgpKTtcbiAgICB9LFxuICB9KTtcbn1cblxuLyoqXG4gKlxuICovXG5hc3luYyBmdW5jdGlvbiByZWFkV2hhdHdnUmVhZGFibGVTdHJlYW0ocnM6IFJlYWRhYmxlU3RyZWFtLCBvdXRzOiBXcml0YWJsZSkge1xuICBjb25zdCByZWFkZXIgPSBycy5nZXRSZWFkZXIoKTtcbiAgYXN5bmMgZnVuY3Rpb24gcmVhZEFuZFdyaXRlKCkge1xuICAgIGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG4gICAgaWYgKGRvbmUpIHtcbiAgICAgIG91dHMuZW5kKCk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIG91dHMud3JpdGUodmFsdWUpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHdoaWxlIChhd2FpdCByZWFkQW5kV3JpdGUoKSk7XG59XG5cbi8qKlxuICpcbiAqL1xuYXN5bmMgZnVuY3Rpb24gc3RhcnRGZXRjaFJlcXVlc3QoXG4gIHJlcXVlc3Q6IEh0dHBSZXF1ZXN0LFxuICBvcHRpb25zOiBIdHRwUmVxdWVzdE9wdGlvbnMsXG4gIGlucHV0OiBSZWFkYWJsZSB8IHVuZGVmaW5lZCxcbiAgb3V0cHV0OiBXcml0YWJsZSxcbiAgZW1pdHRlcjogRXZlbnRFbWl0dGVyLFxuICBjb3VudGVyOiBudW1iZXIgPSAwLFxuKSB7XG4gIGNvbnN0IHsgZm9sbG93UmVkaXJlY3QgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHsgdXJsLCBib2R5OiByZXFCb2R5LCAuLi5ycmVxIH0gPSByZXF1ZXN0O1xuICBjb25zdCBib2R5ID1cbiAgICBpbnB1dCAmJiAvXihwb3N0fHB1dHxwYXRjaCkkL2kudGVzdChyZXF1ZXN0Lm1ldGhvZClcbiAgICAgID8gc3VwcG9ydHNSZWFkYWJsZVN0cmVhbVxuICAgICAgICA/IHRvV2hhdHdnUmVhZGFibGVTdHJlYW0oaW5wdXQpXG4gICAgICAgIDogYXdhaXQgcmVhZEFsbChpbnB1dClcbiAgICAgIDogdW5kZWZpbmVkO1xuICBjb25zdCBjb250cm9sbGVyID1cbiAgICB0eXBlb2YgQWJvcnRDb250cm9sbGVyICE9PSAndW5kZWZpbmVkJyA/IG5ldyBBYm9ydENvbnRyb2xsZXIoKSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgcmVzID0gYXdhaXQgZXhlY3V0ZVdpdGhUaW1lb3V0KFxuICAgICgpID0+XG4gICAgICBmZXRjaCh1cmwsIHtcbiAgICAgICAgLi4ucnJlcSxcbiAgICAgICAgLi4uKGJvZHkgPyB7IGJvZHkgfSA6IHt9KSxcbiAgICAgICAgcmVkaXJlY3Q6ICdtYW51YWwnLFxuICAgICAgICAuLi4oY29udHJvbGxlciA/IHsgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCB9IDoge30pLFxuICAgICAgICAuLi4oeyBhbGxvd0hUVFAxRm9yU3RyZWFtaW5nVXBsb2FkOiB0cnVlIH0gYXMgYW55KSwgLy8gQ2hyb21lIGFsbG93cyByZXF1ZXN0IHN0cmVhbSBvbmx5IGluIEhUVFAyL1FVSUMgdW5sZXNzIHRoaXMgb3B0LWluIGZsYWdcbiAgICAgIH0pLFxuICAgIG9wdGlvbnMudGltZW91dCxcbiAgICAoKSA9PiBjb250cm9sbGVyPy5hYm9ydCgpLFxuICApO1xuICBjb25zdCBoZWFkZXJzOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge307XG4gIGZvciAoY29uc3QgaGVhZGVyTmFtZSBvZiByZXMuaGVhZGVycy5rZXlzKCkpIHtcbiAgICBoZWFkZXJzW2hlYWRlck5hbWUudG9Mb3dlckNhc2UoKV0gPSByZXMuaGVhZGVycy5nZXQoaGVhZGVyTmFtZSk7XG4gIH1cbiAgY29uc3QgcmVzcG9uc2UgPSB7XG4gICAgc3RhdHVzQ29kZTogcmVzLnN0YXR1cyxcbiAgICBoZWFkZXJzLFxuICB9O1xuICBpZiAoZm9sbG93UmVkaXJlY3QgJiYgaXNSZWRpcmVjdChyZXNwb25zZS5zdGF0dXNDb2RlKSkge1xuICAgIHRyeSB7XG4gICAgICBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0KFxuICAgICAgICByZXF1ZXN0LFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgZm9sbG93UmVkaXJlY3QsXG4gICAgICAgIGNvdW50ZXIsXG4gICAgICAgIChyZXEpID0+XG4gICAgICAgICAgc3RhcnRGZXRjaFJlcXVlc3QoXG4gICAgICAgICAgICByZXEsXG4gICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICAgICAgb3V0cHV0LFxuICAgICAgICAgICAgZW1pdHRlcixcbiAgICAgICAgICAgIGNvdW50ZXIgKyAxLFxuICAgICAgICAgICksXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgZW1pdHRlci5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuICBlbWl0dGVyLmVtaXQoJ3Jlc3BvbnNlJywgcmVzcG9uc2UpO1xuICBpZiAocmVzLmJvZHkpIHtcbiAgICByZWFkV2hhdHdnUmVhZGFibGVTdHJlYW0ocmVzLmJvZHksIG91dHB1dCk7XG4gIH0gZWxzZSB7XG4gICAgb3V0cHV0LmVuZCgpO1xuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZ2V0UmVzcG9uc2VIZWFkZXJOYW1lcyh4aHI6IFhNTEh0dHBSZXF1ZXN0KSB7XG4gIGNvbnN0IGhlYWRlckxpbmVzID0gKHhoci5nZXRBbGxSZXNwb25zZUhlYWRlcnMoKSB8fCAnJylcbiAgICAuc3BsaXQoL1tcXHJcXG5dKy8pXG4gICAgLmZpbHRlcigobCkgPT4gbC50cmltKCkgIT09ICcnKTtcbiAgcmV0dXJuIGhlYWRlckxpbmVzLm1hcCgoaGVhZGVyTGluZSkgPT5cbiAgICBoZWFkZXJMaW5lLnNwbGl0KC9cXHMqOi8pWzBdLnRvTG93ZXJDYXNlKCksXG4gICk7XG59XG5cbi8qKlxuICpcbiAqL1xuYXN5bmMgZnVuY3Rpb24gc3RhcnRYbWxIdHRwUmVxdWVzdChcbiAgcmVxdWVzdDogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgaW5wdXQ6IFJlYWRhYmxlIHwgdW5kZWZpbmVkLFxuICBvdXRwdXQ6IFdyaXRhYmxlLFxuICBlbWl0dGVyOiBFdmVudEVtaXR0ZXIsXG4gIGNvdW50ZXI6IG51bWJlciA9IDAsXG4pIHtcbiAgY29uc3QgeyBtZXRob2QsIHVybCwgaGVhZGVyczogcmVxSGVhZGVycyB9ID0gcmVxdWVzdDtcbiAgY29uc3QgeyBmb2xsb3dSZWRpcmVjdCB9ID0gb3B0aW9ucztcbiAgY29uc3QgcmVxQm9keSA9XG4gICAgaW5wdXQgJiYgL14ocG9zdHxwdXR8cGF0Y2gpJC9pLnRlc3QobWV0aG9kKSA/IGF3YWl0IHJlYWRBbGwoaW5wdXQpIDogbnVsbDtcbiAgY29uc3QgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gIGF3YWl0IGV4ZWN1dGVXaXRoVGltZW91dChcbiAgICAoKSA9PiB7XG4gICAgICB4aHIub3BlbihtZXRob2QsIHVybCk7XG4gICAgICBpZiAocmVxSGVhZGVycykge1xuICAgICAgICBmb3IgKGNvbnN0IGhlYWRlciBpbiByZXFIZWFkZXJzKSB7XG4gICAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoaGVhZGVyLCByZXFIZWFkZXJzW2hlYWRlcl0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy50aW1lb3V0KSB7XG4gICAgICAgIHhoci50aW1lb3V0ID0gb3B0aW9ucy50aW1lb3V0O1xuICAgICAgfVxuICAgICAgeGhyLnJlc3BvbnNlVHlwZSA9ICdhcnJheWJ1ZmZlcic7XG4gICAgICB4aHIuc2VuZChyZXFCb2R5KTtcbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHhoci5vbmxvYWQgPSAoKSA9PiByZXNvbHZlKCk7XG4gICAgICAgIHhoci5vbmVycm9yID0gcmVqZWN0O1xuICAgICAgICB4aHIub250aW1lb3V0ID0gcmVqZWN0O1xuICAgICAgICB4aHIub25hYm9ydCA9IHJlamVjdDtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgb3B0aW9ucy50aW1lb3V0LFxuICAgICgpID0+IHhoci5hYm9ydCgpLFxuICApO1xuICBjb25zdCBoZWFkZXJOYW1lcyA9IGdldFJlc3BvbnNlSGVhZGVyTmFtZXMoeGhyKTtcbiAgY29uc3QgaGVhZGVycyA9IGhlYWRlck5hbWVzLnJlZHVjZShcbiAgICAoaGVhZGVycywgaGVhZGVyTmFtZSkgPT4gKHtcbiAgICAgIC4uLmhlYWRlcnMsXG4gICAgICBbaGVhZGVyTmFtZV06IHhoci5nZXRSZXNwb25zZUhlYWRlcihoZWFkZXJOYW1lKSB8fCAnJyxcbiAgICB9KSxcbiAgICB7fSBhcyB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSxcbiAgKTtcbiAgY29uc3QgcmVzcG9uc2UgPSB7XG4gICAgc3RhdHVzQ29kZTogeGhyLnN0YXR1cyxcbiAgICBoZWFkZXJzOiBoZWFkZXJzLFxuICB9O1xuICBpZiAoZm9sbG93UmVkaXJlY3QgJiYgaXNSZWRpcmVjdChyZXNwb25zZS5zdGF0dXNDb2RlKSkge1xuICAgIHRyeSB7XG4gICAgICBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0KFxuICAgICAgICByZXF1ZXN0LFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgZm9sbG93UmVkaXJlY3QsXG4gICAgICAgIGNvdW50ZXIsXG4gICAgICAgIChyZXEpID0+XG4gICAgICAgICAgc3RhcnRYbWxIdHRwUmVxdWVzdChcbiAgICAgICAgICAgIHJlcSxcbiAgICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICBlbWl0dGVyLFxuICAgICAgICAgICAgY291bnRlciArIDEsXG4gICAgICAgICAgKSxcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBlbWl0dGVyLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIGxldCBib2R5OiBCdWZmZXI7XG4gIGlmICghcmVzcG9uc2Uuc3RhdHVzQ29kZSkge1xuICAgIHJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDA7XG4gICAgYm9keSA9IEJ1ZmZlci5mcm9tKCdBY2Nlc3MgRGVjbGluZWQnKTtcbiAgfSBlbHNlIHtcbiAgICBib2R5ID0gQnVmZmVyLmZyb20oeGhyLnJlc3BvbnNlKTtcbiAgfVxuICBlbWl0dGVyLmVtaXQoJ3Jlc3BvbnNlJywgcmVzcG9uc2UpO1xuICBvdXRwdXQud3JpdGUoYm9keSk7XG4gIG91dHB1dC5lbmQoKTtcbn1cblxuLyoqXG4gKlxuICovXG5sZXQgZGVmYXVsdHM6IEh0dHBSZXF1ZXN0T3B0aW9ucyA9IHt9O1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXREZWZhdWx0cyhkZWZhdWx0c186IEh0dHBSZXF1ZXN0T3B0aW9ucykge1xuICBkZWZhdWx0cyA9IGRlZmF1bHRzXztcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiByZXF1ZXN0KFxuICByZXE6IEh0dHBSZXF1ZXN0LFxuICBvcHRpb25zXzogSHR0cFJlcXVlc3RPcHRpb25zID0ge30sXG4pIHtcbiAgY29uc3Qgb3B0aW9ucyA9IHsgLi4uZGVmYXVsdHMsIC4uLm9wdGlvbnNfIH07XG4gIGNvbnN0IHsgaW5wdXQsIG91dHB1dCwgc3RyZWFtIH0gPSBjcmVhdGVIdHRwUmVxdWVzdEhhbmRsZXJTdHJlYW1zKHJlcSk7XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2Ygd2luZG93LmZldGNoID09PSAnZnVuY3Rpb24nKSB7XG4gICAgc3RhcnRGZXRjaFJlcXVlc3QocmVxLCBvcHRpb25zLCBpbnB1dCwgb3V0cHV0LCBzdHJlYW0pO1xuICB9IGVsc2Uge1xuICAgIHN0YXJ0WG1sSHR0cFJlcXVlc3QocmVxLCBvcHRpb25zLCBpbnB1dCwgb3V0cHV0LCBzdHJlYW0pO1xuICB9XG4gIHJldHVybiBzdHJlYW07XG59XG4iXX0=