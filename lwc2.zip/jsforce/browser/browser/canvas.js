import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.split";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context2; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context2 = Object.prototype.toString.call(o)).call(_context2, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 *
 */
import { Transform } from 'stream';

function parseHeaders(hs) {
  var headers = {};

  var _iterator = _createForOfIteratorHelper(hs.split(/\n/)),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var line = _step.value;

      var _line$split = line.split(/\s*:\s*/),
          _line$split2 = _slicedToArray(_line$split, 2),
          name = _line$split2[0],
          value = _line$split2[1];

      headers[name.toLowerCase()] = value;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return headers;
}

function processCanvasRequest(_x, _x2, _x3) {
  return _processCanvasRequest.apply(this, arguments);
}

function _processCanvasRequest() {
  _processCanvasRequest = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(params, signedRequest, requestBody) {
    var settings, paramHeaders, _i, _Object$keys, name, data, headers, responseBody;

    return _regeneratorRuntime.wrap(function _callee2$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            settings = {
              client: signedRequest.client,
              method: params.method,
              data: requestBody
            };
            paramHeaders = params.headers;

            if (paramHeaders) {
              settings.headers = {};

              for (_i = 0, _Object$keys = _Object$keys2(paramHeaders); _i < _Object$keys.length; _i++) {
                name = _Object$keys[_i];

                if (name.toLowerCase() === 'content-type') {
                  settings.contentType = paramHeaders[name];
                } else {
                  settings.headers[name] = paramHeaders[name];
                }
              }
            }

            _context3.next = 5;
            return new _Promise(function (resolve, reject) {
              settings.success = resolve;
              settings.failure = reject;
              Sfdc.canvas.client.ajax(params.url, settings);
            });

          case 5:
            data = _context3.sent;
            headers = parseHeaders(data.responseHeaders);
            responseBody = data.payload;

            if (typeof responseBody !== 'string') {
              responseBody = _JSON$stringify(responseBody);
            }

            return _context3.abrupt("return", {
              statusCode: data.status,
              headers: headers,
              body: responseBody
            });

          case 10:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee2);
  }));
  return _processCanvasRequest.apply(this, arguments);
}

function createRequest(signedRequest) {
  return function (params) {
    var buf = [];
    var stream = new Transform({
      transform: function transform(chunk, encoding, callback) {
        buf.push(typeof chunk === 'string' ? chunk : chunk.toString('utf8'));
        callback();
      },
      flush: function flush() {
        _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var body, response;
          return _regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  body = buf.join('');
                  _context.next = 3;
                  return processCanvasRequest(params, signedRequest, body);

                case 3:
                  response = _context.sent;
                  stream.emit('response', response);
                  stream.emit('complete', response);
                  stream.push(response.body);
                  stream.push(null);

                case 8:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }))();
      }
    });

    if (params.body) {
      stream.end(params.body);
    }

    return stream;
  };
}

export default {
  supported: (typeof Sfdc === "undefined" ? "undefined" : _typeof(Sfdc)) === 'object' && typeof Sfdc.canvas !== 'undefined',
  createRequest: createRequest
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9icm93c2VyL2NhbnZhcy50cyJdLCJuYW1lcyI6WyJUcmFuc2Zvcm0iLCJwYXJzZUhlYWRlcnMiLCJocyIsImhlYWRlcnMiLCJzcGxpdCIsImxpbmUiLCJuYW1lIiwidmFsdWUiLCJ0b0xvd2VyQ2FzZSIsInByb2Nlc3NDYW52YXNSZXF1ZXN0IiwicGFyYW1zIiwic2lnbmVkUmVxdWVzdCIsInJlcXVlc3RCb2R5Iiwic2V0dGluZ3MiLCJjbGllbnQiLCJtZXRob2QiLCJkYXRhIiwicGFyYW1IZWFkZXJzIiwiY29udGVudFR5cGUiLCJyZXNvbHZlIiwicmVqZWN0Iiwic3VjY2VzcyIsImZhaWx1cmUiLCJTZmRjIiwiY2FudmFzIiwiYWpheCIsInVybCIsInJlc3BvbnNlSGVhZGVycyIsInJlc3BvbnNlQm9keSIsInBheWxvYWQiLCJzdGF0dXNDb2RlIiwic3RhdHVzIiwiYm9keSIsImNyZWF0ZVJlcXVlc3QiLCJidWYiLCJzdHJlYW0iLCJ0cmFuc2Zvcm0iLCJjaHVuayIsImVuY29kaW5nIiwiY2FsbGJhY2siLCJwdXNoIiwidG9TdHJpbmciLCJmbHVzaCIsImpvaW4iLCJyZXNwb25zZSIsImVtaXQiLCJlbmQiLCJzdXBwb3J0ZWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFNBQVQsUUFBMEIsUUFBMUI7O0FBV0EsU0FBU0MsWUFBVCxDQUFzQkMsRUFBdEIsRUFBa0M7QUFDaEMsTUFBTUMsT0FBK0IsR0FBRyxFQUF4Qzs7QUFEZ0MsNkNBRWJELEVBQUUsQ0FBQ0UsS0FBSCxDQUFTLElBQVQsQ0FGYTtBQUFBOztBQUFBO0FBRWhDLHdEQUFtQztBQUFBLFVBQXhCQyxJQUF3Qjs7QUFBQSx3QkFDWEEsSUFBSSxDQUFDRCxLQUFMLENBQVcsU0FBWCxDQURXO0FBQUE7QUFBQSxVQUMxQkUsSUFEMEI7QUFBQSxVQUNwQkMsS0FEb0I7O0FBRWpDSixNQUFBQSxPQUFPLENBQUNHLElBQUksQ0FBQ0UsV0FBTCxFQUFELENBQVAsR0FBOEJELEtBQTlCO0FBQ0Q7QUFMK0I7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFNaEMsU0FBT0osT0FBUDtBQUNEOztTQUVjTSxvQjs7Ozs7bUZBQWYsa0JBQ0VDLE1BREYsRUFFRUMsYUFGRixFQUdFQyxXQUhGO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLUUMsWUFBQUEsUUFMUixHQUt3QjtBQUNwQkMsY0FBQUEsTUFBTSxFQUFFSCxhQUFhLENBQUNHLE1BREY7QUFFcEJDLGNBQUFBLE1BQU0sRUFBRUwsTUFBTSxDQUFDSyxNQUZLO0FBR3BCQyxjQUFBQSxJQUFJLEVBQUVKO0FBSGMsYUFMeEI7QUFVUUssWUFBQUEsWUFWUixHQVV1QlAsTUFBTSxDQUFDUCxPQVY5Qjs7QUFXRSxnQkFBSWMsWUFBSixFQUFrQjtBQUNoQkosY0FBQUEsUUFBUSxDQUFDVixPQUFULEdBQW1CLEVBQW5COztBQUNBLDBDQUFtQixjQUFZYyxZQUFaLENBQW5CLGtDQUE4QztBQUFuQ1gsZ0JBQUFBLElBQW1DOztBQUM1QyxvQkFBSUEsSUFBSSxDQUFDRSxXQUFMLE9BQXVCLGNBQTNCLEVBQTJDO0FBQ3pDSyxrQkFBQUEsUUFBUSxDQUFDSyxXQUFULEdBQXVCRCxZQUFZLENBQUNYLElBQUQsQ0FBbkM7QUFDRCxpQkFGRCxNQUVPO0FBQ0xPLGtCQUFBQSxRQUFRLENBQUNWLE9BQVQsQ0FBaUJHLElBQWpCLElBQXlCVyxZQUFZLENBQUNYLElBQUQsQ0FBckM7QUFDRDtBQUNGO0FBQ0Y7O0FBcEJIO0FBQUEsbUJBcUJxQixhQUE0QixVQUFDYSxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDbEVQLGNBQUFBLFFBQVEsQ0FBQ1EsT0FBVCxHQUFtQkYsT0FBbkI7QUFDQU4sY0FBQUEsUUFBUSxDQUFDUyxPQUFULEdBQW1CRixNQUFuQjtBQUNBRyxjQUFBQSxJQUFJLENBQUNDLE1BQUwsQ0FBWVYsTUFBWixDQUFtQlcsSUFBbkIsQ0FBd0JmLE1BQU0sQ0FBQ2dCLEdBQS9CLEVBQW9DYixRQUFwQztBQUNELGFBSmtCLENBckJyQjs7QUFBQTtBQXFCUUcsWUFBQUEsSUFyQlI7QUEwQlFiLFlBQUFBLE9BMUJSLEdBMEJrQkYsWUFBWSxDQUFDZSxJQUFJLENBQUNXLGVBQU4sQ0ExQjlCO0FBMkJNQyxZQUFBQSxZQTNCTixHQTJCcUJaLElBQUksQ0FBQ2EsT0EzQjFCOztBQTRCRSxnQkFBSSxPQUFPRCxZQUFQLEtBQXdCLFFBQTVCLEVBQXNDO0FBQ3BDQSxjQUFBQSxZQUFZLEdBQUcsZ0JBQWVBLFlBQWYsQ0FBZjtBQUNEOztBQTlCSCw4Q0ErQlM7QUFDTEUsY0FBQUEsVUFBVSxFQUFFZCxJQUFJLENBQUNlLE1BRFo7QUFFTDVCLGNBQUFBLE9BQU8sRUFBUEEsT0FGSztBQUdMNkIsY0FBQUEsSUFBSSxFQUFFSjtBQUhELGFBL0JUOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7QUFzQ0EsU0FBU0ssYUFBVCxDQUF1QnRCLGFBQXZCLEVBQTJEO0FBQ3pELFNBQU8sVUFBQ0QsTUFBRCxFQUF5QjtBQUM5QixRQUFNd0IsR0FBYSxHQUFHLEVBQXRCO0FBQ0EsUUFBTUMsTUFBTSxHQUFHLElBQUluQyxTQUFKLENBQWM7QUFDM0JvQyxNQUFBQSxTQUQyQixxQkFDakJDLEtBRGlCLEVBQ1ZDLFFBRFUsRUFDQUMsUUFEQSxFQUNVO0FBQ25DTCxRQUFBQSxHQUFHLENBQUNNLElBQUosQ0FBUyxPQUFPSCxLQUFQLEtBQWlCLFFBQWpCLEdBQTRCQSxLQUE1QixHQUFvQ0EsS0FBSyxDQUFDSSxRQUFOLENBQWUsTUFBZixDQUE3QztBQUNBRixRQUFBQSxRQUFRO0FBQ1QsT0FKMEI7QUFLM0JHLE1BQUFBLEtBTDJCLG1CQUtuQjtBQUNOLGlFQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNPVixrQkFBQUEsSUFEUCxHQUNjRSxHQUFHLENBQUNTLElBQUosQ0FBUyxFQUFULENBRGQ7QUFBQTtBQUFBLHlCQUV3QmxDLG9CQUFvQixDQUN6Q0MsTUFEeUMsRUFFekNDLGFBRnlDLEVBR3pDcUIsSUFIeUMsQ0FGNUM7O0FBQUE7QUFFT1ksa0JBQUFBLFFBRlA7QUFPQ1Qsa0JBQUFBLE1BQU0sQ0FBQ1UsSUFBUCxDQUFZLFVBQVosRUFBd0JELFFBQXhCO0FBQ0FULGtCQUFBQSxNQUFNLENBQUNVLElBQVAsQ0FBWSxVQUFaLEVBQXdCRCxRQUF4QjtBQUNBVCxrQkFBQUEsTUFBTSxDQUFDSyxJQUFQLENBQVlJLFFBQVEsQ0FBQ1osSUFBckI7QUFDQUcsa0JBQUFBLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLElBQVo7O0FBVkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBRDtBQVlEO0FBbEIwQixLQUFkLENBQWY7O0FBb0JBLFFBQUk5QixNQUFNLENBQUNzQixJQUFYLEVBQWlCO0FBQ2ZHLE1BQUFBLE1BQU0sQ0FBQ1csR0FBUCxDQUFXcEMsTUFBTSxDQUFDc0IsSUFBbEI7QUFDRDs7QUFDRCxXQUFPRyxNQUFQO0FBQ0QsR0ExQkQ7QUEyQkQ7O0FBRUQsZUFBZTtBQUNiWSxFQUFBQSxTQUFTLEVBQUUsUUFBT3hCLElBQVAseUNBQU9BLElBQVAsT0FBZ0IsUUFBaEIsSUFBNEIsT0FBT0EsSUFBSSxDQUFDQyxNQUFaLEtBQXVCLFdBRGpEO0FBRWJTLEVBQUFBLGFBQWEsRUFBYkE7QUFGYSxDQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHsgSHR0cFJlcXVlc3QsIFNpZ25lZFJlcXVlc3RPYmplY3QgfSBmcm9tICcuLi90eXBlcyc7XG5cbmRlY2xhcmUgdmFyIFNmZGM6IGFueTtcblxudHlwZSBDYW52YXNSZXNwb25zZSA9IHtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIHJlc3BvbnNlSGVhZGVyczogc3RyaW5nO1xuICBwYXlsb2FkOiBhbnk7XG59O1xuXG5mdW5jdGlvbiBwYXJzZUhlYWRlcnMoaHM6IHN0cmluZykge1xuICBjb25zdCBoZWFkZXJzOiBIdHRwUmVxdWVzdFsnaGVhZGVycyddID0ge307XG4gIGZvciAoY29uc3QgbGluZSBvZiBocy5zcGxpdCgvXFxuLykpIHtcbiAgICBjb25zdCBbbmFtZSwgdmFsdWVdID0gbGluZS5zcGxpdCgvXFxzKjpcXHMqLyk7XG4gICAgaGVhZGVyc1tuYW1lLnRvTG93ZXJDYXNlKCldID0gdmFsdWU7XG4gIH1cbiAgcmV0dXJuIGhlYWRlcnM7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NDYW52YXNSZXF1ZXN0KFxuICBwYXJhbXM6IEh0dHBSZXF1ZXN0LFxuICBzaWduZWRSZXF1ZXN0OiBTaWduZWRSZXF1ZXN0T2JqZWN0LFxuICByZXF1ZXN0Qm9keTogc3RyaW5nLFxuKSB7XG4gIGNvbnN0IHNldHRpbmdzOiBhbnkgPSB7XG4gICAgY2xpZW50OiBzaWduZWRSZXF1ZXN0LmNsaWVudCxcbiAgICBtZXRob2Q6IHBhcmFtcy5tZXRob2QsXG4gICAgZGF0YTogcmVxdWVzdEJvZHksXG4gIH07XG4gIGNvbnN0IHBhcmFtSGVhZGVycyA9IHBhcmFtcy5oZWFkZXJzO1xuICBpZiAocGFyYW1IZWFkZXJzKSB7XG4gICAgc2V0dGluZ3MuaGVhZGVycyA9IHt9O1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhwYXJhbUhlYWRlcnMpKSB7XG4gICAgICBpZiAobmFtZS50b0xvd2VyQ2FzZSgpID09PSAnY29udGVudC10eXBlJykge1xuICAgICAgICBzZXR0aW5ncy5jb250ZW50VHlwZSA9IHBhcmFtSGVhZGVyc1tuYW1lXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldHRpbmdzLmhlYWRlcnNbbmFtZV0gPSBwYXJhbUhlYWRlcnNbbmFtZV07XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IGRhdGEgPSBhd2FpdCBuZXcgUHJvbWlzZTxDYW52YXNSZXNwb25zZT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHNldHRpbmdzLnN1Y2Nlc3MgPSByZXNvbHZlO1xuICAgIHNldHRpbmdzLmZhaWx1cmUgPSByZWplY3Q7XG4gICAgU2ZkYy5jYW52YXMuY2xpZW50LmFqYXgocGFyYW1zLnVybCwgc2V0dGluZ3MpO1xuICB9KTtcbiAgY29uc3QgaGVhZGVycyA9IHBhcnNlSGVhZGVycyhkYXRhLnJlc3BvbnNlSGVhZGVycyk7XG4gIGxldCByZXNwb25zZUJvZHkgPSBkYXRhLnBheWxvYWQ7XG4gIGlmICh0eXBlb2YgcmVzcG9uc2VCb2R5ICE9PSAnc3RyaW5nJykge1xuICAgIHJlc3BvbnNlQm9keSA9IEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlQm9keSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzdGF0dXNDb2RlOiBkYXRhLnN0YXR1cyxcbiAgICBoZWFkZXJzLFxuICAgIGJvZHk6IHJlc3BvbnNlQm9keSBhcyBzdHJpbmcsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVJlcXVlc3Qoc2lnbmVkUmVxdWVzdDogU2lnbmVkUmVxdWVzdE9iamVjdCkge1xuICByZXR1cm4gKHBhcmFtczogSHR0cFJlcXVlc3QpID0+IHtcbiAgICBjb25zdCBidWY6IHN0cmluZ1tdID0gW107XG4gICAgY29uc3Qgc3RyZWFtID0gbmV3IFRyYW5zZm9ybSh7XG4gICAgICB0cmFuc2Zvcm0oY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykge1xuICAgICAgICBidWYucHVzaCh0eXBlb2YgY2h1bmsgPT09ICdzdHJpbmcnID8gY2h1bmsgOiBjaHVuay50b1N0cmluZygndXRmOCcpKTtcbiAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgIH0sXG4gICAgICBmbHVzaCgpIHtcbiAgICAgICAgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBib2R5ID0gYnVmLmpvaW4oJycpO1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcHJvY2Vzc0NhbnZhc1JlcXVlc3QoXG4gICAgICAgICAgICBwYXJhbXMsXG4gICAgICAgICAgICBzaWduZWRSZXF1ZXN0LFxuICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICApO1xuICAgICAgICAgIHN0cmVhbS5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgICAgICAgICBzdHJlYW0uZW1pdCgnY29tcGxldGUnLCByZXNwb25zZSk7XG4gICAgICAgICAgc3RyZWFtLnB1c2gocmVzcG9uc2UuYm9keSk7XG4gICAgICAgICAgc3RyZWFtLnB1c2gobnVsbCk7XG4gICAgICAgIH0pKCk7XG4gICAgICB9LFxuICAgIH0pO1xuICAgIGlmIChwYXJhbXMuYm9keSkge1xuICAgICAgc3RyZWFtLmVuZChwYXJhbXMuYm9keSk7XG4gICAgfVxuICAgIHJldHVybiBzdHJlYW07XG4gIH07XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc3VwcG9ydGVkOiB0eXBlb2YgU2ZkYyA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIFNmZGMuY2FudmFzICE9PSAndW5kZWZpbmVkJyxcbiAgY3JlYXRlUmVxdWVzdCxcbn07XG4iXX0=