import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";

/**
 *
 */
import { Transform } from 'stream';
var _index = 0;

function processJsonpRequest(_x, _x2, _x3) {
  return _processJsonpRequest.apply(this, arguments);
}

function _processJsonpRequest() {
  _processJsonpRequest = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(params, jsonpParam, timeout) {
    var _context2;

    var cbFuncName, callbacks, url, script, pid, res;
    return _regeneratorRuntime.wrap(function _callee2$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            if (!(params.method.toUpperCase() !== 'GET')) {
              _context3.next = 2;
              break;
            }

            throw new Error('JSONP only supports GET request.');

          case 2:
            _index += 1;
            cbFuncName = "_jsforce_jsonpCallback_".concat(_index);
            callbacks = window;
            url = params.url;
            url += _indexOfInstanceProperty(url).call(url, '?') > 0 ? '&' : '?';
            url += _concatInstanceProperty(_context2 = "".concat(jsonpParam, "=")).call(_context2, cbFuncName);
            script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = url;

            if (document.documentElement) {
              document.documentElement.appendChild(script);
            }

            _context3.prev = 12;
            _context3.next = 15;
            return new _Promise(function (resolve, reject) {
              pid = _setTimeout(function () {
                reject(new Error('JSONP call time out.'));
              }, timeout);
              callbacks[cbFuncName] = resolve;
            });

          case 15:
            res = _context3.sent;
            return _context3.abrupt("return", {
              statusCode: 200,
              headers: {
                'content-type': 'application/json'
              },
              body: _JSON$stringify(res)
            });

          case 17:
            _context3.prev = 17;
            clearTimeout(pid);

            if (document.documentElement) {
              document.documentElement.removeChild(script);
            }

            delete callbacks[cbFuncName];
            return _context3.finish(17);

          case 22:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee2, null, [[12,, 17, 22]]);
  }));
  return _processJsonpRequest.apply(this, arguments);
}

function createRequest() {
  var jsonpParam = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'callback';
  var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10000;
  return function (params) {
    var stream = new Transform({
      transform: function transform(chunk, encoding, callback) {
        callback();
      },
      flush: function flush() {
        _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var response;
          return _regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return processJsonpRequest(params, jsonpParam, timeout);

                case 2:
                  response = _context.sent;
                  stream.emit('response', response);
                  stream.emit('complete', response);
                  stream.push(response.body);
                  stream.push(null);

                case 7:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }))();
      }
    });
    stream.end();
    return stream;
  };
}

export default {
  supported: typeof window !== 'undefined' && typeof document !== 'undefined',
  createRequest: createRequest
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9icm93c2VyL2pzb25wLnRzIl0sIm5hbWVzIjpbIlRyYW5zZm9ybSIsIl9pbmRleCIsInByb2Nlc3NKc29ucFJlcXVlc3QiLCJwYXJhbXMiLCJqc29ucFBhcmFtIiwidGltZW91dCIsIm1ldGhvZCIsInRvVXBwZXJDYXNlIiwiRXJyb3IiLCJjYkZ1bmNOYW1lIiwiY2FsbGJhY2tzIiwid2luZG93IiwidXJsIiwic2NyaXB0IiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwidHlwZSIsInNyYyIsImRvY3VtZW50RWxlbWVudCIsImFwcGVuZENoaWxkIiwicmVzb2x2ZSIsInJlamVjdCIsInBpZCIsInJlcyIsInN0YXR1c0NvZGUiLCJoZWFkZXJzIiwiYm9keSIsImNsZWFyVGltZW91dCIsInJlbW92ZUNoaWxkIiwiY3JlYXRlUmVxdWVzdCIsInN0cmVhbSIsInRyYW5zZm9ybSIsImNodW5rIiwiZW5jb2RpbmciLCJjYWxsYmFjayIsImZsdXNoIiwicmVzcG9uc2UiLCJlbWl0IiwicHVzaCIsImVuZCIsInN1cHBvcnRlZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsU0FBVCxRQUEwQixRQUExQjtBQUdBLElBQUlDLE1BQU0sR0FBRyxDQUFiOztTQUVlQyxtQjs7Ozs7a0ZBQWYsa0JBQ0VDLE1BREYsRUFFRUMsVUFGRixFQUdFQyxPQUhGO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtNRixNQUFNLENBQUNHLE1BQVAsQ0FBY0MsV0FBZCxPQUFnQyxLQUx0QztBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFNVSxJQUFJQyxLQUFKLENBQVUsa0NBQVYsQ0FOVjs7QUFBQTtBQVFFUCxZQUFBQSxNQUFNLElBQUksQ0FBVjtBQUNNUSxZQUFBQSxVQVRSLG9DQVMrQ1IsTUFUL0M7QUFVUVMsWUFBQUEsU0FWUixHQVV5QkMsTUFWekI7QUFXTUMsWUFBQUEsR0FYTixHQVdZVCxNQUFNLENBQUNTLEdBWG5CO0FBWUVBLFlBQUFBLEdBQUcsSUFBSSx5QkFBQUEsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBUyxHQUFULENBQUgsR0FBbUIsQ0FBbkIsR0FBdUIsR0FBdkIsR0FBNkIsR0FBcEM7QUFDQUEsWUFBQUEsR0FBRyxrREFBT1IsVUFBUCx3QkFBcUJLLFVBQXJCLENBQUg7QUFDTUksWUFBQUEsTUFkUixHQWNpQkMsUUFBUSxDQUFDQyxhQUFULENBQXVCLFFBQXZCLENBZGpCO0FBZUVGLFlBQUFBLE1BQU0sQ0FBQ0csSUFBUCxHQUFjLGlCQUFkO0FBQ0FILFlBQUFBLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhTCxHQUFiOztBQUNBLGdCQUFJRSxRQUFRLENBQUNJLGVBQWIsRUFBOEI7QUFDNUJKLGNBQUFBLFFBQVEsQ0FBQ0ksZUFBVCxDQUF5QkMsV0FBekIsQ0FBcUNOLE1BQXJDO0FBQ0Q7O0FBbkJIO0FBQUE7QUFBQSxtQkFzQnNCLGFBQVksVUFBQ08sT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ2pEQyxjQUFBQSxHQUFHLEdBQUcsWUFBVyxZQUFNO0FBQ3JCRCxnQkFBQUEsTUFBTSxDQUFDLElBQUliLEtBQUosQ0FBVSxzQkFBVixDQUFELENBQU47QUFDRCxlQUZLLEVBRUhILE9BRkcsQ0FBTjtBQUdBSyxjQUFBQSxTQUFTLENBQUNELFVBQUQsQ0FBVCxHQUF3QlcsT0FBeEI7QUFDRCxhQUxpQixDQXRCdEI7O0FBQUE7QUFzQlVHLFlBQUFBLEdBdEJWO0FBQUEsOENBNEJXO0FBQ0xDLGNBQUFBLFVBQVUsRUFBRSxHQURQO0FBRUxDLGNBQUFBLE9BQU8sRUFBRTtBQUFFLGdDQUFnQjtBQUFsQixlQUZKO0FBR0xDLGNBQUFBLElBQUksRUFBRSxnQkFBZUgsR0FBZjtBQUhELGFBNUJYOztBQUFBO0FBQUE7QUFrQ0lJLFlBQUFBLFlBQVksQ0FBQ0wsR0FBRCxDQUFaOztBQUNBLGdCQUFJUixRQUFRLENBQUNJLGVBQWIsRUFBOEI7QUFDNUJKLGNBQUFBLFFBQVEsQ0FBQ0ksZUFBVCxDQUF5QlUsV0FBekIsQ0FBcUNmLE1BQXJDO0FBQ0Q7O0FBQ0QsbUJBQU9ILFNBQVMsQ0FBQ0QsVUFBRCxDQUFoQjtBQXRDSjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBMENBLFNBQVNvQixhQUFULEdBR0U7QUFBQSxNQUZBekIsVUFFQSx1RUFGcUIsVUFFckI7QUFBQSxNQURBQyxPQUNBLHVFQURrQixLQUNsQjtBQUNBLFNBQU8sVUFBQ0YsTUFBRCxFQUF5QjtBQUM5QixRQUFNMkIsTUFBTSxHQUFHLElBQUk5QixTQUFKLENBQWM7QUFDM0IrQixNQUFBQSxTQUQyQixxQkFDakJDLEtBRGlCLEVBQ1ZDLFFBRFUsRUFDQUMsUUFEQSxFQUNVO0FBQ25DQSxRQUFBQSxRQUFRO0FBQ1QsT0FIMEI7QUFJM0JDLE1BQUFBLEtBSjJCLG1CQUluQjtBQUNOLGlFQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQ3dCakMsbUJBQW1CLENBQ3hDQyxNQUR3QyxFQUV4Q0MsVUFGd0MsRUFHeENDLE9BSHdDLENBRDNDOztBQUFBO0FBQ08rQixrQkFBQUEsUUFEUDtBQU1DTixrQkFBQUEsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF3QkQsUUFBeEI7QUFDQU4sa0JBQUFBLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFVBQVosRUFBd0JELFFBQXhCO0FBQ0FOLGtCQUFBQSxNQUFNLENBQUNRLElBQVAsQ0FBWUYsUUFBUSxDQUFDVixJQUFyQjtBQUNBSSxrQkFBQUEsTUFBTSxDQUFDUSxJQUFQLENBQVksSUFBWjs7QUFURDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFEO0FBV0Q7QUFoQjBCLEtBQWQsQ0FBZjtBQWtCQVIsSUFBQUEsTUFBTSxDQUFDUyxHQUFQO0FBQ0EsV0FBT1QsTUFBUDtBQUNELEdBckJEO0FBc0JEOztBQUVELGVBQWU7QUFDYlUsRUFBQUEsU0FBUyxFQUFFLE9BQU83QixNQUFQLEtBQWtCLFdBQWxCLElBQWlDLE9BQU9HLFFBQVAsS0FBb0IsV0FEbkQ7QUFFYmUsRUFBQUEsYUFBYSxFQUFiQTtBQUZhLENBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgeyBIdHRwUmVxdWVzdCB9IGZyb20gJy4uL3R5cGVzJztcblxubGV0IF9pbmRleCA9IDA7XG5cbmFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NKc29ucFJlcXVlc3QoXG4gIHBhcmFtczogSHR0cFJlcXVlc3QsXG4gIGpzb25wUGFyYW06IHN0cmluZyxcbiAgdGltZW91dDogbnVtYmVyLFxuKSB7XG4gIGlmIChwYXJhbXMubWV0aG9kLnRvVXBwZXJDYXNlKCkgIT09ICdHRVQnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdKU09OUCBvbmx5IHN1cHBvcnRzIEdFVCByZXF1ZXN0LicpO1xuICB9XG4gIF9pbmRleCArPSAxO1xuICBjb25zdCBjYkZ1bmNOYW1lID0gYF9qc2ZvcmNlX2pzb25wQ2FsbGJhY2tfJHtfaW5kZXh9YDtcbiAgY29uc3QgY2FsbGJhY2tzOiBhbnkgPSB3aW5kb3c7XG4gIGxldCB1cmwgPSBwYXJhbXMudXJsO1xuICB1cmwgKz0gdXJsLmluZGV4T2YoJz8nKSA+IDAgPyAnJicgOiAnPyc7XG4gIHVybCArPSBgJHtqc29ucFBhcmFtfT0ke2NiRnVuY05hbWV9YDtcbiAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gIHNjcmlwdC50eXBlID0gJ3RleHQvamF2YXNjcmlwdCc7XG4gIHNjcmlwdC5zcmMgPSB1cmw7XG4gIGlmIChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpIHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcbiAgfVxuICBsZXQgcGlkO1xuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHBpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKCdKU09OUCBjYWxsIHRpbWUgb3V0LicpKTtcbiAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgY2FsbGJhY2tzW2NiRnVuY05hbWVdID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXMpLFxuICAgIH07XG4gIH0gZmluYWxseSB7XG4gICAgY2xlYXJUaW1lb3V0KHBpZCk7XG4gICAgaWYgKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkge1xuICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnJlbW92ZUNoaWxkKHNjcmlwdCk7XG4gICAgfVxuICAgIGRlbGV0ZSBjYWxsYmFja3NbY2JGdW5jTmFtZV07XG4gIH1cbn1cblxuZnVuY3Rpb24gY3JlYXRlUmVxdWVzdChcbiAganNvbnBQYXJhbTogc3RyaW5nID0gJ2NhbGxiYWNrJyxcbiAgdGltZW91dDogbnVtYmVyID0gMTAwMDAsXG4pIHtcbiAgcmV0dXJuIChwYXJhbXM6IEh0dHBSZXF1ZXN0KSA9PiB7XG4gICAgY29uc3Qgc3RyZWFtID0gbmV3IFRyYW5zZm9ybSh7XG4gICAgICB0cmFuc2Zvcm0oY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykge1xuICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgfSxcbiAgICAgIGZsdXNoKCkge1xuICAgICAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcHJvY2Vzc0pzb25wUmVxdWVzdChcbiAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICAgIGpzb25wUGFyYW0sXG4gICAgICAgICAgICB0aW1lb3V0LFxuICAgICAgICAgICk7XG4gICAgICAgICAgc3RyZWFtLmVtaXQoJ3Jlc3BvbnNlJywgcmVzcG9uc2UpO1xuICAgICAgICAgIHN0cmVhbS5lbWl0KCdjb21wbGV0ZScsIHJlc3BvbnNlKTtcbiAgICAgICAgICBzdHJlYW0ucHVzaChyZXNwb25zZS5ib2R5KTtcbiAgICAgICAgICBzdHJlYW0ucHVzaChudWxsKTtcbiAgICAgICAgfSkoKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgc3RyZWFtLmVuZCgpO1xuICAgIHJldHVybiBzdHJlYW07XG4gIH07XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc3VwcG9ydGVkOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnLFxuICBjcmVhdGVSZXF1ZXN0LFxufTtcbiJdfQ==