import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _get from "@babel/runtime-corejs3/helpers/get";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

import OAuth2 from './oauth2';
export var JwtOAuth2 = /*#__PURE__*/function (_OAuth) {
  _inherits(JwtOAuth2, _OAuth);

  var _super = _createSuper(JwtOAuth2);

  function JwtOAuth2(config) {
    _classCallCheck(this, JwtOAuth2);

    return _super.call(this, config);
  }

  _createClass(JwtOAuth2, [{
    key: "jwtAuthorize",
    value: function jwtAuthorize(innerToken) {
      return _get(_getPrototypeOf(JwtOAuth2.prototype), "_postParams", this).call(this, {
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: innerToken
      });
    }
  }]);

  return JwtOAuth2;
}(OAuth2);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9qd3RPQXV0aDIudHMiXSwibmFtZXMiOlsiT0F1dGgyIiwiSnd0T0F1dGgyIiwiY29uZmlnIiwiaW5uZXJUb2tlbiIsImdyYW50X3R5cGUiLCJhc3NlcnRpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLE1BQVAsTUFBcUMsVUFBckM7QUFXQSxXQUFhQyxTQUFiO0FBQUE7O0FBQUE7O0FBQ0UscUJBQVlDLE1BQVosRUFBa0M7QUFBQTs7QUFBQSw2QkFDMUJBLE1BRDBCO0FBRWpDOztBQUhIO0FBQUE7QUFBQSxpQ0FLc0JDLFVBTHRCLEVBS3dEO0FBQ3BELHdGQUF5QjtBQUN2QkMsUUFBQUEsVUFBVSxFQUFFLDZDQURXO0FBRXZCQyxRQUFBQSxTQUFTLEVBQUVGO0FBRlksT0FBekI7QUFJRDtBQVZIOztBQUFBO0FBQUEsRUFBK0JILE1BQS9CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE9BdXRoMiwgeyBPQXV0aDJDb25maWcgfSBmcm9tICcuL29hdXRoMic7XG5cbmV4cG9ydCB0eXBlIEp3dE9BdXRoMkNvbmZpZyA9IE9BdXRoMkNvbmZpZyAmIHtcbiAgcHJpdmF0ZUtleT86IHN0cmluZztcbiAgcHJpdmF0ZUtleUZpbGU/OiBzdHJpbmc7XG4gIGF1dGhDb2RlPzogc3RyaW5nO1xuICByZWZyZXNoVG9rZW4/OiBzdHJpbmc7XG4gIGxvZ2luVXJsPzogc3RyaW5nO1xuICB1c2VybmFtZT86IHN0cmluZztcbn07XG5cbmV4cG9ydCBjbGFzcyBKd3RPQXV0aDIgZXh0ZW5kcyBPQXV0aDIge1xuICBjb25zdHJ1Y3Rvcihjb25maWc6IE9BdXRoMkNvbmZpZykge1xuICAgIHN1cGVyKGNvbmZpZyk7XG4gIH1cblxuICBwdWJsaWMgand0QXV0aG9yaXplKGlubmVyVG9rZW46IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuIHN1cGVyLl9wb3N0UGFyYW1zKHtcbiAgICAgIGdyYW50X3R5cGU6ICd1cm46aWV0ZjpwYXJhbXM6b2F1dGg6Z3JhbnQtdHlwZTpqd3QtYmVhcmVyJyxcbiAgICAgIGFzc2VydGlvbjogaW5uZXJUb2tlbixcbiAgICB9KTtcbiAgfVxufVxuIl19