import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.join";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

import fs from 'fs';
import path from 'path';
import { BaseRegistry } from './base';
/**
 *
 */

function getDefaultConfigFilePath() {
  var homeDir = process.env[process.platform === 'win32' ? 'USERPROFILE' : 'HOME'];

  if (!homeDir) {
    throw new Error('cannot find user home directory to store configuration files');
  }

  return path.join(homeDir, '.jsforce', 'config.json');
}
/**
 *
 */


export var FileRegistry = /*#__PURE__*/function (_BaseRegistry) {
  _inherits(FileRegistry, _BaseRegistry);

  var _super = _createSuper(FileRegistry);

  function FileRegistry(_ref) {
    var _this;

    var configFilePath = _ref.configFilePath;

    _classCallCheck(this, FileRegistry);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_configFilePath", void 0);

    _this._configFilePath = configFilePath || getDefaultConfigFilePath();

    try {
      var data = fs.readFileSync(_this._configFilePath, 'utf-8');
      _this._registryConfig = JSON.parse(data);
    } catch (e) {//
    }

    return _this;
  }

  _createClass(FileRegistry, [{
    key: "_saveConfig",
    value: function _saveConfig() {
      var data = _JSON$stringify(this._registryConfig, null, 4);

      try {
        fs.writeFileSync(this._configFilePath, data);
        fs.chmodSync(this._configFilePath, '600');
      } catch (e) {
        var configDir = path.dirname(this._configFilePath);
        fs.mkdirSync(configDir);
        fs.chmodSync(configDir, '700');
        fs.writeFileSync(this._configFilePath, data);
        fs.chmodSync(this._configFilePath, '600');
      }
    }
  }]);

  return FileRegistry;
}(BaseRegistry);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWdpc3RyeS9maWxlLnRzIl0sIm5hbWVzIjpbImZzIiwicGF0aCIsIkJhc2VSZWdpc3RyeSIsImdldERlZmF1bHRDb25maWdGaWxlUGF0aCIsImhvbWVEaXIiLCJwcm9jZXNzIiwiZW52IiwicGxhdGZvcm0iLCJFcnJvciIsImpvaW4iLCJGaWxlUmVnaXN0cnkiLCJjb25maWdGaWxlUGF0aCIsIl9jb25maWdGaWxlUGF0aCIsImRhdGEiLCJyZWFkRmlsZVN5bmMiLCJfcmVnaXN0cnlDb25maWciLCJKU09OIiwicGFyc2UiLCJlIiwid3JpdGVGaWxlU3luYyIsImNobW9kU3luYyIsImNvbmZpZ0RpciIsImRpcm5hbWUiLCJta2RpclN5bmMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLEVBQVAsTUFBZSxJQUFmO0FBQ0EsT0FBT0MsSUFBUCxNQUFpQixNQUFqQjtBQUNBLFNBQVNDLFlBQVQsUUFBNkIsUUFBN0I7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0Msd0JBQVQsR0FBb0M7QUFDbEMsTUFBTUMsT0FBTyxHQUNYQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUQsT0FBTyxDQUFDRSxRQUFSLEtBQXFCLE9BQXJCLEdBQStCLGFBQS9CLEdBQStDLE1BQTNELENBREY7O0FBRUEsTUFBSSxDQUFDSCxPQUFMLEVBQWM7QUFDWixVQUFNLElBQUlJLEtBQUosQ0FDSiw4REFESSxDQUFOO0FBR0Q7O0FBQ0QsU0FBT1AsSUFBSSxDQUFDUSxJQUFMLENBQVVMLE9BQVYsRUFBbUIsVUFBbkIsRUFBK0IsYUFBL0IsQ0FBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxXQUFhTSxZQUFiO0FBQUE7O0FBQUE7O0FBR0UsOEJBQTZEO0FBQUE7O0FBQUEsUUFBL0NDLGNBQStDLFFBQS9DQSxjQUErQzs7QUFBQTs7QUFDM0Q7O0FBRDJEOztBQUUzRCxVQUFLQyxlQUFMLEdBQXVCRCxjQUFjLElBQUlSLHdCQUF3QixFQUFqRTs7QUFDQSxRQUFJO0FBQ0YsVUFBSVUsSUFBSSxHQUFHYixFQUFFLENBQUNjLFlBQUgsQ0FBZ0IsTUFBS0YsZUFBckIsRUFBc0MsT0FBdEMsQ0FBWDtBQUNBLFlBQUtHLGVBQUwsR0FBdUJDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSixJQUFYLENBQXZCO0FBQ0QsS0FIRCxDQUdFLE9BQU9LLENBQVAsRUFBVSxDQUNWO0FBQ0Q7O0FBUjBEO0FBUzVEOztBQVpIO0FBQUE7QUFBQSxrQ0FjZ0I7QUFDWixVQUFNTCxJQUFJLEdBQUcsZ0JBQWUsS0FBS0UsZUFBcEIsRUFBcUMsSUFBckMsRUFBMkMsQ0FBM0MsQ0FBYjs7QUFDQSxVQUFJO0FBQ0ZmLFFBQUFBLEVBQUUsQ0FBQ21CLGFBQUgsQ0FBaUIsS0FBS1AsZUFBdEIsRUFBdUNDLElBQXZDO0FBQ0FiLFFBQUFBLEVBQUUsQ0FBQ29CLFNBQUgsQ0FBYSxLQUFLUixlQUFsQixFQUFtQyxLQUFuQztBQUNELE9BSEQsQ0FHRSxPQUFPTSxDQUFQLEVBQVU7QUFDVixZQUFNRyxTQUFTLEdBQUdwQixJQUFJLENBQUNxQixPQUFMLENBQWEsS0FBS1YsZUFBbEIsQ0FBbEI7QUFDQVosUUFBQUEsRUFBRSxDQUFDdUIsU0FBSCxDQUFhRixTQUFiO0FBQ0FyQixRQUFBQSxFQUFFLENBQUNvQixTQUFILENBQWFDLFNBQWIsRUFBd0IsS0FBeEI7QUFDQXJCLFFBQUFBLEVBQUUsQ0FBQ21CLGFBQUgsQ0FBaUIsS0FBS1AsZUFBdEIsRUFBdUNDLElBQXZDO0FBQ0FiLFFBQUFBLEVBQUUsQ0FBQ29CLFNBQUgsQ0FBYSxLQUFLUixlQUFsQixFQUFtQyxLQUFuQztBQUNEO0FBQ0Y7QUExQkg7O0FBQUE7QUFBQSxFQUFrQ1YsWUFBbEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgeyBCYXNlUmVnaXN0cnkgfSBmcm9tICcuL2Jhc2UnO1xuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIGdldERlZmF1bHRDb25maWdGaWxlUGF0aCgpIHtcbiAgY29uc3QgaG9tZURpciA9XG4gICAgcHJvY2Vzcy5lbnZbcHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJyA/ICdVU0VSUFJPRklMRScgOiAnSE9NRSddO1xuICBpZiAoIWhvbWVEaXIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnY2Fubm90IGZpbmQgdXNlciBob21lIGRpcmVjdG9yeSB0byBzdG9yZSBjb25maWd1cmF0aW9uIGZpbGVzJyxcbiAgICApO1xuICB9XG4gIHJldHVybiBwYXRoLmpvaW4oaG9tZURpciwgJy5qc2ZvcmNlJywgJ2NvbmZpZy5qc29uJyk7XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGNsYXNzIEZpbGVSZWdpc3RyeSBleHRlbmRzIEJhc2VSZWdpc3RyeSB7XG4gIF9jb25maWdGaWxlUGF0aDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHsgY29uZmlnRmlsZVBhdGggfTogeyBjb25maWdGaWxlUGF0aD86IHN0cmluZyB9KSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9jb25maWdGaWxlUGF0aCA9IGNvbmZpZ0ZpbGVQYXRoIHx8IGdldERlZmF1bHRDb25maWdGaWxlUGF0aCgpO1xuICAgIHRyeSB7XG4gICAgICB2YXIgZGF0YSA9IGZzLnJlYWRGaWxlU3luYyh0aGlzLl9jb25maWdGaWxlUGF0aCwgJ3V0Zi04Jyk7XG4gICAgICB0aGlzLl9yZWdpc3RyeUNvbmZpZyA9IEpTT04ucGFyc2UoZGF0YSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy9cbiAgICB9XG4gIH1cblxuICBfc2F2ZUNvbmZpZygpIHtcbiAgICBjb25zdCBkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5fcmVnaXN0cnlDb25maWcsIG51bGwsIDQpO1xuICAgIHRyeSB7XG4gICAgICBmcy53cml0ZUZpbGVTeW5jKHRoaXMuX2NvbmZpZ0ZpbGVQYXRoLCBkYXRhKTtcbiAgICAgIGZzLmNobW9kU3luYyh0aGlzLl9jb25maWdGaWxlUGF0aCwgJzYwMCcpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGNvbmZpZ0RpciA9IHBhdGguZGlybmFtZSh0aGlzLl9jb25maWdGaWxlUGF0aCk7XG4gICAgICBmcy5ta2RpclN5bmMoY29uZmlnRGlyKTtcbiAgICAgIGZzLmNobW9kU3luYyhjb25maWdEaXIsICc3MDAnKTtcbiAgICAgIGZzLndyaXRlRmlsZVN5bmModGhpcy5fY29uZmlnRmlsZVBhdGgsIGRhdGEpO1xuICAgICAgZnMuY2htb2RTeW5jKHRoaXMuX2NvbmZpZ0ZpbGVQYXRoLCAnNjAwJyk7XG4gICAgfVxuICB9XG59XG4iXX0=