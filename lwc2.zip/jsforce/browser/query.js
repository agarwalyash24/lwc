import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.includes";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.promise";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.includes";
import "core-js/modules/es.string.iterator";
import "core-js/modules/es.string.split";
import "core-js/modules/web.dom-collections.iterator";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _Object$entries from "@babel/runtime-corejs3/core-js-stable/object/entries";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _sortInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/sort";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context38; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context38 = Object.prototype.toString.call(o)).call(_context38, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context36; _forEachInstanceProperty(_context36 = ownKeys(Object(source), true)).call(_context36, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context37; _forEachInstanceProperty(_context37 = ownKeys(Object(source))).call(_context37, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages query for records in Salesforce
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { getLogger } from './util/logger';
import RecordStream, { Serializable } from './record-stream';
import { createSOQL } from './soql-builder';
var ResponseTargetValues = ['QueryResult', 'Records', 'SingleRecord', 'Count'];
export var ResponseTargets = _reduceInstanceProperty(ResponseTargetValues).call(ResponseTargetValues, function (values, target) {
  return _objectSpread(_objectSpread({}, values), {}, _defineProperty({}, target, target));
}, {});

/**
 *
 */
var DEFAULT_BULK_THRESHOLD = 200;
var DEFAULT_BULK_API_VERSION = 1;
/**
 * Query
 */

export var Query = /*#__PURE__*/function (_EventEmitter) {
  _inherits(Query, _EventEmitter);

  var _super = _createSuper(Query);

  /**
   *
   */
  function Query(conn, config, options) {
    var _this;

    _classCallCheck(this, Query);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_conn", void 0);

    _defineProperty(_assertThisInitialized(_this), "_logger", void 0);

    _defineProperty(_assertThisInitialized(_this), "_soql", void 0);

    _defineProperty(_assertThisInitialized(_this), "_locator", void 0);

    _defineProperty(_assertThisInitialized(_this), "_config", {});

    _defineProperty(_assertThisInitialized(_this), "_children", []);

    _defineProperty(_assertThisInitialized(_this), "_options", void 0);

    _defineProperty(_assertThisInitialized(_this), "_executed", false);

    _defineProperty(_assertThisInitialized(_this), "_finished", false);

    _defineProperty(_assertThisInitialized(_this), "_chaining", false);

    _defineProperty(_assertThisInitialized(_this), "_promise", void 0);

    _defineProperty(_assertThisInitialized(_this), "_stream", void 0);

    _defineProperty(_assertThisInitialized(_this), "totalSize", 0);

    _defineProperty(_assertThisInitialized(_this), "totalFetched", 0);

    _defineProperty(_assertThisInitialized(_this), "records", []);

    _defineProperty(_assertThisInitialized(_this), "offset", _this.skip);

    _defineProperty(_assertThisInitialized(_this), "orderby", _sortInstanceProperty(_this));

    _defineProperty(_assertThisInitialized(_this), "exec", _this.execute);

    _defineProperty(_assertThisInitialized(_this), "run", _this.execute);

    _defineProperty(_assertThisInitialized(_this), "delete", _this.destroy);

    _defineProperty(_assertThisInitialized(_this), "del", _this.destroy);

    _this._conn = conn;
    _this._logger = conn._logLevel ? Query._logger.createInstance(conn._logLevel) : Query._logger;

    if (typeof config === 'string') {
      _this._soql = config;

      _this._logger.debug("config is soql: ".concat(config));
    } else if (typeof config.locator === 'string') {
      var locator = config.locator;

      _this._logger.debug("config is locator: ".concat(locator));

      _this._locator = _includesInstanceProperty(locator).call(locator, '/') ? _this.urlToLocator(locator) : locator;
    } else {
      _this._logger.debug("config is QueryConfig: ".concat(config));

      var _ref = config,
          _fields = _ref.fields,
          includes = _includesInstanceProperty(_ref),
          _sort2 = _sortInstanceProperty(_ref),
          _config = _objectWithoutProperties(_ref, ["fields", "includes", "sort"]);

      _this._config = _config;

      _this.select(_fields);

      if (includes) {
        _this.includeChildren(includes);
      }

      if (_sort2) {
        _sortInstanceProperty(_this).call(_this, _sort2);
      }
    }

    _this._options = _objectSpread({
      headers: {},
      maxFetch: 10000,
      autoFetch: false,
      scanAll: false,
      responseTarget: 'QueryResult'
    }, options || {}); // promise instance

    _this._promise = new _Promise(function (resolve, reject) {
      _this.on('response', resolve);

      _this.on('error', reject);
    });
    _this._stream = new Serializable();

    _this.on('record', function (record) {
      return _this._stream.push(record);
    });

    _this.on('end', function () {
      return _this._stream.push(null);
    });

    _this.on('error', function (err) {
      try {
        _this._stream.emit('error', err);
      } catch (e) {// eslint-disable-line no-empty
      }
    });

    return _this;
  }
  /**
   * Select fields to include in the returning result
   */


  _createClass(Query, [{
    key: "select",
    value: function select() {
      var fields = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '*';

      if (this._soql) {
        throw Error('Cannot set select fields for the query which has already built SOQL.');
      }

      function toFieldArray(fields) {
        var _context, _context2, _context4, _context5;

        return typeof fields === 'string' ? fields.split(/\s*,\s*/) : _Array$isArray(fields) ? _reduceInstanceProperty(_context = _mapInstanceProperty(_context2 = fields).call(_context2, toFieldArray)).call(_context, function (fs, f) {
          var _context3;

          return _concatInstanceProperty(_context3 = []).call(_context3, _toConsumableArray(fs), _toConsumableArray(f));
        }, []) : _reduceInstanceProperty(_context4 = _mapInstanceProperty(_context5 = _Object$entries(fields)).call(_context5, function (_ref2) {
          var _ref3 = _slicedToArray(_ref2, 2),
              f = _ref3[0],
              v = _ref3[1];

          if (typeof v === 'number' || typeof v === 'boolean') {
            return v ? [f] : [];
          } else {
            var _context6;

            return _mapInstanceProperty(_context6 = toFieldArray(v)).call(_context6, function (p) {
              var _context7;

              return _concatInstanceProperty(_context7 = "".concat(f, ".")).call(_context7, p);
            });
          }
        })).call(_context4, function (fs, f) {
          var _context8;

          return _concatInstanceProperty(_context8 = []).call(_context8, _toConsumableArray(fs), _toConsumableArray(f));
        }, []);
      }

      if (fields) {
        this._config.fields = toFieldArray(fields);
      } // force convert query record type without changing instance;


      return this;
    }
    /**
     * Set query conditions to filter the result records
     */

  }, {
    key: "where",
    value: function where(conditions) {
      if (this._soql) {
        throw Error('Cannot set where conditions for the query which has already built SOQL.');
      }

      this._config.conditions = conditions;
      return this;
    }
    /**
     * Limit the returning result
     */

  }, {
    key: "limit",
    value: function limit(_limit) {
      if (this._soql) {
        throw Error('Cannot set limit for the query which has already built SOQL.');
      }

      this._config.limit = _limit;
      return this;
    }
    /**
     * Skip records
     */

  }, {
    key: "skip",
    value: function skip(offset) {
      if (this._soql) {
        throw Error('Cannot set skip/offset for the query which has already built SOQL.');
      }

      this._config.offset = offset;
      return this;
    }
    /**
     * Synonym of Query#skip()
     */

  }, {
    key: "sort",
    value: function (_sort) {
      function sort(_x, _x2) {
        return _sort.apply(this, arguments);
      }

      sort.toString = function () {
        return _sort.toString();
      };

      return sort;
    }(function (sort, dir) {
      if (this._soql) {
        throw Error('Cannot set sort for the query which has already built SOQL.');
      }

      if (typeof sort === 'string' && typeof dir !== 'undefined') {
        this._config.sort = [[sort, dir]];
      } else {
        this._config.sort = sort;
      }

      return this;
    })
    /**
     * Synonym of Query#sort()
     */

  }, {
    key: "include",
    value: function include(childRelName, conditions, fields) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

      if (this._soql) {
        throw Error('Cannot include child relationship into the query which has already built SOQL.');
      }

      var childConfig = {
        fields: fields === null ? undefined : fields,
        table: childRelName,
        conditions: conditions === null ? undefined : conditions,
        limit: options.limit,
        offset: options.offset,
        sort: _sortInstanceProperty(options)
      }; // eslint-disable-next-line no-use-before-define

      var childQuery = new SubQuery(this._conn, childRelName, childConfig, this);

      this._children.push(childQuery);

      return childQuery;
    }
    /**
     * Include child relationship queries, but not moving down to the children context
     */

  }, {
    key: "includeChildren",
    value: function includeChildren(includes) {
      if (this._soql) {
        throw Error('Cannot include child relationship into the query which has already built SOQL.');
      }

      var _iterator = _createForOfIteratorHelper(_Object$keys(includes)),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var crname = _step.value;

          var _ref4 = includes[crname],
              _conditions = _ref4.conditions,
              _fields2 = _ref4.fields,
              _options = _objectWithoutProperties(_ref4, ["conditions", "fields"]);

          this.include(crname, _conditions, _fields2, _options);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      return this;
    }
    /**
     * Setting maxFetch query option
     */

  }, {
    key: "maxFetch",
    value: function maxFetch(_maxFetch) {
      this._options.maxFetch = _maxFetch;
      return this;
    }
    /**
     * Switching auto fetch mode
     */

  }, {
    key: "autoFetch",
    value: function autoFetch(_autoFetch) {
      this._options.autoFetch = _autoFetch;
      return this;
    }
    /**
     * Set flag to scan all records including deleted and archived.
     */

  }, {
    key: "scanAll",
    value: function scanAll(_scanAll) {
      this._options.scanAll = _scanAll;
      return this;
    }
    /**
     *
     */

  }, {
    key: "setResponseTarget",
    value: function setResponseTarget(responseTarget) {
      if (responseTarget in ResponseTargets) {
        this._options.responseTarget = responseTarget;
      } // force change query response target without changing instance


      return this;
    }
    /**
     * Execute query and fetch records from server.
     */

  }, {
    key: "execute",
    value: function execute() {
      var _this2 = this;

      var options_ = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (this._executed) {
        throw new Error('re-executing already executed query');
      }

      if (this._finished) {
        throw new Error('executing already closed query');
      }

      var options = {
        headers: options_.headers || this._options.headers,
        responseTarget: options_.responseTarget || this._options.responseTarget,
        autoFetch: options_.autoFetch || this._options.autoFetch,
        maxFetch: options_.maxFetch || this._options.maxFetch,
        scanAll: options_.scanAll || this._options.scanAll
      }; // collect fetched records in array
      // only when response target is Records and
      // either callback or chaining promises are available to this query.

      this.once('fetch', function () {
        if (options.responseTarget === ResponseTargets.Records && _this2._chaining) {
          _this2._logger.debug('--- collecting all fetched records ---');

          var records = [];

          var onRecord = function onRecord(record) {
            return records.push(record);
          };

          _this2.on('record', onRecord);

          _this2.once('end', function () {
            _this2.removeListener('record', onRecord);

            _this2.emit('response', records, _this2);
          });
        }
      }); // flag to prevent re-execution

      this._executed = true;

      _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        return _regeneratorRuntime.wrap(function _callee$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                // start actual query
                _this2._logger.debug('>>> Query start >>>');

                _context9.prev = 1;
                _context9.next = 4;
                return _this2._execute(options);

              case 4:
                _this2._logger.debug('*** Query finished ***');

                _context9.next = 11;
                break;

              case 7:
                _context9.prev = 7;
                _context9.t0 = _context9["catch"](1);

                _this2._logger.debug('--- Query error ---', _context9.t0);

                _this2.emit('error', _context9.t0);

              case 11:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee, null, [[1, 7]]);
      }))(); // return Query instance for chaining


      return this;
    }
    /**
     * Synonym of Query#execute()
     */

  }, {
    key: "locatorToUrl",
    value: function locatorToUrl() {
      return this._locator ? [this._conn._baseUrl(), '/query/', this._locator].join('') : '';
    }
  }, {
    key: "urlToLocator",
    value: function urlToLocator(url) {
      return url.split('/').pop();
    }
  }, {
    key: "constructResponse",
    value: function constructResponse(rawDone, responseTarget) {
      var _this$records$, _this$records;

      switch (responseTarget) {
        case 'Count':
          return this.totalSize;

        case 'SingleRecord':
          return (_this$records$ = (_this$records = this.records) === null || _this$records === void 0 ? void 0 : _this$records[0]) !== null && _this$records$ !== void 0 ? _this$records$ : null;

        case 'Records':
          return this.records;
        // QueryResult is default response target

        default:
          return _objectSpread(_objectSpread({}, {
            records: this.records,
            totalSize: this.totalSize,
            done: rawDone !== null && rawDone !== void 0 ? rawDone : true // when no records, done is omitted

          }), this._locator ? {
            nextRecordsUrl: this.locatorToUrl()
          } : {});
      }
    }
    /**
     * @private
     */

  }, {
    key: "_execute",
    value: function () {
      var _execute2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(options) {
        var _this$records2, _context10, _data$records$length, _data$records;

        var headers, responseTarget, autoFetch, maxFetch, scanAll, url, soql, data, numRecords, totalFetched, i, record, response;
        return _regeneratorRuntime.wrap(function _callee2$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                headers = options.headers, responseTarget = options.responseTarget, autoFetch = options.autoFetch, maxFetch = options.maxFetch, scanAll = options.scanAll;

                this._logger.debug('execute with options', options);

                if (!this._locator) {
                  _context11.next = 6;
                  break;
                }

                url = this.locatorToUrl();
                _context11.next = 11;
                break;

              case 6:
                _context11.next = 8;
                return this.toSOQL();

              case 8:
                soql = _context11.sent;

                this._logger.debug("SOQL = ".concat(soql));

                url = [this._conn._baseUrl(), '/', scanAll ? 'queryAll' : 'query', '?q=', encodeURIComponent(soql)].join('');

              case 11:
                _context11.next = 13;
                return this._conn.request({
                  method: 'GET',
                  url: url,
                  headers: headers
                });

              case 13:
                data = _context11.sent;
                this.emit('fetch');
                this.totalSize = data.totalSize;
                this.records = (_this$records2 = this.records) === null || _this$records2 === void 0 ? void 0 : _concatInstanceProperty(_this$records2).call(_this$records2, maxFetch - this.records.length > data.records.length ? data.records : _sliceInstanceProperty(_context10 = data.records).call(_context10, 0, maxFetch - this.records.length));
                this._locator = data.nextRecordsUrl ? this.urlToLocator(data.nextRecordsUrl) : undefined;
                this._finished = this._finished || data.done || !autoFetch || // this is what the response looks like when there are no results
                data.records.length === 0 && data.done === undefined; // streaming record instances

                numRecords = (_data$records$length = (_data$records = data.records) === null || _data$records === void 0 ? void 0 : _data$records.length) !== null && _data$records$length !== void 0 ? _data$records$length : 0;
                totalFetched = this.totalFetched;
                i = 0;

              case 22:
                if (!(i < numRecords)) {
                  _context11.next = 32;
                  break;
                }

                if (!(totalFetched >= maxFetch)) {
                  _context11.next = 26;
                  break;
                }

                this._finished = true;
                return _context11.abrupt("break", 32);

              case 26:
                record = data.records[i];
                this.emit('record', record, totalFetched, this);
                totalFetched += 1;

              case 29:
                i++;
                _context11.next = 22;
                break;

              case 32:
                this.totalFetched = totalFetched;

                if (!this._finished) {
                  _context11.next = 40;
                  break;
                }

                response = this.constructResponse(data.done, responseTarget); // only fire response event when it should be notified per fetch

                if (responseTarget !== ResponseTargets.Records) {
                  this.emit('response', response, this);
                }

                this.emit('end');
                return _context11.abrupt("return", response);

              case 40:
                return _context11.abrupt("return", this._execute(options));

              case 41:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee2, this);
      }));

      function _execute(_x3) {
        return _execute2.apply(this, arguments);
      }

      return _execute;
    }()
    /**
     * Obtain readable stream instance
     */

  }, {
    key: "stream",
    value: function stream() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'csv';

      if (!this._finished && !this._executed) {
        this.execute({
          autoFetch: true
        });
      }

      return type === 'record' ? this._stream : this._stream.stream(type);
    }
    /**
     * Pipe the queried records to another stream
     * This is for backward compatibility; Query is not a record stream instance anymore in 2.0.
     * If you want a record stream instance, use `Query#stream('record')`.
     */

  }, {
    key: "pipe",
    value: function pipe(stream) {
      return this.stream('record').pipe(stream);
    }
    /**
     * @protected
     */

  }, {
    key: "_expandFields",
    value: function () {
      var _expandFields2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(sobject_) {
        var _context12, _context13, _context14, _context16, _context17;

        var _this$_config, _this$_config$fields, fields, _this$_config$table, table, sobject, _yield$Promise$all, _yield$Promise$all2, efields;

        return _regeneratorRuntime.wrap(function _callee4$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                if (!this._soql) {
                  _context18.next = 2;
                  break;
                }

                throw new Error('Cannot expand fields for the query which has already built SOQL.');

              case 2:
                _this$_config = this._config, _this$_config$fields = _this$_config.fields, fields = _this$_config$fields === void 0 ? [] : _this$_config$fields, _this$_config$table = _this$_config.table, table = _this$_config$table === void 0 ? '' : _this$_config$table;
                sobject = sobject_ || table;

                this._logger.debug(_concatInstanceProperty(_context12 = "_expandFields: sobject = ".concat(sobject, ", fields = ")).call(_context12, fields.join(', ')));

                _context18.next = 7;
                return _Promise.all(_concatInstanceProperty(_context13 = [this._expandAsteriskFields(sobject, fields)]).call(_context13, _toConsumableArray(_mapInstanceProperty(_context14 = this._children).call(_context14, /*#__PURE__*/function () {
                  var _ref6 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(childQuery) {
                    return _regeneratorRuntime.wrap(function _callee3$(_context15) {
                      while (1) {
                        switch (_context15.prev = _context15.next) {
                          case 0:
                            _context15.next = 2;
                            return childQuery._expandFields();

                          case 2:
                            return _context15.abrupt("return", []);

                          case 3:
                          case "end":
                            return _context15.stop();
                        }
                      }
                    }, _callee3);
                  }));

                  return function (_x5) {
                    return _ref6.apply(this, arguments);
                  };
                }()))));

              case 7:
                _yield$Promise$all = _context18.sent;
                _yield$Promise$all2 = _slicedToArray(_yield$Promise$all, 1);
                efields = _yield$Promise$all2[0];
                this._config.fields = efields;
                this._config.includes = _reduceInstanceProperty(_context16 = _mapInstanceProperty(_context17 = this._children).call(_context17, function (cquery) {
                  var cconfig = cquery._query._config;
                  return [cconfig.table, cconfig];
                })).call(_context16, function (includes, _ref7) {
                  var _ref8 = _slicedToArray(_ref7, 2),
                      ctable = _ref8[0],
                      cconfig = _ref8[1];

                  return _objectSpread(_objectSpread({}, includes), {}, _defineProperty({}, ctable, cconfig));
                }, {});

              case 12:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee4, this);
      }));

      function _expandFields(_x4) {
        return _expandFields2.apply(this, arguments);
      }

      return _expandFields;
    }()
    /**
     *
     */

  }, {
    key: "_findRelationObject",
    value: function () {
      var _findRelationObject2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(relName) {
        var _context19;

        var table, sobject, upperRname, _iterator2, _step2, cr;

        return _regeneratorRuntime.wrap(function _callee5$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                table = this._config.table;

                if (table) {
                  _context20.next = 3;
                  break;
                }

                throw new Error('No table information provided in the query');

              case 3:
                this._logger.debug(_concatInstanceProperty(_context19 = "finding table for relation \"".concat(relName, "\" in \"")).call(_context19, table, "\"..."));

                _context20.next = 6;
                return this._conn.describe$(table);

              case 6:
                sobject = _context20.sent;
                upperRname = relName.toUpperCase();
                _iterator2 = _createForOfIteratorHelper(sobject.childRelationships);
                _context20.prev = 9;

                _iterator2.s();

              case 11:
                if ((_step2 = _iterator2.n()).done) {
                  _context20.next = 17;
                  break;
                }

                cr = _step2.value;

                if (!((cr.relationshipName || '').toUpperCase() === upperRname && cr.childSObject)) {
                  _context20.next = 15;
                  break;
                }

                return _context20.abrupt("return", cr.childSObject);

              case 15:
                _context20.next = 11;
                break;

              case 17:
                _context20.next = 22;
                break;

              case 19:
                _context20.prev = 19;
                _context20.t0 = _context20["catch"](9);

                _iterator2.e(_context20.t0);

              case 22:
                _context20.prev = 22;

                _iterator2.f();

                return _context20.finish(22);

              case 25:
                throw new Error("No child relationship found: ".concat(relName));

              case 26:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee5, this, [[9, 19, 22, 25]]);
      }));

      function _findRelationObject(_x6) {
        return _findRelationObject2.apply(this, arguments);
      }

      return _findRelationObject;
    }()
    /**
     *
     */

  }, {
    key: "_expandAsteriskFields",
    value: function () {
      var _expandAsteriskFields2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(sobject, fields) {
        var _this3 = this;

        var expandedFields;
        return _regeneratorRuntime.wrap(function _callee7$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                _context23.next = 2;
                return _Promise.all(_mapInstanceProperty(fields).call(fields, /*#__PURE__*/function () {
                  var _ref9 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6(field) {
                    return _regeneratorRuntime.wrap(function _callee6$(_context21) {
                      while (1) {
                        switch (_context21.prev = _context21.next) {
                          case 0:
                            return _context21.abrupt("return", _this3._expandAsteriskField(sobject, field));

                          case 1:
                          case "end":
                            return _context21.stop();
                        }
                      }
                    }, _callee6);
                  }));

                  return function (_x9) {
                    return _ref9.apply(this, arguments);
                  };
                }()));

              case 2:
                expandedFields = _context23.sent;
                return _context23.abrupt("return", _reduceInstanceProperty(expandedFields).call(expandedFields, function (eflds, flds) {
                  var _context22;

                  return _concatInstanceProperty(_context22 = []).call(_context22, _toConsumableArray(eflds), _toConsumableArray(flds));
                }, []));

              case 4:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee7);
      }));

      function _expandAsteriskFields(_x7, _x8) {
        return _expandAsteriskFields2.apply(this, arguments);
      }

      return _expandAsteriskFields;
    }()
    /**
     *
     */

  }, {
    key: "_expandAsteriskField",
    value: function () {
      var _expandAsteriskField2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(sobject, field) {
        var _context24,
            _this4 = this;

        var fpath, _context27, so, _ret;

        return _regeneratorRuntime.wrap(function _callee9$(_context28) {
          while (1) {
            switch (_context28.prev = _context28.next) {
              case 0:
                this._logger.debug(_concatInstanceProperty(_context24 = "expanding field \"".concat(field, "\" in \"")).call(_context24, sobject, "\"..."));

                fpath = field.split('.');

                if (!(fpath[fpath.length - 1] === '*')) {
                  _context28.next = 13;
                  break;
                }

                _context28.next = 5;
                return this._conn.describe$(sobject);

              case 5:
                so = _context28.sent;

                this._logger.debug("table ".concat(sobject, " has been described"));

                if (!(fpath.length > 1)) {
                  _context28.next = 12;
                  break;
                }

                return _context28.delegateYield( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
                  var rname, _iterator3, _step3, f, rfield, referenceTo, rtable, fpaths;

                  return _regeneratorRuntime.wrap(function _callee8$(_context26) {
                    while (1) {
                      switch (_context26.prev = _context26.next) {
                        case 0:
                          rname = fpath.shift();
                          _iterator3 = _createForOfIteratorHelper(so.fields);
                          _context26.prev = 2;

                          _iterator3.s();

                        case 4:
                          if ((_step3 = _iterator3.n()).done) {
                            _context26.next = 16;
                            break;
                          }

                          f = _step3.value;

                          if (!(f.relationshipName && rname && f.relationshipName.toUpperCase() === rname.toUpperCase())) {
                            _context26.next = 14;
                            break;
                          }

                          rfield = f;
                          referenceTo = rfield.referenceTo || [];
                          rtable = referenceTo.length === 1 ? referenceTo[0] : 'Name';
                          _context26.next = 12;
                          return _this4._expandAsteriskField(rtable, fpath.join('.'));

                        case 12:
                          fpaths = _context26.sent;
                          return _context26.abrupt("return", {
                            v: _mapInstanceProperty(fpaths).call(fpaths, function (fp) {
                              var _context25;

                              return _concatInstanceProperty(_context25 = "".concat(rname, ".")).call(_context25, fp);
                            })
                          });

                        case 14:
                          _context26.next = 4;
                          break;

                        case 16:
                          _context26.next = 21;
                          break;

                        case 18:
                          _context26.prev = 18;
                          _context26.t0 = _context26["catch"](2);

                          _iterator3.e(_context26.t0);

                        case 21:
                          _context26.prev = 21;

                          _iterator3.f();

                          return _context26.finish(21);

                        case 24:
                          return _context26.abrupt("return", {
                            v: []
                          });

                        case 25:
                        case "end":
                          return _context26.stop();
                      }
                    }
                  }, _callee8, null, [[2, 18, 21, 24]]);
                })(), "t0", 9);

              case 9:
                _ret = _context28.t0;

                if (!(_typeof(_ret) === "object")) {
                  _context28.next = 12;
                  break;
                }

                return _context28.abrupt("return", _ret.v);

              case 12:
                return _context28.abrupt("return", _mapInstanceProperty(_context27 = so.fields).call(_context27, function (f) {
                  return f.name;
                }));

              case 13:
                return _context28.abrupt("return", [field]);

              case 14:
              case "end":
                return _context28.stop();
            }
          }
        }, _callee9, this);
      }));

      function _expandAsteriskField(_x10, _x11) {
        return _expandAsteriskField2.apply(this, arguments);
      }

      return _expandAsteriskField;
    }()
    /**
     * Explain plan for executing query
     */

  }, {
    key: "explain",
    value: function () {
      var _explain = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        var soql, url;
        return _regeneratorRuntime.wrap(function _callee10$(_context29) {
          while (1) {
            switch (_context29.prev = _context29.next) {
              case 0:
                _context29.next = 2;
                return this.toSOQL();

              case 2:
                soql = _context29.sent;

                this._logger.debug("SOQL = ".concat(soql));

                url = "/query/?explain=".concat(encodeURIComponent(soql));
                return _context29.abrupt("return", this._conn.request(url));

              case 6:
              case "end":
                return _context29.stop();
            }
          }
        }, _callee10, this);
      }));

      function explain() {
        return _explain.apply(this, arguments);
      }

      return explain;
    }()
    /**
     * Return SOQL expression for the query
     */

  }, {
    key: "toSOQL",
    value: function () {
      var _toSOQL = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        return _regeneratorRuntime.wrap(function _callee11$(_context30) {
          while (1) {
            switch (_context30.prev = _context30.next) {
              case 0:
                if (!this._soql) {
                  _context30.next = 2;
                  break;
                }

                return _context30.abrupt("return", this._soql);

              case 2:
                _context30.next = 4;
                return this._expandFields();

              case 4:
                return _context30.abrupt("return", createSOQL(this._config));

              case 5:
              case "end":
                return _context30.stop();
            }
          }
        }, _callee11, this);
      }));

      function toSOQL() {
        return _toSOQL.apply(this, arguments);
      }

      return toSOQL;
    }()
    /**
     * Promise/A+ interface
     * http://promises-aplus.github.io/promises-spec/
     *
     * Delegate to deferred promise, return promise instance for query result
     */

  }, {
    key: "then",
    value: function then(onResolve, onReject) {
      this._chaining = true;

      if (!this._finished && !this._executed) {
        this.execute();
      }

      if (!this._promise) {
        throw new Error('invalid state: promise is not set after query execution');
      }

      return this._promise.then(onResolve, onReject);
    }
  }, {
    key: "catch",
    value: function _catch(onReject) {
      return this.then(null, onReject);
    }
  }, {
    key: "promise",
    value: function promise() {
      return _Promise.resolve(this);
    }
    /**
     * Bulk delete queried records
     */

  }, {
    key: "destroy",
    value: function destroy(type, options) {
      var _options$bulkApiVersi,
          _this5 = this;

      if (_typeof(type) === 'object' && type !== null) {
        options = type;
        type = undefined;
      }

      options = options || {};
      var type_ = type || this._config.table;

      if (!type_) {
        throw new Error('SOQL based query needs SObject type information to bulk delete.');
      } // Set the threshold number to pass to bulk API


      var thresholdNum = options.allowBulk === false ? -1 : typeof options.bulkThreshold === 'number' ? options.bulkThreshold : // determine threshold if the connection version supports SObject collection API or not
      this._conn._ensureVersion(42) ? DEFAULT_BULK_THRESHOLD : this._conn._maxRequest / 2;
      var bulkApiVersion = (_options$bulkApiVersi = options.bulkApiVersion) !== null && _options$bulkApiVersi !== void 0 ? _options$bulkApiVersi : DEFAULT_BULK_API_VERSION;
      return new _Promise(function (resolve, reject) {
        var createBatch = function createBatch() {
          return _this5._conn.sobject(type_).deleteBulk().on('response', resolve).on('error', reject);
        };

        var records = [];
        var batch = null;

        var handleRecord = function handleRecord(rec) {
          if (!rec.Id) {
            var _err = new Error('Queried record does not include Salesforce record ID.');

            _this5.emit('error', _err);

            return;
          }

          var record = {
            Id: rec.Id
          };

          if (batch) {
            batch.write(record);
          } else {
            records.push(record);

            if (thresholdNum >= 0 && records.length > thresholdNum && bulkApiVersion === 1) {
              // Use bulk delete instead of SObject REST API
              batch = createBatch();

              var _iterator4 = _createForOfIteratorHelper(records),
                  _step4;

              try {
                for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                  var _record = _step4.value;
                  batch.write(_record);
                }
              } catch (err) {
                _iterator4.e(err);
              } finally {
                _iterator4.f();
              }

              records = [];
            }
          }
        };

        var handleEnd = function handleEnd() {
          if (batch) {
            batch.end();
          } else {
            var ids = _mapInstanceProperty(records).call(records, function (record) {
              return record.Id;
            });

            if (records.length > thresholdNum && bulkApiVersion === 2) {
              _this5._conn.bulk2.loadAndWaitForResults({
                object: type_,
                operation: 'delete',
                input: records
              }).then(function (allResults) {
                return resolve(_this5.mapBulkV2ResultsToSaveResults(allResults));
              }, reject);
            } else {
              _this5._conn.sobject(type_).destroy(ids, {
                allowRecursive: true
              }).then(resolve, reject);
            }
          }
        };

        _this5.stream('record').on('data', handleRecord).on('end', handleEnd).on('error', reject);
      });
    }
    /**
     * Synonym of Query#destroy()
     */

  }, {
    key: "update",
    value: function update(mapping, type, options) {
      var _options$bulkApiVersi2,
          _this6 = this;

      if (_typeof(type) === 'object' && type !== null) {
        options = type;
        type = undefined;
      }

      options = options || {};
      var type_ = type || this._config && this._config.table;

      if (!type_) {
        throw new Error('SOQL based query needs SObject type information to bulk update.');
      }

      var updateStream = typeof mapping === 'function' ? _mapInstanceProperty(RecordStream).call(RecordStream, mapping) : RecordStream.recordMapStream(mapping); // Set the threshold number to pass to bulk API

      var thresholdNum = options.allowBulk === false ? -1 : typeof options.bulkThreshold === 'number' ? options.bulkThreshold : // determine threshold if the connection version supports SObject collection API or not
      this._conn._ensureVersion(42) ? DEFAULT_BULK_THRESHOLD : this._conn._maxRequest / 2;
      var bulkApiVersion = (_options$bulkApiVersi2 = options.bulkApiVersion) !== null && _options$bulkApiVersi2 !== void 0 ? _options$bulkApiVersi2 : DEFAULT_BULK_API_VERSION;
      return new _Promise(function (resolve, reject) {
        var createBatch = function createBatch() {
          return _this6._conn.sobject(type_).updateBulk().on('response', resolve).on('error', reject);
        };

        var records = [];
        var batch = null;

        var handleRecord = function handleRecord(record) {
          if (batch) {
            batch.write(record);
          } else {
            records.push(record);
          }

          if (thresholdNum >= 0 && records.length > thresholdNum && bulkApiVersion === 1) {
            // Use bulk update instead of SObject REST API
            batch = createBatch();

            var _iterator5 = _createForOfIteratorHelper(records),
                _step5;

            try {
              for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                var _record2 = _step5.value;
                batch.write(_record2);
              }
            } catch (err) {
              _iterator5.e(err);
            } finally {
              _iterator5.f();
            }

            records = [];
          }
        };

        var handleEnd = function handleEnd() {
          if (batch) {
            batch.end();
          } else {
            if (records.length > thresholdNum && bulkApiVersion === 2) {
              _this6._conn.bulk2.loadAndWaitForResults({
                object: type_,
                operation: 'update',
                input: records
              }).then(function (allResults) {
                return resolve(_this6.mapBulkV2ResultsToSaveResults(allResults));
              }, reject);
            } else {
              _this6._conn.sobject(type_).update(records, {
                allowRecursive: true
              }).then(resolve, reject);
            }
          }
        };

        _this6.stream('record').on('error', reject).pipe(updateStream).on('data', handleRecord).on('end', handleEnd).on('error', reject);
      });
    }
  }, {
    key: "mapBulkV2ResultsToSaveResults",
    value: function mapBulkV2ResultsToSaveResults(bulkJobAllResults) {
      var _context31, _context32, _context33;

      var successSaveResults = _mapInstanceProperty(_context31 = bulkJobAllResults.successfulResults).call(_context31, function (r) {
        var saveResult = {
          id: r.sf__Id,
          success: true,
          errors: []
        };
        return saveResult;
      });

      var failedSaveResults = _mapInstanceProperty(_context32 = bulkJobAllResults.failedResults).call(_context32, function (r) {
        var saveResult = {
          success: false,
          errors: [{
            errorCode: r.sf__Error,
            message: r.sf__Error
          }]
        };
        return saveResult;
      });

      return _concatInstanceProperty(_context33 = []).call(_context33, _toConsumableArray(successSaveResults), _toConsumableArray(failedSaveResults));
    }
  }]);

  return Query;
}(EventEmitter);
/*--------------------------------------------*/

/**
 * SubQuery object for representing child relationship query
 */

_defineProperty(Query, "_logger", getLogger('query'));

export var SubQuery = /*#__PURE__*/function () {
  /**
   *
   */
  function SubQuery(conn, relName, config, parent) {
    _classCallCheck(this, SubQuery);

    _defineProperty(this, "_relName", void 0);

    _defineProperty(this, "_query", void 0);

    _defineProperty(this, "_parent", void 0);

    _defineProperty(this, "offset", this.skip);

    _defineProperty(this, "orderby", _sortInstanceProperty(this));

    this._relName = relName;
    this._query = new Query(conn, config);
    this._parent = parent;
  }
  /**
   *
   */


  _createClass(SubQuery, [{
    key: "select",
    value: function select(fields) {
      // force convert query record type without changing instance
      this._query = this._query.select(fields);
      return this;
    }
    /**
     *
     */

  }, {
    key: "where",
    value: function where(conditions) {
      this._query = this._query.where(conditions);
      return this;
    }
    /**
     * Limit the returning result
     */

  }, {
    key: "limit",
    value: function limit(_limit2) {
      this._query = this._query.limit(_limit2);
      return this;
    }
    /**
     * Skip records
     */

  }, {
    key: "skip",
    value: function skip(offset) {
      this._query = this._query.skip(offset);
      return this;
    }
    /**
     * Synonym of SubQuery#skip()
     */

  }, {
    key: "sort",
    value: function (_sort3) {
      function sort(_x12, _x13) {
        return _sort3.apply(this, arguments);
      }

      sort.toString = function () {
        return _sort3.toString();
      };

      return sort;
    }(function (sort, dir) {
      var _context34;

      this._query = _sortInstanceProperty(_context34 = this._query).call(_context34, sort, dir);
      return this;
    })
    /**
     * Synonym of SubQuery#sort()
     */

  }, {
    key: "_expandFields",

    /**
     *
     */
    value: function () {
      var _expandFields3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        var sobject;
        return _regeneratorRuntime.wrap(function _callee12$(_context35) {
          while (1) {
            switch (_context35.prev = _context35.next) {
              case 0:
                _context35.next = 2;
                return this._parent._findRelationObject(this._relName);

              case 2:
                sobject = _context35.sent;
                return _context35.abrupt("return", this._query._expandFields(sobject));

              case 4:
              case "end":
                return _context35.stop();
            }
          }
        }, _callee12, this);
      }));

      function _expandFields() {
        return _expandFields3.apply(this, arguments);
      }

      return _expandFields;
    }()
    /**
     * Back the context to parent query object
     */

  }, {
    key: "end",
    value: function end() {
      return this._parent;
    }
  }]);

  return SubQuery;
}();
export default Query;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9xdWVyeS50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJnZXRMb2dnZXIiLCJSZWNvcmRTdHJlYW0iLCJTZXJpYWxpemFibGUiLCJjcmVhdGVTT1FMIiwiUmVzcG9uc2VUYXJnZXRWYWx1ZXMiLCJSZXNwb25zZVRhcmdldHMiLCJ2YWx1ZXMiLCJ0YXJnZXQiLCJERUZBVUxUX0JVTEtfVEhSRVNIT0xEIiwiREVGQVVMVF9CVUxLX0FQSV9WRVJTSU9OIiwiUXVlcnkiLCJjb25uIiwiY29uZmlnIiwib3B0aW9ucyIsInNraXAiLCJleGVjdXRlIiwiZGVzdHJveSIsIl9jb25uIiwiX2xvZ2dlciIsIl9sb2dMZXZlbCIsImNyZWF0ZUluc3RhbmNlIiwiX3NvcWwiLCJkZWJ1ZyIsImxvY2F0b3IiLCJfbG9jYXRvciIsInVybFRvTG9jYXRvciIsImZpZWxkcyIsImluY2x1ZGVzIiwic29ydCIsIl9jb25maWciLCJzZWxlY3QiLCJpbmNsdWRlQ2hpbGRyZW4iLCJfb3B0aW9ucyIsImhlYWRlcnMiLCJtYXhGZXRjaCIsImF1dG9GZXRjaCIsInNjYW5BbGwiLCJyZXNwb25zZVRhcmdldCIsIl9wcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIm9uIiwiX3N0cmVhbSIsInJlY29yZCIsInB1c2giLCJlcnIiLCJlbWl0IiwiZSIsIkVycm9yIiwidG9GaWVsZEFycmF5Iiwic3BsaXQiLCJmcyIsImYiLCJ2IiwicCIsImNvbmRpdGlvbnMiLCJsaW1pdCIsIm9mZnNldCIsImRpciIsImNoaWxkUmVsTmFtZSIsImNoaWxkQ29uZmlnIiwidW5kZWZpbmVkIiwidGFibGUiLCJjaGlsZFF1ZXJ5IiwiU3ViUXVlcnkiLCJfY2hpbGRyZW4iLCJjcm5hbWUiLCJpbmNsdWRlIiwib3B0aW9uc18iLCJfZXhlY3V0ZWQiLCJfZmluaXNoZWQiLCJvbmNlIiwiUmVjb3JkcyIsIl9jaGFpbmluZyIsInJlY29yZHMiLCJvblJlY29yZCIsInJlbW92ZUxpc3RlbmVyIiwiX2V4ZWN1dGUiLCJfYmFzZVVybCIsImpvaW4iLCJ1cmwiLCJwb3AiLCJyYXdEb25lIiwidG90YWxTaXplIiwiZG9uZSIsIm5leHRSZWNvcmRzVXJsIiwibG9jYXRvclRvVXJsIiwidG9TT1FMIiwic29xbCIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlcXVlc3QiLCJtZXRob2QiLCJkYXRhIiwibGVuZ3RoIiwibnVtUmVjb3JkcyIsInRvdGFsRmV0Y2hlZCIsImkiLCJyZXNwb25zZSIsImNvbnN0cnVjdFJlc3BvbnNlIiwidHlwZSIsInN0cmVhbSIsInBpcGUiLCJzb2JqZWN0XyIsInNvYmplY3QiLCJhbGwiLCJfZXhwYW5kQXN0ZXJpc2tGaWVsZHMiLCJfZXhwYW5kRmllbGRzIiwiZWZpZWxkcyIsImNxdWVyeSIsImNjb25maWciLCJfcXVlcnkiLCJjdGFibGUiLCJyZWxOYW1lIiwiZGVzY3JpYmUkIiwidXBwZXJSbmFtZSIsInRvVXBwZXJDYXNlIiwiY2hpbGRSZWxhdGlvbnNoaXBzIiwiY3IiLCJyZWxhdGlvbnNoaXBOYW1lIiwiY2hpbGRTT2JqZWN0IiwiZmllbGQiLCJfZXhwYW5kQXN0ZXJpc2tGaWVsZCIsImV4cGFuZGVkRmllbGRzIiwiZWZsZHMiLCJmbGRzIiwiZnBhdGgiLCJzbyIsInJuYW1lIiwic2hpZnQiLCJyZmllbGQiLCJyZWZlcmVuY2VUbyIsInJ0YWJsZSIsImZwYXRocyIsImZwIiwibmFtZSIsIm9uUmVzb2x2ZSIsIm9uUmVqZWN0IiwidGhlbiIsInR5cGVfIiwidGhyZXNob2xkTnVtIiwiYWxsb3dCdWxrIiwiYnVsa1RocmVzaG9sZCIsIl9lbnN1cmVWZXJzaW9uIiwiX21heFJlcXVlc3QiLCJidWxrQXBpVmVyc2lvbiIsImNyZWF0ZUJhdGNoIiwiZGVsZXRlQnVsayIsImJhdGNoIiwiaGFuZGxlUmVjb3JkIiwicmVjIiwiSWQiLCJ3cml0ZSIsImhhbmRsZUVuZCIsImVuZCIsImlkcyIsImJ1bGsyIiwibG9hZEFuZFdhaXRGb3JSZXN1bHRzIiwib2JqZWN0Iiwib3BlcmF0aW9uIiwiaW5wdXQiLCJhbGxSZXN1bHRzIiwibWFwQnVsa1YyUmVzdWx0c1RvU2F2ZVJlc3VsdHMiLCJhbGxvd1JlY3Vyc2l2ZSIsIm1hcHBpbmciLCJ1cGRhdGVTdHJlYW0iLCJyZWNvcmRNYXBTdHJlYW0iLCJ1cGRhdGVCdWxrIiwidXBkYXRlIiwiYnVsa0pvYkFsbFJlc3VsdHMiLCJzdWNjZXNzU2F2ZVJlc3VsdHMiLCJzdWNjZXNzZnVsUmVzdWx0cyIsInIiLCJzYXZlUmVzdWx0IiwiaWQiLCJzZl9fSWQiLCJzdWNjZXNzIiwiZXJyb3JzIiwiZmFpbGVkU2F2ZVJlc3VsdHMiLCJmYWlsZWRSZXN1bHRzIiwiZXJyb3JDb2RlIiwic2ZfX0Vycm9yIiwibWVzc2FnZSIsInBhcmVudCIsIl9yZWxOYW1lIiwiX3BhcmVudCIsIndoZXJlIiwiX2ZpbmRSZWxhdGlvbk9iamVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsU0FBaUJDLFNBQWpCLFFBQWtDLGVBQWxDO0FBQ0EsT0FBT0MsWUFBUCxJQUF1QkMsWUFBdkIsUUFBMkMsaUJBQTNDO0FBRUEsU0FBU0MsVUFBVCxRQUEyQixnQkFBM0I7QUE2SUEsSUFBTUMsb0JBQW9CLEdBQUcsQ0FDM0IsYUFEMkIsRUFFM0IsU0FGMkIsRUFHM0IsY0FIMkIsRUFJM0IsT0FKMkIsQ0FBN0I7QUFTQSxPQUFPLElBQU1DLGVBRVosR0FBRyx3QkFBQUQsb0JBQW9CLE1BQXBCLENBQUFBLG9CQUFvQixFQUN0QixVQUFDRSxNQUFELEVBQVNDLE1BQVQ7QUFBQSx5Q0FBMEJELE1BQTFCLDJCQUFtQ0MsTUFBbkMsRUFBNENBLE1BQTVDO0FBQUEsQ0FEc0IsRUFFdEIsRUFGc0IsQ0FGakI7O0FBa0NQO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHNCQUFzQixHQUFHLEdBQS9CO0FBQ0EsSUFBTUMsd0JBQXdCLEdBQUcsQ0FBakM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsV0FBYUMsS0FBYjtBQUFBOztBQUFBOztBQXlCRTtBQUNGO0FBQ0E7QUFDRSxpQkFDRUMsSUFERixFQUVFQyxNQUZGLEVBR0VDLE9BSEYsRUFJRTtBQUFBOztBQUFBOztBQUNBOztBQURBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLDhEQXBCeUIsRUFvQnpCOztBQUFBLGdFQW5CbUQsRUFtQm5EOztBQUFBOztBQUFBLGdFQWpCbUIsS0FpQm5COztBQUFBLGdFQWhCbUIsS0FnQm5COztBQUFBLGdFQWZtQixLQWVuQjs7QUFBQTs7QUFBQTs7QUFBQSxnRUFYVSxDQVdWOztBQUFBLG1FQVZhLENBVWI7O0FBQUEsOERBVGEsRUFTYjs7QUFBQSw2REF1SU8sTUFBS0MsSUF2SVo7O0FBQUE7O0FBQUEsMkRBa1dLLE1BQUtDLE9BbFdWOztBQUFBLDBEQXVXSSxNQUFLQSxPQXZXVDs7QUFBQSw2REFnd0JPLE1BQUtDLE9BaHdCWjs7QUFBQSwwREFxd0JJLE1BQUtBLE9BcndCVDs7QUFFQSxVQUFLQyxLQUFMLEdBQWFOLElBQWI7QUFDQSxVQUFLTyxPQUFMLEdBQWVQLElBQUksQ0FBQ1EsU0FBTCxHQUNYVCxLQUFLLENBQUNRLE9BQU4sQ0FBY0UsY0FBZCxDQUE2QlQsSUFBSSxDQUFDUSxTQUFsQyxDQURXLEdBRVhULEtBQUssQ0FBQ1EsT0FGVjs7QUFHQSxRQUFJLE9BQU9OLE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0M7QUFDOUIsWUFBS1MsS0FBTCxHQUFhVCxNQUFiOztBQUNBLFlBQUtNLE9BQUwsQ0FBYUksS0FBYiwyQkFBc0NWLE1BQXRDO0FBQ0QsS0FIRCxNQUdPLElBQUksT0FBUUEsTUFBRCxDQUFnQlcsT0FBdkIsS0FBbUMsUUFBdkMsRUFBaUQ7QUFDdEQsVUFBTUEsT0FBZSxHQUFJWCxNQUFELENBQWdCVyxPQUF4Qzs7QUFDQSxZQUFLTCxPQUFMLENBQWFJLEtBQWIsOEJBQXlDQyxPQUF6Qzs7QUFDQSxZQUFLQyxRQUFMLEdBQWdCLDBCQUFBRCxPQUFPLE1BQVAsQ0FBQUEsT0FBTyxFQUFVLEdBQVYsQ0FBUCxHQUNaLE1BQUtFLFlBQUwsQ0FBa0JGLE9BQWxCLENBRFksR0FFWkEsT0FGSjtBQUdELEtBTk0sTUFNQTtBQUNMLFlBQUtMLE9BQUwsQ0FBYUksS0FBYixrQ0FBNkNWLE1BQTdDOztBQURLLGlCQUUwQ0EsTUFGMUM7QUFBQSxVQUVHYyxPQUZILFFBRUdBLE1BRkg7QUFBQSxVQUVXQyxRQUZYO0FBQUEsVUFFcUJDLE1BRnJCO0FBQUEsVUFFOEJDLE9BRjlCOztBQU1MLFlBQUtBLE9BQUwsR0FBZUEsT0FBZjs7QUFDQSxZQUFLQyxNQUFMLENBQVlKLE9BQVo7O0FBQ0EsVUFBSUMsUUFBSixFQUFjO0FBQ1osY0FBS0ksZUFBTCxDQUFxQkosUUFBckI7QUFDRDs7QUFDRCxVQUFJQyxNQUFKLEVBQVU7QUFDUixpREFBVUEsTUFBVjtBQUNEO0FBQ0Y7O0FBQ0QsVUFBS0ksUUFBTDtBQUNFQyxNQUFBQSxPQUFPLEVBQUUsRUFEWDtBQUVFQyxNQUFBQSxRQUFRLEVBQUUsS0FGWjtBQUdFQyxNQUFBQSxTQUFTLEVBQUUsS0FIYjtBQUlFQyxNQUFBQSxPQUFPLEVBQUUsS0FKWDtBQUtFQyxNQUFBQSxjQUFjLEVBQUU7QUFMbEIsT0FNTXhCLE9BQU8sSUFBSSxFQU5qQixFQTlCQSxDQXNDQTs7QUFDQSxVQUFLeUIsUUFBTCxHQUFnQixhQUFZLFVBQUNDLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUMvQyxZQUFLQyxFQUFMLENBQVEsVUFBUixFQUFvQkYsT0FBcEI7O0FBQ0EsWUFBS0UsRUFBTCxDQUFRLE9BQVIsRUFBaUJELE1BQWpCO0FBQ0QsS0FIZSxDQUFoQjtBQUlBLFVBQUtFLE9BQUwsR0FBZSxJQUFJeEMsWUFBSixFQUFmOztBQUNBLFVBQUt1QyxFQUFMLENBQVEsUUFBUixFQUFrQixVQUFDRSxNQUFEO0FBQUEsYUFBWSxNQUFLRCxPQUFMLENBQWFFLElBQWIsQ0FBa0JELE1BQWxCLENBQVo7QUFBQSxLQUFsQjs7QUFDQSxVQUFLRixFQUFMLENBQVEsS0FBUixFQUFlO0FBQUEsYUFBTSxNQUFLQyxPQUFMLENBQWFFLElBQWIsQ0FBa0IsSUFBbEIsQ0FBTjtBQUFBLEtBQWY7O0FBQ0EsVUFBS0gsRUFBTCxDQUFRLE9BQVIsRUFBaUIsVUFBQ0ksR0FBRCxFQUFTO0FBQ3hCLFVBQUk7QUFDRixjQUFLSCxPQUFMLENBQWFJLElBQWIsQ0FBa0IsT0FBbEIsRUFBMkJELEdBQTNCO0FBQ0QsT0FGRCxDQUVFLE9BQU9FLENBQVAsRUFBVSxDQUNWO0FBQ0Q7QUFDRixLQU5EOztBQTlDQTtBQXFERDtBQUVEO0FBQ0Y7QUFDQTs7O0FBekZBO0FBQUE7QUFBQSw2QkErRjhEO0FBQUEsVUFBMURyQixNQUEwRCx1RUFBM0IsR0FBMkI7O0FBQzFELFVBQUksS0FBS0wsS0FBVCxFQUFnQjtBQUNkLGNBQU0yQixLQUFLLENBQ1Qsc0VBRFMsQ0FBWDtBQUdEOztBQUNELGVBQVNDLFlBQVQsQ0FBc0J2QixNQUF0QixFQUE4RDtBQUFBOztBQUM1RCxlQUFPLE9BQU9BLE1BQVAsS0FBa0IsUUFBbEIsR0FDSEEsTUFBTSxDQUFDd0IsS0FBUCxDQUFhLFNBQWIsQ0FERyxHQUVILGVBQWN4QixNQUFkLElBQ0Esb0VBQUNBLE1BQUQsa0JBQ091QixZQURQLGtCQUVVLFVBQUNFLEVBQUQsRUFBS0MsQ0FBTDtBQUFBOztBQUFBLDRGQUFlRCxFQUFmLHNCQUFzQkMsQ0FBdEI7QUFBQSxTQUZWLEVBRW9DLEVBRnBDLENBREEsR0FJQSxxRkFBZTFCLE1BQWYsbUJBQ08saUJBQVk7QUFBQTtBQUFBLGNBQVYwQixDQUFVO0FBQUEsY0FBUEMsQ0FBTzs7QUFDZixjQUFJLE9BQU9BLENBQVAsS0FBYSxRQUFiLElBQXlCLE9BQU9BLENBQVAsS0FBYSxTQUExQyxFQUFxRDtBQUNuRCxtQkFBT0EsQ0FBQyxHQUFHLENBQUNELENBQUQsQ0FBSCxHQUFTLEVBQWpCO0FBQ0QsV0FGRCxNQUVPO0FBQUE7O0FBQ0wsbUJBQU8saUNBQUFILFlBQVksQ0FBQ0ksQ0FBRCxDQUFaLGtCQUFvQixVQUFDQyxDQUFEO0FBQUE7O0FBQUEsbUVBQVVGLENBQVYsd0JBQWVFLENBQWY7QUFBQSxhQUFwQixDQUFQO0FBQ0Q7QUFDRixTQVBILG1CQVFVLFVBQUNILEVBQUQsRUFBS0MsQ0FBTDtBQUFBOztBQUFBLDRGQUFlRCxFQUFmLHNCQUFzQkMsQ0FBdEI7QUFBQSxTQVJWLEVBUW9DLEVBUnBDLENBTko7QUFlRDs7QUFDRCxVQUFJMUIsTUFBSixFQUFZO0FBQ1YsYUFBS0csT0FBTCxDQUFhSCxNQUFiLEdBQXNCdUIsWUFBWSxDQUFDdkIsTUFBRCxDQUFsQztBQUNELE9BekJ5RCxDQTBCMUQ7OztBQUNBLGFBQVEsSUFBUjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQS9IQTtBQUFBO0FBQUEsMEJBZ0lRNkIsVUFoSVIsRUFnSW1EO0FBQy9DLFVBQUksS0FBS2xDLEtBQVQsRUFBZ0I7QUFDZCxjQUFNMkIsS0FBSyxDQUNULHlFQURTLENBQVg7QUFHRDs7QUFDRCxXQUFLbkIsT0FBTCxDQUFhMEIsVUFBYixHQUEwQkEsVUFBMUI7QUFDQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE1SUE7QUFBQTtBQUFBLDBCQTZJUUMsTUE3SVIsRUE2SXVCO0FBQ25CLFVBQUksS0FBS25DLEtBQVQsRUFBZ0I7QUFDZCxjQUFNMkIsS0FBSyxDQUNULDhEQURTLENBQVg7QUFHRDs7QUFDRCxXQUFLbkIsT0FBTCxDQUFhMkIsS0FBYixHQUFxQkEsTUFBckI7QUFDQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF6SkE7QUFBQTtBQUFBLHlCQTBKT0MsTUExSlAsRUEwSnVCO0FBQ25CLFVBQUksS0FBS3BDLEtBQVQsRUFBZ0I7QUFDZCxjQUFNMkIsS0FBSyxDQUNULG9FQURTLENBQVg7QUFHRDs7QUFDRCxXQUFLbkIsT0FBTCxDQUFhNEIsTUFBYixHQUFzQkEsTUFBdEI7QUFDQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0S0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLGdCQWlMSTdCLElBakxKLEVBa0xJOEIsR0FsTEosRUFtTEk7QUFDQSxVQUFJLEtBQUtyQyxLQUFULEVBQWdCO0FBQ2QsY0FBTTJCLEtBQUssQ0FDVCw2REFEUyxDQUFYO0FBR0Q7O0FBQ0QsVUFBSSxPQUFPcEIsSUFBUCxLQUFnQixRQUFoQixJQUE0QixPQUFPOEIsR0FBUCxLQUFlLFdBQS9DLEVBQTREO0FBQzFELGFBQUs3QixPQUFMLENBQWFELElBQWIsR0FBb0IsQ0FBQyxDQUFDQSxJQUFELEVBQU84QixHQUFQLENBQUQsQ0FBcEI7QUFDRCxPQUZELE1BRU87QUFDTCxhQUFLN0IsT0FBTCxDQUFhRCxJQUFiLEdBQW9CQSxJQUFwQjtBQUNEOztBQUNELGFBQU8sSUFBUDtBQUNELEtBL0xIO0FBaU1FO0FBQ0Y7QUFDQTs7QUFuTUE7QUFBQTtBQUFBLDRCQXVPSStCLFlBdk9KLEVBd09JSixVQXhPSixFQXlPSTdCLE1Bek9KLEVBMk95QztBQUFBLFVBRHJDYixPQUNxQyx1RUFEbUMsRUFDbkM7O0FBQ3JDLFVBQUksS0FBS1EsS0FBVCxFQUFnQjtBQUNkLGNBQU0yQixLQUFLLENBQ1QsZ0ZBRFMsQ0FBWDtBQUdEOztBQUNELFVBQU1ZLFdBQW9DLEdBQUc7QUFDM0NsQyxRQUFBQSxNQUFNLEVBQUVBLE1BQU0sS0FBSyxJQUFYLEdBQWtCbUMsU0FBbEIsR0FBOEJuQyxNQURLO0FBRTNDb0MsUUFBQUEsS0FBSyxFQUFFSCxZQUZvQztBQUczQ0osUUFBQUEsVUFBVSxFQUFFQSxVQUFVLEtBQUssSUFBZixHQUFzQk0sU0FBdEIsR0FBa0NOLFVBSEg7QUFJM0NDLFFBQUFBLEtBQUssRUFBRTNDLE9BQU8sQ0FBQzJDLEtBSjRCO0FBSzNDQyxRQUFBQSxNQUFNLEVBQUU1QyxPQUFPLENBQUM0QyxNQUwyQjtBQU0zQzdCLFFBQUFBLElBQUksd0JBQUVmLE9BQUY7QUFOdUMsT0FBN0MsQ0FOcUMsQ0FjckM7O0FBQ0EsVUFBTWtELFVBQVUsR0FBRyxJQUFJQyxRQUFKLENBQ2pCLEtBQUsvQyxLQURZLEVBRWpCMEMsWUFGaUIsRUFHakJDLFdBSGlCLEVBSWpCLElBSmlCLENBQW5COztBQU1BLFdBQUtLLFNBQUwsQ0FBZXJCLElBQWYsQ0FBb0JtQixVQUFwQjs7QUFDQSxhQUFPQSxVQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBdFFBO0FBQUE7QUFBQSxvQ0F3UUlwQyxRQXhRSixFQThRSTtBQUVBLFVBQUksS0FBS04sS0FBVCxFQUFnQjtBQUNkLGNBQU0yQixLQUFLLENBQ1QsZ0ZBRFMsQ0FBWDtBQUdEOztBQU5ELGlEQU9xQixhQUFZckIsUUFBWixDQVByQjtBQUFBOztBQUFBO0FBT0EsNERBQXFEO0FBQUEsY0FBMUN1QyxNQUEwQzs7QUFBQSxzQkFDUnZDLFFBQVEsQ0FDakR1QyxNQURpRCxDQURBO0FBQUEsY0FDM0NYLFdBRDJDLFNBQzNDQSxVQUQyQztBQUFBLGNBQy9CN0IsUUFEK0IsU0FDL0JBLE1BRCtCO0FBQUEsY0FDcEJiLFFBRG9COztBQUluRCxlQUFLc0QsT0FBTCxDQUFhRCxNQUFiLEVBQXFCWCxXQUFyQixFQUFpQzdCLFFBQWpDLEVBQXlDYixRQUF6QztBQUNEO0FBWkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFhQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFoU0E7QUFBQTtBQUFBLDZCQWlTV3FCLFNBalNYLEVBaVM2QjtBQUN6QixXQUFLRixRQUFMLENBQWNFLFFBQWQsR0FBeUJBLFNBQXpCO0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBeFNBO0FBQUE7QUFBQSw4QkF5U1lDLFVBelNaLEVBeVNnQztBQUM1QixXQUFLSCxRQUFMLENBQWNHLFNBQWQsR0FBMEJBLFVBQTFCO0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBaFRBO0FBQUE7QUFBQSw0QkFpVFVDLFFBalRWLEVBaVQ0QjtBQUN4QixXQUFLSixRQUFMLENBQWNJLE9BQWQsR0FBd0JBLFFBQXhCO0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBeFRBO0FBQUE7QUFBQSxzQ0EwVElDLGNBMVRKLEVBMlQwQjtBQUN0QixVQUFJQSxjQUFjLElBQUloQyxlQUF0QixFQUF1QztBQUNyQyxhQUFLMkIsUUFBTCxDQUFjSyxjQUFkLEdBQStCQSxjQUEvQjtBQUNELE9BSHFCLENBSXRCOzs7QUFDQSxhQUFRLElBQVI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFyVUE7QUFBQTtBQUFBLDhCQXdVMEI7QUFBQTs7QUFBQSxVQUR0QitCLFFBQ3NCLHVFQUR3QyxFQUN4Qzs7QUFDdEIsVUFBSSxLQUFLQyxTQUFULEVBQW9CO0FBQ2xCLGNBQU0sSUFBSXJCLEtBQUosQ0FBVSxxQ0FBVixDQUFOO0FBQ0Q7O0FBRUQsVUFBSSxLQUFLc0IsU0FBVCxFQUFvQjtBQUNsQixjQUFNLElBQUl0QixLQUFKLENBQVUsZ0NBQVYsQ0FBTjtBQUNEOztBQUVELFVBQU1uQyxPQUFPLEdBQUc7QUFDZG9CLFFBQUFBLE9BQU8sRUFBRW1DLFFBQVEsQ0FBQ25DLE9BQVQsSUFBb0IsS0FBS0QsUUFBTCxDQUFjQyxPQUQ3QjtBQUVkSSxRQUFBQSxjQUFjLEVBQUUrQixRQUFRLENBQUMvQixjQUFULElBQTJCLEtBQUtMLFFBQUwsQ0FBY0ssY0FGM0M7QUFHZEYsUUFBQUEsU0FBUyxFQUFFaUMsUUFBUSxDQUFDakMsU0FBVCxJQUFzQixLQUFLSCxRQUFMLENBQWNHLFNBSGpDO0FBSWRELFFBQUFBLFFBQVEsRUFBRWtDLFFBQVEsQ0FBQ2xDLFFBQVQsSUFBcUIsS0FBS0YsUUFBTCxDQUFjRSxRQUovQjtBQUtkRSxRQUFBQSxPQUFPLEVBQUVnQyxRQUFRLENBQUNoQyxPQUFULElBQW9CLEtBQUtKLFFBQUwsQ0FBY0k7QUFMN0IsT0FBaEIsQ0FUc0IsQ0FpQnRCO0FBQ0E7QUFDQTs7QUFDQSxXQUFLbUMsSUFBTCxDQUFVLE9BQVYsRUFBbUIsWUFBTTtBQUN2QixZQUNFMUQsT0FBTyxDQUFDd0IsY0FBUixLQUEyQmhDLGVBQWUsQ0FBQ21FLE9BQTNDLElBQ0EsTUFBSSxDQUFDQyxTQUZQLEVBR0U7QUFDQSxVQUFBLE1BQUksQ0FBQ3ZELE9BQUwsQ0FBYUksS0FBYixDQUFtQix3Q0FBbkI7O0FBQ0EsY0FBTW9ELE9BQWlCLEdBQUcsRUFBMUI7O0FBQ0EsY0FBTUMsUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQ2hDLE1BQUQ7QUFBQSxtQkFBb0IrQixPQUFPLENBQUM5QixJQUFSLENBQWFELE1BQWIsQ0FBcEI7QUFBQSxXQUFqQjs7QUFDQSxVQUFBLE1BQUksQ0FBQ0YsRUFBTCxDQUFRLFFBQVIsRUFBa0JrQyxRQUFsQjs7QUFDQSxVQUFBLE1BQUksQ0FBQ0osSUFBTCxDQUFVLEtBQVYsRUFBaUIsWUFBTTtBQUNyQixZQUFBLE1BQUksQ0FBQ0ssY0FBTCxDQUFvQixRQUFwQixFQUE4QkQsUUFBOUI7O0FBQ0EsWUFBQSxNQUFJLENBQUM3QixJQUFMLENBQVUsVUFBVixFQUFzQjRCLE9BQXRCLEVBQStCLE1BQS9CO0FBQ0QsV0FIRDtBQUlEO0FBQ0YsT0FkRCxFQXBCc0IsQ0FvQ3RCOztBQUNBLFdBQUtMLFNBQUwsR0FBaUIsSUFBakI7O0FBRUEsK0RBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNDO0FBQ0EsZ0JBQUEsTUFBSSxDQUFDbkQsT0FBTCxDQUFhSSxLQUFiLENBQW1CLHFCQUFuQjs7QUFGRDtBQUFBO0FBQUEsdUJBSVMsTUFBSSxDQUFDdUQsUUFBTCxDQUFjaEUsT0FBZCxDQUpUOztBQUFBO0FBS0csZ0JBQUEsTUFBSSxDQUFDSyxPQUFMLENBQWFJLEtBQWIsQ0FBbUIsd0JBQW5COztBQUxIO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQU9HLGdCQUFBLE1BQUksQ0FBQ0osT0FBTCxDQUFhSSxLQUFiLENBQW1CLHFCQUFuQjs7QUFDQSxnQkFBQSxNQUFJLENBQUN3QixJQUFMLENBQVUsT0FBVjs7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFELEtBdkNzQixDQW1EdEI7OztBQUNBLGFBQVEsSUFBUjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWpZQTtBQUFBO0FBQUEsbUNBeVl5QjtBQUNyQixhQUFPLEtBQUt0QixRQUFMLEdBQ0gsQ0FBQyxLQUFLUCxLQUFMLENBQVc2RCxRQUFYLEVBQUQsRUFBd0IsU0FBeEIsRUFBbUMsS0FBS3RELFFBQXhDLEVBQWtEdUQsSUFBbEQsQ0FBdUQsRUFBdkQsQ0FERyxHQUVILEVBRko7QUFHRDtBQTdZSDtBQUFBO0FBQUEsaUNBK1l1QkMsR0EvWXZCLEVBK1lvQztBQUNoQyxhQUFPQSxHQUFHLENBQUM5QixLQUFKLENBQVUsR0FBVixFQUFlK0IsR0FBZixFQUFQO0FBQ0Q7QUFqWkg7QUFBQTtBQUFBLHNDQW9hSUMsT0FwYUosRUFxYUk3QyxjQXJhSixFQXNhdUM7QUFBQTs7QUFDbkMsY0FBUUEsY0FBUjtBQUNFLGFBQUssT0FBTDtBQUNFLGlCQUFPLEtBQUs4QyxTQUFaOztBQUNGLGFBQUssY0FBTDtBQUNFLG9EQUFPLEtBQUtULE9BQVosa0RBQU8sY0FBZSxDQUFmLENBQVAsMkRBQTRCLElBQTVCOztBQUNGLGFBQUssU0FBTDtBQUNFLGlCQUFPLEtBQUtBLE9BQVo7QUFDRjs7QUFDQTtBQUNFLGlEQUNLO0FBQ0RBLFlBQUFBLE9BQU8sRUFBRSxLQUFLQSxPQURiO0FBRURTLFlBQUFBLFNBQVMsRUFBRSxLQUFLQSxTQUZmO0FBR0RDLFlBQUFBLElBQUksRUFBRUYsT0FBRixhQUFFQSxPQUFGLGNBQUVBLE9BQUYsR0FBYSxJQUhoQixDQUdzQjs7QUFIdEIsV0FETCxHQU1NLEtBQUsxRCxRQUFMLEdBQWdCO0FBQUU2RCxZQUFBQSxjQUFjLEVBQUUsS0FBS0MsWUFBTDtBQUFsQixXQUFoQixHQUEwRCxFQU5oRTtBQVRKO0FBa0JEO0FBQ0Q7QUFDRjtBQUNBOztBQTViQTtBQUFBO0FBQUE7QUFBQSxpR0E2YmlCekUsT0E3YmpCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQThiWW9CLGdCQUFBQSxPQTliWixHQThic0VwQixPQTlidEUsQ0E4YllvQixPQTliWixFQThicUJJLGNBOWJyQixHQThic0V4QixPQTlidEUsQ0E4YnFCd0IsY0E5YnJCLEVBOGJxQ0YsU0E5YnJDLEdBOGJzRXRCLE9BOWJ0RSxDQThicUNzQixTQTlickMsRUE4YmdERCxRQTliaEQsR0E4YnNFckIsT0E5YnRFLENBOGJnRHFCLFFBOWJoRCxFQThiMERFLE9BOWIxRCxHQThic0V2QixPQTlidEUsQ0E4YjBEdUIsT0E5YjFEOztBQStiSSxxQkFBS2xCLE9BQUwsQ0FBYUksS0FBYixDQUFtQixzQkFBbkIsRUFBMkNULE9BQTNDOztBQS9iSixxQkFpY1EsS0FBS1csUUFqY2I7QUFBQTtBQUFBO0FBQUE7O0FBa2NNd0QsZ0JBQUFBLEdBQUcsR0FBRyxLQUFLTSxZQUFMLEVBQU47QUFsY047QUFBQTs7QUFBQTtBQUFBO0FBQUEsdUJBb2N5QixLQUFLQyxNQUFMLEVBcGN6Qjs7QUFBQTtBQW9jWUMsZ0JBQUFBLElBcGNaOztBQXFjTSxxQkFBS3RFLE9BQUwsQ0FBYUksS0FBYixrQkFBNkJrRSxJQUE3Qjs7QUFDQVIsZ0JBQUFBLEdBQUcsR0FBRyxDQUNKLEtBQUsvRCxLQUFMLENBQVc2RCxRQUFYLEVBREksRUFFSixHQUZJLEVBR0oxQyxPQUFPLEdBQUcsVUFBSCxHQUFnQixPQUhuQixFQUlKLEtBSkksRUFLSnFELGtCQUFrQixDQUFDRCxJQUFELENBTGQsRUFNSlQsSUFOSSxDQU1DLEVBTkQsQ0FBTjs7QUF0Y047QUFBQTtBQUFBLHVCQThjdUIsS0FBSzlELEtBQUwsQ0FBV3lFLE9BQVgsQ0FBc0I7QUFBRUMsa0JBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCWCxrQkFBQUEsR0FBRyxFQUFIQSxHQUFqQjtBQUFzQi9DLGtCQUFBQSxPQUFPLEVBQVBBO0FBQXRCLGlCQUF0QixDQTljdkI7O0FBQUE7QUE4Y1UyRCxnQkFBQUEsSUE5Y1Y7QUErY0kscUJBQUs5QyxJQUFMLENBQVUsT0FBVjtBQUNBLHFCQUFLcUMsU0FBTCxHQUFpQlMsSUFBSSxDQUFDVCxTQUF0QjtBQUNBLHFCQUFLVCxPQUFMLHFCQUFlLEtBQUtBLE9BQXBCLG1EQUFlLDZEQUNieEMsUUFBUSxHQUFHLEtBQUt3QyxPQUFMLENBQWFtQixNQUF4QixHQUFpQ0QsSUFBSSxDQUFDbEIsT0FBTCxDQUFhbUIsTUFBOUMsR0FDSUQsSUFBSSxDQUFDbEIsT0FEVCxHQUVJLG9DQUFBa0IsSUFBSSxDQUFDbEIsT0FBTCxtQkFBbUIsQ0FBbkIsRUFBc0J4QyxRQUFRLEdBQUcsS0FBS3dDLE9BQUwsQ0FBYW1CLE1BQTlDLENBSFMsQ0FBZjtBQUtBLHFCQUFLckUsUUFBTCxHQUFnQm9FLElBQUksQ0FBQ1AsY0FBTCxHQUNaLEtBQUs1RCxZQUFMLENBQWtCbUUsSUFBSSxDQUFDUCxjQUF2QixDQURZLEdBRVp4QixTQUZKO0FBR0EscUJBQUtTLFNBQUwsR0FDRSxLQUFLQSxTQUFMLElBQ0FzQixJQUFJLENBQUNSLElBREwsSUFFQSxDQUFDakQsU0FGRCxJQUdBO0FBQ0N5RCxnQkFBQUEsSUFBSSxDQUFDbEIsT0FBTCxDQUFhbUIsTUFBYixLQUF3QixDQUF4QixJQUE2QkQsSUFBSSxDQUFDUixJQUFMLEtBQWN2QixTQUw5QyxDQXpkSixDQWdlSTs7QUFDTWlDLGdCQUFBQSxVQWplViw0Q0FpZXVCRixJQUFJLENBQUNsQixPQWplNUIsa0RBaWV1QixjQUFjbUIsTUFqZXJDLHVFQWllK0MsQ0FqZS9DO0FBa2VRRSxnQkFBQUEsWUFsZVIsR0FrZXVCLEtBQUtBLFlBbGU1QjtBQW1lYUMsZ0JBQUFBLENBbmViLEdBbWVpQixDQW5lakI7O0FBQUE7QUFBQSxzQkFtZW9CQSxDQUFDLEdBQUdGLFVBbmV4QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkFvZVVDLFlBQVksSUFBSTdELFFBcGUxQjtBQUFBO0FBQUE7QUFBQTs7QUFxZVEscUJBQUtvQyxTQUFMLEdBQWlCLElBQWpCO0FBcmVSOztBQUFBO0FBd2VZM0IsZ0JBQUFBLE1BeGVaLEdBd2VxQmlELElBQUksQ0FBQ2xCLE9BQUwsQ0FBYXNCLENBQWIsQ0F4ZXJCO0FBeWVNLHFCQUFLbEQsSUFBTCxDQUFVLFFBQVYsRUFBb0JILE1BQXBCLEVBQTRCb0QsWUFBNUIsRUFBMEMsSUFBMUM7QUFDQUEsZ0JBQUFBLFlBQVksSUFBSSxDQUFoQjs7QUExZU47QUFtZW9DQyxnQkFBQUEsQ0FBQyxFQW5lckM7QUFBQTtBQUFBOztBQUFBO0FBNGVJLHFCQUFLRCxZQUFMLEdBQW9CQSxZQUFwQjs7QUE1ZUoscUJBOGVRLEtBQUt6QixTQTllYjtBQUFBO0FBQUE7QUFBQTs7QUErZVkyQixnQkFBQUEsUUEvZVosR0ErZXVCLEtBQUtDLGlCQUFMLENBQXVCTixJQUFJLENBQUNSLElBQTVCLEVBQWtDL0MsY0FBbEMsQ0EvZXZCLEVBZ2ZNOztBQUNBLG9CQUFJQSxjQUFjLEtBQUtoQyxlQUFlLENBQUNtRSxPQUF2QyxFQUFnRDtBQUM5Qyx1QkFBSzFCLElBQUwsQ0FBVSxVQUFWLEVBQXNCbUQsUUFBdEIsRUFBZ0MsSUFBaEM7QUFDRDs7QUFDRCxxQkFBS25ELElBQUwsQ0FBVSxLQUFWO0FBcGZOLG1EQXFmYW1ELFFBcmZiOztBQUFBO0FBQUEsbURBdWZhLEtBQUtwQixRQUFMLENBQWNoRSxPQUFkLENBdmZiOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMmZFO0FBQ0Y7QUFDQTs7QUE3ZkE7QUFBQTtBQUFBLDZCQWdnQnlDO0FBQUEsVUFBaENzRixJQUFnQyx1RUFBUCxLQUFPOztBQUNyQyxVQUFJLENBQUMsS0FBSzdCLFNBQU4sSUFBbUIsQ0FBQyxLQUFLRCxTQUE3QixFQUF3QztBQUN0QyxhQUFLdEQsT0FBTCxDQUFhO0FBQUVvQixVQUFBQSxTQUFTLEVBQUU7QUFBYixTQUFiO0FBQ0Q7O0FBQ0QsYUFBT2dFLElBQUksS0FBSyxRQUFULEdBQW9CLEtBQUt6RCxPQUF6QixHQUFtQyxLQUFLQSxPQUFMLENBQWEwRCxNQUFiLENBQW9CRCxJQUFwQixDQUExQztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7QUEzZ0JBO0FBQUE7QUFBQSx5QkE0Z0JPQyxNQTVnQlAsRUE0Z0JzQztBQUNsQyxhQUFPLEtBQUtBLE1BQUwsQ0FBWSxRQUFaLEVBQXNCQyxJQUF0QixDQUEyQkQsTUFBM0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWxoQkE7QUFBQTtBQUFBO0FBQUEsc0dBbWhCc0JFLFFBbmhCdEI7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9oQlEsS0FBS2pGLEtBcGhCYjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkFxaEJZLElBQUkyQixLQUFKLENBQ0osa0VBREksQ0FyaEJaOztBQUFBO0FBQUEsZ0NBeWhCd0MsS0FBS25CLE9BemhCN0MsdUNBeWhCWUgsTUF6aEJaLEVBeWhCWUEsTUF6aEJaLHFDQXloQnFCLEVBemhCckIsNkRBeWhCeUJvQyxLQXpoQnpCLEVBeWhCeUJBLEtBemhCekIsb0NBeWhCaUMsRUF6aEJqQztBQTBoQlV5QyxnQkFBQUEsT0ExaEJWLEdBMGhCb0JELFFBQVEsSUFBSXhDLEtBMWhCaEM7O0FBMmhCSSxxQkFBSzVDLE9BQUwsQ0FBYUksS0FBYix5RUFDOEJpRixPQUQ5QixtQ0FDbUQ3RSxNQUFNLENBQUNxRCxJQUFQLENBQVksSUFBWixDQURuRDs7QUEzaEJKO0FBQUEsdUJBOGhCNEIsU0FBUXlCLEdBQVIsdUNBQ3RCLEtBQUtDLHFCQUFMLENBQTJCRixPQUEzQixFQUFvQzdFLE1BQXBDLENBRHNCLHVDQUVuQix1Q0FBS3VDLFNBQUw7QUFBQSx1RkFBbUIsa0JBQU9GLFVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQ2RBLFVBQVUsQ0FBQzJDLGFBQVgsRUFEYzs7QUFBQTtBQUFBLCtEQUViLEVBRmE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW5COztBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZtQixHQTloQjVCOztBQUFBO0FBQUE7QUFBQTtBQThoQldDLGdCQUFBQSxPQTloQlg7QUFxaUJJLHFCQUFLOUUsT0FBTCxDQUFhSCxNQUFiLEdBQXNCaUYsT0FBdEI7QUFDQSxxQkFBSzlFLE9BQUwsQ0FBYUYsUUFBYixHQUF3Qiw0RUFBS3NDLFNBQUwsbUJBQ2pCLFVBQUMyQyxNQUFELEVBQVk7QUFDZixzQkFBTUMsT0FBTyxHQUFHRCxNQUFNLENBQUNFLE1BQVAsQ0FBY2pGLE9BQTlCO0FBQ0EseUJBQU8sQ0FBQ2dGLE9BQU8sQ0FBQy9DLEtBQVQsRUFBZ0IrQyxPQUFoQixDQUFQO0FBQ0QsaUJBSnFCLG9CQU1wQixVQUFDbEYsUUFBRDtBQUFBO0FBQUEsc0JBQVlvRixNQUFaO0FBQUEsc0JBQW9CRixPQUFwQjs7QUFBQSx5REFDS2xGLFFBREwsMkJBRUdvRixNQUZILEVBRVlGLE9BRlo7QUFBQSxpQkFOb0IsRUFVcEIsRUFWb0IsQ0FBeEI7O0FBdGlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQW9qQkU7QUFDRjtBQUNBOztBQXRqQkE7QUFBQTtBQUFBO0FBQUEsNEdBdWpCNEJHLE9BdmpCNUI7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXdqQlVsRCxnQkFBQUEsS0F4akJWLEdBd2pCa0IsS0FBS2pDLE9BQUwsQ0FBYWlDLEtBeGpCL0I7O0FBQUEsb0JBeWpCU0EsS0F6akJUO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTBqQlksSUFBSWQsS0FBSixDQUFVLDRDQUFWLENBMWpCWjs7QUFBQTtBQTRqQkkscUJBQUs5QixPQUFMLENBQWFJLEtBQWIsNkVBQ2lDMEYsT0FEakMsZ0NBQ2lEbEQsS0FEakQ7O0FBNWpCSjtBQUFBLHVCQStqQjBCLEtBQUs3QyxLQUFMLENBQVdnRyxTQUFYLENBQXFCbkQsS0FBckIsQ0EvakIxQjs7QUFBQTtBQStqQlV5QyxnQkFBQUEsT0EvakJWO0FBZ2tCVVcsZ0JBQUFBLFVBaGtCVixHQWdrQnVCRixPQUFPLENBQUNHLFdBQVIsRUFoa0J2QjtBQUFBLHdEQWlrQnFCWixPQUFPLENBQUNhLGtCQWprQjdCO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFpa0JlQyxnQkFBQUEsRUFqa0JmOztBQUFBLHNCQW1rQlEsQ0FBQ0EsRUFBRSxDQUFDQyxnQkFBSCxJQUF1QixFQUF4QixFQUE0QkgsV0FBNUIsT0FBOENELFVBQTlDLElBQ0FHLEVBQUUsQ0FBQ0UsWUFwa0JYO0FBQUE7QUFBQTtBQUFBOztBQUFBLG1EQXNrQmVGLEVBQUUsQ0FBQ0UsWUF0a0JsQjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTs7QUFBQTtBQUFBOztBQUFBOztBQUFBOztBQUFBO0FBQUEsc0JBeWtCVSxJQUFJdkUsS0FBSix3Q0FBMENnRSxPQUExQyxFQXprQlY7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE0a0JFO0FBQ0Y7QUFDQTs7QUE5a0JBO0FBQUE7QUFBQTtBQUFBLDhHQWdsQklULE9BaGxCSixFQWlsQkk3RSxNQWpsQko7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtbEJpQyxTQUFROEUsR0FBUixDQUMzQixxQkFBQTlFLE1BQU0sTUFBTixDQUFBQSxNQUFNO0FBQUEsdUZBQUssa0JBQU84RixLQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrREFBaUIsTUFBSSxDQUFDQyxvQkFBTCxDQUEwQmxCLE9BQTFCLEVBQW1DaUIsS0FBbkMsQ0FBakI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQUw7O0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRHFCLENBbmxCakM7O0FBQUE7QUFtbEJVRSxnQkFBQUEsY0FubEJWO0FBQUEsbURBc2xCVyx3QkFBQUEsY0FBYyxNQUFkLENBQUFBLGNBQWMsRUFDbkIsVUFBQ0MsS0FBRCxFQUFrQkMsSUFBbEI7QUFBQTs7QUFBQSxzR0FBbURELEtBQW5ELHNCQUE2REMsSUFBN0Q7QUFBQSxpQkFEbUIsRUFFbkIsRUFGbUIsQ0F0bEJ6Qjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTRsQkU7QUFDRjtBQUNBOztBQTlsQkE7QUFBQTtBQUFBO0FBQUEsNkdBZ21CSXJCLE9BaG1CSixFQWltQklpQixLQWptQko7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbW1CSSxxQkFBS3RHLE9BQUwsQ0FBYUksS0FBYixrRUFBdUNrRyxLQUF2QyxnQ0FBcURqQixPQUFyRDs7QUFDTXNCLGdCQUFBQSxLQXBtQlYsR0FvbUJrQkwsS0FBSyxDQUFDdEUsS0FBTixDQUFZLEdBQVosQ0FwbUJsQjs7QUFBQSxzQkFxbUJRMkUsS0FBSyxDQUFDQSxLQUFLLENBQUNoQyxNQUFOLEdBQWUsQ0FBaEIsQ0FBTCxLQUE0QixHQXJtQnBDO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBc21CdUIsS0FBSzVFLEtBQUwsQ0FBV2dHLFNBQVgsQ0FBcUJWLE9BQXJCLENBdG1CdkI7O0FBQUE7QUFzbUJZdUIsZ0JBQUFBLEVBdG1CWjs7QUF1bUJNLHFCQUFLNUcsT0FBTCxDQUFhSSxLQUFiLGlCQUE0QmlGLE9BQTVCOztBQXZtQk4sc0JBd21CVXNCLEtBQUssQ0FBQ2hDLE1BQU4sR0FBZSxDQXhtQnpCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5bUJja0MsMEJBQUFBLEtBem1CZCxHQXltQnNCRixLQUFLLENBQUNHLEtBQU4sRUF6bUJ0QjtBQUFBLGtFQTBtQndCRixFQUFFLENBQUNwRyxNQTFtQjNCO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUEwbUJtQjBCLDBCQUFBQSxDQTFtQm5COztBQUFBLGdDQTRtQllBLENBQUMsQ0FBQ2tFLGdCQUFGLElBQ0FTLEtBREEsSUFFQTNFLENBQUMsQ0FBQ2tFLGdCQUFGLENBQW1CSCxXQUFuQixPQUFxQ1ksS0FBSyxDQUFDWixXQUFOLEVBOW1CakQ7QUFBQTtBQUFBO0FBQUE7O0FBZ25Ca0JjLDBCQUFBQSxNQWhuQmxCLEdBZ25CMkI3RSxDQWhuQjNCO0FBaW5Ca0I4RSwwQkFBQUEsV0FqbkJsQixHQWluQmdDRCxNQUFNLENBQUNDLFdBQVAsSUFBc0IsRUFqbkJ0RDtBQWtuQmtCQywwQkFBQUEsTUFsbkJsQixHQWtuQjJCRCxXQUFXLENBQUNyQyxNQUFaLEtBQXVCLENBQXZCLEdBQTJCcUMsV0FBVyxDQUFDLENBQUQsQ0FBdEMsR0FBNEMsTUFsbkJ2RTtBQUFBO0FBQUEsaUNBbW5CaUMsTUFBSSxDQUFDVCxvQkFBTCxDQUNuQlUsTUFEbUIsRUFFbkJOLEtBQUssQ0FBQzlDLElBQU4sQ0FBVyxHQUFYLENBRm1CLENBbm5CakM7O0FBQUE7QUFtbkJrQnFELDBCQUFBQSxNQW5uQmxCO0FBQUE7QUFBQSwrQkF1bkJtQixxQkFBQUEsTUFBTSxNQUFOLENBQUFBLE1BQU0sRUFBSyxVQUFDQyxFQUFEO0FBQUE7O0FBQUEsb0ZBQVdOLEtBQVgseUJBQW9CTSxFQUFwQjtBQUFBLDZCQUFMO0FBdm5CekI7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUEsK0JBMG5CZTtBQTFuQmY7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTs7QUFBQTtBQUFBLG1EQTRuQmEsa0NBQUFQLEVBQUUsQ0FBQ3BHLE1BQUgsbUJBQWMsVUFBQzBCLENBQUQ7QUFBQSx5QkFBT0EsQ0FBQyxDQUFDa0YsSUFBVDtBQUFBLGlCQUFkLENBNW5CYjs7QUFBQTtBQUFBLG1EQThuQlcsQ0FBQ2QsS0FBRCxDQTluQlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFpb0JFO0FBQ0Y7QUFDQTs7QUFub0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcW9CdUIsS0FBS2pDLE1BQUwsRUFyb0J2Qjs7QUFBQTtBQXFvQlVDLGdCQUFBQSxJQXJvQlY7O0FBc29CSSxxQkFBS3RFLE9BQUwsQ0FBYUksS0FBYixrQkFBNkJrRSxJQUE3Qjs7QUFDTVIsZ0JBQUFBLEdBdm9CViw2QkF1b0JtQ1Msa0JBQWtCLENBQUNELElBQUQsQ0F2b0JyRDtBQUFBLG1EQXdvQlcsS0FBS3ZFLEtBQUwsQ0FBV3lFLE9BQVgsQ0FBdUNWLEdBQXZDLENBeG9CWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTJvQkU7QUFDRjtBQUNBOztBQTdvQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStvQlEsS0FBSzNELEtBL29CYjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxtREFncEJhLEtBQUtBLEtBaHBCbEI7O0FBQUE7QUFBQTtBQUFBLHVCQWtwQlUsS0FBS3FGLGFBQUwsRUFscEJWOztBQUFBO0FBQUEsbURBbXBCV3ZHLFVBQVUsQ0FBQyxLQUFLMEIsT0FBTixDQW5wQnJCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBc3BCRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBM3BCQTtBQUFBO0FBQUEseUJBNnBCSTBHLFNBN3BCSixFQWlxQklDLFFBanFCSixFQWtxQm9CO0FBQ2hCLFdBQUsvRCxTQUFMLEdBQWlCLElBQWpCOztBQUNBLFVBQUksQ0FBQyxLQUFLSCxTQUFOLElBQW1CLENBQUMsS0FBS0QsU0FBN0IsRUFBd0M7QUFDdEMsYUFBS3RELE9BQUw7QUFDRDs7QUFDRCxVQUFJLENBQUMsS0FBS3VCLFFBQVYsRUFBb0I7QUFDbEIsY0FBTSxJQUFJVSxLQUFKLENBQ0oseURBREksQ0FBTjtBQUdEOztBQUNELGFBQU8sS0FBS1YsUUFBTCxDQUFjbUcsSUFBZCxDQUFtQkYsU0FBbkIsRUFBOEJDLFFBQTlCLENBQVA7QUFDRDtBQTdxQkg7QUFBQTtBQUFBLDJCQWdyQklBLFFBaHJCSixFQW1yQm9DO0FBQ2hDLGFBQU8sS0FBS0MsSUFBTCxDQUFVLElBQVYsRUFBZ0JELFFBQWhCLENBQVA7QUFDRDtBQXJyQkg7QUFBQTtBQUFBLDhCQXVyQjRDO0FBQ3hDLGFBQU8sU0FBUWpHLE9BQVIsQ0FBZ0IsSUFBaEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTdyQkE7QUFBQTtBQUFBLDRCQWdzQlU0RCxJQWhzQlYsRUFnc0IwQ3RGLE9BaHNCMUMsRUFnc0J5RTtBQUFBO0FBQUE7O0FBQ3JFLFVBQUksUUFBT3NGLElBQVAsTUFBZ0IsUUFBaEIsSUFBNEJBLElBQUksS0FBSyxJQUF6QyxFQUErQztBQUM3Q3RGLFFBQUFBLE9BQU8sR0FBR3NGLElBQVY7QUFDQUEsUUFBQUEsSUFBSSxHQUFHdEMsU0FBUDtBQUNEOztBQUNEaEQsTUFBQUEsT0FBTyxHQUFHQSxPQUFPLElBQUksRUFBckI7QUFDQSxVQUFNNkgsS0FBa0IsR0FBR3ZDLElBQUksSUFBSyxLQUFLdEUsT0FBTCxDQUFhaUMsS0FBakQ7O0FBQ0EsVUFBSSxDQUFDNEUsS0FBTCxFQUFZO0FBQ1YsY0FBTSxJQUFJMUYsS0FBSixDQUNKLGlFQURJLENBQU47QUFHRCxPQVhvRSxDQVlyRTs7O0FBQ0EsVUFBTTJGLFlBQVksR0FDaEI5SCxPQUFPLENBQUMrSCxTQUFSLEtBQXNCLEtBQXRCLEdBQ0ksQ0FBQyxDQURMLEdBRUksT0FBTy9ILE9BQU8sQ0FBQ2dJLGFBQWYsS0FBaUMsUUFBakMsR0FDQWhJLE9BQU8sQ0FBQ2dJLGFBRFIsR0FFQTtBQUNGLFdBQUs1SCxLQUFMLENBQVc2SCxjQUFYLENBQTBCLEVBQTFCLElBQ0V0SSxzQkFERixHQUVFLEtBQUtTLEtBQUwsQ0FBVzhILFdBQVgsR0FBeUIsQ0FSL0I7QUFVQSxVQUFNQyxjQUFjLDRCQUFHbkksT0FBTyxDQUFDbUksY0FBWCx5RUFBNkJ2SSx3QkFBakQ7QUFFQSxhQUFPLGFBQVksVUFBQzhCLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUN0QyxZQUFNeUcsV0FBVyxHQUFHLFNBQWRBLFdBQWM7QUFBQSxpQkFDbEIsTUFBSSxDQUFDaEksS0FBTCxDQUNHc0YsT0FESCxDQUNXbUMsS0FEWCxFQUVHUSxVQUZILEdBR0d6RyxFQUhILENBR00sVUFITixFQUdrQkYsT0FIbEIsRUFJR0UsRUFKSCxDQUlNLE9BSk4sRUFJZUQsTUFKZixDQURrQjtBQUFBLFNBQXBCOztBQU1BLFlBQUlrQyxPQUFpQixHQUFHLEVBQXhCO0FBQ0EsWUFBSXlFLEtBQTRDLEdBQUcsSUFBbkQ7O0FBQ0EsWUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsR0FBRCxFQUFpQjtBQUNwQyxjQUFJLENBQUNBLEdBQUcsQ0FBQ0MsRUFBVCxFQUFhO0FBQ1gsZ0JBQU16RyxJQUFHLEdBQUcsSUFBSUcsS0FBSixDQUNWLHVEQURVLENBQVo7O0FBR0EsWUFBQSxNQUFJLENBQUNGLElBQUwsQ0FBVSxPQUFWLEVBQW1CRCxJQUFuQjs7QUFDQTtBQUNEOztBQUNELGNBQU1GLE1BQWMsR0FBRztBQUFFMkcsWUFBQUEsRUFBRSxFQUFFRCxHQUFHLENBQUNDO0FBQVYsV0FBdkI7O0FBQ0EsY0FBSUgsS0FBSixFQUFXO0FBQ1RBLFlBQUFBLEtBQUssQ0FBQ0ksS0FBTixDQUFZNUcsTUFBWjtBQUNELFdBRkQsTUFFTztBQUNMK0IsWUFBQUEsT0FBTyxDQUFDOUIsSUFBUixDQUFhRCxNQUFiOztBQUNBLGdCQUNFZ0csWUFBWSxJQUFJLENBQWhCLElBQ0FqRSxPQUFPLENBQUNtQixNQUFSLEdBQWlCOEMsWUFEakIsSUFFQUssY0FBYyxLQUFLLENBSHJCLEVBSUU7QUFDQTtBQUNBRyxjQUFBQSxLQUFLLEdBQUdGLFdBQVcsRUFBbkI7O0FBRkEsMERBR3FCdkUsT0FIckI7QUFBQTs7QUFBQTtBQUdBLHVFQUE4QjtBQUFBLHNCQUFuQi9CLE9BQW1CO0FBQzVCd0csa0JBQUFBLEtBQUssQ0FBQ0ksS0FBTixDQUFZNUcsT0FBWjtBQUNEO0FBTEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFNQStCLGNBQUFBLE9BQU8sR0FBRyxFQUFWO0FBQ0Q7QUFDRjtBQUNGLFNBMUJEOztBQTJCQSxZQUFNOEUsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBTTtBQUN0QixjQUFJTCxLQUFKLEVBQVc7QUFDVEEsWUFBQUEsS0FBSyxDQUFDTSxHQUFOO0FBQ0QsV0FGRCxNQUVPO0FBQ0wsZ0JBQU1DLEdBQUcsR0FBRyxxQkFBQWhGLE9BQU8sTUFBUCxDQUFBQSxPQUFPLEVBQUssVUFBQy9CLE1BQUQ7QUFBQSxxQkFBWUEsTUFBTSxDQUFDMkcsRUFBbkI7QUFBQSxhQUFMLENBQW5COztBQUNBLGdCQUFJNUUsT0FBTyxDQUFDbUIsTUFBUixHQUFpQjhDLFlBQWpCLElBQWlDSyxjQUFjLEtBQUssQ0FBeEQsRUFBMkQ7QUFDekQsY0FBQSxNQUFJLENBQUMvSCxLQUFMLENBQVcwSSxLQUFYLENBQ0dDLHFCQURILENBQ3lCO0FBQ3JCQyxnQkFBQUEsTUFBTSxFQUFFbkIsS0FEYTtBQUVyQm9CLGdCQUFBQSxTQUFTLEVBQUUsUUFGVTtBQUdyQkMsZ0JBQUFBLEtBQUssRUFBRXJGO0FBSGMsZUFEekIsRUFNRytELElBTkgsQ0FPSSxVQUFDdUIsVUFBRDtBQUFBLHVCQUNFekgsT0FBTyxDQUFDLE1BQUksQ0FBQzBILDZCQUFMLENBQW1DRCxVQUFuQyxDQUFELENBRFQ7QUFBQSxlQVBKLEVBU0l4SCxNQVRKO0FBV0QsYUFaRCxNQVlPO0FBQ0wsY0FBQSxNQUFJLENBQUN2QixLQUFMLENBQ0dzRixPQURILENBQ1dtQyxLQURYLEVBRUcxSCxPQUZILENBRVcwSSxHQUZYLEVBRWdCO0FBQUVRLGdCQUFBQSxjQUFjLEVBQUU7QUFBbEIsZUFGaEIsRUFHR3pCLElBSEgsQ0FHUWxHLE9BSFIsRUFHaUJDLE1BSGpCO0FBSUQ7QUFDRjtBQUNGLFNBeEJEOztBQXlCQSxRQUFBLE1BQUksQ0FBQzRELE1BQUwsQ0FBWSxRQUFaLEVBQ0czRCxFQURILENBQ00sTUFETixFQUNjMkcsWUFEZCxFQUVHM0csRUFGSCxDQUVNLEtBRk4sRUFFYStHLFNBRmIsRUFHRy9HLEVBSEgsQ0FHTSxPQUhOLEVBR2VELE1BSGY7QUFJRCxPQWpFTSxDQUFQO0FBa0VEO0FBRUQ7QUFDRjtBQUNBOztBQS94QkE7QUFBQTtBQUFBLDJCQW96QkkySCxPQXB6QkosRUFxekJJaEUsSUFyekJKLEVBc3pCSXRGLE9BdHpCSixFQXV6Qkk7QUFBQTtBQUFBOztBQUNBLFVBQUksUUFBT3NGLElBQVAsTUFBZ0IsUUFBaEIsSUFBNEJBLElBQUksS0FBSyxJQUF6QyxFQUErQztBQUM3Q3RGLFFBQUFBLE9BQU8sR0FBR3NGLElBQVY7QUFDQUEsUUFBQUEsSUFBSSxHQUFHdEMsU0FBUDtBQUNEOztBQUNEaEQsTUFBQUEsT0FBTyxHQUFHQSxPQUFPLElBQUksRUFBckI7QUFDQSxVQUFNNkgsS0FBa0IsR0FDdEJ2QyxJQUFJLElBQUssS0FBS3RFLE9BQUwsSUFBaUIsS0FBS0EsT0FBTCxDQUFhaUMsS0FEekM7O0FBRUEsVUFBSSxDQUFDNEUsS0FBTCxFQUFZO0FBQ1YsY0FBTSxJQUFJMUYsS0FBSixDQUNKLGlFQURJLENBQU47QUFHRDs7QUFDRCxVQUFNb0gsWUFBWSxHQUNoQixPQUFPRCxPQUFQLEtBQW1CLFVBQW5CLEdBQ0kscUJBQUFsSyxZQUFZLE1BQVosQ0FBQUEsWUFBWSxFQUFLa0ssT0FBTCxDQURoQixHQUVJbEssWUFBWSxDQUFDb0ssZUFBYixDQUE2QkYsT0FBN0IsQ0FITixDQWJBLENBaUJBOztBQUNBLFVBQU14QixZQUFZLEdBQ2hCOUgsT0FBTyxDQUFDK0gsU0FBUixLQUFzQixLQUF0QixHQUNJLENBQUMsQ0FETCxHQUVJLE9BQU8vSCxPQUFPLENBQUNnSSxhQUFmLEtBQWlDLFFBQWpDLEdBQ0FoSSxPQUFPLENBQUNnSSxhQURSLEdBRUE7QUFDRixXQUFLNUgsS0FBTCxDQUFXNkgsY0FBWCxDQUEwQixFQUExQixJQUNFdEksc0JBREYsR0FFRSxLQUFLUyxLQUFMLENBQVc4SCxXQUFYLEdBQXlCLENBUi9CO0FBU0EsVUFBTUMsY0FBYyw2QkFBR25JLE9BQU8sQ0FBQ21JLGNBQVgsMkVBQTZCdkksd0JBQWpEO0FBQ0EsYUFBTyxhQUFZLFVBQUM4QixPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDdEMsWUFBTXlHLFdBQVcsR0FBRyxTQUFkQSxXQUFjO0FBQUEsaUJBQ2xCLE1BQUksQ0FBQ2hJLEtBQUwsQ0FDR3NGLE9BREgsQ0FDV21DLEtBRFgsRUFFRzRCLFVBRkgsR0FHRzdILEVBSEgsQ0FHTSxVQUhOLEVBR2tCRixPQUhsQixFQUlHRSxFQUpILENBSU0sT0FKTixFQUllRCxNQUpmLENBRGtCO0FBQUEsU0FBcEI7O0FBTUEsWUFBSWtDLE9BQW9DLEdBQUcsRUFBM0M7QUFDQSxZQUFJeUUsS0FBNEMsR0FBRyxJQUFuRDs7QUFDQSxZQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDekcsTUFBRCxFQUFvQjtBQUN2QyxjQUFJd0csS0FBSixFQUFXO0FBQ1RBLFlBQUFBLEtBQUssQ0FBQ0ksS0FBTixDQUFZNUcsTUFBWjtBQUNELFdBRkQsTUFFTztBQUNMK0IsWUFBQUEsT0FBTyxDQUFDOUIsSUFBUixDQUFhRCxNQUFiO0FBQ0Q7O0FBQ0QsY0FDRWdHLFlBQVksSUFBSSxDQUFoQixJQUNBakUsT0FBTyxDQUFDbUIsTUFBUixHQUFpQjhDLFlBRGpCLElBRUFLLGNBQWMsS0FBSyxDQUhyQixFQUlFO0FBQ0E7QUFDQUcsWUFBQUEsS0FBSyxHQUFHRixXQUFXLEVBQW5COztBQUZBLHdEQUdxQnZFLE9BSHJCO0FBQUE7O0FBQUE7QUFHQSxxRUFBOEI7QUFBQSxvQkFBbkIvQixRQUFtQjtBQUM1QndHLGdCQUFBQSxLQUFLLENBQUNJLEtBQU4sQ0FBWTVHLFFBQVo7QUFDRDtBQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBTUErQixZQUFBQSxPQUFPLEdBQUcsRUFBVjtBQUNEO0FBQ0YsU0FsQkQ7O0FBbUJBLFlBQU04RSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxHQUFNO0FBQ3RCLGNBQUlMLEtBQUosRUFBVztBQUNUQSxZQUFBQSxLQUFLLENBQUNNLEdBQU47QUFDRCxXQUZELE1BRU87QUFDTCxnQkFBSS9FLE9BQU8sQ0FBQ21CLE1BQVIsR0FBaUI4QyxZQUFqQixJQUFpQ0ssY0FBYyxLQUFLLENBQXhELEVBQTJEO0FBQ3pELGNBQUEsTUFBSSxDQUFDL0gsS0FBTCxDQUFXMEksS0FBWCxDQUNHQyxxQkFESCxDQUN5QjtBQUNyQkMsZ0JBQUFBLE1BQU0sRUFBRW5CLEtBRGE7QUFFckJvQixnQkFBQUEsU0FBUyxFQUFFLFFBRlU7QUFHckJDLGdCQUFBQSxLQUFLLEVBQUVyRjtBQUhjLGVBRHpCLEVBTUcrRCxJQU5ILENBT0ksVUFBQ3VCLFVBQUQ7QUFBQSx1QkFDRXpILE9BQU8sQ0FBQyxNQUFJLENBQUMwSCw2QkFBTCxDQUFtQ0QsVUFBbkMsQ0FBRCxDQURUO0FBQUEsZUFQSixFQVNJeEgsTUFUSjtBQVdELGFBWkQsTUFZTztBQUNMLGNBQUEsTUFBSSxDQUFDdkIsS0FBTCxDQUNHc0YsT0FESCxDQUNXbUMsS0FEWCxFQUVHNkIsTUFGSCxDQUVVN0YsT0FGVixFQUVtQjtBQUFFd0YsZ0JBQUFBLGNBQWMsRUFBRTtBQUFsQixlQUZuQixFQUdHekIsSUFISCxDQUdRbEcsT0FIUixFQUdpQkMsTUFIakI7QUFJRDtBQUNGO0FBQ0YsU0F2QkQ7O0FBd0JBLFFBQUEsTUFBSSxDQUFDNEQsTUFBTCxDQUFZLFFBQVosRUFDRzNELEVBREgsQ0FDTSxPQUROLEVBQ2VELE1BRGYsRUFFRzZELElBRkgsQ0FFUStELFlBRlIsRUFHRzNILEVBSEgsQ0FHTSxNQUhOLEVBR2MyRyxZQUhkLEVBSUczRyxFQUpILENBSU0sS0FKTixFQUlhK0csU0FKYixFQUtHL0csRUFMSCxDQUtNLE9BTE4sRUFLZUQsTUFMZjtBQU1ELE9BMURNLENBQVA7QUEyREQ7QUE5NEJIO0FBQUE7QUFBQSxrREFpNUJJZ0ksaUJBajVCSixFQWs1QmtCO0FBQUE7O0FBQ2QsVUFBTUMsa0JBQWdDLEdBQUcsa0NBQUFELGlCQUFpQixDQUFDRSxpQkFBbEIsbUJBQ3ZDLFVBQUNDLENBQUQsRUFBTztBQUNMLFlBQU1DLFVBQXNCLEdBQUc7QUFDN0JDLFVBQUFBLEVBQUUsRUFBRUYsQ0FBQyxDQUFDRyxNQUR1QjtBQUU3QkMsVUFBQUEsT0FBTyxFQUFFLElBRm9CO0FBRzdCQyxVQUFBQSxNQUFNLEVBQUU7QUFIcUIsU0FBL0I7QUFLQSxlQUFPSixVQUFQO0FBQ0QsT0FSc0MsQ0FBekM7O0FBV0EsVUFBTUssaUJBQWlCLEdBQUcsa0NBQUFULGlCQUFpQixDQUFDVSxhQUFsQixtQkFBb0MsVUFBQ1AsQ0FBRCxFQUFPO0FBQ25FLFlBQU1DLFVBQXNCLEdBQUc7QUFDN0JHLFVBQUFBLE9BQU8sRUFBRSxLQURvQjtBQUU3QkMsVUFBQUEsTUFBTSxFQUFFLENBQ047QUFDRUcsWUFBQUEsU0FBUyxFQUFFUixDQUFDLENBQUNTLFNBRGY7QUFFRUMsWUFBQUEsT0FBTyxFQUFFVixDQUFDLENBQUNTO0FBRmIsV0FETTtBQUZxQixTQUEvQjtBQVNBLGVBQU9SLFVBQVA7QUFDRCxPQVh5QixDQUExQjs7QUFhQSwwRkFBV0gsa0JBQVgsc0JBQWtDUSxpQkFBbEM7QUFDRDtBQTU2Qkg7O0FBQUE7QUFBQSxFQUtVbEwsWUFMVjtBQSs2QkE7O0FBRUE7QUFDQTtBQUNBOztnQkFuN0JhVyxLLGFBTU1WLFNBQVMsQ0FBQyxPQUFELEM7O0FBODZCNUIsV0FBYWdFLFFBQWI7QUFhRTtBQUNGO0FBQ0E7QUFDRSxvQkFDRXJELElBREYsRUFFRXFHLE9BRkYsRUFHRXBHLE1BSEYsRUFJRTBLLE1BSkYsRUFLRTtBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9DQXdETyxLQUFLeEssSUF4RFo7O0FBQUEsMkRBNEV3QyxJQTVFeEM7O0FBQ0EsU0FBS3lLLFFBQUwsR0FBZ0J2RSxPQUFoQjtBQUNBLFNBQUtGLE1BQUwsR0FBYyxJQUFJcEcsS0FBSixDQUFVQyxJQUFWLEVBQWdCQyxNQUFoQixDQUFkO0FBQ0EsU0FBSzRLLE9BQUwsR0FBZUYsTUFBZjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUE3QkE7QUFBQTtBQUFBLDJCQW1DSTVKLE1BbkNKLEVBb0NzRTtBQUNsRTtBQUNBLFdBQUtvRixNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZaEYsTUFBWixDQUFtQkosTUFBbkIsQ0FBZDtBQUNBLGFBQVEsSUFBUjtBQVNEO0FBRUQ7QUFDRjtBQUNBOztBQXBEQTtBQUFBO0FBQUEsMEJBcURRNkIsVUFyRFIsRUFxRDBEO0FBQ3RELFdBQUt1RCxNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZMkUsS0FBWixDQUFrQmxJLFVBQWxCLENBQWQ7QUFDQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE1REE7QUFBQTtBQUFBLDBCQTZEUUMsT0E3RFIsRUE2RHVCO0FBQ25CLFdBQUtzRCxNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZdEQsS0FBWixDQUFrQkEsT0FBbEIsQ0FBZDtBQUNBLGFBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXBFQTtBQUFBO0FBQUEseUJBcUVPQyxNQXJFUCxFQXFFdUI7QUFDbkIsV0FBS3FELE1BQUwsR0FBYyxLQUFLQSxNQUFMLENBQVloRyxJQUFaLENBQWlCMkMsTUFBakIsQ0FBZDtBQUNBLGFBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTVFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsZ0JBdUZJN0IsSUF2RkosRUF3Rkk4QixHQXhGSixFQXlGSTtBQUFBOztBQUNBLFdBQUtvRCxNQUFMLEdBQWMsd0NBQUtBLE1BQUwsbUJBQWlCbEYsSUFBakIsRUFBOEI4QixHQUE5QixDQUFkO0FBQ0EsYUFBTyxJQUFQO0FBQ0QsS0E1Rkg7QUE4RkU7QUFDRjtBQUNBOztBQWhHQTtBQUFBOztBQW1HRTtBQUNGO0FBQ0E7QUFyR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVHMEIsS0FBSzhILE9BQUwsQ0FBYUUsbUJBQWIsQ0FBaUMsS0FBS0gsUUFBdEMsQ0F2RzFCOztBQUFBO0FBdUdVaEYsZ0JBQUFBLE9BdkdWO0FBQUEsbURBd0dXLEtBQUtPLE1BQUwsQ0FBWUosYUFBWixDQUEwQkgsT0FBMUIsQ0F4R1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUEyR0U7QUFDRjtBQUNBOztBQTdHQTtBQUFBO0FBQUEsMEJBb0grQjtBQUMzQixhQUFRLEtBQUtpRixPQUFiO0FBQ0Q7QUF0SEg7O0FBQUE7QUFBQTtBQXlIQSxlQUFlOUssS0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBxdWVyeSBmb3IgcmVjb3JkcyBpbiBTYWxlc2ZvcmNlXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCB7IExvZ2dlciwgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQgUmVjb3JkU3RyZWFtLCB7IFNlcmlhbGl6YWJsZSB9IGZyb20gJy4vcmVjb3JkLXN0cmVhbSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgY3JlYXRlU09RTCB9IGZyb20gJy4vc29xbC1idWlsZGVyJztcbmltcG9ydCB7IFF1ZXJ5Q29uZmlnIGFzIFNPUUxRdWVyeUNvbmZpZywgU29ydERpciB9IGZyb20gJy4vc29xbC1idWlsZGVyJztcbmltcG9ydCB7XG4gIFJlY29yZCxcbiAgT3B0aW9uYWwsXG4gIFNjaGVtYSxcbiAgU09iamVjdE5hbWVzLFxuICBDaGlsZFJlbGF0aW9uc2hpcE5hbWVzLFxuICBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lLFxuICBGaWVsZFByb2plY3Rpb25Db25maWcsXG4gIEZpZWxkUGF0aFNwZWNpZmllcixcbiAgRmllbGRQYXRoU2NvcGVkUHJvamVjdGlvbixcbiAgU09iamVjdFJlY29yZCxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxuICBTYXZlUmVzdWx0LFxuICBEYXRlU3RyaW5nLFxuICBTT2JqZWN0Q2hpbGRSZWxhdGlvbnNoaXBQcm9wLFxuICBTT2JqZWN0RmllbGROYW1lcyxcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBSZWFkYWJsZSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgU2ZEYXRlIGZyb20gJy4vZGF0ZSc7XG5pbXBvcnQgeyBJbmdlc3RKb2JWMlJlc3VsdHMgfSBmcm9tICcuL2FwaS9idWxrJztcblxuLyoqXG4gKlxuICovXG5leHBvcnQgdHlwZSBRdWVyeUZpZWxkPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICBGUCBleHRlbmRzIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPlxuPiA9IEZQIHwgRlBbXSB8IHN0cmluZyB8IHN0cmluZ1tdIHwgeyBbZmllbGQ6IHN0cmluZ106IG51bWJlciB8IGJvb2xlYW4gfTtcblxuLyoqXG4gKlxuICovXG50eXBlIENWYWx1ZTxUPiA9IFQgZXh0ZW5kcyBEYXRlU3RyaW5nXG4gID8gU2ZEYXRlXG4gIDogVCBleHRlbmRzIHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW5cbiAgPyBUXG4gIDogbmV2ZXI7XG5cbnR5cGUgQ29uZE9wPFQ+ID1cbiAgfCBbJyRlcScsIENWYWx1ZTxUPiB8IG51bGxdXG4gIHwgWyckbmUnLCBDVmFsdWU8VD4gfCBudWxsXVxuICB8IFsnJGd0JywgQ1ZhbHVlPFQ+XVxuICB8IFsnJGd0ZScsIENWYWx1ZTxUPl1cbiAgfCBbJyRsdCcsIENWYWx1ZTxUPl1cbiAgfCBbJyRsdGUnLCBDVmFsdWU8VD5dXG4gIHwgWyckbGlrZScsIFQgZXh0ZW5kcyBzdHJpbmcgPyBUIDogbmV2ZXJdXG4gIHwgWyckbmxpa2UnLCBUIGV4dGVuZHMgc3RyaW5nID8gVCA6IG5ldmVyXVxuICB8IFsnJGluJywgQXJyYXk8Q1ZhbHVlPFQ+Pl1cbiAgfCBbJyRuaW4nLCBBcnJheTxDVmFsdWU8VD4+XVxuICB8IFsnJGluY2x1ZGVzJywgVCBleHRlbmRzIHN0cmluZyA/IFRbXSA6IG5ldmVyXVxuICB8IFsnJGV4Y2x1ZGVzJywgVCBleHRlbmRzIHN0cmluZyA/IFRbXSA6IG5ldmVyXVxuICB8IFsnJGV4aXN0cycsIGJvb2xlYW5dO1xuXG50eXBlIENvbmRWYWx1ZU9iajxULCBPcCA9IENvbmRPcDxUPlswXT4gPSBPcCBleHRlbmRzIENvbmRPcDxUPlswXVxuICA/IE9wIGV4dGVuZHMgc3RyaW5nXG4gICAgPyB7IFtLIGluIE9wXTogRXh0cmFjdDxDb25kT3A8VD4sIFtPcCwgYW55XT5bMV0gfVxuICAgIDogbmV2ZXJcbiAgOiBuZXZlcjtcblxudHlwZSBDb25kVmFsdWU8VD4gPSBDVmFsdWU8VD4gfCBBcnJheTxDVmFsdWU8VD4+IHwgbnVsbCB8IENvbmRWYWx1ZU9iajxUPjtcblxudHlwZSBDb25kaXRpb25TZXQ8UiBleHRlbmRzIFJlY29yZD4gPSB7XG4gIFtLIGluIGtleW9mIFJdPzogQ29uZFZhbHVlPFJbS10+O1xufTtcblxuZXhwb3J0IHR5cGUgUXVlcnlDb25kaXRpb248UyBleHRlbmRzIFNjaGVtYSwgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4gPVxuICB8IHtcbiAgICAgICRvcjogUXVlcnlDb25kaXRpb248UywgTj5bXTtcbiAgICB9XG4gIHwge1xuICAgICAgJGFuZDogUXVlcnlDb25kaXRpb248UywgTj5bXTtcbiAgICB9XG4gIHwgQ29uZGl0aW9uU2V0PFNPYmplY3RSZWNvcmQ8UywgTj4+O1xuXG5leHBvcnQgdHlwZSBRdWVyeVNvcnQ8XG4gIFMgZXh0ZW5kcyBTY2hlbWEsXG4gIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gIFIgZXh0ZW5kcyBTT2JqZWN0UmVjb3JkPFMsIE4+ID0gU09iamVjdFJlY29yZDxTLCBOPlxuPiA9XG4gIHwge1xuICAgICAgW0sgaW4ga2V5b2YgUl0/OiBTb3J0RGlyO1xuICAgIH1cbiAgfCBBcnJheTxba2V5b2YgUiwgU29ydERpcl0+O1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIFF1ZXJ5Q29uZmlnPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICBGUCBleHRlbmRzIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPlxuPiA9IHtcbiAgZmllbGRzPzogUXVlcnlGaWVsZDxTLCBOLCBGUD47XG4gIGluY2x1ZGVzPzoge1xuICAgIFtDUk4gaW4gQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBOPl0/OiBRdWVyeUNvbmZpZzxcbiAgICAgIFMsXG4gICAgICBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj5cbiAgICA+O1xuICB9O1xuICB0YWJsZT86IHN0cmluZztcbiAgY29uZGl0aW9ucz86IFF1ZXJ5Q29uZGl0aW9uPFMsIE4+O1xuICBzb3J0PzogUXVlcnlTb3J0PFMsIE4+O1xuICBsaW1pdD86IG51bWJlcjtcbiAgb2Zmc2V0PzogbnVtYmVyO1xufTtcblxuZXhwb3J0IHR5cGUgUXVlcnlPcHRpb25zID0ge1xuICBoZWFkZXJzOiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfTtcbiAgbWF4RmV0Y2g6IG51bWJlcjtcbiAgYXV0b0ZldGNoOiBib29sZWFuO1xuICBzY2FuQWxsOiBib29sZWFuO1xuICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldDtcbn07XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5UmVzdWx0PFIgZXh0ZW5kcyBSZWNvcmQ+ID0ge1xuICBkb25lOiBib29sZWFuO1xuICB0b3RhbFNpemU6IG51bWJlcjtcbiAgcmVjb3JkczogUltdO1xuICBuZXh0UmVjb3Jkc1VybD86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5RXhwbGFpblJlc3VsdCA9IHtcbiAgcGxhbnM6IEFycmF5PHtcbiAgICBjYXJkaW5hbGl0eTogbnVtYmVyO1xuICAgIGZpZWxkczogc3RyaW5nW107XG4gICAgbGVhZGluZ09wZXJhdGlvblR5cGU6ICdJbmRleCcgfCAnT3RoZXInIHwgJ1NoYXJpbmcnIHwgJ1RhYmxlU2Nhbic7XG4gICAgbm90ZXM6IEFycmF5PHtcbiAgICAgIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gICAgICBmaWVsZHM6IHN0cmluZ1tdO1xuICAgICAgdGFibGVFbnVtT3JJZDogc3RyaW5nO1xuICAgIH0+O1xuICAgIHJlbGF0aXZlQ29zdDogbnVtYmVyO1xuICAgIHNvYmplY3RDYXJkaW5hbGl0eTogbnVtYmVyO1xuICAgIHNvYmplY3RUeXBlOiBzdHJpbmc7XG4gIH0+O1xufTtcblxuY29uc3QgUmVzcG9uc2VUYXJnZXRWYWx1ZXMgPSBbXG4gICdRdWVyeVJlc3VsdCcsXG4gICdSZWNvcmRzJyxcbiAgJ1NpbmdsZVJlY29yZCcsXG4gICdDb3VudCcsXG5dIGFzIGNvbnN0O1xuXG5leHBvcnQgdHlwZSBRdWVyeVJlc3BvbnNlVGFyZ2V0ID0gdHlwZW9mIFJlc3BvbnNlVGFyZ2V0VmFsdWVzW251bWJlcl07XG5cbmV4cG9ydCBjb25zdCBSZXNwb25zZVRhcmdldHM6IHtcbiAgW0sgaW4gUXVlcnlSZXNwb25zZVRhcmdldF06IEs7XG59ID0gUmVzcG9uc2VUYXJnZXRWYWx1ZXMucmVkdWNlKFxuICAodmFsdWVzLCB0YXJnZXQpID0+ICh7IC4uLnZhbHVlcywgW3RhcmdldF06IHRhcmdldCB9KSxcbiAge30gYXMge1xuICAgIFtLIGluIFF1ZXJ5UmVzcG9uc2VUYXJnZXRdOiBLO1xuICB9LFxuKTtcblxuZXhwb3J0IHR5cGUgUXVlcnlSZXNwb25zZTxcbiAgUiBleHRlbmRzIFJlY29yZCxcbiAgUVJUIGV4dGVuZHMgUXVlcnlSZXNwb25zZVRhcmdldCA9IFF1ZXJ5UmVzcG9uc2VUYXJnZXRcbj4gPSBRUlQgZXh0ZW5kcyAnUXVlcnlSZXN1bHQnXG4gID8gUXVlcnlSZXN1bHQ8Uj5cbiAgOiBRUlQgZXh0ZW5kcyAnUmVjb3JkcydcbiAgPyBSW11cbiAgOiBRUlQgZXh0ZW5kcyAnU2luZ2xlUmVjb3JkJ1xuICA/IFIgfCBudWxsXG4gIDogbnVtYmVyOyAvLyBRUlQgZXh0ZW5kcyAnQ291bnQnXG5cbmV4cG9ydCB0eXBlIEJ1bGtBcGlWZXJzaW9uID0gMSB8IDI7XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5RGVzdHJveU9wdGlvbnMgPSB7XG4gIGFsbG93QnVsaz86IGJvb2xlYW47XG4gIGJ1bGtUaHJlc2hvbGQ/OiBudW1iZXI7XG4gIGJ1bGtBcGlWZXJzaW9uPzogQnVsa0FwaVZlcnNpb247XG59O1xuXG5leHBvcnQgdHlwZSBRdWVyeVVwZGF0ZU9wdGlvbnMgPSB7XG4gIGFsbG93QnVsaz86IGJvb2xlYW47XG4gIGJ1bGtUaHJlc2hvbGQ/OiBudW1iZXI7XG4gIGJ1bGtBcGlWZXJzaW9uPzogQnVsa0FwaVZlcnNpb247XG59O1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IERFRkFVTFRfQlVMS19USFJFU0hPTEQgPSAyMDA7XG5jb25zdCBERUZBVUxUX0JVTEtfQVBJX1ZFUlNJT04gPSAxO1xuXG4vKipcbiAqIFF1ZXJ5XG4gKi9cbmV4cG9ydCBjbGFzcyBRdWVyeTxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgUiBleHRlbmRzIFJlY29yZCA9IFJlY29yZCxcbiAgUVJUIGV4dGVuZHMgUXVlcnlSZXNwb25zZVRhcmdldCA9IFF1ZXJ5UmVzcG9uc2VUYXJnZXRcbj4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBzdGF0aWMgX2xvZ2dlciA9IGdldExvZ2dlcigncXVlcnknKTtcblxuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcbiAgX2xvZ2dlcjogTG9nZ2VyO1xuICBfc29xbDogT3B0aW9uYWw8c3RyaW5nPjtcbiAgX2xvY2F0b3I6IE9wdGlvbmFsPHN0cmluZz47XG4gIF9jb25maWc6IFNPUUxRdWVyeUNvbmZpZyA9IHt9O1xuICBfY2hpbGRyZW46IFN1YlF1ZXJ5PFMsIE4sIFIsIFFSVCwgYW55LCBhbnksIGFueT5bXSA9IFtdO1xuICBfb3B0aW9uczogUXVlcnlPcHRpb25zO1xuICBfZXhlY3V0ZWQ6IGJvb2xlYW4gPSBmYWxzZTtcbiAgX2ZpbmlzaGVkOiBib29sZWFuID0gZmFsc2U7XG4gIF9jaGFpbmluZzogYm9vbGVhbiA9IGZhbHNlO1xuICBfcHJvbWlzZTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFIsIFFSVD4+O1xuICBfc3RyZWFtOiBTZXJpYWxpemFibGU8Uj47XG5cbiAgdG90YWxTaXplID0gMDtcbiAgdG90YWxGZXRjaGVkID0gMDtcbiAgcmVjb3JkczogUltdID0gW107XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICAgIGNvbmZpZzogc3RyaW5nIHwgUXVlcnlDb25maWc8UywgTj4gfCB7IGxvY2F0b3I6IHN0cmluZyB9LFxuICAgIG9wdGlvbnM/OiBQYXJ0aWFsPFF1ZXJ5T3B0aW9ucz4sXG4gICkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5fbG9nZ2VyID0gY29ubi5fbG9nTGV2ZWxcbiAgICAgID8gUXVlcnkuX2xvZ2dlci5jcmVhdGVJbnN0YW5jZShjb25uLl9sb2dMZXZlbClcbiAgICAgIDogUXVlcnkuX2xvZ2dlcjtcbiAgICBpZiAodHlwZW9mIGNvbmZpZyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHRoaXMuX3NvcWwgPSBjb25maWc7XG4gICAgICB0aGlzLl9sb2dnZXIuZGVidWcoYGNvbmZpZyBpcyBzb3FsOiAke2NvbmZpZ31gKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiAoY29uZmlnIGFzIGFueSkubG9jYXRvciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGxvY2F0b3I6IHN0cmluZyA9IChjb25maWcgYXMgYW55KS5sb2NhdG9yO1xuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBjb25maWcgaXMgbG9jYXRvcjogJHtsb2NhdG9yfWApO1xuICAgICAgdGhpcy5fbG9jYXRvciA9IGxvY2F0b3IuaW5jbHVkZXMoJy8nKVxuICAgICAgICA/IHRoaXMudXJsVG9Mb2NhdG9yKGxvY2F0b3IpXG4gICAgICAgIDogbG9jYXRvcjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBjb25maWcgaXMgUXVlcnlDb25maWc6ICR7Y29uZmlnfWApO1xuICAgICAgY29uc3QgeyBmaWVsZHMsIGluY2x1ZGVzLCBzb3J0LCAuLi5fY29uZmlnIH0gPSBjb25maWcgYXMgUXVlcnlDb25maWc8XG4gICAgICAgIFMsXG4gICAgICAgIE5cbiAgICAgID47XG4gICAgICB0aGlzLl9jb25maWcgPSBfY29uZmlnO1xuICAgICAgdGhpcy5zZWxlY3QoZmllbGRzKTtcbiAgICAgIGlmIChpbmNsdWRlcykge1xuICAgICAgICB0aGlzLmluY2x1ZGVDaGlsZHJlbihpbmNsdWRlcyk7XG4gICAgICB9XG4gICAgICBpZiAoc29ydCkge1xuICAgICAgICB0aGlzLnNvcnQoc29ydCk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuX29wdGlvbnMgPSB7XG4gICAgICBoZWFkZXJzOiB7fSxcbiAgICAgIG1heEZldGNoOiAxMDAwMCxcbiAgICAgIGF1dG9GZXRjaDogZmFsc2UsXG4gICAgICBzY2FuQWxsOiBmYWxzZSxcbiAgICAgIHJlc3BvbnNlVGFyZ2V0OiAnUXVlcnlSZXN1bHQnLFxuICAgICAgLi4uKG9wdGlvbnMgfHwge30pLFxuICAgIH0gYXMgUXVlcnlPcHRpb25zO1xuICAgIC8vIHByb21pc2UgaW5zdGFuY2VcbiAgICB0aGlzLl9wcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5vbigncmVzcG9uc2UnLCByZXNvbHZlKTtcbiAgICAgIHRoaXMub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcbiAgICB0aGlzLl9zdHJlYW0gPSBuZXcgU2VyaWFsaXphYmxlKCk7XG4gICAgdGhpcy5vbigncmVjb3JkJywgKHJlY29yZCkgPT4gdGhpcy5fc3RyZWFtLnB1c2gocmVjb3JkKSk7XG4gICAgdGhpcy5vbignZW5kJywgKCkgPT4gdGhpcy5fc3RyZWFtLnB1c2gobnVsbCkpO1xuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycikgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5fc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1lbXB0eVxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbGVjdCBmaWVsZHMgdG8gaW5jbHVkZSBpbiB0aGUgcmV0dXJuaW5nIHJlc3VsdFxuICAgKi9cbiAgc2VsZWN0PFxuICAgIFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQsXG4gICAgRlAgZXh0ZW5kcyBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj4gPSBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj4sXG4gICAgRlBDIGV4dGVuZHMgRmllbGRQcm9qZWN0aW9uQ29uZmlnID0gRmllbGRQYXRoU2NvcGVkUHJvamVjdGlvbjxTLCBOLCBGUD4sXG4gICAgUjIgZXh0ZW5kcyBTT2JqZWN0UmVjb3JkPFMsIE4sIEZQQywgUj4gPSBTT2JqZWN0UmVjb3JkPFMsIE4sIEZQQywgUj5cbiAgPihmaWVsZHM6IFF1ZXJ5RmllbGQ8UywgTiwgRlA+ID0gJyonKTogUXVlcnk8UywgTiwgUjIsIFFSVD4ge1xuICAgIGlmICh0aGlzLl9zb3FsKSB7XG4gICAgICB0aHJvdyBFcnJvcihcbiAgICAgICAgJ0Nhbm5vdCBzZXQgc2VsZWN0IGZpZWxkcyBmb3IgdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHRvRmllbGRBcnJheShmaWVsZHM6IFF1ZXJ5RmllbGQ8UywgTiwgRlA+KTogc3RyaW5nW10ge1xuICAgICAgcmV0dXJuIHR5cGVvZiBmaWVsZHMgPT09ICdzdHJpbmcnXG4gICAgICAgID8gZmllbGRzLnNwbGl0KC9cXHMqLFxccyovKVxuICAgICAgICA6IEFycmF5LmlzQXJyYXkoZmllbGRzKVxuICAgICAgICA/IChmaWVsZHMgYXMgQXJyYXk8c3RyaW5nIHwgRlA+KVxuICAgICAgICAgICAgLm1hcCh0b0ZpZWxkQXJyYXkpXG4gICAgICAgICAgICAucmVkdWNlKChmcywgZikgPT4gWy4uLmZzLCAuLi5mXSwgW10gYXMgc3RyaW5nW10pXG4gICAgICAgIDogT2JqZWN0LmVudHJpZXMoZmllbGRzIGFzIHsgW25hbWU6IHN0cmluZ106IFF1ZXJ5RmllbGQ8UywgTiwgRlA+IH0pXG4gICAgICAgICAgICAubWFwKChbZiwgdl0pID0+IHtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHYgPyBbZl0gOiBbXTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdG9GaWVsZEFycmF5KHYpLm1hcCgocCkgPT4gYCR7Zn0uJHtwfWApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnJlZHVjZSgoZnMsIGYpID0+IFsuLi5mcywgLi4uZl0sIFtdIGFzIHN0cmluZ1tdKTtcbiAgICB9XG4gICAgaWYgKGZpZWxkcykge1xuICAgICAgdGhpcy5fY29uZmlnLmZpZWxkcyA9IHRvRmllbGRBcnJheShmaWVsZHMpO1xuICAgIH1cbiAgICAvLyBmb3JjZSBjb252ZXJ0IHF1ZXJ5IHJlY29yZCB0eXBlIHdpdGhvdXQgY2hhbmdpbmcgaW5zdGFuY2U7XG4gICAgcmV0dXJuICh0aGlzIGFzIGFueSkgYXMgUXVlcnk8UywgTiwgUjIsIFFSVD47XG4gIH1cblxuICAvKipcbiAgICogU2V0IHF1ZXJ5IGNvbmRpdGlvbnMgdG8gZmlsdGVyIHRoZSByZXN1bHQgcmVjb3Jkc1xuICAgKi9cbiAgd2hlcmUoY29uZGl0aW9uczogUXVlcnlDb25kaXRpb248UywgTj4gfCBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3Qgc2V0IHdoZXJlIGNvbmRpdGlvbnMgZm9yIHRoZSBxdWVyeSB3aGljaCBoYXMgYWxyZWFkeSBidWlsdCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICB0aGlzLl9jb25maWcuY29uZGl0aW9ucyA9IGNvbmRpdGlvbnM7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogTGltaXQgdGhlIHJldHVybmluZyByZXN1bHRcbiAgICovXG4gIGxpbWl0KGxpbWl0OiBudW1iZXIpIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3Qgc2V0IGxpbWl0IGZvciB0aGUgcXVlcnkgd2hpY2ggaGFzIGFscmVhZHkgYnVpbHQgU09RTC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy5fY29uZmlnLmxpbWl0ID0gbGltaXQ7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU2tpcCByZWNvcmRzXG4gICAqL1xuICBza2lwKG9mZnNldDogbnVtYmVyKSB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IHNldCBza2lwL29mZnNldCBmb3IgdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIHRoaXMuX2NvbmZpZy5vZmZzZXQgPSBvZmZzZXQ7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBRdWVyeSNza2lwKClcbiAgICovXG4gIG9mZnNldCA9IHRoaXMuc2tpcDtcblxuICAvKipcbiAgICogU2V0IHF1ZXJ5IHNvcnQgd2l0aCBkaXJlY3Rpb25cbiAgICovXG4gIHNvcnQoc29ydDogUXVlcnlTb3J0PFMsIE4+KTogdGhpcztcbiAgc29ydChzb3J0OiBzdHJpbmcpOiB0aGlzO1xuICBzb3J0KHNvcnQ6IFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+LCBkaXI6IFNvcnREaXIpOiB0aGlzO1xuICBzb3J0KHNvcnQ6IHN0cmluZywgZGlyOiBTb3J0RGlyKTogdGhpcztcbiAgc29ydChcbiAgICBzb3J0OiBRdWVyeVNvcnQ8UywgTj4gfCBTT2JqZWN0RmllbGROYW1lczxTLCBOPiB8IHN0cmluZyxcbiAgICBkaXI/OiBTb3J0RGlyLFxuICApIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3Qgc2V0IHNvcnQgZm9yIHRoZSBxdWVyeSB3aGljaCBoYXMgYWxyZWFkeSBidWlsdCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHNvcnQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBkaXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aGlzLl9jb25maWcuc29ydCA9IFtbc29ydCwgZGlyXV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2NvbmZpZy5zb3J0ID0gc29ydCBhcyBzdHJpbmcgfCB7IFtmaWVsZDogc3RyaW5nXTogU29ydERpciB9O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFF1ZXJ5I3NvcnQoKVxuICAgKi9cbiAgb3JkZXJieTogdHlwZW9mIFF1ZXJ5LnByb3RvdHlwZS5zb3J0ID0gdGhpcy5zb3J0O1xuXG4gIC8qKlxuICAgKiBJbmNsdWRlIGNoaWxkIHJlbGF0aW9uc2hpcCBxdWVyeSBhbmQgbW92ZSBkb3duIHRvIHRoZSBjaGlsZCBxdWVyeSBjb250ZXh0XG4gICAqL1xuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4sXG4gICAgQ0ZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBDTj4sXG4gICAgQ0ZQQyBleHRlbmRzIEZpZWxkUHJvamVjdGlvbkNvbmZpZyA9IEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb248UywgQ04sIENGUD4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOLCBDRlBDPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogQ1JOLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04sIENGUD4+LFxuICAgIG9wdGlvbnM/OiB7IGxpbWl0PzogbnVtYmVyOyBvZmZzZXQ/OiBudW1iZXI7IHNvcnQ/OiBRdWVyeVNvcnQ8UywgQ04+IH0sXG4gICk6IFN1YlF1ZXJ5PFMsIE4sIFIsIFFSVCwgQ1JOLCBDTiwgQ1I+O1xuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogc3RyaW5nLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04+PixcbiAgICBvcHRpb25zPzogeyBsaW1pdD86IG51bWJlcjsgb2Zmc2V0PzogbnVtYmVyOyBzb3J0PzogUXVlcnlTb3J0PFMsIENOPiB9LFxuICApOiBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPjtcblxuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4sXG4gICAgQ0ZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBDTj4sXG4gICAgQ0ZQQyBleHRlbmRzIEZpZWxkUHJvamVjdGlvbkNvbmZpZyA9IEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb248UywgQ04sIENGUD4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOLCBDRlBDPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogQ1JOIHwgc3RyaW5nLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04sIENGUD4+LFxuICAgIG9wdGlvbnM6IHsgbGltaXQ/OiBudW1iZXI7IG9mZnNldD86IG51bWJlcjsgc29ydD86IFF1ZXJ5U29ydDxTLCBDTj4gfSA9IHt9LFxuICApOiBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPiB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IGluY2x1ZGUgY2hpbGQgcmVsYXRpb25zaGlwIGludG8gdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkQ29uZmlnOiBRdWVyeUNvbmZpZzxTLCBDTiwgQ0ZQPiA9IHtcbiAgICAgIGZpZWxkczogZmllbGRzID09PSBudWxsID8gdW5kZWZpbmVkIDogZmllbGRzLFxuICAgICAgdGFibGU6IGNoaWxkUmVsTmFtZSxcbiAgICAgIGNvbmRpdGlvbnM6IGNvbmRpdGlvbnMgPT09IG51bGwgPyB1bmRlZmluZWQgOiBjb25kaXRpb25zLFxuICAgICAgbGltaXQ6IG9wdGlvbnMubGltaXQsXG4gICAgICBvZmZzZXQ6IG9wdGlvbnMub2Zmc2V0LFxuICAgICAgc29ydDogb3B0aW9ucy5zb3J0LFxuICAgIH07XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gICAgY29uc3QgY2hpbGRRdWVyeSA9IG5ldyBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPihcbiAgICAgIHRoaXMuX2Nvbm4sXG4gICAgICBjaGlsZFJlbE5hbWUgYXMgQ1JOLFxuICAgICAgY2hpbGRDb25maWcsXG4gICAgICB0aGlzLFxuICAgICk7XG4gICAgdGhpcy5fY2hpbGRyZW4ucHVzaChjaGlsZFF1ZXJ5KTtcbiAgICByZXR1cm4gY2hpbGRRdWVyeTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbmNsdWRlIGNoaWxkIHJlbGF0aW9uc2hpcCBxdWVyaWVzLCBidXQgbm90IG1vdmluZyBkb3duIHRvIHRoZSBjaGlsZHJlbiBjb250ZXh0XG4gICAqL1xuICBpbmNsdWRlQ2hpbGRyZW4oXG4gICAgaW5jbHVkZXM6IHtcbiAgICAgIFtDUk4gaW4gQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBOPl0/OiBRdWVyeUNvbmZpZzxcbiAgICAgICAgUyxcbiAgICAgICAgQ2hpbGRSZWxhdGlvbnNoaXBTT2JqZWN0TmFtZTxTLCBOLCBDUk4+XG4gICAgICA+O1xuICAgIH0sXG4gICkge1xuICAgIHR5cGUgQ1JOID0gQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBOPjtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3QgaW5jbHVkZSBjaGlsZCByZWxhdGlvbnNoaXAgaW50byB0aGUgcXVlcnkgd2hpY2ggaGFzIGFscmVhZHkgYnVpbHQgU09RTC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjcm5hbWUgb2YgT2JqZWN0LmtleXMoaW5jbHVkZXMpIGFzIENSTltdKSB7XG4gICAgICBjb25zdCB7IGNvbmRpdGlvbnMsIGZpZWxkcywgLi4ub3B0aW9ucyB9ID0gaW5jbHVkZXNbXG4gICAgICAgIGNybmFtZVxuICAgICAgXSBhcyBRdWVyeUNvbmZpZzxTLCBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4+O1xuICAgICAgdGhpcy5pbmNsdWRlKGNybmFtZSwgY29uZGl0aW9ucywgZmllbGRzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU2V0dGluZyBtYXhGZXRjaCBxdWVyeSBvcHRpb25cbiAgICovXG4gIG1heEZldGNoKG1heEZldGNoOiBudW1iZXIpIHtcbiAgICB0aGlzLl9vcHRpb25zLm1heEZldGNoID0gbWF4RmV0Y2g7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU3dpdGNoaW5nIGF1dG8gZmV0Y2ggbW9kZVxuICAgKi9cbiAgYXV0b0ZldGNoKGF1dG9GZXRjaDogYm9vbGVhbikge1xuICAgIHRoaXMuX29wdGlvbnMuYXV0b0ZldGNoID0gYXV0b0ZldGNoO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCBmbGFnIHRvIHNjYW4gYWxsIHJlY29yZHMgaW5jbHVkaW5nIGRlbGV0ZWQgYW5kIGFyY2hpdmVkLlxuICAgKi9cbiAgc2NhbkFsbChzY2FuQWxsOiBib29sZWFuKSB7XG4gICAgdGhpcy5fb3B0aW9ucy5zY2FuQWxsID0gc2NhbkFsbDtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgc2V0UmVzcG9uc2VUYXJnZXQ8UVJUMSBleHRlbmRzIFF1ZXJ5UmVzcG9uc2VUYXJnZXQ+KFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRUlQxLFxuICApOiBRdWVyeTxTLCBOLCBSLCBRUlQxPiB7XG4gICAgaWYgKHJlc3BvbnNlVGFyZ2V0IGluIFJlc3BvbnNlVGFyZ2V0cykge1xuICAgICAgdGhpcy5fb3B0aW9ucy5yZXNwb25zZVRhcmdldCA9IHJlc3BvbnNlVGFyZ2V0O1xuICAgIH1cbiAgICAvLyBmb3JjZSBjaGFuZ2UgcXVlcnkgcmVzcG9uc2UgdGFyZ2V0IHdpdGhvdXQgY2hhbmdpbmcgaW5zdGFuY2VcbiAgICByZXR1cm4gKHRoaXMgYXMgUXVlcnk8UywgTiwgUj4pIGFzIFF1ZXJ5PFMsIE4sIFIsIFFSVDE+O1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgcXVlcnkgYW5kIGZldGNoIHJlY29yZHMgZnJvbSBzZXJ2ZXIuXG4gICAqL1xuICBleGVjdXRlPFFSVDEgZXh0ZW5kcyBRdWVyeVJlc3BvbnNlVGFyZ2V0ID0gUVJUPihcbiAgICBvcHRpb25zXzogUGFydGlhbDxRdWVyeU9wdGlvbnM+ICYgeyByZXNwb25zZVRhcmdldD86IFFSVDEgfSA9IHt9LFxuICApOiBRdWVyeTxTLCBOLCBSLCBRUlQxPiB7XG4gICAgaWYgKHRoaXMuX2V4ZWN1dGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3JlLWV4ZWN1dGluZyBhbHJlYWR5IGV4ZWN1dGVkIHF1ZXJ5Jyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2ZpbmlzaGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2V4ZWN1dGluZyBhbHJlYWR5IGNsb3NlZCBxdWVyeScpO1xuICAgIH1cblxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICBoZWFkZXJzOiBvcHRpb25zXy5oZWFkZXJzIHx8IHRoaXMuX29wdGlvbnMuaGVhZGVycyxcbiAgICAgIHJlc3BvbnNlVGFyZ2V0OiBvcHRpb25zXy5yZXNwb25zZVRhcmdldCB8fCB0aGlzLl9vcHRpb25zLnJlc3BvbnNlVGFyZ2V0LFxuICAgICAgYXV0b0ZldGNoOiBvcHRpb25zXy5hdXRvRmV0Y2ggfHwgdGhpcy5fb3B0aW9ucy5hdXRvRmV0Y2gsXG4gICAgICBtYXhGZXRjaDogb3B0aW9uc18ubWF4RmV0Y2ggfHwgdGhpcy5fb3B0aW9ucy5tYXhGZXRjaCxcbiAgICAgIHNjYW5BbGw6IG9wdGlvbnNfLnNjYW5BbGwgfHwgdGhpcy5fb3B0aW9ucy5zY2FuQWxsLFxuICAgIH07XG5cbiAgICAvLyBjb2xsZWN0IGZldGNoZWQgcmVjb3JkcyBpbiBhcnJheVxuICAgIC8vIG9ubHkgd2hlbiByZXNwb25zZSB0YXJnZXQgaXMgUmVjb3JkcyBhbmRcbiAgICAvLyBlaXRoZXIgY2FsbGJhY2sgb3IgY2hhaW5pbmcgcHJvbWlzZXMgYXJlIGF2YWlsYWJsZSB0byB0aGlzIHF1ZXJ5LlxuICAgIHRoaXMub25jZSgnZmV0Y2gnLCAoKSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgIG9wdGlvbnMucmVzcG9uc2VUYXJnZXQgPT09IFJlc3BvbnNlVGFyZ2V0cy5SZWNvcmRzICYmXG4gICAgICAgIHRoaXMuX2NoYWluaW5nXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKCctLS0gY29sbGVjdGluZyBhbGwgZmV0Y2hlZCByZWNvcmRzIC0tLScpO1xuICAgICAgICBjb25zdCByZWNvcmRzOiBSZWNvcmRbXSA9IFtdO1xuICAgICAgICBjb25zdCBvblJlY29yZCA9IChyZWNvcmQ6IFJlY29yZCkgPT4gcmVjb3Jkcy5wdXNoKHJlY29yZCk7XG4gICAgICAgIHRoaXMub24oJ3JlY29yZCcsIG9uUmVjb3JkKTtcbiAgICAgICAgdGhpcy5vbmNlKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcigncmVjb3JkJywgb25SZWNvcmQpO1xuICAgICAgICAgIHRoaXMuZW1pdCgncmVzcG9uc2UnLCByZWNvcmRzLCB0aGlzKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBmbGFnIHRvIHByZXZlbnQgcmUtZXhlY3V0aW9uXG4gICAgdGhpcy5fZXhlY3V0ZWQgPSB0cnVlO1xuXG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIC8vIHN0YXJ0IGFjdHVhbCBxdWVyeVxuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKCc+Pj4gUXVlcnkgc3RhcnQgPj4+Jyk7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLl9leGVjdXRlKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJyoqKiBRdWVyeSBmaW5pc2hlZCAqKionKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZygnLS0tIFF1ZXJ5IGVycm9yIC0tLScsIGVycm9yKTtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuXG4gICAgLy8gcmV0dXJuIFF1ZXJ5IGluc3RhbmNlIGZvciBjaGFpbmluZ1xuICAgIHJldHVybiAodGhpcyBhcyBRdWVyeTxTLCBOLCBSPikgYXMgUXVlcnk8UywgTiwgUiwgUVJUMT47XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBRdWVyeSNleGVjdXRlKClcbiAgICovXG4gIGV4ZWMgPSB0aGlzLmV4ZWN1dGU7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUXVlcnkjZXhlY3V0ZSgpXG4gICAqL1xuICBydW4gPSB0aGlzLmV4ZWN1dGU7XG5cbiAgcHJpdmF0ZSBsb2NhdG9yVG9VcmwoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvY2F0b3JcbiAgICAgID8gW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJy9xdWVyeS8nLCB0aGlzLl9sb2NhdG9yXS5qb2luKCcnKVxuICAgICAgOiAnJztcbiAgfVxuXG4gIHByaXZhdGUgdXJsVG9Mb2NhdG9yKHVybDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHVybC5zcGxpdCgnLycpLnBvcCgpO1xuICB9XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3RSZXNwb25zZShcbiAgICByYXdEb25lOiBib29sZWFuLFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRdWVyeVJlc3BvbnNlVGFyZ2V0WzNdLFxuICApOiBudW1iZXI7XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldFsyXSxcbiAgKTogUjtcbiAgcHJpdmF0ZSBjb25zdHJ1Y3RSZXNwb25zZShcbiAgICByYXdEb25lOiBib29sZWFuLFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRdWVyeVJlc3BvbnNlVGFyZ2V0WzFdLFxuICApOiBSW107XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldFswXSxcbiAgKTogUXVlcnlSZXN1bHQ8Uj47XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldCxcbiAgKTogUXVlcnlSZXN1bHQ8Uj4gfCBSW10gfCBudW1iZXIgfCBSIHtcbiAgICBzd2l0Y2ggKHJlc3BvbnNlVGFyZ2V0KSB7XG4gICAgICBjYXNlICdDb3VudCc6XG4gICAgICAgIHJldHVybiB0aGlzLnRvdGFsU2l6ZTtcbiAgICAgIGNhc2UgJ1NpbmdsZVJlY29yZCc6XG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZHM/LlswXSA/PyBudWxsO1xuICAgICAgY2FzZSAnUmVjb3Jkcyc6XG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZHM7XG4gICAgICAvLyBRdWVyeVJlc3VsdCBpcyBkZWZhdWx0IHJlc3BvbnNlIHRhcmdldFxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi57XG4gICAgICAgICAgICByZWNvcmRzOiB0aGlzLnJlY29yZHMsXG4gICAgICAgICAgICB0b3RhbFNpemU6IHRoaXMudG90YWxTaXplLFxuICAgICAgICAgICAgZG9uZTogcmF3RG9uZSA/PyB0cnVlLCAvLyB3aGVuIG5vIHJlY29yZHMsIGRvbmUgaXMgb21pdHRlZFxuICAgICAgICAgIH0sXG4gICAgICAgICAgLi4uKHRoaXMuX2xvY2F0b3IgPyB7IG5leHRSZWNvcmRzVXJsOiB0aGlzLmxvY2F0b3JUb1VybCgpIH0gOiB7fSksXG4gICAgICAgIH07XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX2V4ZWN1dGUob3B0aW9uczogUXVlcnlPcHRpb25zKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFI+PiB7XG4gICAgY29uc3QgeyBoZWFkZXJzLCByZXNwb25zZVRhcmdldCwgYXV0b0ZldGNoLCBtYXhGZXRjaCwgc2NhbkFsbCB9ID0gb3B0aW9ucztcbiAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ2V4ZWN1dGUgd2l0aCBvcHRpb25zJywgb3B0aW9ucyk7XG4gICAgbGV0IHVybDtcbiAgICBpZiAodGhpcy5fbG9jYXRvcikge1xuICAgICAgdXJsID0gdGhpcy5sb2NhdG9yVG9VcmwoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc29xbCA9IGF3YWl0IHRoaXMudG9TT1FMKCk7XG4gICAgICB0aGlzLl9sb2dnZXIuZGVidWcoYFNPUUwgPSAke3NvcWx9YCk7XG4gICAgICB1cmwgPSBbXG4gICAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICAgJy8nLFxuICAgICAgICBzY2FuQWxsID8gJ3F1ZXJ5QWxsJyA6ICdxdWVyeScsXG4gICAgICAgICc/cT0nLFxuICAgICAgICBlbmNvZGVVUklDb21wb25lbnQoc29xbCksXG4gICAgICBdLmpvaW4oJycpO1xuICAgIH1cbiAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHsgbWV0aG9kOiAnR0VUJywgdXJsLCBoZWFkZXJzIH0pO1xuICAgIHRoaXMuZW1pdCgnZmV0Y2gnKTtcbiAgICB0aGlzLnRvdGFsU2l6ZSA9IGRhdGEudG90YWxTaXplO1xuICAgIHRoaXMucmVjb3JkcyA9IHRoaXMucmVjb3Jkcz8uY29uY2F0KFxuICAgICAgbWF4RmV0Y2ggLSB0aGlzLnJlY29yZHMubGVuZ3RoID4gZGF0YS5yZWNvcmRzLmxlbmd0aFxuICAgICAgICA/IGRhdGEucmVjb3Jkc1xuICAgICAgICA6IGRhdGEucmVjb3Jkcy5zbGljZSgwLCBtYXhGZXRjaCAtIHRoaXMucmVjb3Jkcy5sZW5ndGgpLFxuICAgICk7XG4gICAgdGhpcy5fbG9jYXRvciA9IGRhdGEubmV4dFJlY29yZHNVcmxcbiAgICAgID8gdGhpcy51cmxUb0xvY2F0b3IoZGF0YS5uZXh0UmVjb3Jkc1VybClcbiAgICAgIDogdW5kZWZpbmVkO1xuICAgIHRoaXMuX2ZpbmlzaGVkID1cbiAgICAgIHRoaXMuX2ZpbmlzaGVkIHx8XG4gICAgICBkYXRhLmRvbmUgfHxcbiAgICAgICFhdXRvRmV0Y2ggfHxcbiAgICAgIC8vIHRoaXMgaXMgd2hhdCB0aGUgcmVzcG9uc2UgbG9va3MgbGlrZSB3aGVuIHRoZXJlIGFyZSBubyByZXN1bHRzXG4gICAgICAoZGF0YS5yZWNvcmRzLmxlbmd0aCA9PT0gMCAmJiBkYXRhLmRvbmUgPT09IHVuZGVmaW5lZCk7XG5cbiAgICAvLyBzdHJlYW1pbmcgcmVjb3JkIGluc3RhbmNlc1xuICAgIGNvbnN0IG51bVJlY29yZHMgPSBkYXRhLnJlY29yZHM/Lmxlbmd0aCA/PyAwO1xuICAgIGxldCB0b3RhbEZldGNoZWQgPSB0aGlzLnRvdGFsRmV0Y2hlZDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bVJlY29yZHM7IGkrKykge1xuICAgICAgaWYgKHRvdGFsRmV0Y2hlZCA+PSBtYXhGZXRjaCkge1xuICAgICAgICB0aGlzLl9maW5pc2hlZCA9IHRydWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVjb3JkID0gZGF0YS5yZWNvcmRzW2ldO1xuICAgICAgdGhpcy5lbWl0KCdyZWNvcmQnLCByZWNvcmQsIHRvdGFsRmV0Y2hlZCwgdGhpcyk7XG4gICAgICB0b3RhbEZldGNoZWQgKz0gMTtcbiAgICB9XG4gICAgdGhpcy50b3RhbEZldGNoZWQgPSB0b3RhbEZldGNoZWQ7XG5cbiAgICBpZiAodGhpcy5fZmluaXNoZWQpIHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5jb25zdHJ1Y3RSZXNwb25zZShkYXRhLmRvbmUsIHJlc3BvbnNlVGFyZ2V0KTtcbiAgICAgIC8vIG9ubHkgZmlyZSByZXNwb25zZSBldmVudCB3aGVuIGl0IHNob3VsZCBiZSBub3RpZmllZCBwZXIgZmV0Y2hcbiAgICAgIGlmIChyZXNwb25zZVRhcmdldCAhPT0gUmVzcG9uc2VUYXJnZXRzLlJlY29yZHMpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuZW1pdCgnZW5kJyk7XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLl9leGVjdXRlKG9wdGlvbnMpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBPYnRhaW4gcmVhZGFibGUgc3RyZWFtIGluc3RhbmNlXG4gICAqL1xuICBzdHJlYW0odHlwZTogJ3JlY29yZCcpOiBTZXJpYWxpemFibGU8Uj47XG4gIHN0cmVhbSh0eXBlOiAnY3N2Jyk6IFJlYWRhYmxlO1xuICBzdHJlYW0odHlwZTogJ3JlY29yZCcgfCAnY3N2JyA9ICdjc3YnKSB7XG4gICAgaWYgKCF0aGlzLl9maW5pc2hlZCAmJiAhdGhpcy5fZXhlY3V0ZWQpIHtcbiAgICAgIHRoaXMuZXhlY3V0ZSh7IGF1dG9GZXRjaDogdHJ1ZSB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHR5cGUgPT09ICdyZWNvcmQnID8gdGhpcy5fc3RyZWFtIDogdGhpcy5fc3RyZWFtLnN0cmVhbSh0eXBlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQaXBlIHRoZSBxdWVyaWVkIHJlY29yZHMgdG8gYW5vdGhlciBzdHJlYW1cbiAgICogVGhpcyBpcyBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eTsgUXVlcnkgaXMgbm90IGEgcmVjb3JkIHN0cmVhbSBpbnN0YW5jZSBhbnltb3JlIGluIDIuMC5cbiAgICogSWYgeW91IHdhbnQgYSByZWNvcmQgc3RyZWFtIGluc3RhbmNlLCB1c2UgYFF1ZXJ5I3N0cmVhbSgncmVjb3JkJylgLlxuICAgKi9cbiAgcGlwZShzdHJlYW06IE5vZGVKUy5Xcml0YWJsZVN0cmVhbSkge1xuICAgIHJldHVybiB0aGlzLnN0cmVhbSgncmVjb3JkJykucGlwZShzdHJlYW0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGFzeW5jIF9leHBhbmRGaWVsZHMoc29iamVjdF8/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnQ2Fubm90IGV4cGFuZCBmaWVsZHMgZm9yIHRoZSBxdWVyeSB3aGljaCBoYXMgYWxyZWFkeSBidWlsdCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCB7IGZpZWxkcyA9IFtdLCB0YWJsZSA9ICcnIH0gPSB0aGlzLl9jb25maWc7XG4gICAgY29uc3Qgc29iamVjdCA9IHNvYmplY3RfIHx8IHRhYmxlO1xuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGBfZXhwYW5kRmllbGRzOiBzb2JqZWN0ID0gJHtzb2JqZWN0fSwgZmllbGRzID0gJHtmaWVsZHMuam9pbignLCAnKX1gLFxuICAgICk7XG4gICAgY29uc3QgW2VmaWVsZHNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgdGhpcy5fZXhwYW5kQXN0ZXJpc2tGaWVsZHMoc29iamVjdCwgZmllbGRzKSxcbiAgICAgIC4uLnRoaXMuX2NoaWxkcmVuLm1hcChhc3luYyAoY2hpbGRRdWVyeSkgPT4ge1xuICAgICAgICBhd2FpdCBjaGlsZFF1ZXJ5Ll9leHBhbmRGaWVsZHMoKTtcbiAgICAgICAgcmV0dXJuIFtdIGFzIHN0cmluZ1tdO1xuICAgICAgfSksXG4gICAgXSk7XG4gICAgdGhpcy5fY29uZmlnLmZpZWxkcyA9IGVmaWVsZHM7XG4gICAgdGhpcy5fY29uZmlnLmluY2x1ZGVzID0gdGhpcy5fY2hpbGRyZW5cbiAgICAgIC5tYXAoKGNxdWVyeSkgPT4ge1xuICAgICAgICBjb25zdCBjY29uZmlnID0gY3F1ZXJ5Ll9xdWVyeS5fY29uZmlnO1xuICAgICAgICByZXR1cm4gW2Njb25maWcudGFibGUsIGNjb25maWddIGFzIFtzdHJpbmcsIFNPUUxRdWVyeUNvbmZpZ107XG4gICAgICB9KVxuICAgICAgLnJlZHVjZShcbiAgICAgICAgKGluY2x1ZGVzLCBbY3RhYmxlLCBjY29uZmlnXSkgPT4gKHtcbiAgICAgICAgICAuLi5pbmNsdWRlcyxcbiAgICAgICAgICBbY3RhYmxlXTogY2NvbmZpZyxcbiAgICAgICAgfSksXG4gICAgICAgIHt9IGFzIHsgW25hbWU6IHN0cmluZ106IFNPUUxRdWVyeUNvbmZpZyB9LFxuICAgICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2ZpbmRSZWxhdGlvbk9iamVjdChyZWxOYW1lOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHRhYmxlID0gdGhpcy5fY29uZmlnLnRhYmxlO1xuICAgIGlmICghdGFibGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdGFibGUgaW5mb3JtYXRpb24gcHJvdmlkZWQgaW4gdGhlIHF1ZXJ5Jyk7XG4gICAgfVxuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGBmaW5kaW5nIHRhYmxlIGZvciByZWxhdGlvbiBcIiR7cmVsTmFtZX1cIiBpbiBcIiR7dGFibGV9XCIuLi5gLFxuICAgICk7XG4gICAgY29uc3Qgc29iamVjdCA9IGF3YWl0IHRoaXMuX2Nvbm4uZGVzY3JpYmUkKHRhYmxlKTtcbiAgICBjb25zdCB1cHBlclJuYW1lID0gcmVsTmFtZS50b1VwcGVyQ2FzZSgpO1xuICAgIGZvciAoY29uc3QgY3Igb2Ygc29iamVjdC5jaGlsZFJlbGF0aW9uc2hpcHMpIHtcbiAgICAgIGlmIChcbiAgICAgICAgKGNyLnJlbGF0aW9uc2hpcE5hbWUgfHwgJycpLnRvVXBwZXJDYXNlKCkgPT09IHVwcGVyUm5hbWUgJiZcbiAgICAgICAgY3IuY2hpbGRTT2JqZWN0XG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGNyLmNoaWxkU09iamVjdDtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBObyBjaGlsZCByZWxhdGlvbnNoaXAgZm91bmQ6ICR7cmVsTmFtZX1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEFzdGVyaXNrRmllbGRzKFxuICAgIHNvYmplY3Q6IHN0cmluZyxcbiAgICBmaWVsZHM6IHN0cmluZ1tdLFxuICApOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgY29uc3QgZXhwYW5kZWRGaWVsZHMgPSBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIGZpZWxkcy5tYXAoYXN5bmMgKGZpZWxkKSA9PiB0aGlzLl9leHBhbmRBc3Rlcmlza0ZpZWxkKHNvYmplY3QsIGZpZWxkKSksXG4gICAgKTtcbiAgICByZXR1cm4gZXhwYW5kZWRGaWVsZHMucmVkdWNlKFxuICAgICAgKGVmbGRzOiBzdHJpbmdbXSwgZmxkczogc3RyaW5nW10pOiBzdHJpbmdbXSA9PiBbLi4uZWZsZHMsIC4uLmZsZHNdLFxuICAgICAgW10sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEFzdGVyaXNrRmllbGQoXG4gICAgc29iamVjdDogc3RyaW5nLFxuICAgIGZpZWxkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8c3RyaW5nW10+IHtcbiAgICB0aGlzLl9sb2dnZXIuZGVidWcoYGV4cGFuZGluZyBmaWVsZCBcIiR7ZmllbGR9XCIgaW4gXCIke3NvYmplY3R9XCIuLi5gKTtcbiAgICBjb25zdCBmcGF0aCA9IGZpZWxkLnNwbGl0KCcuJyk7XG4gICAgaWYgKGZwYXRoW2ZwYXRoLmxlbmd0aCAtIDFdID09PSAnKicpIHtcbiAgICAgIGNvbnN0IHNvID0gYXdhaXQgdGhpcy5fY29ubi5kZXNjcmliZSQoc29iamVjdCk7XG4gICAgICB0aGlzLl9sb2dnZXIuZGVidWcoYHRhYmxlICR7c29iamVjdH0gaGFzIGJlZW4gZGVzY3JpYmVkYCk7XG4gICAgICBpZiAoZnBhdGgubGVuZ3RoID4gMSkge1xuICAgICAgICBjb25zdCBybmFtZSA9IGZwYXRoLnNoaWZ0KCk7XG4gICAgICAgIGZvciAoY29uc3QgZiBvZiBzby5maWVsZHMpIHtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBmLnJlbGF0aW9uc2hpcE5hbWUgJiZcbiAgICAgICAgICAgIHJuYW1lICYmXG4gICAgICAgICAgICBmLnJlbGF0aW9uc2hpcE5hbWUudG9VcHBlckNhc2UoKSA9PT0gcm5hbWUudG9VcHBlckNhc2UoKVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgcmZpZWxkID0gZjtcbiAgICAgICAgICAgIGNvbnN0IHJlZmVyZW5jZVRvID0gcmZpZWxkLnJlZmVyZW5jZVRvIHx8IFtdO1xuICAgICAgICAgICAgY29uc3QgcnRhYmxlID0gcmVmZXJlbmNlVG8ubGVuZ3RoID09PSAxID8gcmVmZXJlbmNlVG9bMF0gOiAnTmFtZSc7XG4gICAgICAgICAgICBjb25zdCBmcGF0aHMgPSBhd2FpdCB0aGlzLl9leHBhbmRBc3Rlcmlza0ZpZWxkKFxuICAgICAgICAgICAgICBydGFibGUsXG4gICAgICAgICAgICAgIGZwYXRoLmpvaW4oJy4nKSxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4gZnBhdGhzLm1hcCgoZnApID0+IGAke3JuYW1lfS4ke2ZwfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgICB9XG4gICAgICByZXR1cm4gc28uZmllbGRzLm1hcCgoZikgPT4gZi5uYW1lKTtcbiAgICB9XG4gICAgcmV0dXJuIFtmaWVsZF07XG4gIH1cblxuICAvKipcbiAgICogRXhwbGFpbiBwbGFuIGZvciBleGVjdXRpbmcgcXVlcnlcbiAgICovXG4gIGFzeW5jIGV4cGxhaW4oKSB7XG4gICAgY29uc3Qgc29xbCA9IGF3YWl0IHRoaXMudG9TT1FMKCk7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBTT1FMID0gJHtzb3FsfWApO1xuICAgIGNvbnN0IHVybCA9IGAvcXVlcnkvP2V4cGxhaW49JHtlbmNvZGVVUklDb21wb25lbnQoc29xbCl9YDtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFF1ZXJ5RXhwbGFpblJlc3VsdD4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gU09RTCBleHByZXNzaW9uIGZvciB0aGUgcXVlcnlcbiAgICovXG4gIGFzeW5jIHRvU09RTCgpIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3NvcWw7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuX2V4cGFuZEZpZWxkcygpO1xuICAgIHJldHVybiBjcmVhdGVTT1FMKHRoaXMuX2NvbmZpZyk7XG4gIH1cblxuICAvKipcbiAgICogUHJvbWlzZS9BKyBpbnRlcmZhY2VcbiAgICogaHR0cDovL3Byb21pc2VzLWFwbHVzLmdpdGh1Yi5pby9wcm9taXNlcy1zcGVjL1xuICAgKlxuICAgKiBEZWxlZ2F0ZSB0byBkZWZlcnJlZCBwcm9taXNlLCByZXR1cm4gcHJvbWlzZSBpbnN0YW5jZSBmb3IgcXVlcnkgcmVzdWx0XG4gICAqL1xuICB0aGVuPFUsIFY+KFxuICAgIG9uUmVzb2x2ZT86XG4gICAgICB8ICgocXI6IFF1ZXJ5UmVzcG9uc2U8UiwgUVJUPikgPT4gVSB8IFByb21pc2U8VT4pXG4gICAgICB8IG51bGxcbiAgICAgIHwgdW5kZWZpbmVkLFxuICAgIG9uUmVqZWN0PzogKChlcnI6IEVycm9yKSA9PiBWIHwgUHJvbWlzZTxWPikgfCBudWxsIHwgdW5kZWZpbmVkLFxuICApOiBQcm9taXNlPFUgfCBWPiB7XG4gICAgdGhpcy5fY2hhaW5pbmcgPSB0cnVlO1xuICAgIGlmICghdGhpcy5fZmluaXNoZWQgJiYgIXRoaXMuX2V4ZWN1dGVkKSB7XG4gICAgICB0aGlzLmV4ZWN1dGUoKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9wcm9taXNlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdpbnZhbGlkIHN0YXRlOiBwcm9taXNlIGlzIG5vdCBzZXQgYWZ0ZXIgcXVlcnkgZXhlY3V0aW9uJyxcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9wcm9taXNlLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gIH1cblxuICBjYXRjaChcbiAgICBvblJlamVjdDogKFxuICAgICAgZXJyOiBFcnJvcixcbiAgICApID0+IFF1ZXJ5UmVzcG9uc2U8UiwgUVJUPiB8IFByb21pc2U8UXVlcnlSZXNwb25zZTxSLCBRUlQ+PixcbiAgKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFIsIFFSVD4+IHtcbiAgICByZXR1cm4gdGhpcy50aGVuKG51bGwsIG9uUmVqZWN0KTtcbiAgfVxuXG4gIHByb21pc2UoKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFIsIFFSVD4+IHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1bGsgZGVsZXRlIHF1ZXJpZWQgcmVjb3Jkc1xuICAgKi9cbiAgZGVzdHJveShvcHRpb25zPzogUXVlcnlEZXN0cm95T3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVzdHJveSh0eXBlOiBOLCBvcHRpb25zPzogUXVlcnlEZXN0cm95T3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVzdHJveSh0eXBlPzogTiB8IFF1ZXJ5RGVzdHJveU9wdGlvbnMsIG9wdGlvbnM/OiBRdWVyeURlc3Ryb3lPcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiB0eXBlID09PSAnb2JqZWN0JyAmJiB0eXBlICE9PSBudWxsKSB7XG4gICAgICBvcHRpb25zID0gdHlwZTtcbiAgICAgIHR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICAgIGNvbnN0IHR5cGVfOiBPcHRpb25hbDxOPiA9IHR5cGUgfHwgKHRoaXMuX2NvbmZpZy50YWJsZSBhcyBPcHRpb25hbDxOPik7XG4gICAgaWYgKCF0eXBlXykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnU09RTCBiYXNlZCBxdWVyeSBuZWVkcyBTT2JqZWN0IHR5cGUgaW5mb3JtYXRpb24gdG8gYnVsayBkZWxldGUuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIC8vIFNldCB0aGUgdGhyZXNob2xkIG51bWJlciB0byBwYXNzIHRvIGJ1bGsgQVBJXG4gICAgY29uc3QgdGhyZXNob2xkTnVtID1cbiAgICAgIG9wdGlvbnMuYWxsb3dCdWxrID09PSBmYWxzZVxuICAgICAgICA/IC0xXG4gICAgICAgIDogdHlwZW9mIG9wdGlvbnMuYnVsa1RocmVzaG9sZCA9PT0gJ251bWJlcidcbiAgICAgICAgPyBvcHRpb25zLmJ1bGtUaHJlc2hvbGRcbiAgICAgICAgOiAvLyBkZXRlcm1pbmUgdGhyZXNob2xkIGlmIHRoZSBjb25uZWN0aW9uIHZlcnNpb24gc3VwcG9ydHMgU09iamVjdCBjb2xsZWN0aW9uIEFQSSBvciBub3RcbiAgICAgICAgdGhpcy5fY29ubi5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyBERUZBVUxUX0JVTEtfVEhSRVNIT0xEXG4gICAgICAgIDogdGhpcy5fY29ubi5fbWF4UmVxdWVzdCAvIDI7XG5cbiAgICBjb25zdCBidWxrQXBpVmVyc2lvbiA9IG9wdGlvbnMuYnVsa0FwaVZlcnNpb24gPz8gREVGQVVMVF9CVUxLX0FQSV9WRVJTSU9OO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IGNyZWF0ZUJhdGNoID0gKCkgPT5cbiAgICAgICAgdGhpcy5fY29ublxuICAgICAgICAgIC5zb2JqZWN0KHR5cGVfKVxuICAgICAgICAgIC5kZWxldGVCdWxrKClcbiAgICAgICAgICAub24oJ3Jlc3BvbnNlJywgcmVzb2x2ZSlcbiAgICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICAgIGxldCByZWNvcmRzOiBSZWNvcmRbXSA9IFtdO1xuICAgICAgbGV0IGJhdGNoOiBSZXR1cm5UeXBlPHR5cGVvZiBjcmVhdGVCYXRjaD4gfCBudWxsID0gbnVsbDtcbiAgICAgIGNvbnN0IGhhbmRsZVJlY29yZCA9IChyZWM6IFJlY29yZCkgPT4ge1xuICAgICAgICBpZiAoIXJlYy5JZCkge1xuICAgICAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihcbiAgICAgICAgICAgICdRdWVyaWVkIHJlY29yZCBkb2VzIG5vdCBpbmNsdWRlIFNhbGVzZm9yY2UgcmVjb3JkIElELicsXG4gICAgICAgICAgKTtcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVjb3JkOiBSZWNvcmQgPSB7IElkOiByZWMuSWQgfTtcbiAgICAgICAgaWYgKGJhdGNoKSB7XG4gICAgICAgICAgYmF0Y2gud3JpdGUocmVjb3JkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWNvcmRzLnB1c2gocmVjb3JkKTtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICB0aHJlc2hvbGROdW0gPj0gMCAmJlxuICAgICAgICAgICAgcmVjb3Jkcy5sZW5ndGggPiB0aHJlc2hvbGROdW0gJiZcbiAgICAgICAgICAgIGJ1bGtBcGlWZXJzaW9uID09PSAxXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICAvLyBVc2UgYnVsayBkZWxldGUgaW5zdGVhZCBvZiBTT2JqZWN0IFJFU1QgQVBJXG4gICAgICAgICAgICBiYXRjaCA9IGNyZWF0ZUJhdGNoKCk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiByZWNvcmRzKSB7XG4gICAgICAgICAgICAgIGJhdGNoLndyaXRlKHJlY29yZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWNvcmRzID0gW107XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgY29uc3QgaGFuZGxlRW5kID0gKCkgPT4ge1xuICAgICAgICBpZiAoYmF0Y2gpIHtcbiAgICAgICAgICBiYXRjaC5lbmQoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBpZHMgPSByZWNvcmRzLm1hcCgocmVjb3JkKSA9PiByZWNvcmQuSWQgYXMgc3RyaW5nKTtcbiAgICAgICAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiB0aHJlc2hvbGROdW0gJiYgYnVsa0FwaVZlcnNpb24gPT09IDIpIHtcbiAgICAgICAgICAgIHRoaXMuX2Nvbm4uYnVsazJcbiAgICAgICAgICAgICAgLmxvYWRBbmRXYWl0Rm9yUmVzdWx0cyh7XG4gICAgICAgICAgICAgICAgb2JqZWN0OiB0eXBlXyxcbiAgICAgICAgICAgICAgICBvcGVyYXRpb246ICdkZWxldGUnLFxuICAgICAgICAgICAgICAgIGlucHV0OiByZWNvcmRzLFxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihcbiAgICAgICAgICAgICAgICAoYWxsUmVzdWx0cykgPT5cbiAgICAgICAgICAgICAgICAgIHJlc29sdmUodGhpcy5tYXBCdWxrVjJSZXN1bHRzVG9TYXZlUmVzdWx0cyhhbGxSZXN1bHRzKSksXG4gICAgICAgICAgICAgICAgcmVqZWN0LFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9jb25uXG4gICAgICAgICAgICAgIC5zb2JqZWN0KHR5cGVfKVxuICAgICAgICAgICAgICAuZGVzdHJveShpZHMsIHsgYWxsb3dSZWN1cnNpdmU6IHRydWUgfSlcbiAgICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICB0aGlzLnN0cmVhbSgncmVjb3JkJylcbiAgICAgICAgLm9uKCdkYXRhJywgaGFuZGxlUmVjb3JkKVxuICAgICAgICAub24oJ2VuZCcsIGhhbmRsZUVuZClcbiAgICAgICAgLm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBRdWVyeSNkZXN0cm95KClcbiAgICovXG4gIGRlbGV0ZSA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBRdWVyeSNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogQnVsayB1cGRhdGUgcXVlcmllZCByZWNvcmRzLCB1c2luZyBnaXZlbiBtYXBwaW5nIGZ1bmN0aW9uL29iamVjdFxuICAgKi9cbiAgdXBkYXRlPFVSIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+PihcbiAgICBtYXBwaW5nOiAoKHJlYzogUikgPT4gVVIpIHwgVVIsXG4gICAgdHlwZTogTixcbiAgICBvcHRpb25zPzogUXVlcnlVcGRhdGVPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZTxVUiBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPj4oXG4gICAgbWFwcGluZzogKChyZWM6IFIpID0+IFVSKSB8IFVSLFxuICAgIG9wdGlvbnM/OiBRdWVyeVVwZGF0ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlPFVSIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+PihcbiAgICBtYXBwaW5nOiAoKHJlYzogUikgPT4gVVIpIHwgVVIsXG4gICAgdHlwZT86IE4gfCBRdWVyeVVwZGF0ZU9wdGlvbnMsXG4gICAgb3B0aW9ucz86IFF1ZXJ5VXBkYXRlT3B0aW9ucyxcbiAgKSB7XG4gICAgaWYgKHR5cGVvZiB0eXBlID09PSAnb2JqZWN0JyAmJiB0eXBlICE9PSBudWxsKSB7XG4gICAgICBvcHRpb25zID0gdHlwZTtcbiAgICAgIHR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICAgIGNvbnN0IHR5cGVfOiBPcHRpb25hbDxOPiA9XG4gICAgICB0eXBlIHx8ICh0aGlzLl9jb25maWcgJiYgKHRoaXMuX2NvbmZpZy50YWJsZSBhcyBPcHRpb25hbDxOPikpO1xuICAgIGlmICghdHlwZV8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ1NPUUwgYmFzZWQgcXVlcnkgbmVlZHMgU09iamVjdCB0eXBlIGluZm9ybWF0aW9uIHRvIGJ1bGsgdXBkYXRlLicsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCB1cGRhdGVTdHJlYW0gPVxuICAgICAgdHlwZW9mIG1hcHBpbmcgPT09ICdmdW5jdGlvbidcbiAgICAgICAgPyBSZWNvcmRTdHJlYW0ubWFwKG1hcHBpbmcpXG4gICAgICAgIDogUmVjb3JkU3RyZWFtLnJlY29yZE1hcFN0cmVhbShtYXBwaW5nKTtcbiAgICAvLyBTZXQgdGhlIHRocmVzaG9sZCBudW1iZXIgdG8gcGFzcyB0byBidWxrIEFQSVxuICAgIGNvbnN0IHRocmVzaG9sZE51bSA9XG4gICAgICBvcHRpb25zLmFsbG93QnVsayA9PT0gZmFsc2VcbiAgICAgICAgPyAtMVxuICAgICAgICA6IHR5cGVvZiBvcHRpb25zLmJ1bGtUaHJlc2hvbGQgPT09ICdudW1iZXInXG4gICAgICAgID8gb3B0aW9ucy5idWxrVGhyZXNob2xkXG4gICAgICAgIDogLy8gZGV0ZXJtaW5lIHRocmVzaG9sZCBpZiB0aGUgY29ubmVjdGlvbiB2ZXJzaW9uIHN1cHBvcnRzIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgb3Igbm90XG4gICAgICAgIHRoaXMuX2Nvbm4uX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gREVGQVVMVF9CVUxLX1RIUkVTSE9MRFxuICAgICAgICA6IHRoaXMuX2Nvbm4uX21heFJlcXVlc3QgLyAyO1xuICAgIGNvbnN0IGJ1bGtBcGlWZXJzaW9uID0gb3B0aW9ucy5idWxrQXBpVmVyc2lvbiA/PyBERUZBVUxUX0JVTEtfQVBJX1ZFUlNJT047XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IGNyZWF0ZUJhdGNoID0gKCkgPT5cbiAgICAgICAgdGhpcy5fY29ublxuICAgICAgICAgIC5zb2JqZWN0KHR5cGVfKVxuICAgICAgICAgIC51cGRhdGVCdWxrKClcbiAgICAgICAgICAub24oJ3Jlc3BvbnNlJywgcmVzb2x2ZSlcbiAgICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICAgIGxldCByZWNvcmRzOiBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+W10gPSBbXTtcbiAgICAgIGxldCBiYXRjaDogUmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlQmF0Y2g+IHwgbnVsbCA9IG51bGw7XG4gICAgICBjb25zdCBoYW5kbGVSZWNvcmQgPSAocmVjb3JkOiBSZWNvcmQpID0+IHtcbiAgICAgICAgaWYgKGJhdGNoKSB7XG4gICAgICAgICAgYmF0Y2gud3JpdGUocmVjb3JkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWNvcmRzLnB1c2gocmVjb3JkIGFzIFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj4pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChcbiAgICAgICAgICB0aHJlc2hvbGROdW0gPj0gMCAmJlxuICAgICAgICAgIHJlY29yZHMubGVuZ3RoID4gdGhyZXNob2xkTnVtICYmXG4gICAgICAgICAgYnVsa0FwaVZlcnNpb24gPT09IDFcbiAgICAgICAgKSB7XG4gICAgICAgICAgLy8gVXNlIGJ1bGsgdXBkYXRlIGluc3RlYWQgb2YgU09iamVjdCBSRVNUIEFQSVxuICAgICAgICAgIGJhdGNoID0gY3JlYXRlQmF0Y2goKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiByZWNvcmRzKSB7XG4gICAgICAgICAgICBiYXRjaC53cml0ZShyZWNvcmQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZWNvcmRzID0gW107XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCBoYW5kbGVFbmQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChiYXRjaCkge1xuICAgICAgICAgIGJhdGNoLmVuZCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChyZWNvcmRzLmxlbmd0aCA+IHRocmVzaG9sZE51bSAmJiBidWxrQXBpVmVyc2lvbiA9PT0gMikge1xuICAgICAgICAgICAgdGhpcy5fY29ubi5idWxrMlxuICAgICAgICAgICAgICAubG9hZEFuZFdhaXRGb3JSZXN1bHRzKHtcbiAgICAgICAgICAgICAgICBvYmplY3Q6IHR5cGVfLFxuICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogJ3VwZGF0ZScsXG4gICAgICAgICAgICAgICAgaW5wdXQ6IHJlY29yZHMsXG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKFxuICAgICAgICAgICAgICAgIChhbGxSZXN1bHRzKSA9PlxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSh0aGlzLm1hcEJ1bGtWMlJlc3VsdHNUb1NhdmVSZXN1bHRzKGFsbFJlc3VsdHMpKSxcbiAgICAgICAgICAgICAgICByZWplY3QsXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2Nvbm5cbiAgICAgICAgICAgICAgLnNvYmplY3QodHlwZV8pXG4gICAgICAgICAgICAgIC51cGRhdGUocmVjb3JkcywgeyBhbGxvd1JlY3Vyc2l2ZTogdHJ1ZSB9KVxuICAgICAgICAgICAgICAudGhlbihyZXNvbHZlLCByZWplY3QpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHRoaXMuc3RyZWFtKCdyZWNvcmQnKVxuICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KVxuICAgICAgICAucGlwZSh1cGRhdGVTdHJlYW0pXG4gICAgICAgIC5vbignZGF0YScsIGhhbmRsZVJlY29yZClcbiAgICAgICAgLm9uKCdlbmQnLCBoYW5kbGVFbmQpXG4gICAgICAgIC5vbignZXJyb3InLCByZWplY3QpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBtYXBCdWxrVjJSZXN1bHRzVG9TYXZlUmVzdWx0cyhcbiAgICBidWxrSm9iQWxsUmVzdWx0czogSW5nZXN0Sm9iVjJSZXN1bHRzPFM+LFxuICApOiBTYXZlUmVzdWx0W10ge1xuICAgIGNvbnN0IHN1Y2Nlc3NTYXZlUmVzdWx0czogU2F2ZVJlc3VsdFtdID0gYnVsa0pvYkFsbFJlc3VsdHMuc3VjY2Vzc2Z1bFJlc3VsdHMubWFwKFxuICAgICAgKHIpID0+IHtcbiAgICAgICAgY29uc3Qgc2F2ZVJlc3VsdDogU2F2ZVJlc3VsdCA9IHtcbiAgICAgICAgICBpZDogci5zZl9fSWQsXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBlcnJvcnM6IFtdLFxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gc2F2ZVJlc3VsdDtcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIGNvbnN0IGZhaWxlZFNhdmVSZXN1bHRzID0gYnVsa0pvYkFsbFJlc3VsdHMuZmFpbGVkUmVzdWx0cy5tYXAoKHIpID0+IHtcbiAgICAgIGNvbnN0IHNhdmVSZXN1bHQ6IFNhdmVSZXN1bHQgPSB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBlcnJvckNvZGU6IHIuc2ZfX0Vycm9yLFxuICAgICAgICAgICAgbWVzc2FnZTogci5zZl9fRXJyb3IsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH07XG4gICAgICByZXR1cm4gc2F2ZVJlc3VsdDtcbiAgICB9KTtcblxuICAgIHJldHVybiBbLi4uc3VjY2Vzc1NhdmVSZXN1bHRzLCAuLi5mYWlsZWRTYXZlUmVzdWx0c107XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogU3ViUXVlcnkgb2JqZWN0IGZvciByZXByZXNlbnRpbmcgY2hpbGQgcmVsYXRpb25zaGlwIHF1ZXJ5XG4gKi9cbmV4cG9ydCBjbGFzcyBTdWJRdWVyeTxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgUE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gIFBSIGV4dGVuZHMgUmVjb3JkLFxuICBQUVJUIGV4dGVuZHMgUXVlcnlSZXNwb25zZVRhcmdldCxcbiAgQ1JOIGV4dGVuZHMgQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBQTj4gPSBDaGlsZFJlbGF0aW9uc2hpcE5hbWVzPFMsIFBOPixcbiAgQ04gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4gPSBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIFBOLCBDUk4+LFxuICBDUiBleHRlbmRzIFJlY29yZCA9IFJlY29yZFxuPiB7XG4gIF9yZWxOYW1lOiBDUk47XG4gIF9xdWVyeTogUXVlcnk8UywgQ04sIENSPjtcbiAgX3BhcmVudDogUXVlcnk8UywgUE4sIFBSLCBQUVJUPjtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIGNvbm46IENvbm5lY3Rpb248Uz4sXG4gICAgcmVsTmFtZTogQ1JOLFxuICAgIGNvbmZpZzogUXVlcnlDb25maWc8UywgQ04+LFxuICAgIHBhcmVudDogUXVlcnk8UywgUE4sIFBSLCBQUVJUPixcbiAgKSB7XG4gICAgdGhpcy5fcmVsTmFtZSA9IHJlbE5hbWU7XG4gICAgdGhpcy5fcXVlcnkgPSBuZXcgUXVlcnkoY29ubiwgY29uZmlnKTtcbiAgICB0aGlzLl9wYXJlbnQgPSBwYXJlbnQ7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIHNlbGVjdDxcbiAgICBSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkLFxuICAgIEZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBDTj4sXG4gICAgRlBDIGV4dGVuZHMgRmllbGRQcm9qZWN0aW9uQ29uZmlnID0gRmllbGRQYXRoU2NvcGVkUHJvamVjdGlvbjxTLCBDTiwgRlA+XG4gID4oXG4gICAgZmllbGRzOiBRdWVyeUZpZWxkPFMsIENOLCBGUD4sXG4gICk6IFN1YlF1ZXJ5PFMsIFBOLCBQUiwgUFFSVCwgQ1JOLCBDTiwgU09iamVjdFJlY29yZDxTLCBDTiwgRlBDLCBSPj4ge1xuICAgIC8vIGZvcmNlIGNvbnZlcnQgcXVlcnkgcmVjb3JkIHR5cGUgd2l0aG91dCBjaGFuZ2luZyBpbnN0YW5jZVxuICAgIHRoaXMuX3F1ZXJ5ID0gdGhpcy5fcXVlcnkuc2VsZWN0KGZpZWxkcykgYXMgYW55O1xuICAgIHJldHVybiAodGhpcyBhcyBhbnkpIGFzIFN1YlF1ZXJ5PFxuICAgICAgUyxcbiAgICAgIFBOLFxuICAgICAgUFIsXG4gICAgICBQUVJULFxuICAgICAgQ1JOLFxuICAgICAgQ04sXG4gICAgICBTT2JqZWN0UmVjb3JkPFMsIENOLCBGUEMsIFI+XG4gICAgPjtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgd2hlcmUoY29uZGl0aW9uczogUXVlcnlDb25kaXRpb248UywgQ04+IHwgc3RyaW5nKTogdGhpcyB7XG4gICAgdGhpcy5fcXVlcnkgPSB0aGlzLl9xdWVyeS53aGVyZShjb25kaXRpb25zKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBMaW1pdCB0aGUgcmV0dXJuaW5nIHJlc3VsdFxuICAgKi9cbiAgbGltaXQobGltaXQ6IG51bWJlcikge1xuICAgIHRoaXMuX3F1ZXJ5ID0gdGhpcy5fcXVlcnkubGltaXQobGltaXQpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFNraXAgcmVjb3Jkc1xuICAgKi9cbiAgc2tpcChvZmZzZXQ6IG51bWJlcikge1xuICAgIHRoaXMuX3F1ZXJ5ID0gdGhpcy5fcXVlcnkuc2tpcChvZmZzZXQpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgU3ViUXVlcnkjc2tpcCgpXG4gICAqL1xuICBvZmZzZXQgPSB0aGlzLnNraXA7XG5cbiAgLyoqXG4gICAqIFNldCBxdWVyeSBzb3J0IHdpdGggZGlyZWN0aW9uXG4gICAqL1xuICBzb3J0KHNvcnQ6IFF1ZXJ5U29ydDxTLCBDTj4pOiB0aGlzO1xuICBzb3J0KHNvcnQ6IHN0cmluZyk6IHRoaXM7XG4gIHNvcnQoc29ydDogU09iamVjdEZpZWxkTmFtZXM8UywgQ04+LCBkaXI6IFNvcnREaXIpOiB0aGlzO1xuICBzb3J0KHNvcnQ6IHN0cmluZywgZGlyOiBTb3J0RGlyKTogdGhpcztcbiAgc29ydChcbiAgICBzb3J0OiBRdWVyeVNvcnQ8UywgQ04+IHwgU09iamVjdEZpZWxkTmFtZXM8UywgQ04+IHwgc3RyaW5nLFxuICAgIGRpcj86IFNvcnREaXIsXG4gICkge1xuICAgIHRoaXMuX3F1ZXJ5ID0gdGhpcy5fcXVlcnkuc29ydChzb3J0IGFzIGFueSwgZGlyIGFzIFNvcnREaXIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgU3ViUXVlcnkjc29ydCgpXG4gICAqL1xuICBvcmRlcmJ5OiB0eXBlb2YgU3ViUXVlcnkucHJvdG90eXBlLnNvcnQgPSB0aGlzLnNvcnQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBfZXhwYW5kRmllbGRzKCkge1xuICAgIGNvbnN0IHNvYmplY3QgPSBhd2FpdCB0aGlzLl9wYXJlbnQuX2ZpbmRSZWxhdGlvbk9iamVjdCh0aGlzLl9yZWxOYW1lKTtcbiAgICByZXR1cm4gdGhpcy5fcXVlcnkuX2V4cGFuZEZpZWxkcyhzb2JqZWN0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCYWNrIHRoZSBjb250ZXh0IHRvIHBhcmVudCBxdWVyeSBvYmplY3RcbiAgICovXG4gIGVuZDxcbiAgICBDUlAgZXh0ZW5kcyBTT2JqZWN0Q2hpbGRSZWxhdGlvbnNoaXBQcm9wPFxuICAgICAgQ1JOLFxuICAgICAgQ1JcbiAgICA+ID0gU09iamVjdENoaWxkUmVsYXRpb25zaGlwUHJvcDxDUk4sIENSPixcbiAgICBQUjEgZXh0ZW5kcyBSZWNvcmQgPSBQUiAmIENSUFxuICA+KCk6IFF1ZXJ5PFMsIFBOLCBQUjEsIFBRUlQ+IHtcbiAgICByZXR1cm4gKHRoaXMuX3BhcmVudCBhcyBhbnkpIGFzIFF1ZXJ5PFMsIFBOLCBQUjEsIFBRUlQ+O1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFF1ZXJ5O1xuIl19