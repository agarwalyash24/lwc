import "core-js/modules/es.array.join";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.replace";
import "core-js/modules/es.string.split";
import _sortInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/sort";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _Object$entries from "@babel/runtime-corejs3/core-js-stable/object/entries";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _Object$values from "@babel/runtime-corejs3/core-js-stable/object/values";

/**
 * @file Create and build SOQL string from configuration
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import SfDate from './date';

/** @private **/
function escapeSOQLString(str) {
  return String(str || '').replace(/'/g, "\\'");
}
/** @private **/


function createFieldsClause(fields) {
  var _context;

  var childQueries = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var cqueries = _Object$values(childQueries); // eslint-disable-next-line no-use-before-define


  return _concatInstanceProperty(_context = []).call(_context, _toConsumableArray(fields || ['Id']), _toConsumableArray(_mapInstanceProperty(cqueries).call(cqueries, function (cquery) {
    return "(".concat(createSOQL(cquery), ")");
  }))).join(', ');
}
/** @private **/


function createValueExpression(value) {
  if (_Array$isArray(value)) {
    return value.length > 0 ? "(".concat(_mapInstanceProperty(value).call(value, createValueExpression).join(', '), ")") : undefined;
  }

  if (value instanceof SfDate) {
    return value.toString();
  }

  if (typeof value === 'string') {
    return "'".concat(escapeSOQLString(value), "'");
  }

  if (typeof value === 'number') {
    return value.toString();
  }

  if (value === null) {
    return 'null';
  }

  return value;
}

var opMap = {
  '=': '=',
  $eq: '=',
  '!=': '!=',
  $ne: '!=',
  '>': '>',
  $gt: '>',
  '<': '<',
  $lt: '<',
  '>=': '>=',
  $gte: '>=',
  '<=': '<=',
  $lte: '<=',
  $like: 'LIKE',
  $nlike: 'NOT LIKE',
  $in: 'IN',
  $nin: 'NOT IN',
  $includes: 'INCLUDES',
  $excludes: 'EXCLUDES',
  $exists: 'EXISTS'
};
/** @private **/

function createFieldExpression(field, value) {
  var op = '$eq';
  var _value = value; // Assume the `$in` operator if value is an array and none was supplied.

  if (_Array$isArray(value)) {
    op = '$in';
  } else if (_typeof(value) === 'object' && value !== null) {
    // Otherwise, if an object was passed then process the supplied ops.
    for (var _i = 0, _Object$keys = _Object$keys2(value); _i < _Object$keys.length; _i++) {
      var k = _Object$keys[_i];

      if (k[0] === '$') {
        op = k;
        _value = value[k];
        break;
      }
    }
  }

  var sfop = opMap[op];

  if (!sfop || typeof _value === 'undefined') {
    return null;
  }

  var valueExpr = createValueExpression(_value);

  if (typeof valueExpr === 'undefined') {
    return null;
  }

  switch (sfop) {
    case 'NOT LIKE':
      return "(".concat(['NOT', field, 'LIKE', valueExpr].join(' '), ")");

    case 'EXISTS':
      return [field, _value ? '!=' : '=', 'null'].join(' ');

    default:
      return [field, sfop, valueExpr].join(' ');
  }
}
/** @private **/


function createOrderByClause() {
  var sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var _sort = [];

  if (typeof sort === 'string') {
    var _context2;

    if (/,|\s+(asc|desc)\s*$/.test(sort)) {
      // must be specified in pure "order by" clause. Return raw config.
      return sort;
    } // sort order in mongoose-style expression.
    // e.g. "FieldA -FieldB" => "ORDER BY FieldA ASC, FieldB DESC"


    _sort = _mapInstanceProperty(_context2 = sort.split(/\s+/)).call(_context2, function (field) {
      var dir = 'ASC'; // ascending

      var flag = field[0];

      if (flag === '-') {
        dir = 'DESC';
        field = field.substring(1); // eslint-disable-line no-param-reassign
      } else if (flag === '+') {
        field = field.substring(1); // eslint-disable-line no-param-reassign
      }

      return [field, dir];
    });
  } else if (_Array$isArray(sort)) {
    _sort = sort;
  } else {
    var _context3;

    _sort = _mapInstanceProperty(_context3 = _Object$entries(sort)).call(_context3, function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
          field = _ref2[0],
          dir = _ref2[1];

      return [field, dir];
    });
  }

  return _mapInstanceProperty(_sort).call(_sort, function (_ref3) {
    var _context4;

    var _ref4 = _slicedToArray(_ref3, 2),
        field = _ref4[0],
        dir = _ref4[1];

    /* eslint-disable no-param-reassign */
    switch (String(dir)) {
      case 'DESC':
      case 'desc':
      case 'descending':
      case '-':
      case '-1':
        dir = 'DESC';
        break;

      default:
        dir = 'ASC';
    }

    return _concatInstanceProperty(_context4 = "".concat(field, " ")).call(_context4, dir);
  }).join(', ');
}

/** @private **/
function createConditionClause() {
  var _context7;

  var conditions = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var operator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'AND';
  var depth = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

  if (typeof conditions === 'string') {
    return conditions;
  }

  var conditionList = [];

  if (!_Array$isArray(conditions)) {
    var _context5;

    // if passed in hash object
    var conditionsMap = conditions;
    conditionList = _mapInstanceProperty(_context5 = _Object$keys2(conditionsMap)).call(_context5, function (key) {
      return {
        key: key,
        value: conditionsMap[key]
      };
    });
  } else {
    conditionList = _mapInstanceProperty(conditions).call(conditions, function (cond) {
      var _context6;

      var conds = _mapInstanceProperty(_context6 = _Object$keys2(cond)).call(_context6, function (key) {
        return {
          key: key,
          value: cond[key]
        };
      });

      return conds.length > 1 ? {
        key: '$and',
        value: _mapInstanceProperty(conds).call(conds, function (c) {
          return _defineProperty({}, c.key, c.value);
        })
      } : conds[0];
    });
  }

  var conditionClauses = _filterInstanceProperty(_context7 = _mapInstanceProperty(conditionList).call(conditionList, function (cond) {
    var d = depth + 1;
    var op;

    switch (cond.key) {
      case '$or':
      case '$and':
      case '$not':
        if (operator !== 'NOT' && conditionList.length === 1) {
          d = depth; // not change tree depth
        }

        op = cond.key === '$or' ? 'OR' : cond.key === '$and' ? 'AND' : 'NOT';
        return createConditionClause(cond.value, op, d);

      default:
        return createFieldExpression(cond.key, cond.value);
    }
  })).call(_context7, function (expr) {
    return expr;
  });

  var hasParen;

  if (operator === 'NOT') {
    var _context8, _context9;

    hasParen = depth > 0;
    return _concatInstanceProperty(_context8 = _concatInstanceProperty(_context9 = "".concat(hasParen ? '(' : '', "NOT ")).call(_context9, conditionClauses[0])).call(_context8, hasParen ? ')' : '');
  }

  hasParen = depth > 0 && conditionClauses.length > 1;
  return (hasParen ? '(' : '') + conditionClauses.join(" ".concat(operator, " ")) + (hasParen ? ')' : '');
}
/**
 * Create SOQL
 * @private
 */


export function createSOQL(query) {
  var soql = ['SELECT ', createFieldsClause(query.fields, _includesInstanceProperty(query)), ' FROM ', query.table].join('');
  var cond = createConditionClause(query.conditions);

  if (cond) {
    soql += " WHERE ".concat(cond);
  }

  var orderby = createOrderByClause(_sortInstanceProperty(query));

  if (orderby) {
    soql += " ORDER BY ".concat(orderby);
  }

  if (query.limit) {
    soql += " LIMIT ".concat(query.limit);
  }

  if (query.offset) {
    soql += " OFFSET ".concat(query.offset);
  }

  return soql;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zb3FsLWJ1aWxkZXIudHMiXSwibmFtZXMiOlsiU2ZEYXRlIiwiZXNjYXBlU09RTFN0cmluZyIsInN0ciIsIlN0cmluZyIsInJlcGxhY2UiLCJjcmVhdGVGaWVsZHNDbGF1c2UiLCJmaWVsZHMiLCJjaGlsZFF1ZXJpZXMiLCJjcXVlcmllcyIsImNxdWVyeSIsImNyZWF0ZVNPUUwiLCJqb2luIiwiY3JlYXRlVmFsdWVFeHByZXNzaW9uIiwidmFsdWUiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJ0b1N0cmluZyIsIm9wTWFwIiwiJGVxIiwiJG5lIiwiJGd0IiwiJGx0IiwiJGd0ZSIsIiRsdGUiLCIkbGlrZSIsIiRubGlrZSIsIiRpbiIsIiRuaW4iLCIkaW5jbHVkZXMiLCIkZXhjbHVkZXMiLCIkZXhpc3RzIiwiY3JlYXRlRmllbGRFeHByZXNzaW9uIiwiZmllbGQiLCJvcCIsIl92YWx1ZSIsImsiLCJzZm9wIiwidmFsdWVFeHByIiwiY3JlYXRlT3JkZXJCeUNsYXVzZSIsInNvcnQiLCJfc29ydCIsInRlc3QiLCJzcGxpdCIsImRpciIsImZsYWciLCJzdWJzdHJpbmciLCJjcmVhdGVDb25kaXRpb25DbGF1c2UiLCJjb25kaXRpb25zIiwib3BlcmF0b3IiLCJkZXB0aCIsImNvbmRpdGlvbkxpc3QiLCJjb25kaXRpb25zTWFwIiwia2V5IiwiY29uZCIsImNvbmRzIiwiYyIsImNvbmRpdGlvbkNsYXVzZXMiLCJkIiwiZXhwciIsImhhc1BhcmVuIiwicXVlcnkiLCJzb3FsIiwidGFibGUiLCJvcmRlcmJ5IiwibGltaXQiLCJvZmZzZXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPQSxNQUFQLE1BQW1CLFFBQW5COztBQXlCQTtBQUNBLFNBQVNDLGdCQUFULENBQTBCQyxHQUExQixFQUFvRTtBQUNsRSxTQUFPQyxNQUFNLENBQUNELEdBQUcsSUFBSSxFQUFSLENBQU4sQ0FBa0JFLE9BQWxCLENBQTBCLElBQTFCLEVBQWdDLEtBQWhDLENBQVA7QUFDRDtBQUVEOzs7QUFDQSxTQUFTQyxrQkFBVCxDQUNFQyxNQURGLEVBR1U7QUFBQTs7QUFBQSxNQURSQyxZQUNRLHVFQUR3QyxFQUN4Qzs7QUFDUixNQUFNQyxRQUF1QixHQUFJLGVBQy9CRCxZQUQrQixDQUFqQyxDQURRLENBSVI7OztBQUNBLFNBQU8seUVBQ0RELE1BQU0sSUFBSSxDQUFDLElBQUQsQ0FEVCxzQkFFRixxQkFBQUUsUUFBUSxNQUFSLENBQUFBLFFBQVEsRUFBSyxVQUFDQyxNQUFEO0FBQUEsc0JBQWdCQyxVQUFVLENBQUNELE1BQUQsQ0FBMUI7QUFBQSxHQUFMLENBRk4sR0FHTEUsSUFISyxDQUdBLElBSEEsQ0FBUDtBQUlEO0FBRUQ7OztBQUNBLFNBQVNDLHFCQUFULENBQStCQyxLQUEvQixFQUE2RDtBQUMzRCxNQUFJLGVBQWNBLEtBQWQsQ0FBSixFQUEwQjtBQUN4QixXQUFPQSxLQUFLLENBQUNDLE1BQU4sR0FBZSxDQUFmLGNBQ0MscUJBQUFELEtBQUssTUFBTCxDQUFBQSxLQUFLLEVBQUtELHFCQUFMLENBQUwsQ0FBaUNELElBQWpDLENBQXNDLElBQXRDLENBREQsU0FFSEksU0FGSjtBQUdEOztBQUNELE1BQUlGLEtBQUssWUFBWWIsTUFBckIsRUFBNkI7QUFDM0IsV0FBT2EsS0FBSyxDQUFDRyxRQUFOLEVBQVA7QUFDRDs7QUFDRCxNQUFJLE9BQU9ILEtBQVAsS0FBaUIsUUFBckIsRUFBK0I7QUFDN0Isc0JBQVdaLGdCQUFnQixDQUFDWSxLQUFELENBQTNCO0FBQ0Q7O0FBQ0QsTUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzdCLFdBQU9BLEtBQUssQ0FBQ0csUUFBTixFQUFQO0FBQ0Q7O0FBQ0QsTUFBSUgsS0FBSyxLQUFLLElBQWQsRUFBb0I7QUFDbEIsV0FBTyxNQUFQO0FBQ0Q7O0FBQ0QsU0FBT0EsS0FBUDtBQUNEOztBQUVELElBQU1JLEtBQStCLEdBQUc7QUFDdEMsT0FBSyxHQURpQztBQUV0Q0MsRUFBQUEsR0FBRyxFQUFFLEdBRmlDO0FBR3RDLFFBQU0sSUFIZ0M7QUFJdENDLEVBQUFBLEdBQUcsRUFBRSxJQUppQztBQUt0QyxPQUFLLEdBTGlDO0FBTXRDQyxFQUFBQSxHQUFHLEVBQUUsR0FOaUM7QUFPdEMsT0FBSyxHQVBpQztBQVF0Q0MsRUFBQUEsR0FBRyxFQUFFLEdBUmlDO0FBU3RDLFFBQU0sSUFUZ0M7QUFVdENDLEVBQUFBLElBQUksRUFBRSxJQVZnQztBQVd0QyxRQUFNLElBWGdDO0FBWXRDQyxFQUFBQSxJQUFJLEVBQUUsSUFaZ0M7QUFhdENDLEVBQUFBLEtBQUssRUFBRSxNQWIrQjtBQWN0Q0MsRUFBQUEsTUFBTSxFQUFFLFVBZDhCO0FBZXRDQyxFQUFBQSxHQUFHLEVBQUUsSUFmaUM7QUFnQnRDQyxFQUFBQSxJQUFJLEVBQUUsUUFoQmdDO0FBaUJ0Q0MsRUFBQUEsU0FBUyxFQUFFLFVBakIyQjtBQWtCdENDLEVBQUFBLFNBQVMsRUFBRSxVQWxCMkI7QUFtQnRDQyxFQUFBQSxPQUFPLEVBQUU7QUFuQjZCLENBQXhDO0FBc0JBOztBQUNBLFNBQVNDLHFCQUFULENBQStCQyxLQUEvQixFQUE4Q25CLEtBQTlDLEVBQTRFO0FBQzFFLE1BQUlvQixFQUFFLEdBQUcsS0FBVDtBQUNBLE1BQUlDLE1BQU0sR0FBR3JCLEtBQWIsQ0FGMEUsQ0FJMUU7O0FBQ0EsTUFBSSxlQUFjQSxLQUFkLENBQUosRUFBMEI7QUFDeEJvQixJQUFBQSxFQUFFLEdBQUcsS0FBTDtBQUNELEdBRkQsTUFFTyxJQUFJLFFBQU9wQixLQUFQLE1BQWlCLFFBQWpCLElBQTZCQSxLQUFLLEtBQUssSUFBM0MsRUFBaUQ7QUFDdEQ7QUFDQSxvQ0FBZ0IsY0FBWUEsS0FBWixDQUFoQixrQ0FBb0M7QUFBL0IsVUFBTXNCLENBQUMsbUJBQVA7O0FBQ0gsVUFBSUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxLQUFTLEdBQWIsRUFBa0I7QUFDaEJGLFFBQUFBLEVBQUUsR0FBR0UsQ0FBTDtBQUNBRCxRQUFBQSxNQUFNLEdBQUdyQixLQUFLLENBQUNzQixDQUFELENBQWQ7QUFDQTtBQUNEO0FBQ0Y7QUFDRjs7QUFDRCxNQUFNQyxJQUFJLEdBQUduQixLQUFLLENBQUNnQixFQUFELENBQWxCOztBQUNBLE1BQUksQ0FBQ0csSUFBRCxJQUFTLE9BQU9GLE1BQVAsS0FBa0IsV0FBL0IsRUFBNEM7QUFDMUMsV0FBTyxJQUFQO0FBQ0Q7O0FBQ0QsTUFBTUcsU0FBUyxHQUFHekIscUJBQXFCLENBQUNzQixNQUFELENBQXZDOztBQUNBLE1BQUksT0FBT0csU0FBUCxLQUFxQixXQUF6QixFQUFzQztBQUNwQyxXQUFPLElBQVA7QUFDRDs7QUFDRCxVQUFRRCxJQUFSO0FBQ0UsU0FBSyxVQUFMO0FBQ0Usd0JBQVcsQ0FBQyxLQUFELEVBQVFKLEtBQVIsRUFBZSxNQUFmLEVBQXVCSyxTQUF2QixFQUFrQzFCLElBQWxDLENBQXVDLEdBQXZDLENBQVg7O0FBQ0YsU0FBSyxRQUFMO0FBQ0UsYUFBTyxDQUFDcUIsS0FBRCxFQUFRRSxNQUFNLEdBQUcsSUFBSCxHQUFVLEdBQXhCLEVBQTZCLE1BQTdCLEVBQXFDdkIsSUFBckMsQ0FBMEMsR0FBMUMsQ0FBUDs7QUFDRjtBQUNFLGFBQU8sQ0FBQ3FCLEtBQUQsRUFBUUksSUFBUixFQUFjQyxTQUFkLEVBQXlCMUIsSUFBekIsQ0FBOEIsR0FBOUIsQ0FBUDtBQU5KO0FBUUQ7QUFFRDs7O0FBQ0EsU0FBUzJCLG1CQUFULEdBQXNEO0FBQUEsTUFBekJDLElBQXlCLHVFQUFaLEVBQVk7QUFDcEQsTUFBSUMsS0FBK0IsR0FBRyxFQUF0Qzs7QUFDQSxNQUFJLE9BQU9ELElBQVAsS0FBZ0IsUUFBcEIsRUFBOEI7QUFBQTs7QUFDNUIsUUFBSSxzQkFBc0JFLElBQXRCLENBQTJCRixJQUEzQixDQUFKLEVBQXNDO0FBQ3BDO0FBQ0EsYUFBT0EsSUFBUDtBQUNELEtBSjJCLENBSzVCO0FBQ0E7OztBQUNBQyxJQUFBQSxLQUFLLEdBQUcsaUNBQUFELElBQUksQ0FBQ0csS0FBTCxDQUFXLEtBQVgsbUJBQXNCLFVBQUNWLEtBQUQsRUFBVztBQUN2QyxVQUFJVyxHQUFZLEdBQUcsS0FBbkIsQ0FEdUMsQ0FDYjs7QUFDMUIsVUFBTUMsSUFBSSxHQUFHWixLQUFLLENBQUMsQ0FBRCxDQUFsQjs7QUFDQSxVQUFJWSxJQUFJLEtBQUssR0FBYixFQUFrQjtBQUNoQkQsUUFBQUEsR0FBRyxHQUFHLE1BQU47QUFDQVgsUUFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUNhLFNBQU4sQ0FBZ0IsQ0FBaEIsQ0FBUixDQUZnQixDQUVZO0FBQzdCLE9BSEQsTUFHTyxJQUFJRCxJQUFJLEtBQUssR0FBYixFQUFrQjtBQUN2QlosUUFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUNhLFNBQU4sQ0FBZ0IsQ0FBaEIsQ0FBUixDQUR1QixDQUNLO0FBQzdCOztBQUNELGFBQU8sQ0FBQ2IsS0FBRCxFQUFRVyxHQUFSLENBQVA7QUFDRCxLQVZPLENBQVI7QUFXRCxHQWxCRCxNQWtCTyxJQUFJLGVBQWNKLElBQWQsQ0FBSixFQUF5QjtBQUM5QkMsSUFBQUEsS0FBSyxHQUFHRCxJQUFSO0FBQ0QsR0FGTSxNQUVBO0FBQUE7O0FBQ0xDLElBQUFBLEtBQUssR0FBRyxpREFBZUQsSUFBZixtQkFDTjtBQUFBO0FBQUEsVUFBRVAsS0FBRjtBQUFBLFVBQVNXLEdBQVQ7O0FBQUEsYUFBa0IsQ0FBQ1gsS0FBRCxFQUFRVyxHQUFSLENBQWxCO0FBQUEsS0FETSxDQUFSO0FBR0Q7O0FBQ0QsU0FBTyxxQkFBQUgsS0FBSyxNQUFMLENBQUFBLEtBQUssRUFDTCxpQkFBa0I7QUFBQTs7QUFBQTtBQUFBLFFBQWhCUixLQUFnQjtBQUFBLFFBQVRXLEdBQVM7O0FBQ3JCO0FBQ0EsWUFBUXhDLE1BQU0sQ0FBQ3dDLEdBQUQsQ0FBZDtBQUNFLFdBQUssTUFBTDtBQUNBLFdBQUssTUFBTDtBQUNBLFdBQUssWUFBTDtBQUNBLFdBQUssR0FBTDtBQUNBLFdBQUssSUFBTDtBQUNFQSxRQUFBQSxHQUFHLEdBQUcsTUFBTjtBQUNBOztBQUNGO0FBQ0VBLFFBQUFBLEdBQUcsR0FBRyxLQUFOO0FBVEo7O0FBV0EseURBQVVYLEtBQVYsd0JBQW1CVyxHQUFuQjtBQUNELEdBZlMsQ0FBTCxDQWdCSmhDLElBaEJJLENBZ0JDLElBaEJELENBQVA7QUFpQkQ7O0FBSUQ7QUFDQSxTQUFTbUMscUJBQVQsR0FJVTtBQUFBOztBQUFBLE1BSFJDLFVBR1EsdUVBSGdCLEVBR2hCO0FBQUEsTUFGUkMsUUFFUSx1RUFGb0IsS0FFcEI7QUFBQSxNQURSQyxLQUNRLHVFQURRLENBQ1I7O0FBQ1IsTUFBSSxPQUFPRixVQUFQLEtBQXNCLFFBQTFCLEVBQW9DO0FBQ2xDLFdBQU9BLFVBQVA7QUFDRDs7QUFDRCxNQUFJRyxhQUF1RCxHQUFHLEVBQTlEOztBQUNBLE1BQUksQ0FBQyxlQUFjSCxVQUFkLENBQUwsRUFBZ0M7QUFBQTs7QUFDOUI7QUFDQSxRQUFNSSxhQUFhLEdBQUdKLFVBQXRCO0FBQ0FHLElBQUFBLGFBQWEsR0FBRywrQ0FBWUMsYUFBWixtQkFBK0IsVUFBQ0MsR0FBRDtBQUFBLGFBQVU7QUFDdkRBLFFBQUFBLEdBQUcsRUFBSEEsR0FEdUQ7QUFFdkR2QyxRQUFBQSxLQUFLLEVBQUVzQyxhQUFhLENBQUNDLEdBQUQ7QUFGbUMsT0FBVjtBQUFBLEtBQS9CLENBQWhCO0FBSUQsR0FQRCxNQU9PO0FBQ0xGLElBQUFBLGFBQWEsR0FBRyxxQkFBQUgsVUFBVSxNQUFWLENBQUFBLFVBQVUsRUFBSyxVQUFDTSxJQUFELEVBQVU7QUFBQTs7QUFDdkMsVUFBTUMsS0FBSyxHQUFHLCtDQUFZRCxJQUFaLG1CQUFzQixVQUFDRCxHQUFEO0FBQUEsZUFBVTtBQUFFQSxVQUFBQSxHQUFHLEVBQUhBLEdBQUY7QUFBT3ZDLFVBQUFBLEtBQUssRUFBRXdDLElBQUksQ0FBQ0QsR0FBRDtBQUFsQixTQUFWO0FBQUEsT0FBdEIsQ0FBZDs7QUFDQSxhQUFPRSxLQUFLLENBQUN4QyxNQUFOLEdBQWUsQ0FBZixHQUNIO0FBQUVzQyxRQUFBQSxHQUFHLEVBQUUsTUFBUDtBQUFldkMsUUFBQUEsS0FBSyxFQUFFLHFCQUFBeUMsS0FBSyxNQUFMLENBQUFBLEtBQUssRUFBSyxVQUFDQyxDQUFEO0FBQUEscUNBQVdBLENBQUMsQ0FBQ0gsR0FBYixFQUFtQkcsQ0FBQyxDQUFDMUMsS0FBckI7QUFBQSxTQUFMO0FBQTNCLE9BREcsR0FFSHlDLEtBQUssQ0FBQyxDQUFELENBRlQ7QUFHRCxLQUx5QixDQUExQjtBQU1EOztBQUNELE1BQU1FLGdCQUFnQixHQUFJLHlEQUFBTixhQUFhLE1BQWIsQ0FBQUEsYUFBYSxFQUNoQyxVQUFDRyxJQUFELEVBQVU7QUFDYixRQUFJSSxDQUFDLEdBQUdSLEtBQUssR0FBRyxDQUFoQjtBQUNBLFFBQUloQixFQUFKOztBQUNBLFlBQVFvQixJQUFJLENBQUNELEdBQWI7QUFDRSxXQUFLLEtBQUw7QUFDQSxXQUFLLE1BQUw7QUFDQSxXQUFLLE1BQUw7QUFDRSxZQUFJSixRQUFRLEtBQUssS0FBYixJQUFzQkUsYUFBYSxDQUFDcEMsTUFBZCxLQUF5QixDQUFuRCxFQUFzRDtBQUNwRDJDLFVBQUFBLENBQUMsR0FBR1IsS0FBSixDQURvRCxDQUN6QztBQUNaOztBQUNEaEIsUUFBQUEsRUFBRSxHQUFHb0IsSUFBSSxDQUFDRCxHQUFMLEtBQWEsS0FBYixHQUFxQixJQUFyQixHQUE0QkMsSUFBSSxDQUFDRCxHQUFMLEtBQWEsTUFBYixHQUFzQixLQUF0QixHQUE4QixLQUEvRDtBQUNBLGVBQU9OLHFCQUFxQixDQUFDTyxJQUFJLENBQUN4QyxLQUFOLEVBQWFvQixFQUFiLEVBQWlCd0IsQ0FBakIsQ0FBNUI7O0FBQ0Y7QUFDRSxlQUFPMUIscUJBQXFCLENBQUNzQixJQUFJLENBQUNELEdBQU4sRUFBV0MsSUFBSSxDQUFDeEMsS0FBaEIsQ0FBNUI7QUFWSjtBQVlELEdBaEJvQyxDQUFiLGtCQWlCaEIsVUFBQzZDLElBQUQ7QUFBQSxXQUFVQSxJQUFWO0FBQUEsR0FqQmdCLENBQTFCOztBQW1CQSxNQUFJQyxRQUFKOztBQUNBLE1BQUlYLFFBQVEsS0FBSyxLQUFqQixFQUF3QjtBQUFBOztBQUN0QlcsSUFBQUEsUUFBUSxHQUFHVixLQUFLLEdBQUcsQ0FBbkI7QUFDQSw2RkFBVVUsUUFBUSxHQUFHLEdBQUgsR0FBUyxFQUEzQiwyQkFBb0NILGdCQUFnQixDQUFDLENBQUQsQ0FBcEQsbUJBQ0VHLFFBQVEsR0FBRyxHQUFILEdBQVMsRUFEbkI7QUFHRDs7QUFDREEsRUFBQUEsUUFBUSxHQUFHVixLQUFLLEdBQUcsQ0FBUixJQUFhTyxnQkFBZ0IsQ0FBQzFDLE1BQWpCLEdBQTBCLENBQWxEO0FBQ0EsU0FDRSxDQUFDNkMsUUFBUSxHQUFHLEdBQUgsR0FBUyxFQUFsQixJQUNBSCxnQkFBZ0IsQ0FBQzdDLElBQWpCLFlBQTBCcUMsUUFBMUIsT0FEQSxJQUVDVyxRQUFRLEdBQUcsR0FBSCxHQUFTLEVBRmxCLENBREY7QUFLRDtBQUVEO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxPQUFPLFNBQVNqRCxVQUFULENBQW9Ca0QsS0FBcEIsRUFBZ0Q7QUFDckQsTUFBSUMsSUFBSSxHQUFHLENBQ1QsU0FEUyxFQUVUeEQsa0JBQWtCLENBQUN1RCxLQUFLLENBQUN0RCxNQUFQLDRCQUFlc0QsS0FBZixFQUZULEVBR1QsUUFIUyxFQUlUQSxLQUFLLENBQUNFLEtBSkcsRUFLVG5ELElBTFMsQ0FLSixFQUxJLENBQVg7QUFNQSxNQUFNMEMsSUFBSSxHQUFHUCxxQkFBcUIsQ0FBQ2MsS0FBSyxDQUFDYixVQUFQLENBQWxDOztBQUNBLE1BQUlNLElBQUosRUFBVTtBQUNSUSxJQUFBQSxJQUFJLHFCQUFjUixJQUFkLENBQUo7QUFDRDs7QUFDRCxNQUFNVSxPQUFPLEdBQUd6QixtQkFBbUIsdUJBQUNzQixLQUFELEVBQW5DOztBQUNBLE1BQUlHLE9BQUosRUFBYTtBQUNYRixJQUFBQSxJQUFJLHdCQUFpQkUsT0FBakIsQ0FBSjtBQUNEOztBQUNELE1BQUlILEtBQUssQ0FBQ0ksS0FBVixFQUFpQjtBQUNmSCxJQUFBQSxJQUFJLHFCQUFjRCxLQUFLLENBQUNJLEtBQXBCLENBQUo7QUFDRDs7QUFDRCxNQUFJSixLQUFLLENBQUNLLE1BQVYsRUFBa0I7QUFDaEJKLElBQUFBLElBQUksc0JBQWVELEtBQUssQ0FBQ0ssTUFBckIsQ0FBSjtBQUNEOztBQUNELFNBQU9KLElBQVA7QUFDRCIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQ3JlYXRlIGFuZCBidWlsZCBTT1FMIHN0cmluZyBmcm9tIGNvbmZpZ3VyYXRpb25cbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgU2ZEYXRlIGZyb20gJy4vZGF0ZSc7XG5pbXBvcnQgeyBPcHRpb25hbCB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgdHlwZSBDb25kaXRpb24gPVxuICB8IHN0cmluZ1xuICB8IHsgW2ZpZWxkOiBzdHJpbmddOiBhbnkgfVxuICB8IEFycmF5PHsgW2ZpZWxkOiBzdHJpbmddOiBhbnkgfT47XG5cbmV4cG9ydCB0eXBlIFNvcnREaXIgPSAnQVNDJyB8ICdERVNDJyB8ICdhc2MnIHwgJ2Rlc2MnIHwgMSB8IC0xO1xuXG5leHBvcnQgdHlwZSBTb3J0ID1cbiAgfCBzdHJpbmdcbiAgfCBBcnJheTxbc3RyaW5nLCBTb3J0RGlyXT5cbiAgfCB7IFtmaWVsZDogc3RyaW5nXTogU29ydERpciB9O1xuXG5leHBvcnQgdHlwZSBRdWVyeUNvbmZpZyA9IHtcbiAgZmllbGRzPzogc3RyaW5nW107XG4gIGluY2x1ZGVzPzogeyBbZmllbGQ6IHN0cmluZ106IFF1ZXJ5Q29uZmlnIH07XG4gIHRhYmxlPzogc3RyaW5nO1xuICBjb25kaXRpb25zPzogQ29uZGl0aW9uO1xuICBzb3J0PzogU29ydDtcbiAgbGltaXQ/OiBudW1iZXI7XG4gIG9mZnNldD86IG51bWJlcjtcbn07XG5cbi8qKiBAcHJpdmF0ZSAqKi9cbmZ1bmN0aW9uIGVzY2FwZVNPUUxTdHJpbmcoc3RyOiBPcHRpb25hbDxzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuPikge1xuICByZXR1cm4gU3RyaW5nKHN0ciB8fCAnJykucmVwbGFjZSgvJy9nLCBcIlxcXFwnXCIpO1xufVxuXG4vKiogQHByaXZhdGUgKiovXG5mdW5jdGlvbiBjcmVhdGVGaWVsZHNDbGF1c2UoXG4gIGZpZWxkcz86IHN0cmluZ1tdLFxuICBjaGlsZFF1ZXJpZXM6IHsgW25hbWU6IHN0cmluZ106IFF1ZXJ5Q29uZmlnIH0gPSB7fSxcbik6IHN0cmluZyB7XG4gIGNvbnN0IGNxdWVyaWVzOiBRdWVyeUNvbmZpZ1tdID0gKE9iamVjdC52YWx1ZXMoXG4gICAgY2hpbGRRdWVyaWVzLFxuICApIGFzIGFueSkgYXMgUXVlcnlDb25maWdbXTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gIHJldHVybiBbXG4gICAgLi4uKGZpZWxkcyB8fCBbJ0lkJ10pLFxuICAgIC4uLmNxdWVyaWVzLm1hcCgoY3F1ZXJ5KSA9PiBgKCR7Y3JlYXRlU09RTChjcXVlcnkpfSlgKSxcbiAgXS5qb2luKCcsICcpO1xufVxuXG4vKiogQHByaXZhdGUgKiovXG5mdW5jdGlvbiBjcmVhdGVWYWx1ZUV4cHJlc3Npb24odmFsdWU6IGFueSk6IE9wdGlvbmFsPHN0cmluZz4ge1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWUubGVuZ3RoID4gMFxuICAgICAgPyBgKCR7dmFsdWUubWFwKGNyZWF0ZVZhbHVlRXhwcmVzc2lvbikuam9pbignLCAnKX0pYFxuICAgICAgOiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKHZhbHVlIGluc3RhbmNlb2YgU2ZEYXRlKSB7XG4gICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gYCcke2VzY2FwZVNPUUxTdHJpbmcodmFsdWUpfSdgO1xuICB9XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gIH1cbiAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgcmV0dXJuICdudWxsJztcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbmNvbnN0IG9wTWFwOiB7IFtvcDogc3RyaW5nXTogc3RyaW5nIH0gPSB7XG4gICc9JzogJz0nLFxuICAkZXE6ICc9JyxcbiAgJyE9JzogJyE9JyxcbiAgJG5lOiAnIT0nLFxuICAnPic6ICc+JyxcbiAgJGd0OiAnPicsXG4gICc8JzogJzwnLFxuICAkbHQ6ICc8JyxcbiAgJz49JzogJz49JyxcbiAgJGd0ZTogJz49JyxcbiAgJzw9JzogJzw9JyxcbiAgJGx0ZTogJzw9JyxcbiAgJGxpa2U6ICdMSUtFJyxcbiAgJG5saWtlOiAnTk9UIExJS0UnLFxuICAkaW46ICdJTicsXG4gICRuaW46ICdOT1QgSU4nLFxuICAkaW5jbHVkZXM6ICdJTkNMVURFUycsXG4gICRleGNsdWRlczogJ0VYQ0xVREVTJyxcbiAgJGV4aXN0czogJ0VYSVNUUycsXG59O1xuXG4vKiogQHByaXZhdGUgKiovXG5mdW5jdGlvbiBjcmVhdGVGaWVsZEV4cHJlc3Npb24oZmllbGQ6IHN0cmluZywgdmFsdWU6IGFueSk6IE9wdGlvbmFsPHN0cmluZz4ge1xuICBsZXQgb3AgPSAnJGVxJztcbiAgbGV0IF92YWx1ZSA9IHZhbHVlO1xuXG4gIC8vIEFzc3VtZSB0aGUgYCRpbmAgb3BlcmF0b3IgaWYgdmFsdWUgaXMgYW4gYXJyYXkgYW5kIG5vbmUgd2FzIHN1cHBsaWVkLlxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICBvcCA9ICckaW4nO1xuICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgIT09IG51bGwpIHtcbiAgICAvLyBPdGhlcndpc2UsIGlmIGFuIG9iamVjdCB3YXMgcGFzc2VkIHRoZW4gcHJvY2VzcyB0aGUgc3VwcGxpZWQgb3BzLlxuICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyh2YWx1ZSkpIHtcbiAgICAgIGlmIChrWzBdID09PSAnJCcpIHtcbiAgICAgICAgb3AgPSBrO1xuICAgICAgICBfdmFsdWUgPSB2YWx1ZVtrXTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IHNmb3AgPSBvcE1hcFtvcF07XG4gIGlmICghc2ZvcCB8fCB0eXBlb2YgX3ZhbHVlID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHZhbHVlRXhwciA9IGNyZWF0ZVZhbHVlRXhwcmVzc2lvbihfdmFsdWUpO1xuICBpZiAodHlwZW9mIHZhbHVlRXhwciA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBzd2l0Y2ggKHNmb3ApIHtcbiAgICBjYXNlICdOT1QgTElLRSc6XG4gICAgICByZXR1cm4gYCgke1snTk9UJywgZmllbGQsICdMSUtFJywgdmFsdWVFeHByXS5qb2luKCcgJyl9KWA7XG4gICAgY2FzZSAnRVhJU1RTJzpcbiAgICAgIHJldHVybiBbZmllbGQsIF92YWx1ZSA/ICchPScgOiAnPScsICdudWxsJ10uam9pbignICcpO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gW2ZpZWxkLCBzZm9wLCB2YWx1ZUV4cHJdLmpvaW4oJyAnKTtcbiAgfVxufVxuXG4vKiogQHByaXZhdGUgKiovXG5mdW5jdGlvbiBjcmVhdGVPcmRlckJ5Q2xhdXNlKHNvcnQ6IFNvcnQgPSBbXSk6IHN0cmluZyB7XG4gIGxldCBfc29ydDogQXJyYXk8W3N0cmluZywgU29ydERpcl0+ID0gW107XG4gIGlmICh0eXBlb2Ygc29ydCA9PT0gJ3N0cmluZycpIHtcbiAgICBpZiAoLyx8XFxzKyhhc2N8ZGVzYylcXHMqJC8udGVzdChzb3J0KSkge1xuICAgICAgLy8gbXVzdCBiZSBzcGVjaWZpZWQgaW4gcHVyZSBcIm9yZGVyIGJ5XCIgY2xhdXNlLiBSZXR1cm4gcmF3IGNvbmZpZy5cbiAgICAgIHJldHVybiBzb3J0O1xuICAgIH1cbiAgICAvLyBzb3J0IG9yZGVyIGluIG1vbmdvb3NlLXN0eWxlIGV4cHJlc3Npb24uXG4gICAgLy8gZS5nLiBcIkZpZWxkQSAtRmllbGRCXCIgPT4gXCJPUkRFUiBCWSBGaWVsZEEgQVNDLCBGaWVsZEIgREVTQ1wiXG4gICAgX3NvcnQgPSBzb3J0LnNwbGl0KC9cXHMrLykubWFwKChmaWVsZCkgPT4ge1xuICAgICAgbGV0IGRpcjogU29ydERpciA9ICdBU0MnOyAvLyBhc2NlbmRpbmdcbiAgICAgIGNvbnN0IGZsYWcgPSBmaWVsZFswXTtcbiAgICAgIGlmIChmbGFnID09PSAnLScpIHtcbiAgICAgICAgZGlyID0gJ0RFU0MnO1xuICAgICAgICBmaWVsZCA9IGZpZWxkLnN1YnN0cmluZygxKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgfSBlbHNlIGlmIChmbGFnID09PSAnKycpIHtcbiAgICAgICAgZmllbGQgPSBmaWVsZC5zdWJzdHJpbmcoMSk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgIH1cbiAgICAgIHJldHVybiBbZmllbGQsIGRpcl0gYXMgW3N0cmluZywgU29ydERpcl07XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShzb3J0KSkge1xuICAgIF9zb3J0ID0gc29ydDtcbiAgfSBlbHNlIHtcbiAgICBfc29ydCA9IE9iamVjdC5lbnRyaWVzKHNvcnQpLm1hcChcbiAgICAgIChbZmllbGQsIGRpcl0pID0+IFtmaWVsZCwgZGlyXSBhcyBbc3RyaW5nLCBTb3J0RGlyXSxcbiAgICApO1xuICB9XG4gIHJldHVybiBfc29ydFxuICAgIC5tYXAoKFtmaWVsZCwgZGlyXSkgPT4ge1xuICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICAgIHN3aXRjaCAoU3RyaW5nKGRpcikpIHtcbiAgICAgICAgY2FzZSAnREVTQyc6XG4gICAgICAgIGNhc2UgJ2Rlc2MnOlxuICAgICAgICBjYXNlICdkZXNjZW5kaW5nJzpcbiAgICAgICAgY2FzZSAnLSc6XG4gICAgICAgIGNhc2UgJy0xJzpcbiAgICAgICAgICBkaXIgPSAnREVTQyc7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgZGlyID0gJ0FTQyc7XG4gICAgICB9XG4gICAgICByZXR1cm4gYCR7ZmllbGR9ICR7ZGlyfWA7XG4gICAgfSlcbiAgICAuam9pbignLCAnKTtcbn1cblxudHlwZSBMb2dpY2FsT3BlcmF0b3IgPSAnQU5EJyB8ICdPUicgfCAnTk9UJztcblxuLyoqIEBwcml2YXRlICoqL1xuZnVuY3Rpb24gY3JlYXRlQ29uZGl0aW9uQ2xhdXNlKFxuICBjb25kaXRpb25zOiBDb25kaXRpb24gPSB7fSxcbiAgb3BlcmF0b3I6IExvZ2ljYWxPcGVyYXRvciA9ICdBTkQnLFxuICBkZXB0aDogbnVtYmVyID0gMCxcbik6IHN0cmluZyB7XG4gIGlmICh0eXBlb2YgY29uZGl0aW9ucyA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gY29uZGl0aW9ucztcbiAgfVxuICBsZXQgY29uZGl0aW9uTGlzdDogQXJyYXk8eyBrZXk6IHN0cmluZzsgdmFsdWU6IENvbmRpdGlvbiB9PiA9IFtdO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoY29uZGl0aW9ucykpIHtcbiAgICAvLyBpZiBwYXNzZWQgaW4gaGFzaCBvYmplY3RcbiAgICBjb25zdCBjb25kaXRpb25zTWFwID0gY29uZGl0aW9ucztcbiAgICBjb25kaXRpb25MaXN0ID0gT2JqZWN0LmtleXMoY29uZGl0aW9uc01hcCkubWFwKChrZXkpID0+ICh7XG4gICAgICBrZXksXG4gICAgICB2YWx1ZTogY29uZGl0aW9uc01hcFtrZXldLFxuICAgIH0pKTtcbiAgfSBlbHNlIHtcbiAgICBjb25kaXRpb25MaXN0ID0gY29uZGl0aW9ucy5tYXAoKGNvbmQpID0+IHtcbiAgICAgIGNvbnN0IGNvbmRzID0gT2JqZWN0LmtleXMoY29uZCkubWFwKChrZXkpID0+ICh7IGtleSwgdmFsdWU6IGNvbmRba2V5XSB9KSk7XG4gICAgICByZXR1cm4gY29uZHMubGVuZ3RoID4gMVxuICAgICAgICA/IHsga2V5OiAnJGFuZCcsIHZhbHVlOiBjb25kcy5tYXAoKGMpID0+ICh7IFtjLmtleV06IGMudmFsdWUgfSkpIH1cbiAgICAgICAgOiBjb25kc1swXTtcbiAgICB9KTtcbiAgfVxuICBjb25zdCBjb25kaXRpb25DbGF1c2VzID0gKGNvbmRpdGlvbkxpc3RcbiAgICAubWFwKChjb25kKSA9PiB7XG4gICAgICBsZXQgZCA9IGRlcHRoICsgMTtcbiAgICAgIGxldCBvcDogT3B0aW9uYWw8TG9naWNhbE9wZXJhdG9yPjtcbiAgICAgIHN3aXRjaCAoY29uZC5rZXkpIHtcbiAgICAgICAgY2FzZSAnJG9yJzpcbiAgICAgICAgY2FzZSAnJGFuZCc6XG4gICAgICAgIGNhc2UgJyRub3QnOlxuICAgICAgICAgIGlmIChvcGVyYXRvciAhPT0gJ05PVCcgJiYgY29uZGl0aW9uTGlzdC5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgIGQgPSBkZXB0aDsgLy8gbm90IGNoYW5nZSB0cmVlIGRlcHRoXG4gICAgICAgICAgfVxuICAgICAgICAgIG9wID0gY29uZC5rZXkgPT09ICckb3InID8gJ09SJyA6IGNvbmQua2V5ID09PSAnJGFuZCcgPyAnQU5EJyA6ICdOT1QnO1xuICAgICAgICAgIHJldHVybiBjcmVhdGVDb25kaXRpb25DbGF1c2UoY29uZC52YWx1ZSwgb3AsIGQpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiBjcmVhdGVGaWVsZEV4cHJlc3Npb24oY29uZC5rZXksIGNvbmQudmFsdWUpO1xuICAgICAgfVxuICAgIH0pXG4gICAgLmZpbHRlcigoZXhwcikgPT4gZXhwcikgYXMgYW55KSBhcyBzdHJpbmdbXTtcblxuICBsZXQgaGFzUGFyZW46IGJvb2xlYW47XG4gIGlmIChvcGVyYXRvciA9PT0gJ05PVCcpIHtcbiAgICBoYXNQYXJlbiA9IGRlcHRoID4gMDtcbiAgICByZXR1cm4gYCR7aGFzUGFyZW4gPyAnKCcgOiAnJ31OT1QgJHtjb25kaXRpb25DbGF1c2VzWzBdfSR7XG4gICAgICBoYXNQYXJlbiA/ICcpJyA6ICcnXG4gICAgfWA7XG4gIH1cbiAgaGFzUGFyZW4gPSBkZXB0aCA+IDAgJiYgY29uZGl0aW9uQ2xhdXNlcy5sZW5ndGggPiAxO1xuICByZXR1cm4gKFxuICAgIChoYXNQYXJlbiA/ICcoJyA6ICcnKSArXG4gICAgY29uZGl0aW9uQ2xhdXNlcy5qb2luKGAgJHtvcGVyYXRvcn0gYCkgK1xuICAgIChoYXNQYXJlbiA/ICcpJyA6ICcnKVxuICApO1xufVxuXG4vKipcbiAqIENyZWF0ZSBTT1FMXG4gKiBAcHJpdmF0ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU09RTChxdWVyeTogUXVlcnlDb25maWcpOiBzdHJpbmcge1xuICBsZXQgc29xbCA9IFtcbiAgICAnU0VMRUNUICcsXG4gICAgY3JlYXRlRmllbGRzQ2xhdXNlKHF1ZXJ5LmZpZWxkcywgcXVlcnkuaW5jbHVkZXMpLFxuICAgICcgRlJPTSAnLFxuICAgIHF1ZXJ5LnRhYmxlLFxuICBdLmpvaW4oJycpO1xuICBjb25zdCBjb25kID0gY3JlYXRlQ29uZGl0aW9uQ2xhdXNlKHF1ZXJ5LmNvbmRpdGlvbnMpO1xuICBpZiAoY29uZCkge1xuICAgIHNvcWwgKz0gYCBXSEVSRSAke2NvbmR9YDtcbiAgfVxuICBjb25zdCBvcmRlcmJ5ID0gY3JlYXRlT3JkZXJCeUNsYXVzZShxdWVyeS5zb3J0KTtcbiAgaWYgKG9yZGVyYnkpIHtcbiAgICBzb3FsICs9IGAgT1JERVIgQlkgJHtvcmRlcmJ5fWA7XG4gIH1cbiAgaWYgKHF1ZXJ5LmxpbWl0KSB7XG4gICAgc29xbCArPSBgIExJTUlUICR7cXVlcnkubGltaXR9YDtcbiAgfVxuICBpZiAocXVlcnkub2Zmc2V0KSB7XG4gICAgc29xbCArPSBgIE9GRlNFVCAke3F1ZXJ5Lm9mZnNldH1gO1xuICB9XG4gIHJldHVybiBzb3FsO1xufVxuIl19