import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _findInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/find";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _sortInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/sort";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context14; _forEachInstanceProperty(_context14 = ownKeys(Object(source), true)).call(_context14, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context15; _forEachInstanceProperty(_context15 = ownKeys(Object(source))).call(_context15, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */
import { getLogger } from './util/logger';
import RecordReference from './record-reference';
import Query, { ResponseTargets } from './query';
import QuickAction from './quick-action';

/**
 * A class for organizing all SObject access
 */
export var SObject = /*#__PURE__*/function () {
  // layouts: (ln?: string) => Promise<DescribeLayoutResult>;
  // compactLayouts: () => Promise<DescribeCompactLayoutsResult>;
  // approvalLayouts: () => Promise<DescribeApprovalLayoutsResult>;

  /**
   *
   */
  function SObject(conn, type) {
    var _this = this;

    _classCallCheck(this, SObject);

    _defineProperty(this, "type", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "layouts$", void 0);

    _defineProperty(this, "layouts$$", void 0);

    _defineProperty(this, "compactLayouts$", void 0);

    _defineProperty(this, "compactLayouts$$", void 0);

    _defineProperty(this, "approvalLayouts$", void 0);

    _defineProperty(this, "approvalLayouts$$", void 0);

    _defineProperty(this, "insert", this.create);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    _defineProperty(this, "insertBulk", this.createBulk);

    _defineProperty(this, "deleteBulk", this.destroyBulk);

    _defineProperty(this, "deleteHardBulk", this.destroyHardBulk);

    this.type = type;
    this._conn = conn;
    this._logger = conn._logLevel ? SObject._logger.createInstance(conn._logLevel) : SObject._logger;
    var cache = this._conn.cache;

    var layoutCacheKey = function layoutCacheKey(layoutName) {
      return layoutName ? "layouts.namedLayouts.".concat(layoutName) : "layouts.".concat(_this.type);
    };

    var layouts = SObject.prototype.layouts;
    this.layouts = cache.createCachedFunction(layouts, this, {
      key: layoutCacheKey,
      strategy: 'NOCACHE'
    });
    this.layouts$ = cache.createCachedFunction(layouts, this, {
      key: layoutCacheKey,
      strategy: 'HIT'
    });
    this.layouts$$ = cache.createCachedFunction(layouts, this, {
      key: layoutCacheKey,
      strategy: 'IMMEDIATE'
    });
    var compactLayoutCacheKey = "compactLayouts.".concat(this.type);
    var compactLayouts = SObject.prototype.compactLayouts;
    this.compactLayouts = cache.createCachedFunction(compactLayouts, this, {
      key: compactLayoutCacheKey,
      strategy: 'NOCACHE'
    });
    this.compactLayouts$ = cache.createCachedFunction(compactLayouts, this, {
      key: compactLayoutCacheKey,
      strategy: 'HIT'
    });
    this.compactLayouts$$ = cache.createCachedFunction(compactLayouts, this, {
      key: compactLayoutCacheKey,
      strategy: 'IMMEDIATE'
    });
    var approvalLayoutCacheKey = "approvalLayouts.".concat(this.type);
    var approvalLayouts = SObject.prototype.approvalLayouts;
    this.approvalLayouts = cache.createCachedFunction(approvalLayouts, this, {
      key: approvalLayoutCacheKey,
      strategy: 'NOCACHE'
    });
    this.approvalLayouts$ = cache.createCachedFunction(approvalLayouts, this, {
      key: approvalLayoutCacheKey,
      strategy: 'HIT'
    });
    this.approvalLayouts$$ = cache.createCachedFunction(approvalLayouts, this, {
      key: approvalLayoutCacheKey,
      strategy: 'IMMEDIATE'
    });
  }
  /**
   * Create records
   */


  _createClass(SObject, [{
    key: "create",
    value: function create(records, options) {
      return this._conn.create(this.type, records, options);
    }
    /**
     * Synonym of SObject#create()
     */

  }, {
    key: "retrieve",
    value: function retrieve(ids, options) {
      return this._conn.retrieve(this.type, ids, options);
    }
    /**
     * Update records
     */

  }, {
    key: "update",
    value: function update(records, options) {
      return this._conn.update(this.type, records, options);
    }
    /**
     * Upsert records
     */

  }, {
    key: "upsert",
    value: function upsert(records, extIdField, options) {
      return this._conn.upsert(this.type, records, extIdField, options);
    }
    /**
     * Delete records
     */

  }, {
    key: "destroy",
    value: function destroy(ids, options) {
      return this._conn.destroy(this.type, ids, options);
    }
    /**
     * Synonym of SObject#destroy()
     */

  }, {
    key: "bulkload",

    /**
     * Call Bulk#load() to execute bulkload, returning batch object
     */
    value: function bulkload(operation, optionsOrInput, input) {
      return this._conn.bulk.load(this.type, operation, optionsOrInput, input);
    }
    /**
     * Bulkly insert input data using bulk API
     */

  }, {
    key: "createBulk",
    value: function createBulk(input) {
      return this.bulkload('insert', input);
    }
    /**
     * Synonym of SObject#createBulk()
     */

  }, {
    key: "updateBulk",

    /**
     * Bulkly update records by input data using bulk API
     */
    value: function updateBulk(input) {
      return this.bulkload('update', input);
    }
    /**
     * Bulkly upsert records by input data using bulk API
     */

  }, {
    key: "upsertBulk",
    value: function upsertBulk(input, extIdField) {
      return this.bulkload('upsert', {
        extIdField: extIdField
      }, input);
    }
    /**
     * Bulkly delete records specified by input data using bulk API
     */

  }, {
    key: "destroyBulk",
    value: function destroyBulk(input) {
      return this.bulkload('delete', input);
    }
    /**
     * Synonym of SObject#destroyBulk()
     */

  }, {
    key: "destroyHardBulk",

    /**
     * Bulkly hard delete records specified in input data using bulk API
     */
    value: function destroyHardBulk(input) {
      return this.bulkload('hardDelete', input);
    }
    /**
     * Synonym of SObject#destroyHardBulk()
     */

  }, {
    key: "describe",

    /**
     * Describe SObject metadata
     */
    value: function describe() {
      return this._conn.describe(this.type);
    }
    /**
     *
     */

  }, {
    key: "describe$",
    value: function describe$() {
      return this._conn.describe$(this.type);
    }
    /**
     *
     */

  }, {
    key: "describe$$",
    value: function describe$$() {
      return this._conn.describe$$(this.type);
    }
    /**
     * Get record representation instance by given id
     */

  }, {
    key: "record",
    value: function record(id) {
      return new RecordReference(this._conn, this.type, id);
    }
    /**
     * Retrieve recently accessed records
     */

  }, {
    key: "recent",
    value: function recent() {
      return this._conn.recent(this.type);
    }
    /**
     * Retrieve the updated records
     */

  }, {
    key: "updated",
    value: function updated(start, end) {
      return this._conn.updated(this.type, start, end);
    }
    /**
     * Retrieve the deleted records
     */

  }, {
    key: "deleted",
    value: function deleted(start, end) {
      return this._conn.deleted(this.type, start, end);
    }
    /**
     * Describe layout information for SObject
     */

  }, {
    key: "layouts",
    value: function () {
      var _layouts = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(layoutName) {
        var _context;

        var url, body;
        return _regeneratorRuntime.wrap(function _callee$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                url = _concatInstanceProperty(_context = "/sobjects/".concat(this.type, "/describe/")).call(_context, layoutName ? "namedLayouts/".concat(layoutName) : 'layouts');
                _context2.next = 3;
                return this._conn.request(url);

              case 3:
                body = _context2.sent;
                return _context2.abrupt("return", body);

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee, this);
      }));

      function layouts(_x) {
        return _layouts.apply(this, arguments);
      }

      return layouts;
    }()
    /**
     * @typedef {Object} CompactLayoutInfo
     * @prop {Array.<Object>} compactLayouts - Array of compact layouts
     * @prop {String} defaultCompactLayoutId - ID of default compact layout
     * @prop {Array.<Object>} recordTypeCompactLayoutMappings - Array of record type mappings
     */

    /**
     * Describe compact layout information defined for SObject
     *
     * @param {Callback.<CompactLayoutInfo>} [callback] - Callback function
     * @returns {Promise.<CompactLayoutInfo>}
     */

  }, {
    key: "compactLayouts",
    value: function () {
      var _compactLayouts = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee2$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                url = "/sobjects/".concat(this.type, "/describe/compactLayouts");
                _context3.next = 3;
                return this._conn.request(url);

              case 3:
                body = _context3.sent;
                return _context3.abrupt("return", body);

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee2, this);
      }));

      function compactLayouts() {
        return _compactLayouts.apply(this, arguments);
      }

      return compactLayouts;
    }()
    /**
     * Describe compact layout information defined for SObject
     *
     * @param {Callback.<ApprovalLayoutInfo>} [callback] - Callback function
     * @returns {Promise.<ApprovalLayoutInfo>}
     */

  }, {
    key: "approvalLayouts",
    value: function () {
      var _approvalLayouts = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee3$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                url = "/sobjects/".concat(this.type, "/describe/approvalLayouts");
                _context4.next = 3;
                return this._conn.request(url);

              case 3:
                body = _context4.sent;
                return _context4.abrupt("return", body);

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee3, this);
      }));

      function approvalLayouts() {
        return _approvalLayouts.apply(this, arguments);
      }

      return approvalLayouts;
    }()
    /**
     * Find and fetch records which matches given conditions
     */

  }, {
    key: "find",
    value: function find(conditions, fields) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      var sort = _sortInstanceProperty(options),
          limit = options.limit,
          offset = options.offset,
          qoptions = _objectWithoutProperties(options, ["sort", "limit", "offset"]);

      var config = {
        fields: fields == null ? undefined : fields,
        includes: _includesInstanceProperty(options),
        table: this.type,
        conditions: conditions == null ? undefined : conditions,
        sort: sort,
        limit: limit,
        offset: offset
      };
      var query = new Query(this._conn, config, qoptions);
      return query.setResponseTarget(ResponseTargets.Records);
    }
    /**
     * Fetch one record which matches given conditions
     */

  }, {
    key: "findOne",
    value: function findOne(conditions, fields) {
      var _context5;

      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

      var query = _findInstanceProperty(_context5 = this).call(_context5, conditions, fields, _objectSpread(_objectSpread({}, options), {}, {
        limit: 1
      }));

      return query.setResponseTarget(ResponseTargets.SingleRecord);
    }
    /**
     * Find and fetch records only by specifying fields to fetch.
     */

  }, {
    key: "select",
    value: function select(fields) {
      var _context6;

      return _findInstanceProperty(_context6 = this).call(_context6, null, fields);
    }
    /**
     * Count num of records which matches given conditions
     */

  }, {
    key: "count",
    value: function count(conditions) {
      var _context7;

      var query = _findInstanceProperty(_context7 = this).call(_context7, conditions, 'count()');

      return query.setResponseTarget(ResponseTargets.Count);
    }
    /**
     * Returns the list of list views for the SObject
     *
     * @param {Callback.<ListViewsInfo>} [callback] - Callback function
     * @returns {Promise.<ListViewsInfo>}
     */

  }, {
    key: "listviews",
    value: function listviews() {
      var _context8;

      var url = _concatInstanceProperty(_context8 = "".concat(this._conn._baseUrl(), "/sobjects/")).call(_context8, this.type, "/listviews");

      return this._conn.request(url);
    }
    /**
     * Returns the list view info in specifed view id
     *
     * @param {String} id - List view ID
     * @returns {ListView}
     */

  }, {
    key: "listview",
    value: function listview(id) {
      return new ListView(this._conn, this.type, id); // eslint-disable-line no-use-before-define
    }
    /**
     * Returns all registered quick actions for the SObject
     *
     * @param {Callback.<Array.<QuickAction~QuickActionInfo>>} [callback] - Callback function
     * @returns {Promise.<Array.<QuickAction~QuickActionInfo>>}
     */

  }, {
    key: "quickActions",
    value: function quickActions() {
      return this._conn.request("/sobjects/".concat(this.type, "/quickActions"));
    }
    /**
     * Get reference for specified quick aciton in the SObject
     *
     * @param {String} actionName - Name of the quick action
     * @returns {QuickAction}
     */

  }, {
    key: "quickAction",
    value: function quickAction(actionName) {
      var _context9;

      return new QuickAction(this._conn, _concatInstanceProperty(_context9 = "/sobjects/".concat(this.type, "/quickActions/")).call(_context9, actionName));
    }
  }]);

  return SObject;
}();
/**
 * A class for organizing list view information
 *
 * @protected
 * @class ListView
 * @param {Connection} conn - Connection instance
 * @param {SObject} type - SObject type
 * @param {String} id - List view ID
 */

_defineProperty(SObject, "_logger", getLogger('sobject'));

var ListView = /*#__PURE__*/function () {
  /**
   *
   */
  function ListView(conn, type, id) {
    _classCallCheck(this, ListView);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "type", void 0);

    _defineProperty(this, "id", void 0);

    this._conn = conn;
    this.type = type;
    this.id = id;
  }
  /**
   * Executes query for the list view and returns the resulting data and presentation information.
   */


  _createClass(ListView, [{
    key: "results",
    value: function results() {
      var _context10, _context11;

      var url = _concatInstanceProperty(_context10 = _concatInstanceProperty(_context11 = "".concat(this._conn._baseUrl(), "/sobjects/")).call(_context11, this.type, "/listviews/")).call(_context10, this.id, "/results");

      return this._conn.request(url);
    }
    /**
     * Returns detailed information about a list view
     */

  }, {
    key: "describe",
    value: function describe() {
      var _context12, _context13;

      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var url = _concatInstanceProperty(_context12 = _concatInstanceProperty(_context13 = "".concat(this._conn._baseUrl(), "/sobjects/")).call(_context13, this.type, "/listviews/")).call(_context12, this.id, "/describe");

      return this._conn.request({
        method: 'GET',
        url: url,
        headers: options.headers
      });
    }
    /**
     * Explain plan for executing list view
     */

  }, {
    key: "explain",
    value: function explain() {
      var url = "/query/?explain=".concat(this.id);
      return this._conn.request(url);
    }
  }]);

  return ListView;
}();

export default SObject; // TODO Bulk
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zb2JqZWN0LnRzIl0sIm5hbWVzIjpbImdldExvZ2dlciIsIlJlY29yZFJlZmVyZW5jZSIsIlF1ZXJ5IiwiUmVzcG9uc2VUYXJnZXRzIiwiUXVpY2tBY3Rpb24iLCJTT2JqZWN0IiwiY29ubiIsInR5cGUiLCJjcmVhdGUiLCJkZXN0cm95IiwiY3JlYXRlQnVsayIsImRlc3Ryb3lCdWxrIiwiZGVzdHJveUhhcmRCdWxrIiwiX2Nvbm4iLCJfbG9nZ2VyIiwiX2xvZ0xldmVsIiwiY3JlYXRlSW5zdGFuY2UiLCJjYWNoZSIsImxheW91dENhY2hlS2V5IiwibGF5b3V0TmFtZSIsImxheW91dHMiLCJwcm90b3R5cGUiLCJjcmVhdGVDYWNoZWRGdW5jdGlvbiIsImtleSIsInN0cmF0ZWd5IiwibGF5b3V0cyQiLCJsYXlvdXRzJCQiLCJjb21wYWN0TGF5b3V0Q2FjaGVLZXkiLCJjb21wYWN0TGF5b3V0cyIsImNvbXBhY3RMYXlvdXRzJCIsImNvbXBhY3RMYXlvdXRzJCQiLCJhcHByb3ZhbExheW91dENhY2hlS2V5IiwiYXBwcm92YWxMYXlvdXRzIiwiYXBwcm92YWxMYXlvdXRzJCIsImFwcHJvdmFsTGF5b3V0cyQkIiwicmVjb3JkcyIsIm9wdGlvbnMiLCJpZHMiLCJyZXRyaWV2ZSIsInVwZGF0ZSIsImV4dElkRmllbGQiLCJ1cHNlcnQiLCJvcGVyYXRpb24iLCJvcHRpb25zT3JJbnB1dCIsImlucHV0IiwiYnVsayIsImxvYWQiLCJidWxrbG9hZCIsImRlc2NyaWJlIiwiZGVzY3JpYmUkIiwiZGVzY3JpYmUkJCIsImlkIiwicmVjZW50Iiwic3RhcnQiLCJlbmQiLCJ1cGRhdGVkIiwiZGVsZXRlZCIsInVybCIsInJlcXVlc3QiLCJib2R5IiwiY29uZGl0aW9ucyIsImZpZWxkcyIsInNvcnQiLCJsaW1pdCIsIm9mZnNldCIsInFvcHRpb25zIiwiY29uZmlnIiwidW5kZWZpbmVkIiwiaW5jbHVkZXMiLCJ0YWJsZSIsInF1ZXJ5Iiwic2V0UmVzcG9uc2VUYXJnZXQiLCJSZWNvcmRzIiwiU2luZ2xlUmVjb3JkIiwiQ291bnQiLCJfYmFzZVVybCIsIkxpc3RWaWV3IiwiYWN0aW9uTmFtZSIsIm1ldGhvZCIsImhlYWRlcnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQWlCQSxTQUFqQixRQUFrQyxlQUFsQztBQXNCQSxPQUFPQyxlQUFQLE1BQTRCLG9CQUE1QjtBQUNBLE9BQU9DLEtBQVAsSUFDRUMsZUFERixRQU1PLFNBTlA7QUFPQSxPQUFPQyxXQUFQLE1BQXdCLGdCQUF4Qjs7QUFZQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxPQUFiO0FBY0U7QUFHQTtBQUdBOztBQU1BO0FBQ0Y7QUFDQTtBQUNFLG1CQUFZQyxJQUFaLEVBQWlDQyxJQUFqQyxFQUEwQztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9DQXNFakMsS0FBS0MsTUF0RTRCOztBQUFBLG9DQTRJakMsS0FBS0MsT0E1STRCOztBQUFBLGlDQWlKcEMsS0FBS0EsT0FqSitCOztBQUFBLHdDQXdLN0IsS0FBS0MsVUF4S3dCOztBQUFBLHdDQWtNN0IsS0FBS0MsV0FsTXdCOztBQUFBLDRDQThNekIsS0FBS0MsZUE5TW9COztBQUN4QyxTQUFLTCxJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLTSxLQUFMLEdBQWFQLElBQWI7QUFDQSxTQUFLUSxPQUFMLEdBQWVSLElBQUksQ0FBQ1MsU0FBTCxHQUNYVixPQUFPLENBQUNTLE9BQVIsQ0FBZ0JFLGNBQWhCLENBQStCVixJQUFJLENBQUNTLFNBQXBDLENBRFcsR0FFWFYsT0FBTyxDQUFDUyxPQUZaO0FBR0EsUUFBTUcsS0FBSyxHQUFHLEtBQUtKLEtBQUwsQ0FBV0ksS0FBekI7O0FBQ0EsUUFBTUMsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDQyxVQUFEO0FBQUEsYUFDckJBLFVBQVUsa0NBQ2tCQSxVQURsQixzQkFFSyxLQUFJLENBQUNaLElBRlYsQ0FEVztBQUFBLEtBQXZCOztBQUlBLFFBQU1hLE9BQU8sR0FBR2YsT0FBTyxDQUFDZ0IsU0FBUixDQUFrQkQsT0FBbEM7QUFDQSxTQUFLQSxPQUFMLEdBQWVILEtBQUssQ0FBQ0ssb0JBQU4sQ0FBMkJGLE9BQTNCLEVBQW9DLElBQXBDLEVBQTBDO0FBQ3ZERyxNQUFBQSxHQUFHLEVBQUVMLGNBRGtEO0FBRXZETSxNQUFBQSxRQUFRLEVBQUU7QUFGNkMsS0FBMUMsQ0FBZjtBQUlBLFNBQUtDLFFBQUwsR0FBZ0JSLEtBQUssQ0FBQ0ssb0JBQU4sQ0FBMkJGLE9BQTNCLEVBQW9DLElBQXBDLEVBQTBDO0FBQ3hERyxNQUFBQSxHQUFHLEVBQUVMLGNBRG1EO0FBRXhETSxNQUFBQSxRQUFRLEVBQUU7QUFGOEMsS0FBMUMsQ0FBaEI7QUFJQSxTQUFLRSxTQUFMLEdBQWlCVCxLQUFLLENBQUNLLG9CQUFOLENBQTJCRixPQUEzQixFQUFvQyxJQUFwQyxFQUEwQztBQUN6REcsTUFBQUEsR0FBRyxFQUFFTCxjQURvRDtBQUV6RE0sTUFBQUEsUUFBUSxFQUFFO0FBRitDLEtBQTFDLENBQWpCO0FBSUEsUUFBTUcscUJBQXFCLDRCQUFxQixLQUFLcEIsSUFBMUIsQ0FBM0I7QUFDQSxRQUFNcUIsY0FBYyxHQUFHdkIsT0FBTyxDQUFDZ0IsU0FBUixDQUFrQk8sY0FBekM7QUFDQSxTQUFLQSxjQUFMLEdBQXNCWCxLQUFLLENBQUNLLG9CQUFOLENBQTJCTSxjQUEzQixFQUEyQyxJQUEzQyxFQUFpRDtBQUNyRUwsTUFBQUEsR0FBRyxFQUFFSSxxQkFEZ0U7QUFFckVILE1BQUFBLFFBQVEsRUFBRTtBQUYyRCxLQUFqRCxDQUF0QjtBQUlBLFNBQUtLLGVBQUwsR0FBdUJaLEtBQUssQ0FBQ0ssb0JBQU4sQ0FBMkJNLGNBQTNCLEVBQTJDLElBQTNDLEVBQWlEO0FBQ3RFTCxNQUFBQSxHQUFHLEVBQUVJLHFCQURpRTtBQUV0RUgsTUFBQUEsUUFBUSxFQUFFO0FBRjRELEtBQWpELENBQXZCO0FBSUEsU0FBS00sZ0JBQUwsR0FBd0JiLEtBQUssQ0FBQ0ssb0JBQU4sQ0FBMkJNLGNBQTNCLEVBQTJDLElBQTNDLEVBQWlEO0FBQ3ZFTCxNQUFBQSxHQUFHLEVBQUVJLHFCQURrRTtBQUV2RUgsTUFBQUEsUUFBUSxFQUFFO0FBRjZELEtBQWpELENBQXhCO0FBSUEsUUFBTU8sc0JBQXNCLDZCQUFzQixLQUFLeEIsSUFBM0IsQ0FBNUI7QUFDQSxRQUFNeUIsZUFBZSxHQUFHM0IsT0FBTyxDQUFDZ0IsU0FBUixDQUFrQlcsZUFBMUM7QUFDQSxTQUFLQSxlQUFMLEdBQXVCZixLQUFLLENBQUNLLG9CQUFOLENBQTJCVSxlQUEzQixFQUE0QyxJQUE1QyxFQUFrRDtBQUN2RVQsTUFBQUEsR0FBRyxFQUFFUSxzQkFEa0U7QUFFdkVQLE1BQUFBLFFBQVEsRUFBRTtBQUY2RCxLQUFsRCxDQUF2QjtBQUlBLFNBQUtTLGdCQUFMLEdBQXdCaEIsS0FBSyxDQUFDSyxvQkFBTixDQUEyQlUsZUFBM0IsRUFBNEMsSUFBNUMsRUFBa0Q7QUFDeEVULE1BQUFBLEdBQUcsRUFBRVEsc0JBRG1FO0FBRXhFUCxNQUFBQSxRQUFRLEVBQUU7QUFGOEQsS0FBbEQsQ0FBeEI7QUFJQSxTQUFLVSxpQkFBTCxHQUF5QmpCLEtBQUssQ0FBQ0ssb0JBQU4sQ0FBMkJVLGVBQTNCLEVBQTRDLElBQTVDLEVBQWtEO0FBQ3pFVCxNQUFBQSxHQUFHLEVBQUVRLHNCQURvRTtBQUV6RVAsTUFBQUEsUUFBUSxFQUFFO0FBRitELEtBQWxELENBQXpCO0FBSUQ7QUFFRDtBQUNGO0FBQ0E7OztBQXJGQTtBQUFBO0FBQUEsMkJBNEZTVyxPQTVGVCxFQTRGK0NDLE9BNUYvQyxFQTRGcUU7QUFDakUsYUFBTyxLQUFLdkIsS0FBTCxDQUFXTCxNQUFYLENBQWtCLEtBQUtELElBQXZCLEVBQTZCNEIsT0FBN0IsRUFBc0NDLE9BQXRDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFsR0E7QUFBQTtBQUFBLDZCQThHV0MsR0E5R1gsRUE4R21DRCxPQTlHbkMsRUE4RzhEO0FBQzFELGFBQU8sS0FBS3ZCLEtBQUwsQ0FBV3lCLFFBQVgsQ0FBb0IsS0FBSy9CLElBQXpCLEVBQStCOEIsR0FBL0IsRUFBb0NELE9BQXBDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFwSEE7QUFBQTtBQUFBLDJCQTJIU0QsT0EzSFQsRUEySGlEQyxPQTNIakQsRUEySHVFO0FBQ25FLGFBQU8sS0FBS3ZCLEtBQUwsQ0FBVzBCLE1BQVgsQ0FBa0IsS0FBS2hDLElBQXZCLEVBQTZCNEIsT0FBN0IsRUFBc0NDLE9BQXRDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFqSUE7QUFBQTtBQUFBLDJCQWtKSUQsT0FsSkosRUFtSklLLFVBbkpKLEVBb0pJSixPQXBKSixFQXFKSTtBQUNBLGFBQU8sS0FBS3ZCLEtBQUwsQ0FBVzRCLE1BQVgsQ0FBa0IsS0FBS2xDLElBQXZCLEVBQTZCNEIsT0FBN0IsRUFBc0NLLFVBQXRDLEVBQWtESixPQUFsRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBM0pBO0FBQUE7QUFBQSw0QkFrS1VDLEdBbEtWLEVBa0trQ0QsT0FsS2xDLEVBa0t3RDtBQUNwRCxhQUFPLEtBQUt2QixLQUFMLENBQVdKLE9BQVgsQ0FBbUIsS0FBS0YsSUFBeEIsRUFBOEI4QixHQUE5QixFQUFtQ0QsT0FBbkMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXhLQTtBQUFBOztBQWdMRTtBQUNGO0FBQ0E7QUFsTEEsNkJBb0xJTSxTQXBMSixFQXFMSUMsY0FyTEosRUFzTElDLEtBdExKLEVBdUxJO0FBQ0EsYUFBTyxLQUFLL0IsS0FBTCxDQUFXZ0MsSUFBWCxDQUFnQkMsSUFBaEIsQ0FBcUIsS0FBS3ZDLElBQTFCLEVBQWdDbUMsU0FBaEMsRUFBMkNDLGNBQTNDLEVBQTJEQyxLQUEzRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBN0xBO0FBQUE7QUFBQSwrQkE4TGFBLEtBOUxiLEVBOExtRDtBQUMvQyxhQUFPLEtBQUtHLFFBQUwsQ0FBYyxRQUFkLEVBQXdCSCxLQUF4QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBcE1BO0FBQUE7O0FBdU1FO0FBQ0Y7QUFDQTtBQXpNQSwrQkEwTWFBLEtBMU1iLEVBME1tRDtBQUMvQyxhQUFPLEtBQUtHLFFBQUwsQ0FBYyxRQUFkLEVBQXdCSCxLQUF4QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBaE5BO0FBQUE7QUFBQSwrQkFpTmFBLEtBak5iLEVBaU5tREosVUFqTm5ELEVBaU53RTtBQUNwRSxhQUFPLEtBQUtPLFFBQUwsQ0FBYyxRQUFkLEVBQXdCO0FBQUVQLFFBQUFBLFVBQVUsRUFBVkE7QUFBRixPQUF4QixFQUF3Q0ksS0FBeEMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXZOQTtBQUFBO0FBQUEsZ0NBd05jQSxLQXhOZCxFQXdOb0Q7QUFDaEQsYUFBTyxLQUFLRyxRQUFMLENBQWMsUUFBZCxFQUF3QkgsS0FBeEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTlOQTtBQUFBOztBQWlPRTtBQUNGO0FBQ0E7QUFuT0Esb0NBb09rQkEsS0FwT2xCLEVBb084QztBQUMxQyxhQUFPLEtBQUtHLFFBQUwsQ0FBYyxZQUFkLEVBQTRCSCxLQUE1QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBMU9BO0FBQUE7O0FBNk9FO0FBQ0Y7QUFDQTtBQS9PQSwrQkFnUGE7QUFDVCxhQUFPLEtBQUsvQixLQUFMLENBQVdtQyxRQUFYLENBQW9CLEtBQUt6QyxJQUF6QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBdFBBO0FBQUE7QUFBQSxnQ0F1UGM7QUFDVixhQUFPLEtBQUtNLEtBQUwsQ0FBV29DLFNBQVgsQ0FBcUIsS0FBSzFDLElBQTFCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE3UEE7QUFBQTtBQUFBLGlDQThQZTtBQUNYLGFBQU8sS0FBS00sS0FBTCxDQUFXcUMsVUFBWCxDQUFzQixLQUFLM0MsSUFBM0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXBRQTtBQUFBO0FBQUEsMkJBcVFTNEMsRUFyUVQsRUFxUTRDO0FBQ3hDLGFBQU8sSUFBSWxELGVBQUosQ0FBb0IsS0FBS1ksS0FBekIsRUFBZ0MsS0FBS04sSUFBckMsRUFBMkM0QyxFQUEzQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBM1FBO0FBQUE7QUFBQSw2QkE0UVc7QUFDUCxhQUFPLEtBQUt0QyxLQUFMLENBQVd1QyxNQUFYLENBQWtCLEtBQUs3QyxJQUF2QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbFJBO0FBQUE7QUFBQSw0QkFtUlU4QyxLQW5SVixFQW1SZ0NDLEdBblJoQyxFQW1Sb0Q7QUFDaEQsYUFBTyxLQUFLekMsS0FBTCxDQUFXMEMsT0FBWCxDQUFtQixLQUFLaEQsSUFBeEIsRUFBOEI4QyxLQUE5QixFQUFxQ0MsR0FBckMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXpSQTtBQUFBO0FBQUEsNEJBMFJVRCxLQTFSVixFQTBSZ0NDLEdBMVJoQyxFQTBSb0Q7QUFDaEQsYUFBTyxLQUFLekMsS0FBTCxDQUFXMkMsT0FBWCxDQUFtQixLQUFLakQsSUFBeEIsRUFBOEI4QyxLQUE5QixFQUFxQ0MsR0FBckMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWhTQTtBQUFBO0FBQUE7QUFBQSwrRkFpU2dCbkMsVUFqU2hCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWtTVXNDLGdCQUFBQSxHQWxTViwwREFrUzZCLEtBQUtsRCxJQWxTbEMsZ0NBbVNNWSxVQUFVLDBCQUFtQkEsVUFBbkIsSUFBa0MsU0FuU2xEO0FBQUE7QUFBQSx1QkFxU3VCLEtBQUtOLEtBQUwsQ0FBVzZDLE9BQVgsQ0FBbUJELEdBQW5CLENBclN2Qjs7QUFBQTtBQXFTVUUsZ0JBQUFBLElBclNWO0FBQUEsa0RBc1NXQSxJQXRTWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXlTRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0U7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXBUQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFzVFVGLGdCQUFBQSxHQXRUVix1QkFzVDZCLEtBQUtsRCxJQXRUbEM7QUFBQTtBQUFBLHVCQXVUdUIsS0FBS00sS0FBTCxDQUFXNkMsT0FBWCxDQUFtQkQsR0FBbkIsQ0F2VHZCOztBQUFBO0FBdVRVRSxnQkFBQUEsSUF2VFY7QUFBQSxrREF3VFdBLElBeFRYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMlRFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFoVUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBa1VVRixnQkFBQUEsR0FsVVYsdUJBa1U2QixLQUFLbEQsSUFsVWxDO0FBQUE7QUFBQSx1QkFtVXVCLEtBQUtNLEtBQUwsQ0FBVzZDLE9BQVgsQ0FBbUJELEdBQW5CLENBblV2Qjs7QUFBQTtBQW1VVUUsZ0JBQUFBLElBblVWO0FBQUEsa0RBb1VXQSxJQXBVWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXVVRTtBQUNGO0FBQ0E7O0FBelVBO0FBQUE7QUFBQSx5QkF1VklDLFVBdlZKLEVBd1ZJQyxNQXhWSixFQTBWaUM7QUFBQSxVQUQ3QnpCLE9BQzZCLHVFQURBLEVBQ0E7O0FBQUEsVUFDckIwQixJQURxQix5QkFDZ0IxQixPQURoQjtBQUFBLFVBQ2YyQixLQURlLEdBQ2dCM0IsT0FEaEIsQ0FDZjJCLEtBRGU7QUFBQSxVQUNSQyxNQURRLEdBQ2dCNUIsT0FEaEIsQ0FDUjRCLE1BRFE7QUFBQSxVQUNHQyxRQURILDRCQUNnQjdCLE9BRGhCOztBQUU3QixVQUFNOEIsTUFBeUIsR0FBRztBQUNoQ0wsUUFBQUEsTUFBTSxFQUFFQSxNQUFNLElBQUksSUFBVixHQUFpQk0sU0FBakIsR0FBNkJOLE1BREw7QUFFaENPLFFBQUFBLFFBQVEsNEJBQUVoQyxPQUFGLENBRndCO0FBR2hDaUMsUUFBQUEsS0FBSyxFQUFFLEtBQUs5RCxJQUhvQjtBQUloQ3FELFFBQUFBLFVBQVUsRUFBRUEsVUFBVSxJQUFJLElBQWQsR0FBcUJPLFNBQXJCLEdBQWlDUCxVQUpiO0FBS2hDRSxRQUFBQSxJQUFJLEVBQUpBLElBTGdDO0FBTWhDQyxRQUFBQSxLQUFLLEVBQUxBLEtBTmdDO0FBT2hDQyxRQUFBQSxNQUFNLEVBQU5BO0FBUGdDLE9BQWxDO0FBU0EsVUFBTU0sS0FBSyxHQUFHLElBQUlwRSxLQUFKLENBQWdCLEtBQUtXLEtBQXJCLEVBQTRCcUQsTUFBNUIsRUFBb0NELFFBQXBDLENBQWQ7QUFDQSxhQUFPSyxLQUFLLENBQUNDLGlCQUFOLENBQXdCcEUsZUFBZSxDQUFDcUUsT0FBeEMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTNXQTtBQUFBO0FBQUEsNEJBeVhJWixVQXpYSixFQTBYSUMsTUExWEosRUE0WHNDO0FBQUE7O0FBQUEsVUFEbEN6QixPQUNrQyx1RUFETCxFQUNLOztBQUNsQyxVQUFNa0MsS0FBSyxHQUFHLHdEQUFVVixVQUFWLEVBQXNCQyxNQUF0QixrQ0FBbUN6QixPQUFuQztBQUE0QzJCLFFBQUFBLEtBQUssRUFBRTtBQUFuRCxTQUFkOztBQUNBLGFBQU9PLEtBQUssQ0FBQ0MsaUJBQU4sQ0FBd0JwRSxlQUFlLENBQUNzRSxZQUF4QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbllBO0FBQUE7QUFBQSwyQkF5WUlaLE1BellKLEVBMFl5RDtBQUFBOztBQUNyRCxhQUFPLHdEQUFVLElBQVYsRUFBZ0JBLE1BQWhCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFoWkE7QUFBQTtBQUFBLDBCQWlaUUQsVUFqWlIsRUFpWnFEO0FBQUE7O0FBQ2pELFVBQU1VLEtBQUssR0FBRyx3REFBVVYsVUFBVixFQUFzQixTQUF0QixDQUFkOztBQUNBLGFBQU9VLEtBQUssQ0FBQ0MsaUJBQU4sQ0FBd0JwRSxlQUFlLENBQUN1RSxLQUF4QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBM1pBO0FBQUE7QUFBQSxnQ0E0WmM7QUFBQTs7QUFDVixVQUFNakIsR0FBRyxpREFBTSxLQUFLNUMsS0FBTCxDQUFXOEQsUUFBWCxFQUFOLGlDQUF3QyxLQUFLcEUsSUFBN0MsZUFBVDs7QUFDQSxhQUFPLEtBQUtNLEtBQUwsQ0FBVzZDLE9BQVgsQ0FBbUJELEdBQW5CLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUF0YUE7QUFBQTtBQUFBLDZCQXVhV04sRUF2YVgsRUF1YXVCO0FBQ25CLGFBQU8sSUFBSXlCLFFBQUosQ0FBYSxLQUFLL0QsS0FBbEIsRUFBeUIsS0FBS04sSUFBOUIsRUFBb0M0QyxFQUFwQyxDQUFQLENBRG1CLENBQzZCO0FBQ2pEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWhiQTtBQUFBO0FBQUEsbUNBaWJpQjtBQUNiLGFBQU8sS0FBS3RDLEtBQUwsQ0FBVzZDLE9BQVgscUJBQWdDLEtBQUtuRCxJQUFyQyxtQkFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQTFiQTtBQUFBO0FBQUEsZ0NBMmJjc0UsVUEzYmQsRUEyYmtDO0FBQUE7O0FBQzlCLGFBQU8sSUFBSXpFLFdBQUosQ0FDTCxLQUFLUyxLQURBLDBEQUVRLEtBQUtOLElBRmIscUNBRWtDc0UsVUFGbEMsRUFBUDtBQUlEO0FBaGNIOztBQUFBO0FBQUE7QUFtY0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztnQkEzY2F4RSxPLGFBUU1MLFNBQVMsQ0FBQyxTQUFELEM7O0lBb2N0QjRFLFE7QUFLSjtBQUNGO0FBQ0E7QUFDRSxvQkFBWXRFLElBQVosRUFBOEJDLElBQTlCLEVBQTRDNEMsRUFBNUMsRUFBd0Q7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFDdEQsU0FBS3RDLEtBQUwsR0FBYVAsSUFBYjtBQUNBLFNBQUtDLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUs0QyxFQUFMLEdBQVVBLEVBQVY7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7Ozs7OEJBQ1k7QUFBQTs7QUFDUixVQUFNTSxHQUFHLHVGQUFNLEtBQUs1QyxLQUFMLENBQVc4RCxRQUFYLEVBQU4sa0NBQXdDLEtBQUtwRSxJQUE3QyxtQ0FDUCxLQUFLNEMsRUFERSxhQUFUOztBQUdBLGFBQU8sS0FBS3RDLEtBQUwsQ0FBVzZDLE9BQVgsQ0FBbUJELEdBQW5CLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7OzsrQkFDbUU7QUFBQTs7QUFBQSxVQUF4RHJCLE9BQXdELHVFQUFKLEVBQUk7O0FBQy9ELFVBQU1xQixHQUFHLHVGQUFNLEtBQUs1QyxLQUFMLENBQVc4RCxRQUFYLEVBQU4sa0NBQXdDLEtBQUtwRSxJQUE3QyxtQ0FDUCxLQUFLNEMsRUFERSxjQUFUOztBQUdBLGFBQU8sS0FBS3RDLEtBQUwsQ0FBVzZDLE9BQVgsQ0FBbUI7QUFBRW9CLFFBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCckIsUUFBQUEsR0FBRyxFQUFIQSxHQUFqQjtBQUFzQnNCLFFBQUFBLE9BQU8sRUFBRTNDLE9BQU8sQ0FBQzJDO0FBQXZDLE9BQW5CLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7Ozs4QkFDWTtBQUNSLFVBQU10QixHQUFHLDZCQUFzQixLQUFLTixFQUEzQixDQUFUO0FBQ0EsYUFBTyxLQUFLdEMsS0FBTCxDQUFXNkMsT0FBWCxDQUF3QkQsR0FBeEIsQ0FBUDtBQUNEOzs7Ozs7QUFHSCxlQUFlcEQsT0FBZixDLENBRUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IExvZ2dlciwgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQge1xuICBSZWNvcmQsXG4gIERlc2NyaWJlTGF5b3V0UmVzdWx0LFxuICBEZXNjcmliZUNvbXBhY3RMYXlvdXRzUmVzdWx0LFxuICBEZXNjcmliZUFwcHJvdmFsTGF5b3V0c1Jlc3VsdCxcbiAgT3B0aW9uYWwsXG4gIERtbE9wdGlvbnMsXG4gIFNhdmVSZXN1bHQsXG4gIFVwc2VydFJlc3VsdCxcbiAgUmV0cmlldmVPcHRpb25zLFxuICBTY2hlbWEsXG4gIFNPYmplY3ROYW1lcyxcbiAgU09iamVjdFJlY29yZCxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxuICBTT2JqZWN0RmllbGROYW1lcyxcbiAgRmllbGRQcm9qZWN0aW9uQ29uZmlnLFxuICBGaWVsZFBhdGhTcGVjaWZpZXIsXG4gIEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb24sXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCBSZWNvcmRSZWZlcmVuY2UgZnJvbSAnLi9yZWNvcmQtcmVmZXJlbmNlJztcbmltcG9ydCBRdWVyeSwge1xuICBSZXNwb25zZVRhcmdldHMsXG4gIFF1ZXJ5T3B0aW9ucyxcbiAgUXVlcnlGaWVsZCxcbiAgUXVlcnlDb25kaXRpb24sXG4gIFF1ZXJ5Q29uZmlnLFxufSBmcm9tICcuL3F1ZXJ5JztcbmltcG9ydCBRdWlja0FjdGlvbiBmcm9tICcuL3F1aWNrLWFjdGlvbic7XG5pbXBvcnQgeyBDYWNoZWRGdW5jdGlvbiB9IGZyb20gJy4vY2FjaGUnO1xuaW1wb3J0IHsgUmVhZGFibGUgfSBmcm9tICdzdHJlYW0nO1xuXG5leHBvcnQgdHlwZSBGaW5kT3B0aW9uczxTIGV4dGVuZHMgU2NoZW1hLCBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PiA9IFBhcnRpYWw8XG4gIFF1ZXJ5T3B0aW9ucyAmXG4gICAgUGljazxRdWVyeUNvbmZpZzxTLCBOPiwgJ3NvcnQnIHwgJ2luY2x1ZGVzJz4gJiB7XG4gICAgICBsaW1pdDogbnVtYmVyO1xuICAgICAgb2Zmc2V0OiBudW1iZXI7XG4gICAgfVxuPjtcblxuLyoqXG4gKiBBIGNsYXNzIGZvciBvcmdhbml6aW5nIGFsbCBTT2JqZWN0IGFjY2Vzc1xuICovXG5leHBvcnQgY2xhc3MgU09iamVjdDxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgRmllbGROYW1lcyBleHRlbmRzIFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+ID0gU09iamVjdEZpZWxkTmFtZXM8UywgTj4sXG4gIFJldHJpZXZlUmVjb3JkIGV4dGVuZHMgU09iamVjdFJlY29yZDxTLCBOLCAnKic+ID0gU09iamVjdFJlY29yZDxTLCBOLCAnKic+LFxuICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPixcbiAgVXBkYXRlUmVjb3JkIGV4dGVuZHMgU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPiA9IFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj5cbj4ge1xuICBzdGF0aWMgX2xvZ2dlciA9IGdldExvZ2dlcignc29iamVjdCcpO1xuXG4gIHR5cGU6IE47XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBfbG9nZ2VyOiBMb2dnZXI7XG5cbiAgLy8gbGF5b3V0czogKGxuPzogc3RyaW5nKSA9PiBQcm9taXNlPERlc2NyaWJlTGF5b3V0UmVzdWx0PjtcbiAgbGF5b3V0cyQ6IENhY2hlZEZ1bmN0aW9uPChsbj86IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZUxheW91dFJlc3VsdD4+O1xuICBsYXlvdXRzJCQ6IENhY2hlZEZ1bmN0aW9uPChsbj86IHN0cmluZykgPT4gRGVzY3JpYmVMYXlvdXRSZXN1bHQ+O1xuICAvLyBjb21wYWN0TGF5b3V0czogKCkgPT4gUHJvbWlzZTxEZXNjcmliZUNvbXBhY3RMYXlvdXRzUmVzdWx0PjtcbiAgY29tcGFjdExheW91dHMkOiBDYWNoZWRGdW5jdGlvbjwoKSA9PiBQcm9taXNlPERlc2NyaWJlQ29tcGFjdExheW91dHNSZXN1bHQ+PjtcbiAgY29tcGFjdExheW91dHMkJDogQ2FjaGVkRnVuY3Rpb248KCkgPT4gRGVzY3JpYmVDb21wYWN0TGF5b3V0c1Jlc3VsdD47XG4gIC8vIGFwcHJvdmFsTGF5b3V0czogKCkgPT4gUHJvbWlzZTxEZXNjcmliZUFwcHJvdmFsTGF5b3V0c1Jlc3VsdD47XG4gIGFwcHJvdmFsTGF5b3V0cyQ6IENhY2hlZEZ1bmN0aW9uPFxuICAgICgpID0+IFByb21pc2U8RGVzY3JpYmVBcHByb3ZhbExheW91dHNSZXN1bHQ+XG4gID47XG4gIGFwcHJvdmFsTGF5b3V0cyQkOiBDYWNoZWRGdW5jdGlvbjwoKSA9PiBEZXNjcmliZUFwcHJvdmFsTGF5b3V0c1Jlc3VsdD47XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCB0eXBlOiBOKSB7XG4gICAgdGhpcy50eXBlID0gdHlwZTtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgICB0aGlzLl9sb2dnZXIgPSBjb25uLl9sb2dMZXZlbFxuICAgICAgPyBTT2JqZWN0Ll9sb2dnZXIuY3JlYXRlSW5zdGFuY2UoY29ubi5fbG9nTGV2ZWwpXG4gICAgICA6IFNPYmplY3QuX2xvZ2dlcjtcbiAgICBjb25zdCBjYWNoZSA9IHRoaXMuX2Nvbm4uY2FjaGU7XG4gICAgY29uc3QgbGF5b3V0Q2FjaGVLZXkgPSAobGF5b3V0TmFtZTogc3RyaW5nKSA9PlxuICAgICAgbGF5b3V0TmFtZVxuICAgICAgICA/IGBsYXlvdXRzLm5hbWVkTGF5b3V0cy4ke2xheW91dE5hbWV9YFxuICAgICAgICA6IGBsYXlvdXRzLiR7dGhpcy50eXBlfWA7XG4gICAgY29uc3QgbGF5b3V0cyA9IFNPYmplY3QucHJvdG90eXBlLmxheW91dHM7XG4gICAgdGhpcy5sYXlvdXRzID0gY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24obGF5b3V0cywgdGhpcywge1xuICAgICAga2V5OiBsYXlvdXRDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnTk9DQUNIRScsXG4gICAgfSk7XG4gICAgdGhpcy5sYXlvdXRzJCA9IGNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGxheW91dHMsIHRoaXMsIHtcbiAgICAgIGtleTogbGF5b3V0Q2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ0hJVCcsXG4gICAgfSk7XG4gICAgdGhpcy5sYXlvdXRzJCQgPSBjYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihsYXlvdXRzLCB0aGlzLCB7XG4gICAgICBrZXk6IGxheW91dENhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdJTU1FRElBVEUnLFxuICAgIH0pIGFzIGFueTtcbiAgICBjb25zdCBjb21wYWN0TGF5b3V0Q2FjaGVLZXkgPSBgY29tcGFjdExheW91dHMuJHt0aGlzLnR5cGV9YDtcbiAgICBjb25zdCBjb21wYWN0TGF5b3V0cyA9IFNPYmplY3QucHJvdG90eXBlLmNvbXBhY3RMYXlvdXRzO1xuICAgIHRoaXMuY29tcGFjdExheW91dHMgPSBjYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihjb21wYWN0TGF5b3V0cywgdGhpcywge1xuICAgICAga2V5OiBjb21wYWN0TGF5b3V0Q2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ05PQ0FDSEUnLFxuICAgIH0pO1xuICAgIHRoaXMuY29tcGFjdExheW91dHMkID0gY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oY29tcGFjdExheW91dHMsIHRoaXMsIHtcbiAgICAgIGtleTogY29tcGFjdExheW91dENhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdISVQnLFxuICAgIH0pO1xuICAgIHRoaXMuY29tcGFjdExheW91dHMkJCA9IGNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGNvbXBhY3RMYXlvdXRzLCB0aGlzLCB7XG4gICAgICBrZXk6IGNvbXBhY3RMYXlvdXRDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnSU1NRURJQVRFJyxcbiAgICB9KSBhcyBhbnk7XG4gICAgY29uc3QgYXBwcm92YWxMYXlvdXRDYWNoZUtleSA9IGBhcHByb3ZhbExheW91dHMuJHt0aGlzLnR5cGV9YDtcbiAgICBjb25zdCBhcHByb3ZhbExheW91dHMgPSBTT2JqZWN0LnByb3RvdHlwZS5hcHByb3ZhbExheW91dHM7XG4gICAgdGhpcy5hcHByb3ZhbExheW91dHMgPSBjYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihhcHByb3ZhbExheW91dHMsIHRoaXMsIHtcbiAgICAgIGtleTogYXBwcm92YWxMYXlvdXRDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnTk9DQUNIRScsXG4gICAgfSk7XG4gICAgdGhpcy5hcHByb3ZhbExheW91dHMkID0gY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oYXBwcm92YWxMYXlvdXRzLCB0aGlzLCB7XG4gICAgICBrZXk6IGFwcHJvdmFsTGF5b3V0Q2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ0hJVCcsXG4gICAgfSk7XG4gICAgdGhpcy5hcHByb3ZhbExheW91dHMkJCA9IGNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGFwcHJvdmFsTGF5b3V0cywgdGhpcywge1xuICAgICAga2V5OiBhcHByb3ZhbExheW91dENhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdJTU1FRElBVEUnLFxuICAgIH0pIGFzIGFueTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgcmVjb3Jkc1xuICAgKi9cbiAgY3JlYXRlKHJlY29yZHM6IElucHV0UmVjb3JkW10sIG9wdGlvbnM/OiBEbWxPcHRpb25zKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICBjcmVhdGUocmVjb3JkczogSW5wdXRSZWNvcmQsIG9wdGlvbnM/OiBEbWxPcHRpb25zKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgY3JlYXRlKFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkIHwgSW5wdXRSZWNvcmRbXSxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlKHJlY29yZHM6IElucHV0UmVjb3JkIHwgSW5wdXRSZWNvcmRbXSwgb3B0aW9ucz86IERtbE9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5jcmVhdGUodGhpcy50eXBlLCByZWNvcmRzLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFNPYmplY3QjY3JlYXRlKClcbiAgICovXG4gIGluc2VydCA9IHRoaXMuY3JlYXRlO1xuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBzcGVjaWZpZWQgcmVjb3Jkc1xuICAgKi9cbiAgcmV0cmlldmUoaWRzOiBzdHJpbmdbXSwgb3B0aW9ucz86IFJldHJpZXZlT3B0aW9ucyk6IFByb21pc2U8UmV0cmlldmVSZWNvcmRbXT47XG4gIHJldHJpZXZlKGlkczogc3RyaW5nLCBvcHRpb25zPzogUmV0cmlldmVPcHRpb25zKTogUHJvbWlzZTxSZXRyaWV2ZVJlY29yZD47XG4gIHJldHJpZXZlKFxuICAgIGlkczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IFJldHJpZXZlT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxSZXRyaWV2ZVJlY29yZCB8IFJldHJpZXZlUmVjb3JkW10+O1xuICByZXRyaWV2ZShpZHM6IHN0cmluZyB8IHN0cmluZ1tdLCBvcHRpb25zPzogUmV0cmlldmVPcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmV0cmlldmUodGhpcy50eXBlLCBpZHMsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSByZWNvcmRzXG4gICAqL1xuICB1cGRhdGUocmVjb3JkczogVXBkYXRlUmVjb3JkW10sIG9wdGlvbnM/OiBEbWxPcHRpb25zKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICB1cGRhdGUocmVjb3JkczogVXBkYXRlUmVjb3JkLCBvcHRpb25zPzogRG1sT3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIHVwZGF0ZShcbiAgICByZWNvcmRzOiBVcGRhdGVSZWNvcmQgfCBVcGRhdGVSZWNvcmRbXSxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlKHJlY29yZHM6IFVwZGF0ZVJlY29yZCB8IFVwZGF0ZVJlY29yZFtdLCBvcHRpb25zPzogRG1sT3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9jb25uLnVwZGF0ZSh0aGlzLnR5cGUsIHJlY29yZHMsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwc2VydCByZWNvcmRzXG4gICAqL1xuICB1cHNlcnQoXG4gICAgcmVjb3JkczogSW5wdXRSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdFtdPjtcbiAgdXBzZXJ0KFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkLFxuICAgIGV4dElkRmllbGQ6IEZpZWxkTmFtZXMsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0PjtcbiAgdXBzZXJ0KFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkIHwgSW5wdXRSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdCB8IFVwc2VydFJlc3VsdFtdPjtcbiAgdXBzZXJ0KFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkIHwgSW5wdXRSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi51cHNlcnQodGhpcy50eXBlLCByZWNvcmRzLCBleHRJZEZpZWxkLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgcmVjb3Jkc1xuICAgKi9cbiAgZGVzdHJveShpZHM6IHN0cmluZ1tdLCBvcHRpb25zPzogRG1sT3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVzdHJveShpZHM6IHN0cmluZywgb3B0aW9ucz86IERtbE9wdGlvbnMpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICBkZXN0cm95KFxuICAgIGlkczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIGRlc3Ryb3koaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSwgb3B0aW9ucz86IERtbE9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5kZXN0cm95KHRoaXMudHlwZSwgaWRzLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFNPYmplY3QjZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgU09iamVjdCNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogQ2FsbCBCdWxrI2xvYWQoKSB0byBleGVjdXRlIGJ1bGtsb2FkLCByZXR1cm5pbmcgYmF0Y2ggb2JqZWN0XG4gICAqL1xuICBidWxrbG9hZChcbiAgICBvcGVyYXRpb246ICdpbnNlcnQnIHwgJ3VwZGF0ZScgfCAndXBzZXJ0JyB8ICdkZWxldGUnIHwgJ2hhcmREZWxldGUnLFxuICAgIG9wdGlvbnNPcklucHV0PzogT2JqZWN0IHwgUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgICBpbnB1dD86IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICkge1xuICAgIHJldHVybiB0aGlzLl9jb25uLmJ1bGsubG9hZCh0aGlzLnR5cGUsIG9wZXJhdGlvbiwgb3B0aW9uc09ySW5wdXQsIGlucHV0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWxrbHkgaW5zZXJ0IGlucHV0IGRhdGEgdXNpbmcgYnVsayBBUElcbiAgICovXG4gIGNyZWF0ZUJ1bGsoaW5wdXQ/OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuYnVsa2xvYWQoJ2luc2VydCcsIGlucHV0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFNPYmplY3QjY3JlYXRlQnVsaygpXG4gICAqL1xuICBpbnNlcnRCdWxrID0gdGhpcy5jcmVhdGVCdWxrO1xuXG4gIC8qKlxuICAgKiBCdWxrbHkgdXBkYXRlIHJlY29yZHMgYnkgaW5wdXQgZGF0YSB1c2luZyBidWxrIEFQSVxuICAgKi9cbiAgdXBkYXRlQnVsayhpbnB1dD86IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5idWxrbG9hZCgndXBkYXRlJywgaW5wdXQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1bGtseSB1cHNlcnQgcmVjb3JkcyBieSBpbnB1dCBkYXRhIHVzaW5nIGJ1bGsgQVBJXG4gICAqL1xuICB1cHNlcnRCdWxrKGlucHV0PzogUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZywgZXh0SWRGaWVsZD86IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmJ1bGtsb2FkKCd1cHNlcnQnLCB7IGV4dElkRmllbGQgfSwgaW5wdXQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1bGtseSBkZWxldGUgcmVjb3JkcyBzcGVjaWZpZWQgYnkgaW5wdXQgZGF0YSB1c2luZyBidWxrIEFQSVxuICAgKi9cbiAgZGVzdHJveUJ1bGsoaW5wdXQ/OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuYnVsa2xvYWQoJ2RlbGV0ZScsIGlucHV0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFNPYmplY3QjZGVzdHJveUJ1bGsoKVxuICAgKi9cbiAgZGVsZXRlQnVsayA9IHRoaXMuZGVzdHJveUJ1bGs7XG5cbiAgLyoqXG4gICAqIEJ1bGtseSBoYXJkIGRlbGV0ZSByZWNvcmRzIHNwZWNpZmllZCBpbiBpbnB1dCBkYXRhIHVzaW5nIGJ1bGsgQVBJXG4gICAqL1xuICBkZXN0cm95SGFyZEJ1bGsoaW5wdXQ6IFJlY29yZFtdIHwgUmVhZGFibGUpIHtcbiAgICByZXR1cm4gdGhpcy5idWxrbG9hZCgnaGFyZERlbGV0ZScsIGlucHV0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFNPYmplY3QjZGVzdHJveUhhcmRCdWxrKClcbiAgICovXG4gIGRlbGV0ZUhhcmRCdWxrID0gdGhpcy5kZXN0cm95SGFyZEJ1bGs7XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIFNPYmplY3QgbWV0YWRhdGFcbiAgICovXG4gIGRlc2NyaWJlKCkge1xuICAgIHJldHVybiB0aGlzLl9jb25uLmRlc2NyaWJlKHRoaXMudHlwZSk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGRlc2NyaWJlJCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5kZXNjcmliZSQodGhpcy50eXBlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgZGVzY3JpYmUkJCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5kZXNjcmliZSQkKHRoaXMudHlwZSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlY29yZCByZXByZXNlbnRhdGlvbiBpbnN0YW5jZSBieSBnaXZlbiBpZFxuICAgKi9cbiAgcmVjb3JkKGlkOiBzdHJpbmcpOiBSZWNvcmRSZWZlcmVuY2U8UywgTj4ge1xuICAgIHJldHVybiBuZXcgUmVjb3JkUmVmZXJlbmNlKHRoaXMuX2Nvbm4sIHRoaXMudHlwZSwgaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHJlY2VudGx5IGFjY2Vzc2VkIHJlY29yZHNcbiAgICovXG4gIHJlY2VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZWNlbnQodGhpcy50eXBlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSB0aGUgdXBkYXRlZCByZWNvcmRzXG4gICAqL1xuICB1cGRhdGVkKHN0YXJ0OiBzdHJpbmcgfCBEYXRlLCBlbmQ6IHN0cmluZyB8IERhdGUpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi51cGRhdGVkKHRoaXMudHlwZSwgc3RhcnQsIGVuZCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgdGhlIGRlbGV0ZWQgcmVjb3Jkc1xuICAgKi9cbiAgZGVsZXRlZChzdGFydDogc3RyaW5nIHwgRGF0ZSwgZW5kOiBzdHJpbmcgfCBEYXRlKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4uZGVsZXRlZCh0aGlzLnR5cGUsIHN0YXJ0LCBlbmQpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIGxheW91dCBpbmZvcm1hdGlvbiBmb3IgU09iamVjdFxuICAgKi9cbiAgYXN5bmMgbGF5b3V0cyhsYXlvdXROYW1lPzogc3RyaW5nKTogUHJvbWlzZTxEZXNjcmliZUxheW91dFJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IGAvc29iamVjdHMvJHt0aGlzLnR5cGV9L2Rlc2NyaWJlLyR7XG4gICAgICBsYXlvdXROYW1lID8gYG5hbWVkTGF5b3V0cy8ke2xheW91dE5hbWV9YCA6ICdsYXlvdXRzJ1xuICAgIH1gO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLl9jb25uLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZUxheW91dFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBAdHlwZWRlZiB7T2JqZWN0fSBDb21wYWN0TGF5b3V0SW5mb1xuICAgKiBAcHJvcCB7QXJyYXkuPE9iamVjdD59IGNvbXBhY3RMYXlvdXRzIC0gQXJyYXkgb2YgY29tcGFjdCBsYXlvdXRzXG4gICAqIEBwcm9wIHtTdHJpbmd9IGRlZmF1bHRDb21wYWN0TGF5b3V0SWQgLSBJRCBvZiBkZWZhdWx0IGNvbXBhY3QgbGF5b3V0XG4gICAqIEBwcm9wIHtBcnJheS48T2JqZWN0Pn0gcmVjb3JkVHlwZUNvbXBhY3RMYXlvdXRNYXBwaW5ncyAtIEFycmF5IG9mIHJlY29yZCB0eXBlIG1hcHBpbmdzXG4gICAqL1xuICAvKipcbiAgICogRGVzY3JpYmUgY29tcGFjdCBsYXlvdXQgaW5mb3JtYXRpb24gZGVmaW5lZCBmb3IgU09iamVjdFxuICAgKlxuICAgKiBAcGFyYW0ge0NhbGxiYWNrLjxDb21wYWN0TGF5b3V0SW5mbz59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7UHJvbWlzZS48Q29tcGFjdExheW91dEluZm8+fVxuICAgKi9cbiAgYXN5bmMgY29tcGFjdExheW91dHMoKTogUHJvbWlzZTxEZXNjcmliZUNvbXBhY3RMYXlvdXRzUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gYC9zb2JqZWN0cy8ke3RoaXMudHlwZX0vZGVzY3JpYmUvY29tcGFjdExheW91dHNgO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLl9jb25uLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZUNvbXBhY3RMYXlvdXRzUmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIGNvbXBhY3QgbGF5b3V0IGluZm9ybWF0aW9uIGRlZmluZWQgZm9yIFNPYmplY3RcbiAgICpcbiAgICogQHBhcmFtIHtDYWxsYmFjay48QXBwcm92YWxMYXlvdXRJbmZvPn0gW2NhbGxiYWNrXSAtIENhbGxiYWNrIGZ1bmN0aW9uXG4gICAqIEByZXR1cm5zIHtQcm9taXNlLjxBcHByb3ZhbExheW91dEluZm8+fVxuICAgKi9cbiAgYXN5bmMgYXBwcm92YWxMYXlvdXRzKCk6IFByb21pc2U8RGVzY3JpYmVBcHByb3ZhbExheW91dHNSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBgL3NvYmplY3RzLyR7dGhpcy50eXBlfS9kZXNjcmliZS9hcHByb3ZhbExheW91dHNgO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLl9jb25uLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZUFwcHJvdmFsTGF5b3V0c1Jlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBGaW5kIGFuZCBmZXRjaCByZWNvcmRzIHdoaWNoIG1hdGNoZXMgZ2l2ZW4gY29uZGl0aW9uc1xuICAgKi9cbiAgZmluZDxSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkPihcbiAgICBjb25kaXRpb25zPzogT3B0aW9uYWw8UXVlcnlDb25kaXRpb248UywgTj4+LFxuICApOiBRdWVyeTxTLCBOLCBTT2JqZWN0UmVjb3JkPFMsIE4sICcqJywgUj4sICdSZWNvcmRzJz47XG4gIGZpbmQ8XG4gICAgUiBleHRlbmRzIFJlY29yZCA9IFJlY29yZCxcbiAgICBGUCBleHRlbmRzIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPixcbiAgICBGUEMgZXh0ZW5kcyBGaWVsZFByb2plY3Rpb25Db25maWcgPSBGaWVsZFBhdGhTY29wZWRQcm9qZWN0aW9uPFMsIE4sIEZQPlxuICA+KFxuICAgIGNvbmRpdGlvbnM6IE9wdGlvbmFsPFF1ZXJ5Q29uZGl0aW9uPFMsIE4+PixcbiAgICBmaWVsZHM/OiBPcHRpb25hbDxRdWVyeUZpZWxkPFMsIE4sIEZQPj4sXG4gICAgb3B0aW9ucz86IEZpbmRPcHRpb25zPFMsIE4+LFxuICApOiBRdWVyeTxTLCBOLCBTT2JqZWN0UmVjb3JkPFMsIE4sIEZQQywgUj4sICdSZWNvcmRzJz47XG4gIGZpbmQoXG4gICAgY29uZGl0aW9ucz86IE9wdGlvbmFsPFF1ZXJ5Q29uZGl0aW9uPFMsIE4+PixcbiAgICBmaWVsZHM/OiBPcHRpb25hbDxRdWVyeUZpZWxkPFMsIE4sIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPj4+LFxuICAgIG9wdGlvbnM6IEZpbmRPcHRpb25zPFMsIE4+ID0ge30sXG4gICk6IFF1ZXJ5PFMsIE4sIGFueSwgJ1JlY29yZHMnPiB7XG4gICAgY29uc3QgeyBzb3J0LCBsaW1pdCwgb2Zmc2V0LCAuLi5xb3B0aW9ucyB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBjb25maWc6IFF1ZXJ5Q29uZmlnPFMsIE4+ID0ge1xuICAgICAgZmllbGRzOiBmaWVsZHMgPT0gbnVsbCA/IHVuZGVmaW5lZCA6IGZpZWxkcyxcbiAgICAgIGluY2x1ZGVzOiBvcHRpb25zLmluY2x1ZGVzLFxuICAgICAgdGFibGU6IHRoaXMudHlwZSxcbiAgICAgIGNvbmRpdGlvbnM6IGNvbmRpdGlvbnMgPT0gbnVsbCA/IHVuZGVmaW5lZCA6IGNvbmRpdGlvbnMsXG4gICAgICBzb3J0LFxuICAgICAgbGltaXQsXG4gICAgICBvZmZzZXQsXG4gICAgfTtcbiAgICBjb25zdCBxdWVyeSA9IG5ldyBRdWVyeTxTLCBOPih0aGlzLl9jb25uLCBjb25maWcsIHFvcHRpb25zKTtcbiAgICByZXR1cm4gcXVlcnkuc2V0UmVzcG9uc2VUYXJnZXQoUmVzcG9uc2VUYXJnZXRzLlJlY29yZHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIG9uZSByZWNvcmQgd2hpY2ggbWF0Y2hlcyBnaXZlbiBjb25kaXRpb25zXG4gICAqL1xuICBmaW5kT25lPFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+KFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBOPj4sXG4gICk6IFF1ZXJ5PFMsIE4sIFNPYmplY3RSZWNvcmQ8UywgTiwgJyonLCBSPiwgJ1NpbmdsZVJlY29yZCc+O1xuICBmaW5kT25lPFxuICAgIFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQsXG4gICAgRlAgZXh0ZW5kcyBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj4gPSBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj4sXG4gICAgRlBDIGV4dGVuZHMgRmllbGRQcm9qZWN0aW9uQ29uZmlnID0gRmllbGRQYXRoU2NvcGVkUHJvamVjdGlvbjxTLCBOLCBGUD5cbiAgPihcbiAgICBjb25kaXRpb25zOiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBOPj4sXG4gICAgZmllbGRzPzogT3B0aW9uYWw8UXVlcnlGaWVsZDxTLCBOLCBGUD4+LFxuICAgIG9wdGlvbnM/OiBGaW5kT3B0aW9uczxTLCBOPixcbiAgKTogUXVlcnk8UywgTiwgU09iamVjdFJlY29yZDxTLCBOLCBGUEMsIFI+LCAnU2luZ2xlUmVjb3JkJz47XG4gIGZpbmRPbmUoXG4gICAgY29uZGl0aW9ucz86IE9wdGlvbmFsPFF1ZXJ5Q29uZGl0aW9uPFMsIE4+PixcbiAgICBmaWVsZHM/OiBPcHRpb25hbDxRdWVyeUZpZWxkPFMsIE4sIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPj4+LFxuICAgIG9wdGlvbnM6IEZpbmRPcHRpb25zPFMsIE4+ID0ge30sXG4gICk6IFF1ZXJ5PFMsIE4sIGFueSwgJ1NpbmdsZVJlY29yZCc+IHtcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuZmluZChjb25kaXRpb25zLCBmaWVsZHMsIHsgLi4ub3B0aW9ucywgbGltaXQ6IDEgfSk7XG4gICAgcmV0dXJuIHF1ZXJ5LnNldFJlc3BvbnNlVGFyZ2V0KFJlc3BvbnNlVGFyZ2V0cy5TaW5nbGVSZWNvcmQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEZpbmQgYW5kIGZldGNoIHJlY29yZHMgb25seSBieSBzcGVjaWZ5aW5nIGZpZWxkcyB0byBmZXRjaC5cbiAgICovXG4gIHNlbGVjdDxcbiAgICBSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkLFxuICAgIEZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIE4+ID0gRmllbGRQYXRoU3BlY2lmaWVyPFMsIE4+LFxuICAgIEZQQyBleHRlbmRzIEZpZWxkUHJvamVjdGlvbkNvbmZpZyA9IEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb248UywgTiwgRlA+XG4gID4oXG4gICAgZmllbGRzOiBRdWVyeUZpZWxkPFMsIE4sIEZQPixcbiAgKTogUXVlcnk8UywgTiwgU09iamVjdFJlY29yZDxTLCBOLCBGUEMsIFI+LCAnUmVjb3Jkcyc+IHtcbiAgICByZXR1cm4gdGhpcy5maW5kKG51bGwsIGZpZWxkcyk7XG4gIH1cblxuICAvKipcbiAgICogQ291bnQgbnVtIG9mIHJlY29yZHMgd2hpY2ggbWF0Y2hlcyBnaXZlbiBjb25kaXRpb25zXG4gICAqL1xuICBjb3VudChjb25kaXRpb25zPzogT3B0aW9uYWw8UXVlcnlDb25kaXRpb248UywgTj4+KSB7XG4gICAgY29uc3QgcXVlcnkgPSB0aGlzLmZpbmQoY29uZGl0aW9ucywgJ2NvdW50KCknKTtcbiAgICByZXR1cm4gcXVlcnkuc2V0UmVzcG9uc2VUYXJnZXQoUmVzcG9uc2VUYXJnZXRzLkNvdW50KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBsaXN0IG9mIGxpc3Qgdmlld3MgZm9yIHRoZSBTT2JqZWN0XG4gICAqXG4gICAqIEBwYXJhbSB7Q2FsbGJhY2suPExpc3RWaWV3c0luZm8+fSBbY2FsbGJhY2tdIC0gQ2FsbGJhY2sgZnVuY3Rpb25cbiAgICogQHJldHVybnMge1Byb21pc2UuPExpc3RWaWV3c0luZm8+fVxuICAgKi9cbiAgbGlzdHZpZXdzKCkge1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKX0vc29iamVjdHMvJHt0aGlzLnR5cGV9L2xpc3R2aWV3c2A7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdCh1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGxpc3QgdmlldyBpbmZvIGluIHNwZWNpZmVkIHZpZXcgaWRcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IGlkIC0gTGlzdCB2aWV3IElEXG4gICAqIEByZXR1cm5zIHtMaXN0Vmlld31cbiAgICovXG4gIGxpc3R2aWV3KGlkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3IExpc3RWaWV3KHRoaXMuX2Nvbm4sIHRoaXMudHlwZSwgaWQpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbGwgcmVnaXN0ZXJlZCBxdWljayBhY3Rpb25zIGZvciB0aGUgU09iamVjdFxuICAgKlxuICAgKiBAcGFyYW0ge0NhbGxiYWNrLjxBcnJheS48UXVpY2tBY3Rpb25+UXVpY2tBY3Rpb25JbmZvPj59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7UHJvbWlzZS48QXJyYXkuPFF1aWNrQWN0aW9uflF1aWNrQWN0aW9uSW5mbz4+fVxuICAgKi9cbiAgcXVpY2tBY3Rpb25zKCkge1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3QoYC9zb2JqZWN0cy8ke3RoaXMudHlwZX0vcXVpY2tBY3Rpb25zYCk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlZmVyZW5jZSBmb3Igc3BlY2lmaWVkIHF1aWNrIGFjaXRvbiBpbiB0aGUgU09iamVjdFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gYWN0aW9uTmFtZSAtIE5hbWUgb2YgdGhlIHF1aWNrIGFjdGlvblxuICAgKiBAcmV0dXJucyB7UXVpY2tBY3Rpb259XG4gICAqL1xuICBxdWlja0FjdGlvbihhY3Rpb25OYW1lOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3IFF1aWNrQWN0aW9uKFxuICAgICAgdGhpcy5fY29ubixcbiAgICAgIGAvc29iamVjdHMvJHt0aGlzLnR5cGV9L3F1aWNrQWN0aW9ucy8ke2FjdGlvbk5hbWV9YCxcbiAgICApO1xuICB9XG59XG5cbi8qKlxuICogQSBjbGFzcyBmb3Igb3JnYW5pemluZyBsaXN0IHZpZXcgaW5mb3JtYXRpb25cbiAqXG4gKiBAcHJvdGVjdGVkXG4gKiBAY2xhc3MgTGlzdFZpZXdcbiAqIEBwYXJhbSB7Q29ubmVjdGlvbn0gY29ubiAtIENvbm5lY3Rpb24gaW5zdGFuY2VcbiAqIEBwYXJhbSB7U09iamVjdH0gdHlwZSAtIFNPYmplY3QgdHlwZVxuICogQHBhcmFtIHtTdHJpbmd9IGlkIC0gTGlzdCB2aWV3IElEXG4gKi9cbmNsYXNzIExpc3RWaWV3IHtcbiAgX2Nvbm46IENvbm5lY3Rpb247XG4gIHR5cGU6IHN0cmluZztcbiAgaWQ6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb24sIHR5cGU6IHN0cmluZywgaWQ6IHN0cmluZykge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy5pZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGVzIHF1ZXJ5IGZvciB0aGUgbGlzdCB2aWV3IGFuZCByZXR1cm5zIHRoZSByZXN1bHRpbmcgZGF0YSBhbmQgcHJlc2VudGF0aW9uIGluZm9ybWF0aW9uLlxuICAgKi9cbiAgcmVzdWx0cygpIHtcbiAgICBjb25zdCB1cmwgPSBgJHt0aGlzLl9jb25uLl9iYXNlVXJsKCl9L3NvYmplY3RzLyR7dGhpcy50eXBlfS9saXN0dmlld3MvJHtcbiAgICAgIHRoaXMuaWRcbiAgICB9L3Jlc3VsdHNgO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3QodXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGRldGFpbGVkIGluZm9ybWF0aW9uIGFib3V0IGEgbGlzdCB2aWV3XG4gICAqL1xuICBkZXNjcmliZShvcHRpb25zOiB7IGhlYWRlcnM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSB9ID0ge30pIHtcbiAgICBjb25zdCB1cmwgPSBgJHt0aGlzLl9jb25uLl9iYXNlVXJsKCl9L3NvYmplY3RzLyR7dGhpcy50eXBlfS9saXN0dmlld3MvJHtcbiAgICAgIHRoaXMuaWRcbiAgICB9L2Rlc2NyaWJlYDtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0KHsgbWV0aG9kOiAnR0VUJywgdXJsLCBoZWFkZXJzOiBvcHRpb25zLmhlYWRlcnMgfSk7XG4gIH1cblxuICAvKipcbiAgICogRXhwbGFpbiBwbGFuIGZvciBleGVjdXRpbmcgbGlzdCB2aWV3XG4gICAqL1xuICBleHBsYWluKCkge1xuICAgIGNvbnN0IHVybCA9IGAvcXVlcnkvP2V4cGxhaW49JHt0aGlzLmlkfWA7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxhbnk+KHVybCk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgU09iamVjdDtcblxuLy8gVE9ETyBCdWxrXG4iXX0=