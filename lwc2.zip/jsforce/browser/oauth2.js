import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.replace";
import "core-js/modules/es.string.split";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context8; _forEachInstanceProperty(_context8 = ownKeys(Object(source), true)).call(_context8, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context9; _forEachInstanceProperty(_context9 = ownKeys(Object(source))).call(_context9, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */
import { createHash, randomBytes } from 'crypto';
import querystring from 'querystring';
import Transport, { XdProxyTransport, HttpProxyTransport } from './transport';
var defaultOAuth2Config = {
  loginUrl: 'https://login.salesforce.com'
}; // Makes a nodejs base64 encoded string compatible with rfc4648 alternative encoding for urls.
// @param base64Encoded a nodejs base64 encoded string

function base64UrlEscape(base64Encoded) {
  // builtin node js base 64 encoding is not 64 url compatible.
  // See https://toolsn.ietf.org/html/rfc4648#section-5
  return base64Encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}
/**
 * type defs
 */


/**
 * OAuth2 class
 */
export var OAuth2 = /*#__PURE__*/function () {
  /**
   *
   */
  function OAuth2(config) {
    _classCallCheck(this, OAuth2);

    _defineProperty(this, "loginUrl", void 0);

    _defineProperty(this, "authzServiceUrl", void 0);

    _defineProperty(this, "tokenServiceUrl", void 0);

    _defineProperty(this, "revokeServiceUrl", void 0);

    _defineProperty(this, "clientId", void 0);

    _defineProperty(this, "clientSecret", void 0);

    _defineProperty(this, "redirectUri", void 0);

    _defineProperty(this, "codeVerifier", void 0);

    _defineProperty(this, "_transport", void 0);

    var loginUrl = config.loginUrl,
        authzServiceUrl = config.authzServiceUrl,
        tokenServiceUrl = config.tokenServiceUrl,
        revokeServiceUrl = config.revokeServiceUrl,
        clientId = config.clientId,
        clientSecret = config.clientSecret,
        redirectUri = config.redirectUri,
        proxyUrl = config.proxyUrl,
        httpProxy = config.httpProxy,
        useVerifier = config.useVerifier;

    if (authzServiceUrl && tokenServiceUrl) {
      var _context;

      this.loginUrl = _sliceInstanceProperty(_context = authzServiceUrl.split('/')).call(_context, 0, 3).join('/');
      this.authzServiceUrl = authzServiceUrl;
      this.tokenServiceUrl = tokenServiceUrl;
      this.revokeServiceUrl = revokeServiceUrl || "".concat(this.loginUrl, "/services/oauth2/revoke");
    } else {
      this.loginUrl = loginUrl || defaultOAuth2Config.loginUrl;
      this.authzServiceUrl = "".concat(this.loginUrl, "/services/oauth2/authorize");
      this.tokenServiceUrl = "".concat(this.loginUrl, "/services/oauth2/token");
      this.revokeServiceUrl = "".concat(this.loginUrl, "/services/oauth2/revoke");
    }

    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.redirectUri = redirectUri;

    if (proxyUrl) {
      this._transport = new XdProxyTransport(proxyUrl);
    } else if (httpProxy) {
      this._transport = new HttpProxyTransport(httpProxy);
    } else {
      this._transport = new Transport();
    }

    if (useVerifier) {
      // Set a code verifier string for OAuth authorization
      this.codeVerifier = base64UrlEscape(randomBytes(Math.ceil(128)).toString('base64'));
    }
  }
  /**
   * Get Salesforce OAuth2 authorization page URL to redirect user agent.
   */


  _createClass(OAuth2, [{
    key: "getAuthorizationUrl",
    value: function getAuthorizationUrl() {
      var _context2;

      var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (this.codeVerifier) {
        // code verifier must be a base 64 url encoded hash of 128 bytes of random data. Our random data is also
        // base 64 url encoded. See Connection.create();
        var codeChallenge = base64UrlEscape(createHash('sha256').update(this.codeVerifier).digest('base64'));
        params.code_challenge = codeChallenge;
      }

      var _params = _objectSpread(_objectSpread({}, params), {}, {
        response_type: 'code',
        client_id: this.clientId,
        redirect_uri: this.redirectUri
      });

      return this.authzServiceUrl + (_indexOfInstanceProperty(_context2 = this.authzServiceUrl).call(_context2, '?') >= 0 ? '&' : '?') + querystring.stringify(_params);
    }
    /**
     * OAuth2 Refresh Token Flow
     */

  }, {
    key: "refreshToken",
    value: function () {
      var _refreshToken2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(_refreshToken) {
        var params, ret;
        return _regeneratorRuntime.wrap(function _callee$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (this.clientId) {
                  _context3.next = 2;
                  break;
                }

                throw new Error('No OAuth2 client id information is specified');

              case 2:
                params = {
                  grant_type: 'refresh_token',
                  refresh_token: _refreshToken,
                  client_id: this.clientId
                };

                if (this.clientSecret) {
                  params.client_secret = this.clientSecret;
                }

                _context3.next = 6;
                return this._postParams(params);

              case 6:
                ret = _context3.sent;
                return _context3.abrupt("return", ret);

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee, this);
      }));

      function refreshToken(_x) {
        return _refreshToken2.apply(this, arguments);
      }

      return refreshToken;
    }()
    /**
     * OAuth2 Web Server Authentication Flow (Authorization Code)
     * Access Token Request
     */

  }, {
    key: "requestToken",
    value: function () {
      var _requestToken = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(code) {
        var params,
            _params,
            ret,
            _args2 = arguments;

        return _regeneratorRuntime.wrap(function _callee2$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                params = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};

                if (!(!this.clientId || !this.redirectUri)) {
                  _context4.next = 3;
                  break;
                }

                throw new Error('No OAuth2 client id or redirect uri configuration is specified');

              case 3:
                _params = _objectSpread(_objectSpread({}, params), {}, {
                  grant_type: 'authorization_code',
                  code: code,
                  client_id: this.clientId,
                  redirect_uri: this.redirectUri
                });

                if (this.clientSecret) {
                  _params.client_secret = this.clientSecret;
                }

                _context4.next = 7;
                return this._postParams(_params);

              case 7:
                ret = _context4.sent;
                return _context4.abrupt("return", ret);

              case 9:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee2, this);
      }));

      function requestToken(_x2) {
        return _requestToken.apply(this, arguments);
      }

      return requestToken;
    }()
    /**
     * OAuth2 Username-Password Flow (Resource Owner Password Credentials)
     */

  }, {
    key: "authenticate",
    value: function () {
      var _authenticate = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        var ret;
        return _regeneratorRuntime.wrap(function _callee3$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                if (!(!this.clientId || !this.clientSecret || !this.redirectUri)) {
                  _context5.next = 2;
                  break;
                }

                throw new Error('No valid OAuth2 client configuration set');

              case 2:
                _context5.next = 4;
                return this._postParams({
                  grant_type: 'password',
                  username: username,
                  password: password,
                  client_id: this.clientId,
                  client_secret: this.clientSecret,
                  redirect_uri: this.redirectUri
                });

              case 4:
                ret = _context5.sent;
                return _context5.abrupt("return", ret);

              case 6:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee3, this);
      }));

      function authenticate(_x3, _x4) {
        return _authenticate.apply(this, arguments);
      }

      return authenticate;
    }()
    /**
     * OAuth2 Revoke Session Token
     */

  }, {
    key: "revokeToken",
    value: function () {
      var _revokeToken = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(token) {
        var response, res;
        return _regeneratorRuntime.wrap(function _callee4$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this._transport.httpRequest({
                  method: 'POST',
                  url: this.revokeServiceUrl,
                  body: querystring.stringify({
                    token: token
                  }),
                  headers: {
                    'content-type': 'application/x-www-form-urlencoded'
                  }
                });

              case 2:
                response = _context6.sent;

                if (!(response.statusCode >= 400)) {
                  _context6.next = 7;
                  break;
                }

                res = querystring.parse(response.body);

                if (!res || !res.error) {
                  res = {
                    error: "ERROR_HTTP_".concat(response.statusCode),
                    error_description: response.body
                  };
                }

                throw new ( /*#__PURE__*/function (_Error) {
                  _inherits(_class, _Error);

                  var _super = _createSuper(_class);

                  function _class(_ref) {
                    var _this;

                    var error = _ref.error,
                        error_description = _ref.error_description;

                    _classCallCheck(this, _class);

                    _this = _super.call(this, error_description);
                    _this.name = error;
                    return _this;
                  }

                  return _class;
                }( /*#__PURE__*/_wrapNativeSuper(Error)))(res);

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee4, this);
      }));

      function revokeToken(_x5) {
        return _revokeToken.apply(this, arguments);
      }

      return revokeToken;
    }()
    /**
     * @private
     */

  }, {
    key: "_postParams",
    value: function () {
      var _postParams2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(params) {
        var response, res;
        return _regeneratorRuntime.wrap(function _callee5$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (this.codeVerifier) params.code_verifier = this.codeVerifier;
                _context7.next = 3;
                return this._transport.httpRequest({
                  method: 'POST',
                  url: this.tokenServiceUrl,
                  body: querystring.stringify(params),
                  headers: {
                    'content-type': 'application/x-www-form-urlencoded'
                  }
                });

              case 3:
                response = _context7.sent;

                try {
                  res = JSON.parse(response.body);
                } catch (e) {
                  /* eslint-disable no-empty */
                }

                if (!(response.statusCode >= 400)) {
                  _context7.next = 8;
                  break;
                }

                res = res || {
                  error: "ERROR_HTTP_".concat(response.statusCode),
                  error_description: response.body
                };
                throw new ( /*#__PURE__*/function (_Error2) {
                  _inherits(_class2, _Error2);

                  var _super2 = _createSuper(_class2);

                  function _class2(_ref2) {
                    var _this2;

                    var error = _ref2.error,
                        error_description = _ref2.error_description;

                    _classCallCheck(this, _class2);

                    _this2 = _super2.call(this, error_description);
                    _this2.name = error;
                    return _this2;
                  }

                  return _class2;
                }( /*#__PURE__*/_wrapNativeSuper(Error)))(res);

              case 8:
                return _context7.abrupt("return", res);

              case 9:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee5, this);
      }));

      function _postParams(_x6) {
        return _postParams2.apply(this, arguments);
      }

      return _postParams;
    }()
  }]);

  return OAuth2;
}();
export default OAuth2;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9vYXV0aDIudHMiXSwibmFtZXMiOlsiY3JlYXRlSGFzaCIsInJhbmRvbUJ5dGVzIiwicXVlcnlzdHJpbmciLCJUcmFuc3BvcnQiLCJYZFByb3h5VHJhbnNwb3J0IiwiSHR0cFByb3h5VHJhbnNwb3J0IiwiZGVmYXVsdE9BdXRoMkNvbmZpZyIsImxvZ2luVXJsIiwiYmFzZTY0VXJsRXNjYXBlIiwiYmFzZTY0RW5jb2RlZCIsInJlcGxhY2UiLCJPQXV0aDIiLCJjb25maWciLCJhdXRoelNlcnZpY2VVcmwiLCJ0b2tlblNlcnZpY2VVcmwiLCJyZXZva2VTZXJ2aWNlVXJsIiwiY2xpZW50SWQiLCJjbGllbnRTZWNyZXQiLCJyZWRpcmVjdFVyaSIsInByb3h5VXJsIiwiaHR0cFByb3h5IiwidXNlVmVyaWZpZXIiLCJzcGxpdCIsImpvaW4iLCJfdHJhbnNwb3J0IiwiY29kZVZlcmlmaWVyIiwiTWF0aCIsImNlaWwiLCJ0b1N0cmluZyIsInBhcmFtcyIsImNvZGVDaGFsbGVuZ2UiLCJ1cGRhdGUiLCJkaWdlc3QiLCJjb2RlX2NoYWxsZW5nZSIsIl9wYXJhbXMiLCJyZXNwb25zZV90eXBlIiwiY2xpZW50X2lkIiwicmVkaXJlY3RfdXJpIiwic3RyaW5naWZ5IiwicmVmcmVzaFRva2VuIiwiRXJyb3IiLCJncmFudF90eXBlIiwicmVmcmVzaF90b2tlbiIsImNsaWVudF9zZWNyZXQiLCJfcG9zdFBhcmFtcyIsInJldCIsImNvZGUiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwidG9rZW4iLCJodHRwUmVxdWVzdCIsIm1ldGhvZCIsInVybCIsImJvZHkiLCJoZWFkZXJzIiwicmVzcG9uc2UiLCJzdGF0dXNDb2RlIiwicmVzIiwicGFyc2UiLCJlcnJvciIsImVycm9yX2Rlc2NyaXB0aW9uIiwibmFtZSIsImNvZGVfdmVyaWZpZXIiLCJKU09OIiwiZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFVBQVQsRUFBcUJDLFdBQXJCLFFBQXdDLFFBQXhDO0FBQ0EsT0FBT0MsV0FBUCxNQUF3QixhQUF4QjtBQUNBLE9BQU9DLFNBQVAsSUFBb0JDLGdCQUFwQixFQUFzQ0Msa0JBQXRDLFFBQWdFLGFBQWhFO0FBR0EsSUFBTUMsbUJBQW1CLEdBQUc7QUFDMUJDLEVBQUFBLFFBQVEsRUFBRTtBQURnQixDQUE1QixDLENBSUE7QUFDQTs7QUFDQSxTQUFTQyxlQUFULENBQXlCQyxhQUF6QixFQUF3RDtBQUN0RDtBQUNBO0FBQ0EsU0FBT0EsYUFBYSxDQUNqQkMsT0FESSxDQUNJLEtBREosRUFDVyxHQURYLEVBRUpBLE9BRkksQ0FFSSxLQUZKLEVBRVcsR0FGWCxFQUdKQSxPQUhJLENBR0ksSUFISixFQUdVLEVBSFYsQ0FBUDtBQUlEO0FBRUQ7QUFDQTtBQUNBOzs7QUFrQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsTUFBYjtBQVlFO0FBQ0Y7QUFDQTtBQUNFLGtCQUFZQyxNQUFaLEVBQWtDO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsUUFFOUJMLFFBRjhCLEdBWTVCSyxNQVo0QixDQUU5QkwsUUFGOEI7QUFBQSxRQUc5Qk0sZUFIOEIsR0FZNUJELE1BWjRCLENBRzlCQyxlQUg4QjtBQUFBLFFBSTlCQyxlQUo4QixHQVk1QkYsTUFaNEIsQ0FJOUJFLGVBSjhCO0FBQUEsUUFLOUJDLGdCQUw4QixHQVk1QkgsTUFaNEIsQ0FLOUJHLGdCQUw4QjtBQUFBLFFBTTlCQyxRQU44QixHQVk1QkosTUFaNEIsQ0FNOUJJLFFBTjhCO0FBQUEsUUFPOUJDLFlBUDhCLEdBWTVCTCxNQVo0QixDQU85QkssWUFQOEI7QUFBQSxRQVE5QkMsV0FSOEIsR0FZNUJOLE1BWjRCLENBUTlCTSxXQVI4QjtBQUFBLFFBUzlCQyxRQVQ4QixHQVk1QlAsTUFaNEIsQ0FTOUJPLFFBVDhCO0FBQUEsUUFVOUJDLFNBVjhCLEdBWTVCUixNQVo0QixDQVU5QlEsU0FWOEI7QUFBQSxRQVc5QkMsV0FYOEIsR0FZNUJULE1BWjRCLENBVzlCUyxXQVg4Qjs7QUFhaEMsUUFBSVIsZUFBZSxJQUFJQyxlQUF2QixFQUF3QztBQUFBOztBQUN0QyxXQUFLUCxRQUFMLEdBQWdCLGtDQUFBTSxlQUFlLENBQUNTLEtBQWhCLENBQXNCLEdBQXRCLGtCQUFpQyxDQUFqQyxFQUFvQyxDQUFwQyxFQUF1Q0MsSUFBdkMsQ0FBNEMsR0FBNUMsQ0FBaEI7QUFDQSxXQUFLVixlQUFMLEdBQXVCQSxlQUF2QjtBQUNBLFdBQUtDLGVBQUwsR0FBdUJBLGVBQXZCO0FBQ0EsV0FBS0MsZ0JBQUwsR0FDRUEsZ0JBQWdCLGNBQU8sS0FBS1IsUUFBWiw0QkFEbEI7QUFFRCxLQU5ELE1BTU87QUFDTCxXQUFLQSxRQUFMLEdBQWdCQSxRQUFRLElBQUlELG1CQUFtQixDQUFDQyxRQUFoRDtBQUNBLFdBQUtNLGVBQUwsYUFBMEIsS0FBS04sUUFBL0I7QUFDQSxXQUFLTyxlQUFMLGFBQTBCLEtBQUtQLFFBQS9CO0FBQ0EsV0FBS1EsZ0JBQUwsYUFBMkIsS0FBS1IsUUFBaEM7QUFDRDs7QUFDRCxTQUFLUyxRQUFMLEdBQWdCQSxRQUFoQjtBQUNBLFNBQUtDLFlBQUwsR0FBb0JBLFlBQXBCO0FBQ0EsU0FBS0MsV0FBTCxHQUFtQkEsV0FBbkI7O0FBQ0EsUUFBSUMsUUFBSixFQUFjO0FBQ1osV0FBS0ssVUFBTCxHQUFrQixJQUFJcEIsZ0JBQUosQ0FBcUJlLFFBQXJCLENBQWxCO0FBQ0QsS0FGRCxNQUVPLElBQUlDLFNBQUosRUFBZTtBQUNwQixXQUFLSSxVQUFMLEdBQWtCLElBQUluQixrQkFBSixDQUF1QmUsU0FBdkIsQ0FBbEI7QUFDRCxLQUZNLE1BRUE7QUFDTCxXQUFLSSxVQUFMLEdBQWtCLElBQUlyQixTQUFKLEVBQWxCO0FBQ0Q7O0FBQ0QsUUFBSWtCLFdBQUosRUFBaUI7QUFDZjtBQUNBLFdBQUtJLFlBQUwsR0FBb0JqQixlQUFlLENBQ2pDUCxXQUFXLENBQUN5QixJQUFJLENBQUNDLElBQUwsQ0FBVSxHQUFWLENBQUQsQ0FBWCxDQUE0QkMsUUFBNUIsQ0FBcUMsUUFBckMsQ0FEaUMsQ0FBbkM7QUFHRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUE1REE7QUFBQTtBQUFBLDBDQTZEdUQ7QUFBQTs7QUFBQSxVQUFqQ0MsTUFBaUMsdUVBQUosRUFBSTs7QUFDbkQsVUFBSSxLQUFLSixZQUFULEVBQXVCO0FBQ3JCO0FBQ0E7QUFDQSxZQUFNSyxhQUFhLEdBQUd0QixlQUFlLENBQ25DUixVQUFVLENBQUMsUUFBRCxDQUFWLENBQXFCK0IsTUFBckIsQ0FBNEIsS0FBS04sWUFBakMsRUFBK0NPLE1BQS9DLENBQXNELFFBQXRELENBRG1DLENBQXJDO0FBR0FILFFBQUFBLE1BQU0sQ0FBQ0ksY0FBUCxHQUF3QkgsYUFBeEI7QUFDRDs7QUFFRCxVQUFNSSxPQUFPLG1DQUNSTCxNQURRO0FBRVhNLFFBQUFBLGFBQWEsRUFBRSxNQUZKO0FBR1hDLFFBQUFBLFNBQVMsRUFBRSxLQUFLcEIsUUFITDtBQUlYcUIsUUFBQUEsWUFBWSxFQUFFLEtBQUtuQjtBQUpSLFFBQWI7O0FBTUEsYUFDRSxLQUFLTCxlQUFMLElBQ0MsMENBQUtBLGVBQUwsa0JBQTZCLEdBQTdCLEtBQXFDLENBQXJDLEdBQXlDLEdBQXpDLEdBQStDLEdBRGhELElBRUFYLFdBQVcsQ0FBQ29DLFNBQVosQ0FBc0JKLE9BQXRCLENBSEY7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0RkE7QUFBQTtBQUFBO0FBQUEscUdBdUZxQkssYUF2RnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXdGUyxLQUFLdkIsUUF4RmQ7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBeUZZLElBQUl3QixLQUFKLENBQVUsOENBQVYsQ0F6Rlo7O0FBQUE7QUEyRlVYLGdCQUFBQSxNQTNGVixHQTJGK0M7QUFDekNZLGtCQUFBQSxVQUFVLEVBQUUsZUFENkI7QUFFekNDLGtCQUFBQSxhQUFhLEVBQUVILGFBRjBCO0FBR3pDSCxrQkFBQUEsU0FBUyxFQUFFLEtBQUtwQjtBQUh5QixpQkEzRi9DOztBQWdHSSxvQkFBSSxLQUFLQyxZQUFULEVBQXVCO0FBQ3JCWSxrQkFBQUEsTUFBTSxDQUFDYyxhQUFQLEdBQXVCLEtBQUsxQixZQUE1QjtBQUNEOztBQWxHTDtBQUFBLHVCQW1Hc0IsS0FBSzJCLFdBQUwsQ0FBaUJmLE1BQWpCLENBbkd0Qjs7QUFBQTtBQW1HVWdCLGdCQUFBQSxHQW5HVjtBQUFBLGtEQW9HV0EsR0FwR1g7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF1R0U7QUFDRjtBQUNBO0FBQ0E7O0FBMUdBO0FBQUE7QUFBQTtBQUFBLHFHQTRHSUMsSUE1R0o7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTZHSWpCLGdCQUFBQSxNQTdHSiw4REE2R3lDLEVBN0d6Qzs7QUFBQSxzQkErR1EsQ0FBQyxLQUFLYixRQUFOLElBQWtCLENBQUMsS0FBS0UsV0EvR2hDO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQWdIWSxJQUFJc0IsS0FBSixDQUNKLGdFQURJLENBaEhaOztBQUFBO0FBb0hVTixnQkFBQUEsT0FwSFYsbUNBcUhTTCxNQXJIVDtBQXNITVksa0JBQUFBLFVBQVUsRUFBRSxvQkF0SGxCO0FBdUhNSyxrQkFBQUEsSUFBSSxFQUFKQSxJQXZITjtBQXdITVYsa0JBQUFBLFNBQVMsRUFBRSxLQUFLcEIsUUF4SHRCO0FBeUhNcUIsa0JBQUFBLFlBQVksRUFBRSxLQUFLbkI7QUF6SHpCOztBQTJISSxvQkFBSSxLQUFLRCxZQUFULEVBQXVCO0FBQ3JCaUIsa0JBQUFBLE9BQU8sQ0FBQ1MsYUFBUixHQUF3QixLQUFLMUIsWUFBN0I7QUFDRDs7QUE3SEw7QUFBQSx1QkE4SHNCLEtBQUsyQixXQUFMLENBQWlCVixPQUFqQixDQTlIdEI7O0FBQUE7QUE4SFVXLGdCQUFBQSxHQTlIVjtBQUFBLGtEQStIV0EsR0EvSFg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFrSUU7QUFDRjtBQUNBOztBQXBJQTtBQUFBO0FBQUE7QUFBQSxxR0FzSUlFLFFBdElKLEVBdUlJQyxRQXZJSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF5SVEsQ0FBQyxLQUFLaEMsUUFBTixJQUFrQixDQUFDLEtBQUtDLFlBQXhCLElBQXdDLENBQUMsS0FBS0MsV0F6SXREO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTBJWSxJQUFJc0IsS0FBSixDQUFVLDBDQUFWLENBMUlaOztBQUFBO0FBQUE7QUFBQSx1QkE0SXNCLEtBQUtJLFdBQUwsQ0FBaUI7QUFDakNILGtCQUFBQSxVQUFVLEVBQUUsVUFEcUI7QUFFakNNLGtCQUFBQSxRQUFRLEVBQVJBLFFBRmlDO0FBR2pDQyxrQkFBQUEsUUFBUSxFQUFSQSxRQUhpQztBQUlqQ1osa0JBQUFBLFNBQVMsRUFBRSxLQUFLcEIsUUFKaUI7QUFLakMyQixrQkFBQUEsYUFBYSxFQUFFLEtBQUsxQixZQUxhO0FBTWpDb0Isa0JBQUFBLFlBQVksRUFBRSxLQUFLbkI7QUFOYyxpQkFBakIsQ0E1SXRCOztBQUFBO0FBNElVMkIsZ0JBQUFBLEdBNUlWO0FBQUEsa0RBb0pXQSxHQXBKWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXVKRTtBQUNGO0FBQ0E7O0FBekpBO0FBQUE7QUFBQTtBQUFBLG9HQTBKb0JJLEtBMUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJKMkIsS0FBS3pCLFVBQUwsQ0FBZ0IwQixXQUFoQixDQUE0QjtBQUNqREMsa0JBQUFBLE1BQU0sRUFBRSxNQUR5QztBQUVqREMsa0JBQUFBLEdBQUcsRUFBRSxLQUFLckMsZ0JBRnVDO0FBR2pEc0Msa0JBQUFBLElBQUksRUFBRW5ELFdBQVcsQ0FBQ29DLFNBQVosQ0FBc0I7QUFBRVcsb0JBQUFBLEtBQUssRUFBTEE7QUFBRixtQkFBdEIsQ0FIMkM7QUFJakRLLGtCQUFBQSxPQUFPLEVBQUU7QUFDUCxvQ0FBZ0I7QUFEVDtBQUp3QyxpQkFBNUIsQ0EzSjNCOztBQUFBO0FBMkpVQyxnQkFBQUEsUUEzSlY7O0FBQUEsc0JBbUtRQSxRQUFRLENBQUNDLFVBQVQsSUFBdUIsR0FuSy9CO0FBQUE7QUFBQTtBQUFBOztBQW9LVUMsZ0JBQUFBLEdBcEtWLEdBb0txQnZELFdBQVcsQ0FBQ3dELEtBQVosQ0FBa0JILFFBQVEsQ0FBQ0YsSUFBM0IsQ0FwS3JCOztBQXFLTSxvQkFBSSxDQUFDSSxHQUFELElBQVEsQ0FBQ0EsR0FBRyxDQUFDRSxLQUFqQixFQUF3QjtBQUN0QkYsa0JBQUFBLEdBQUcsR0FBRztBQUNKRSxvQkFBQUEsS0FBSyx1QkFBZ0JKLFFBQVEsQ0FBQ0MsVUFBekIsQ0FERDtBQUVKSSxvQkFBQUEsaUJBQWlCLEVBQUVMLFFBQVEsQ0FBQ0Y7QUFGeEIsbUJBQU47QUFJRDs7QUExS1Asc0JBMktZO0FBQUE7O0FBQUE7O0FBQ0osd0NBTUc7QUFBQTs7QUFBQSx3QkFMRE0sS0FLQyxRQUxEQSxLQUtDO0FBQUEsd0JBSkRDLGlCQUlDLFFBSkRBLGlCQUlDOztBQUFBOztBQUNELDhDQUFNQSxpQkFBTjtBQUNBLDBCQUFLQyxJQUFMLEdBQVlGLEtBQVo7QUFGQztBQUdGOztBQVZHO0FBQUEsaURBQW1CbkIsS0FBbkIsSUFXSGlCLEdBWEcsQ0EzS1o7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUEwTEU7QUFDRjtBQUNBOztBQTVMQTtBQUFBO0FBQUE7QUFBQSxvR0E2TG9CNUIsTUE3THBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQThMSSxvQkFBSSxLQUFLSixZQUFULEVBQXVCSSxNQUFNLENBQUNpQyxhQUFQLEdBQXVCLEtBQUtyQyxZQUE1QjtBQTlMM0I7QUFBQSx1QkFnTTJCLEtBQUtELFVBQUwsQ0FBZ0IwQixXQUFoQixDQUE0QjtBQUNqREMsa0JBQUFBLE1BQU0sRUFBRSxNQUR5QztBQUVqREMsa0JBQUFBLEdBQUcsRUFBRSxLQUFLdEMsZUFGdUM7QUFHakR1QyxrQkFBQUEsSUFBSSxFQUFFbkQsV0FBVyxDQUFDb0MsU0FBWixDQUFzQlQsTUFBdEIsQ0FIMkM7QUFJakR5QixrQkFBQUEsT0FBTyxFQUFFO0FBQ1Asb0NBQWdCO0FBRFQ7QUFKd0MsaUJBQTVCLENBaE0zQjs7QUFBQTtBQWdNVUMsZ0JBQUFBLFFBaE1WOztBQXlNSSxvQkFBSTtBQUNGRSxrQkFBQUEsR0FBRyxHQUFHTSxJQUFJLENBQUNMLEtBQUwsQ0FBV0gsUUFBUSxDQUFDRixJQUFwQixDQUFOO0FBQ0QsaUJBRkQsQ0FFRSxPQUFPVyxDQUFQLEVBQVU7QUFDVjtBQUNEOztBQTdNTCxzQkE4TVFULFFBQVEsQ0FBQ0MsVUFBVCxJQUF1QixHQTlNL0I7QUFBQTtBQUFBO0FBQUE7O0FBK01NQyxnQkFBQUEsR0FBRyxHQUFHQSxHQUFHLElBQUk7QUFDWEUsa0JBQUFBLEtBQUssdUJBQWdCSixRQUFRLENBQUNDLFVBQXpCLENBRE07QUFFWEksa0JBQUFBLGlCQUFpQixFQUFFTCxRQUFRLENBQUNGO0FBRmpCLGlCQUFiO0FBL01OLHNCQW1OWTtBQUFBOztBQUFBOztBQUNKLDBDQU1HO0FBQUE7O0FBQUEsd0JBTERNLEtBS0MsU0FMREEsS0FLQztBQUFBLHdCQUpEQyxpQkFJQyxTQUpEQSxpQkFJQzs7QUFBQTs7QUFDRCxnREFBTUEsaUJBQU47QUFDQSwyQkFBS0MsSUFBTCxHQUFZRixLQUFaO0FBRkM7QUFHRjs7QUFWRztBQUFBLGlEQUFtQm5CLEtBQW5CLElBV0hpQixHQVhHLENBbk5aOztBQUFBO0FBQUEsa0RBZ09XQSxHQWhPWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFvT0EsZUFBZTlDLE1BQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IGNyZWF0ZUhhc2gsIHJhbmRvbUJ5dGVzIH0gZnJvbSAnY3J5cHRvJztcbmltcG9ydCBxdWVyeXN0cmluZyBmcm9tICdxdWVyeXN0cmluZyc7XG5pbXBvcnQgVHJhbnNwb3J0LCB7IFhkUHJveHlUcmFuc3BvcnQsIEh0dHBQcm94eVRyYW5zcG9ydCB9IGZyb20gJy4vdHJhbnNwb3J0JztcbmltcG9ydCB7IE9wdGlvbmFsIH0gZnJvbSAnLi90eXBlcyc7XG5cbmNvbnN0IGRlZmF1bHRPQXV0aDJDb25maWcgPSB7XG4gIGxvZ2luVXJsOiAnaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbScsXG59O1xuXG4vLyBNYWtlcyBhIG5vZGVqcyBiYXNlNjQgZW5jb2RlZCBzdHJpbmcgY29tcGF0aWJsZSB3aXRoIHJmYzQ2NDggYWx0ZXJuYXRpdmUgZW5jb2RpbmcgZm9yIHVybHMuXG4vLyBAcGFyYW0gYmFzZTY0RW5jb2RlZCBhIG5vZGVqcyBiYXNlNjQgZW5jb2RlZCBzdHJpbmdcbmZ1bmN0aW9uIGJhc2U2NFVybEVzY2FwZShiYXNlNjRFbmNvZGVkOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBidWlsdGluIG5vZGUganMgYmFzZSA2NCBlbmNvZGluZyBpcyBub3QgNjQgdXJsIGNvbXBhdGlibGUuXG4gIC8vIFNlZSBodHRwczovL3Rvb2xzbi5pZXRmLm9yZy9odG1sL3JmYzQ2NDgjc2VjdGlvbi01XG4gIHJldHVybiBiYXNlNjRFbmNvZGVkXG4gICAgLnJlcGxhY2UoL1xcKy9nLCAnLScpXG4gICAgLnJlcGxhY2UoL1xcLy9nLCAnXycpXG4gICAgLnJlcGxhY2UoLz0vZywgJycpO1xufVxuXG4vKipcbiAqIHR5cGUgZGVmc1xuICovXG5leHBvcnQgdHlwZSBPQXV0aDJDb25maWcgPSB7XG4gIGNsaWVudElkPzogc3RyaW5nO1xuICBjbGllbnRTZWNyZXQ/OiBzdHJpbmc7XG4gIHJlZGlyZWN0VXJpPzogc3RyaW5nO1xuICBsb2dpblVybD86IHN0cmluZztcbiAgYXV0aHpTZXJ2aWNlVXJsPzogc3RyaW5nO1xuICB0b2tlblNlcnZpY2VVcmw/OiBzdHJpbmc7XG4gIHJldm9rZVNlcnZpY2VVcmw/OiBzdHJpbmc7XG4gIHByb3h5VXJsPzogc3RyaW5nO1xuICBodHRwUHJveHk/OiBzdHJpbmc7XG4gIHVzZVZlcmlmaWVyPzogYm9vbGVhbjtcbn07XG5cbmV4cG9ydCB0eXBlIEF1dGh6UmVxdWVzdFBhcmFtcyA9IHtcbiAgc2NvcGU/OiBzdHJpbmc7XG4gIHN0YXRlPzogc3RyaW5nO1xuICBjb2RlX2NoYWxsZW5nZT86IHN0cmluZztcbn0gJiB7XG4gIFthdHRyOiBzdHJpbmddOiBzdHJpbmc7XG59O1xuXG5leHBvcnQgdHlwZSBUb2tlblJlc3BvbnNlID0ge1xuICB0b2tlbl90eXBlOiAnQmVhcmVyJztcbiAgaWQ6IHN0cmluZztcbiAgYWNjZXNzX3Rva2VuOiBzdHJpbmc7XG4gIHJlZnJlc2hfdG9rZW4/OiBzdHJpbmc7XG4gIHNpZ25hdHVyZTogc3RyaW5nO1xuICBpc3N1ZWRfYXQ6IHN0cmluZztcbiAgaW5zdGFuY2VfdXJsOiBzdHJpbmc7XG4gIHNmZGNfY29tbXVuaXR5X3VybD86IHN0cmluZztcbiAgc2ZkY19jb21tdW5pdHlfaWQ/OiBzdHJpbmc7XG59O1xuXG4vKipcbiAqIE9BdXRoMiBjbGFzc1xuICovXG5leHBvcnQgY2xhc3MgT0F1dGgyIHtcbiAgbG9naW5Vcmw6IHN0cmluZztcbiAgYXV0aHpTZXJ2aWNlVXJsOiBzdHJpbmc7XG4gIHRva2VuU2VydmljZVVybDogc3RyaW5nO1xuICByZXZva2VTZXJ2aWNlVXJsOiBzdHJpbmc7XG4gIGNsaWVudElkOiBPcHRpb25hbDxzdHJpbmc+O1xuICBjbGllbnRTZWNyZXQ6IE9wdGlvbmFsPHN0cmluZz47XG4gIHJlZGlyZWN0VXJpOiBPcHRpb25hbDxzdHJpbmc+O1xuICBjb2RlVmVyaWZpZXI6IE9wdGlvbmFsPHN0cmluZz47XG5cbiAgX3RyYW5zcG9ydDogVHJhbnNwb3J0O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29uZmlnOiBPQXV0aDJDb25maWcpIHtcbiAgICBjb25zdCB7XG4gICAgICBsb2dpblVybCxcbiAgICAgIGF1dGh6U2VydmljZVVybCxcbiAgICAgIHRva2VuU2VydmljZVVybCxcbiAgICAgIHJldm9rZVNlcnZpY2VVcmwsXG4gICAgICBjbGllbnRJZCxcbiAgICAgIGNsaWVudFNlY3JldCxcbiAgICAgIHJlZGlyZWN0VXJpLFxuICAgICAgcHJveHlVcmwsXG4gICAgICBodHRwUHJveHksXG4gICAgICB1c2VWZXJpZmllcixcbiAgICB9ID0gY29uZmlnO1xuICAgIGlmIChhdXRoelNlcnZpY2VVcmwgJiYgdG9rZW5TZXJ2aWNlVXJsKSB7XG4gICAgICB0aGlzLmxvZ2luVXJsID0gYXV0aHpTZXJ2aWNlVXJsLnNwbGl0KCcvJykuc2xpY2UoMCwgMykuam9pbignLycpO1xuICAgICAgdGhpcy5hdXRoelNlcnZpY2VVcmwgPSBhdXRoelNlcnZpY2VVcmw7XG4gICAgICB0aGlzLnRva2VuU2VydmljZVVybCA9IHRva2VuU2VydmljZVVybDtcbiAgICAgIHRoaXMucmV2b2tlU2VydmljZVVybCA9XG4gICAgICAgIHJldm9rZVNlcnZpY2VVcmwgfHwgYCR7dGhpcy5sb2dpblVybH0vc2VydmljZXMvb2F1dGgyL3Jldm9rZWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubG9naW5VcmwgPSBsb2dpblVybCB8fCBkZWZhdWx0T0F1dGgyQ29uZmlnLmxvZ2luVXJsO1xuICAgICAgdGhpcy5hdXRoelNlcnZpY2VVcmwgPSBgJHt0aGlzLmxvZ2luVXJsfS9zZXJ2aWNlcy9vYXV0aDIvYXV0aG9yaXplYDtcbiAgICAgIHRoaXMudG9rZW5TZXJ2aWNlVXJsID0gYCR7dGhpcy5sb2dpblVybH0vc2VydmljZXMvb2F1dGgyL3Rva2VuYDtcbiAgICAgIHRoaXMucmV2b2tlU2VydmljZVVybCA9IGAke3RoaXMubG9naW5Vcmx9L3NlcnZpY2VzL29hdXRoMi9yZXZva2VgO1xuICAgIH1cbiAgICB0aGlzLmNsaWVudElkID0gY2xpZW50SWQ7XG4gICAgdGhpcy5jbGllbnRTZWNyZXQgPSBjbGllbnRTZWNyZXQ7XG4gICAgdGhpcy5yZWRpcmVjdFVyaSA9IHJlZGlyZWN0VXJpO1xuICAgIGlmIChwcm94eVVybCkge1xuICAgICAgdGhpcy5fdHJhbnNwb3J0ID0gbmV3IFhkUHJveHlUcmFuc3BvcnQocHJveHlVcmwpO1xuICAgIH0gZWxzZSBpZiAoaHR0cFByb3h5KSB7XG4gICAgICB0aGlzLl90cmFuc3BvcnQgPSBuZXcgSHR0cFByb3h5VHJhbnNwb3J0KGh0dHBQcm94eSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3RyYW5zcG9ydCA9IG5ldyBUcmFuc3BvcnQoKTtcbiAgICB9XG4gICAgaWYgKHVzZVZlcmlmaWVyKSB7XG4gICAgICAvLyBTZXQgYSBjb2RlIHZlcmlmaWVyIHN0cmluZyBmb3IgT0F1dGggYXV0aG9yaXphdGlvblxuICAgICAgdGhpcy5jb2RlVmVyaWZpZXIgPSBiYXNlNjRVcmxFc2NhcGUoXG4gICAgICAgIHJhbmRvbUJ5dGVzKE1hdGguY2VpbCgxMjgpKS50b1N0cmluZygnYmFzZTY0JyksXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgU2FsZXNmb3JjZSBPQXV0aDIgYXV0aG9yaXphdGlvbiBwYWdlIFVSTCB0byByZWRpcmVjdCB1c2VyIGFnZW50LlxuICAgKi9cbiAgZ2V0QXV0aG9yaXphdGlvblVybChwYXJhbXM6IEF1dGh6UmVxdWVzdFBhcmFtcyA9IHt9KSB7XG4gICAgaWYgKHRoaXMuY29kZVZlcmlmaWVyKSB7XG4gICAgICAvLyBjb2RlIHZlcmlmaWVyIG11c3QgYmUgYSBiYXNlIDY0IHVybCBlbmNvZGVkIGhhc2ggb2YgMTI4IGJ5dGVzIG9mIHJhbmRvbSBkYXRhLiBPdXIgcmFuZG9tIGRhdGEgaXMgYWxzb1xuICAgICAgLy8gYmFzZSA2NCB1cmwgZW5jb2RlZC4gU2VlIENvbm5lY3Rpb24uY3JlYXRlKCk7XG4gICAgICBjb25zdCBjb2RlQ2hhbGxlbmdlID0gYmFzZTY0VXJsRXNjYXBlKFxuICAgICAgICBjcmVhdGVIYXNoKCdzaGEyNTYnKS51cGRhdGUodGhpcy5jb2RlVmVyaWZpZXIpLmRpZ2VzdCgnYmFzZTY0JyksXG4gICAgICApO1xuICAgICAgcGFyYW1zLmNvZGVfY2hhbGxlbmdlID0gY29kZUNoYWxsZW5nZTtcbiAgICB9XG5cbiAgICBjb25zdCBfcGFyYW1zID0ge1xuICAgICAgLi4ucGFyYW1zLFxuICAgICAgcmVzcG9uc2VfdHlwZTogJ2NvZGUnLFxuICAgICAgY2xpZW50X2lkOiB0aGlzLmNsaWVudElkLFxuICAgICAgcmVkaXJlY3RfdXJpOiB0aGlzLnJlZGlyZWN0VXJpLFxuICAgIH07XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuYXV0aHpTZXJ2aWNlVXJsICtcbiAgICAgICh0aGlzLmF1dGh6U2VydmljZVVybC5pbmRleE9mKCc/JykgPj0gMCA/ICcmJyA6ICc/JykgK1xuICAgICAgcXVlcnlzdHJpbmcuc3RyaW5naWZ5KF9wYXJhbXMgYXMgeyBbbmFtZTogc3RyaW5nXTogYW55IH0pXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPQXV0aDIgUmVmcmVzaCBUb2tlbiBGbG93XG4gICAqL1xuICBhc3luYyByZWZyZXNoVG9rZW4ocmVmcmVzaFRva2VuOiBzdHJpbmcpOiBQcm9taXNlPFRva2VuUmVzcG9uc2U+IHtcbiAgICBpZiAoIXRoaXMuY2xpZW50SWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gT0F1dGgyIGNsaWVudCBpZCBpbmZvcm1hdGlvbiBpcyBzcGVjaWZpZWQnKTtcbiAgICB9XG4gICAgY29uc3QgcGFyYW1zOiB7IFtwcm9wOiBzdHJpbmddOiBzdHJpbmcgfSA9IHtcbiAgICAgIGdyYW50X3R5cGU6ICdyZWZyZXNoX3Rva2VuJyxcbiAgICAgIHJlZnJlc2hfdG9rZW46IHJlZnJlc2hUb2tlbixcbiAgICAgIGNsaWVudF9pZDogdGhpcy5jbGllbnRJZCxcbiAgICB9O1xuICAgIGlmICh0aGlzLmNsaWVudFNlY3JldCkge1xuICAgICAgcGFyYW1zLmNsaWVudF9zZWNyZXQgPSB0aGlzLmNsaWVudFNlY3JldDtcbiAgICB9XG4gICAgY29uc3QgcmV0ID0gYXdhaXQgdGhpcy5fcG9zdFBhcmFtcyhwYXJhbXMpO1xuICAgIHJldHVybiByZXQgYXMgVG9rZW5SZXNwb25zZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPQXV0aDIgV2ViIFNlcnZlciBBdXRoZW50aWNhdGlvbiBGbG93IChBdXRob3JpemF0aW9uIENvZGUpXG4gICAqIEFjY2VzcyBUb2tlbiBSZXF1ZXN0XG4gICAqL1xuICBhc3luYyByZXF1ZXN0VG9rZW4oXG4gICAgY29kZTogc3RyaW5nLFxuICAgIHBhcmFtczogeyBbcHJvcDogc3RyaW5nXTogc3RyaW5nIH0gPSB7fSxcbiAgKTogUHJvbWlzZTxUb2tlblJlc3BvbnNlPiB7XG4gICAgaWYgKCF0aGlzLmNsaWVudElkIHx8ICF0aGlzLnJlZGlyZWN0VXJpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdObyBPQXV0aDIgY2xpZW50IGlkIG9yIHJlZGlyZWN0IHVyaSBjb25maWd1cmF0aW9uIGlzIHNwZWNpZmllZCcsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBfcGFyYW1zOiB7IFtwcm9wOiBzdHJpbmddOiBzdHJpbmcgfSA9IHtcbiAgICAgIC4uLnBhcmFtcyxcbiAgICAgIGdyYW50X3R5cGU6ICdhdXRob3JpemF0aW9uX2NvZGUnLFxuICAgICAgY29kZSxcbiAgICAgIGNsaWVudF9pZDogdGhpcy5jbGllbnRJZCxcbiAgICAgIHJlZGlyZWN0X3VyaTogdGhpcy5yZWRpcmVjdFVyaSxcbiAgICB9O1xuICAgIGlmICh0aGlzLmNsaWVudFNlY3JldCkge1xuICAgICAgX3BhcmFtcy5jbGllbnRfc2VjcmV0ID0gdGhpcy5jbGllbnRTZWNyZXQ7XG4gICAgfVxuICAgIGNvbnN0IHJldCA9IGF3YWl0IHRoaXMuX3Bvc3RQYXJhbXMoX3BhcmFtcyk7XG4gICAgcmV0dXJuIHJldCBhcyBUb2tlblJlc3BvbnNlO1xuICB9XG5cbiAgLyoqXG4gICAqIE9BdXRoMiBVc2VybmFtZS1QYXNzd29yZCBGbG93IChSZXNvdXJjZSBPd25lciBQYXNzd29yZCBDcmVkZW50aWFscylcbiAgICovXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZShcbiAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgIHBhc3N3b3JkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8VG9rZW5SZXNwb25zZT4ge1xuICAgIGlmICghdGhpcy5jbGllbnRJZCB8fCAhdGhpcy5jbGllbnRTZWNyZXQgfHwgIXRoaXMucmVkaXJlY3RVcmkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdmFsaWQgT0F1dGgyIGNsaWVudCBjb25maWd1cmF0aW9uIHNldCcpO1xuICAgIH1cbiAgICBjb25zdCByZXQgPSBhd2FpdCB0aGlzLl9wb3N0UGFyYW1zKHtcbiAgICAgIGdyYW50X3R5cGU6ICdwYXNzd29yZCcsXG4gICAgICB1c2VybmFtZSxcbiAgICAgIHBhc3N3b3JkLFxuICAgICAgY2xpZW50X2lkOiB0aGlzLmNsaWVudElkLFxuICAgICAgY2xpZW50X3NlY3JldDogdGhpcy5jbGllbnRTZWNyZXQsXG4gICAgICByZWRpcmVjdF91cmk6IHRoaXMucmVkaXJlY3RVcmksXG4gICAgfSk7XG4gICAgcmV0dXJuIHJldCBhcyBUb2tlblJlc3BvbnNlO1xuICB9XG5cbiAgLyoqXG4gICAqIE9BdXRoMiBSZXZva2UgU2Vzc2lvbiBUb2tlblxuICAgKi9cbiAgYXN5bmMgcmV2b2tlVG9rZW4odG9rZW46IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fdHJhbnNwb3J0Lmh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiB0aGlzLnJldm9rZVNlcnZpY2VVcmwsXG4gICAgICBib2R5OiBxdWVyeXN0cmluZy5zdHJpbmdpZnkoeyB0b2tlbiB9KSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIGxldCByZXM6IGFueSA9IHF1ZXJ5c3RyaW5nLnBhcnNlKHJlc3BvbnNlLmJvZHkpO1xuICAgICAgaWYgKCFyZXMgfHwgIXJlcy5lcnJvcikge1xuICAgICAgICByZXMgPSB7XG4gICAgICAgICAgZXJyb3I6IGBFUlJPUl9IVFRQXyR7cmVzcG9uc2Uuc3RhdHVzQ29kZX1gLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiByZXNwb25zZS5ib2R5LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IChjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uLFxuICAgICAgICB9OiB7XG4gICAgICAgICAgZXJyb3I6IHN0cmluZztcbiAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgICAgICB9KSB7XG4gICAgICAgICAgc3VwZXIoZXJyb3JfZGVzY3JpcHRpb24pO1xuICAgICAgICAgIHRoaXMubmFtZSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KShyZXMpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX3Bvc3RQYXJhbXMocGFyYW1zOiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSk6IFByb21pc2U8YW55PiB7XG4gICAgaWYgKHRoaXMuY29kZVZlcmlmaWVyKSBwYXJhbXMuY29kZV92ZXJpZmllciA9IHRoaXMuY29kZVZlcmlmaWVyO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLl90cmFuc3BvcnQuaHR0cFJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHRoaXMudG9rZW5TZXJ2aWNlVXJsLFxuICAgICAgYm9keTogcXVlcnlzdHJpbmcuc3RyaW5naWZ5KHBhcmFtcyksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgbGV0IHJlcztcbiAgICB0cnkge1xuICAgICAgcmVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5ib2R5KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1lbXB0eSAqL1xuICAgIH1cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIHJlcyA9IHJlcyB8fCB7XG4gICAgICAgIGVycm9yOiBgRVJST1JfSFRUUF8ke3Jlc3BvbnNlLnN0YXR1c0NvZGV9YCxcbiAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IHJlc3BvbnNlLmJvZHksXG4gICAgICB9O1xuICAgICAgdGhyb3cgbmV3IChjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uLFxuICAgICAgICB9OiB7XG4gICAgICAgICAgZXJyb3I6IHN0cmluZztcbiAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgICAgICB9KSB7XG4gICAgICAgICAgc3VwZXIoZXJyb3JfZGVzY3JpcHRpb24pO1xuICAgICAgICAgIHRoaXMubmFtZSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KShyZXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IE9BdXRoMjtcbiJdfQ==