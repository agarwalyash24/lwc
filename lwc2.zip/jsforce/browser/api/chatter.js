import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.join";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context5; _forEachInstanceProperty(_context5 = ownKeys(Object(source), true)).call(_context5, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context6; _forEachInstanceProperty(_context6 = ownKeys(Object(source))).call(_context6, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Chatter REST API calls
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import { isObject } from '../util/function';
/**
 *
 */

/*--------------------------------------------*/

/**
 * A class representing chatter API request
 */
var Request = /*#__PURE__*/function () {
  function Request(chatter, request) {
    _classCallCheck(this, Request);

    _defineProperty(this, "_chatter", void 0);

    _defineProperty(this, "_request", void 0);

    _defineProperty(this, "_promise", void 0);

    this._chatter = chatter;
    this._request = request;
  }
  /**
   * Retrieve parameters in batch request form
   */


  _createClass(Request, [{
    key: "batchParams",
    value: function batchParams() {
      var _this$_request = this._request,
          method = _this$_request.method,
          url = _this$_request.url,
          body = _this$_request.body;
      return _objectSpread({
        method: method,
        url: this._chatter._normalizeUrl(url)
      }, typeof body !== 'undefined' ? {
        richInput: body
      } : {});
    }
    /**
     * Retrieve parameters in batch request form
     *
     * @method Chatter~Request#promise
     * @returns {Promise.<Chatter~RequestResult>}
     */

  }, {
    key: "promise",
    value: function promise() {
      return this._promise || (this._promise = this._chatter._request(this._request));
    }
    /**
     * Returns Node.js Stream object for request
     *
     * @method Chatter~Request#stream
     * @returns {stream.Stream}
     */

  }, {
    key: "stream",
    value: function stream() {
      return this._chatter._request(this._request).stream();
    }
    /**
     * Promise/A+ interface
     * http://promises-aplus.github.io/promises-spec/
     *
     * Delegate to deferred promise, return promise instance for batch result
     */

  }, {
    key: "then",
    value: function then(onResolve, onReject) {
      return this.promise().then(onResolve, onReject);
    }
  }]);

  return Request;
}();

function apppendQueryParamsToUrl(url, queryParams) {
  if (queryParams) {
    var _context;

    var qstring = _mapInstanceProperty(_context = _Object$keys(queryParams)).call(_context, function (name) {
      var _context2, _queryParams$name;

      return _concatInstanceProperty(_context2 = "".concat(name, "=")).call(_context2, encodeURIComponent(String((_queryParams$name = queryParams[name]) !== null && _queryParams$name !== void 0 ? _queryParams$name : '')));
    }).join('&');

    url += (_indexOfInstanceProperty(url).call(url, '?') > 0 ? '&' : '?') + qstring;
  }

  return url;
}
/*------------------------------*/


export var Resource = /*#__PURE__*/function (_Request) {
  _inherits(Resource, _Request);

  var _super = _createSuper(Resource);

  /**
   *
   */
  function Resource(chatter, url, queryParams) {
    var _this;

    _classCallCheck(this, Resource);

    _this = _super.call(this, chatter, {
      method: 'GET',
      url: apppendQueryParamsToUrl(url, queryParams)
    });

    _defineProperty(_assertThisInitialized(_this), "_url", void 0);

    _defineProperty(_assertThisInitialized(_this), "delete", _this.destroy);

    _defineProperty(_assertThisInitialized(_this), "del", _this.destroy);

    _this._url = _this._request.url;
    return _this;
  }
  /**
   * Create a new resource
   */


  _createClass(Resource, [{
    key: "create",
    value: function create(data) {
      return this._chatter.request({
        method: 'POST',
        url: this._url,
        body: data
      });
    }
    /**
     * Retrieve resource content
     */

  }, {
    key: "retrieve",
    value: function retrieve() {
      return this._chatter.request({
        method: 'GET',
        url: this._url
      });
    }
    /**
     * Update specified resource
     */

  }, {
    key: "update",
    value: function update(data) {
      return this._chatter.request({
        method: 'POST',
        url: this._url,
        body: data
      });
    }
    /**
     * Delete specified resource
     */

  }, {
    key: "destroy",
    value: function destroy() {
      return this._chatter.request({
        method: 'DELETE',
        url: this._url
      });
    }
    /**
     * Synonym of Resource#destroy()
     */

  }]);

  return Resource;
}(Request);
/*------------------------------*/

/**
 * API class for Chatter REST API call
 */

export var Chatter = /*#__PURE__*/function () {
  /**
   *
   */
  function Chatter(conn) {
    _classCallCheck(this, Chatter);

    _defineProperty(this, "_conn", void 0);

    this._conn = conn;
  }
  /**
   * Sending request to API endpoint
   * @private
   */


  _createClass(Chatter, [{
    key: "_request",
    value: function _request(req_) {
      var method = req_.method,
          url_ = req_.url,
          headers_ = req_.headers,
          body_ = req_.body;
      var headers = headers_ !== null && headers_ !== void 0 ? headers_ : {};
      var body;

      if (/^(put|post|patch)$/i.test(method)) {
        if (isObject(body_)) {
          headers = _objectSpread(_objectSpread({}, headers_), {}, {
            'Content-Type': 'application/json'
          });
          body = _JSON$stringify(body_);
        } else {
          body = body_;
        }
      }

      var url = this._normalizeUrl(url_);

      return this._conn.request({
        method: method,
        url: url,
        headers: headers,
        body: body
      });
    }
    /**
     * Convert path to site root relative url
     * @private
     */

  }, {
    key: "_normalizeUrl",
    value: function _normalizeUrl(url) {
      if (_indexOfInstanceProperty(url).call(url, '/chatter/') === 0 || _indexOfInstanceProperty(url).call(url, '/connect/') === 0) {
        return '/services/data/v' + this._conn.version + url;
      } else if (/^\/v[\d]+\.[\d]+\//.test(url)) {
        return '/services/data' + url;
      } else if (_indexOfInstanceProperty(url).call(url, '/services/') !== 0 && url[0] === '/') {
        return '/services/data/v' + this._conn.version + '/chatter' + url;
      } else {
        return url;
      }
    }
    /**
     * Make a request for chatter API resource
     */

  }, {
    key: "request",
    value: function request(req) {
      return new Request(this, req);
    }
    /**
     * Make a resource request to chatter API
     */

  }, {
    key: "resource",
    value: function resource(url, queryParams) {
      return new Resource(this, url, queryParams);
    }
    /**
     * Make a batch request to chatter API
     */

  }, {
    key: "batch",
    value: function () {
      var _batch = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(requests) {
        var _context3;

        var deferreds, res;
        return _regeneratorRuntime.wrap(function _callee$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                deferreds = _mapInstanceProperty(requests).call(requests, function (request) {
                  var deferred = defer();
                  request._promise = deferred.promise;
                  return deferred;
                });
                _context4.next = 3;
                return this.request({
                  method: 'POST',
                  url: this._normalizeUrl('/connect/batch'),
                  body: {
                    batchRequests: _mapInstanceProperty(requests).call(requests, function (request) {
                      return request.batchParams();
                    })
                  }
                });

              case 3:
                res = _context4.sent;

                _forEachInstanceProperty(_context3 = res.results).call(_context3, function (result, i) {
                  var deferred = deferreds[i];

                  if (result.statusCode >= 400) {
                    deferred.reject(result.result);
                  } else {
                    deferred.resolve(result.result);
                  }
                });

                return _context4.abrupt("return", res);

              case 6:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee, this);
      }));

      function batch(_x) {
        return _batch.apply(this, arguments);
      }

      return batch;
    }()
  }]);

  return Chatter;
}();

function defer() {
  var resolve_ = function resolve_() {};

  var reject_ = function reject_() {};

  var promise = new _Promise(function (resolve, reject) {
    resolve_ = resolve;
    reject_ = reject;
  });
  return {
    promise: promise,
    resolve: resolve_,
    reject: reject_
  };
}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */


registerModule('chatter', function (conn) {
  return new Chatter(conn);
});
export default Chatter;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvY2hhdHRlci50cyJdLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsImlzT2JqZWN0IiwiUmVxdWVzdCIsImNoYXR0ZXIiLCJyZXF1ZXN0IiwiX2NoYXR0ZXIiLCJfcmVxdWVzdCIsIm1ldGhvZCIsInVybCIsImJvZHkiLCJfbm9ybWFsaXplVXJsIiwicmljaElucHV0IiwiX3Byb21pc2UiLCJzdHJlYW0iLCJvblJlc29sdmUiLCJvblJlamVjdCIsInByb21pc2UiLCJ0aGVuIiwiYXBwcGVuZFF1ZXJ5UGFyYW1zVG9VcmwiLCJxdWVyeVBhcmFtcyIsInFzdHJpbmciLCJuYW1lIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiU3RyaW5nIiwiam9pbiIsIlJlc291cmNlIiwiZGVzdHJveSIsIl91cmwiLCJkYXRhIiwiQ2hhdHRlciIsImNvbm4iLCJfY29ubiIsInJlcV8iLCJ1cmxfIiwiaGVhZGVyc18iLCJoZWFkZXJzIiwiYm9keV8iLCJ0ZXN0IiwidmVyc2lvbiIsInJlcSIsInJlcXVlc3RzIiwiZGVmZXJyZWRzIiwiZGVmZXJyZWQiLCJkZWZlciIsImJhdGNoUmVxdWVzdHMiLCJiYXRjaFBhcmFtcyIsInJlcyIsInJlc3VsdHMiLCJyZXN1bHQiLCJpIiwic3RhdHVzQ29kZSIsInJlamVjdCIsInJlc29sdmUiLCJyZXNvbHZlXyIsInJlamVjdF8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLGNBQVQsUUFBK0IsWUFBL0I7QUFHQSxTQUFTQyxRQUFULFFBQXlCLGtCQUF6QjtBQUVBO0FBQ0E7QUFDQTs7QUEyQkE7O0FBQ0E7QUFDQTtBQUNBO0lBQ01DLE87QUFLSixtQkFBWUMsT0FBWixFQUFpQ0MsT0FBakMsRUFBZ0U7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFDOUQsU0FBS0MsUUFBTCxHQUFnQkYsT0FBaEI7QUFDQSxTQUFLRyxRQUFMLEdBQWdCRixPQUFoQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7OztrQ0FDZ0I7QUFBQSwyQkFDa0IsS0FBS0UsUUFEdkI7QUFBQSxVQUNKQyxNQURJLGtCQUNKQSxNQURJO0FBQUEsVUFDSUMsR0FESixrQkFDSUEsR0FESjtBQUFBLFVBQ1NDLElBRFQsa0JBQ1NBLElBRFQ7QUFFWjtBQUNFRixRQUFBQSxNQUFNLEVBQU5BLE1BREY7QUFFRUMsUUFBQUEsR0FBRyxFQUFFLEtBQUtILFFBQUwsQ0FBY0ssYUFBZCxDQUE0QkYsR0FBNUI7QUFGUCxTQUdNLE9BQU9DLElBQVAsS0FBZ0IsV0FBaEIsR0FBOEI7QUFBRUUsUUFBQUEsU0FBUyxFQUFFRjtBQUFiLE9BQTlCLEdBQW9ELEVBSDFEO0FBS0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7OEJBQ1k7QUFDUixhQUNFLEtBQUtHLFFBQUwsS0FBa0IsS0FBS0EsUUFBTCxHQUFnQixLQUFLUCxRQUFMLENBQWNDLFFBQWQsQ0FBdUIsS0FBS0EsUUFBNUIsQ0FBbEMsQ0FERjtBQUdEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OzZCQUNXO0FBQ1AsYUFBTyxLQUFLRCxRQUFMLENBQWNDLFFBQWQsQ0FBMEIsS0FBS0EsUUFBL0IsRUFBeUNPLE1BQXpDLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozt5QkFFSUMsUyxFQUNBQyxRLEVBQ0E7QUFDQSxhQUFPLEtBQUtDLE9BQUwsR0FBZUMsSUFBZixDQUFvQkgsU0FBcEIsRUFBK0JDLFFBQS9CLENBQVA7QUFDRDs7Ozs7O0FBR0gsU0FBU0csdUJBQVQsQ0FDRVYsR0FERixFQUVFVyxXQUZGLEVBR0U7QUFDQSxNQUFJQSxXQUFKLEVBQWlCO0FBQUE7O0FBQ2YsUUFBTUMsT0FBTyxHQUFHLDZDQUFZRCxXQUFaLGtCQUVaLFVBQUNFLElBQUQ7QUFBQTs7QUFBQSwyREFDS0EsSUFETCx3QkFDYUMsa0JBQWtCLENBQUNDLE1BQU0sc0JBQUNKLFdBQVcsQ0FBQ0UsSUFBRCxDQUFaLGlFQUFzQixFQUF0QixDQUFQLENBRC9CO0FBQUEsS0FGWSxFQUtiRyxJQUxhLENBS1IsR0FMUSxDQUFoQjs7QUFNQWhCLElBQUFBLEdBQUcsSUFBSSxDQUFDLHlCQUFBQSxHQUFHLE1BQUgsQ0FBQUEsR0FBRyxFQUFTLEdBQVQsQ0FBSCxHQUFtQixDQUFuQixHQUF1QixHQUF2QixHQUE2QixHQUE5QixJQUFxQ1ksT0FBNUM7QUFDRDs7QUFDRCxTQUFPWixHQUFQO0FBQ0Q7QUFFRDs7O0FBQ0EsV0FBYWlCLFFBQWI7QUFBQTs7QUFBQTs7QUFHRTtBQUNGO0FBQ0E7QUFDRSxvQkFDRXRCLE9BREYsRUFFRUssR0FGRixFQUdFVyxXQUhGLEVBSUU7QUFBQTs7QUFBQTs7QUFDQSw4QkFBTWhCLE9BQU4sRUFBZTtBQUNiSSxNQUFBQSxNQUFNLEVBQUUsS0FESztBQUViQyxNQUFBQSxHQUFHLEVBQUVVLHVCQUF1QixDQUFDVixHQUFELEVBQU1XLFdBQU47QUFGZixLQUFmOztBQURBOztBQUFBLDZEQXFETyxNQUFLTyxPQXJEWjs7QUFBQSwwREEwREksTUFBS0EsT0ExRFQ7O0FBS0EsVUFBS0MsSUFBTCxHQUFZLE1BQUtyQixRQUFMLENBQWNFLEdBQTFCO0FBTEE7QUFNRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBcEJBO0FBQUE7QUFBQSwyQkFxQm1Cb0IsSUFyQm5CLEVBcUJpRDtBQUM3QyxhQUFPLEtBQUt2QixRQUFMLENBQWNELE9BQWQsQ0FBMEI7QUFDL0JHLFFBQUFBLE1BQU0sRUFBRSxNQUR1QjtBQUUvQkMsUUFBQUEsR0FBRyxFQUFFLEtBQUttQixJQUZxQjtBQUcvQmxCLFFBQUFBLElBQUksRUFBRW1CO0FBSHlCLE9BQTFCLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7QUEvQkE7QUFBQTtBQUFBLCtCQWdDcUI7QUFDakIsYUFBTyxLQUFLdkIsUUFBTCxDQUFjRCxPQUFkLENBQTBCO0FBQy9CRyxRQUFBQSxNQUFNLEVBQUUsS0FEdUI7QUFFL0JDLFFBQUFBLEdBQUcsRUFBRSxLQUFLbUI7QUFGcUIsT0FBMUIsQ0FBUDtBQUlEO0FBRUQ7QUFDRjtBQUNBOztBQXpDQTtBQUFBO0FBQUEsMkJBMENtQkMsSUExQ25CLEVBMENpQztBQUM3QixhQUFPLEtBQUt2QixRQUFMLENBQWNELE9BQWQsQ0FBMEI7QUFDL0JHLFFBQUFBLE1BQU0sRUFBRSxNQUR1QjtBQUUvQkMsUUFBQUEsR0FBRyxFQUFFLEtBQUttQixJQUZxQjtBQUcvQmxCLFFBQUFBLElBQUksRUFBRW1CO0FBSHlCLE9BQTFCLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7QUFwREE7QUFBQTtBQUFBLDhCQXFEWTtBQUNSLGFBQU8sS0FBS3ZCLFFBQUwsQ0FBY0QsT0FBZCxDQUE0QjtBQUNqQ0csUUFBQUEsTUFBTSxFQUFFLFFBRHlCO0FBRWpDQyxRQUFBQSxHQUFHLEVBQUUsS0FBS21CO0FBRnVCLE9BQTVCLENBQVA7QUFJRDtBQUVEO0FBQ0Y7QUFDQTs7QUE5REE7O0FBQUE7QUFBQSxFQUFtRHpCLE9BQW5EO0FBdUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhMkIsT0FBYjtBQUdFO0FBQ0Y7QUFDQTtBQUNFLG1CQUFZQyxJQUFaLEVBQWlDO0FBQUE7O0FBQUE7O0FBQy9CLFNBQUtDLEtBQUwsR0FBYUQsSUFBYjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQWJBO0FBQUE7QUFBQSw2QkFjY0UsSUFkZCxFQWMwQztBQUFBLFVBQzlCekIsTUFEOEIsR0FDd0J5QixJQUR4QixDQUM5QnpCLE1BRDhCO0FBQUEsVUFDakIwQixJQURpQixHQUN3QkQsSUFEeEIsQ0FDdEJ4QixHQURzQjtBQUFBLFVBQ0YwQixRQURFLEdBQ3dCRixJQUR4QixDQUNYRyxPQURXO0FBQUEsVUFDY0MsS0FEZCxHQUN3QkosSUFEeEIsQ0FDUXZCLElBRFI7QUFFdEMsVUFBSTBCLE9BQU8sR0FBR0QsUUFBSCxhQUFHQSxRQUFILGNBQUdBLFFBQUgsR0FBZSxFQUExQjtBQUNBLFVBQUl6QixJQUFKOztBQUNBLFVBQUksc0JBQXNCNEIsSUFBdEIsQ0FBMkI5QixNQUEzQixDQUFKLEVBQXdDO0FBQ3RDLFlBQUlOLFFBQVEsQ0FBQ21DLEtBQUQsQ0FBWixFQUFxQjtBQUNuQkQsVUFBQUEsT0FBTyxtQ0FDRkQsUUFERTtBQUVMLDRCQUFnQjtBQUZYLFlBQVA7QUFJQXpCLFVBQUFBLElBQUksR0FBRyxnQkFBZTJCLEtBQWYsQ0FBUDtBQUNELFNBTkQsTUFNTztBQUNMM0IsVUFBQUEsSUFBSSxHQUFHMkIsS0FBUDtBQUNEO0FBQ0Y7O0FBQ0QsVUFBTTVCLEdBQUcsR0FBRyxLQUFLRSxhQUFMLENBQW1CdUIsSUFBbkIsQ0FBWjs7QUFDQSxhQUFPLEtBQUtGLEtBQUwsQ0FBVzNCLE9BQVgsQ0FBc0I7QUFDM0JHLFFBQUFBLE1BQU0sRUFBTkEsTUFEMkI7QUFFM0JDLFFBQUFBLEdBQUcsRUFBSEEsR0FGMkI7QUFHM0IyQixRQUFBQSxPQUFPLEVBQVBBLE9BSDJCO0FBSTNCMUIsUUFBQUEsSUFBSSxFQUFKQTtBQUoyQixPQUF0QixDQUFQO0FBTUQ7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7QUF6Q0E7QUFBQTtBQUFBLGtDQTBDZ0JELEdBMUNoQixFQTBDNkI7QUFDekIsVUFBSSx5QkFBQUEsR0FBRyxNQUFILENBQUFBLEdBQUcsRUFBUyxXQUFULENBQUgsS0FBNkIsQ0FBN0IsSUFBa0MseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsV0FBVCxDQUFILEtBQTZCLENBQW5FLEVBQXNFO0FBQ3BFLGVBQU8scUJBQXFCLEtBQUt1QixLQUFMLENBQVdPLE9BQWhDLEdBQTBDOUIsR0FBakQ7QUFDRCxPQUZELE1BRU8sSUFBSSxxQkFBcUI2QixJQUFyQixDQUEwQjdCLEdBQTFCLENBQUosRUFBb0M7QUFDekMsZUFBTyxtQkFBbUJBLEdBQTFCO0FBQ0QsT0FGTSxNQUVBLElBQUkseUJBQUFBLEdBQUcsTUFBSCxDQUFBQSxHQUFHLEVBQVMsWUFBVCxDQUFILEtBQThCLENBQTlCLElBQW1DQSxHQUFHLENBQUMsQ0FBRCxDQUFILEtBQVcsR0FBbEQsRUFBdUQ7QUFDNUQsZUFBTyxxQkFBcUIsS0FBS3VCLEtBQUwsQ0FBV08sT0FBaEMsR0FBMEMsVUFBMUMsR0FBdUQ5QixHQUE5RDtBQUNELE9BRk0sTUFFQTtBQUNMLGVBQU9BLEdBQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOztBQXhEQTtBQUFBO0FBQUEsNEJBeUR1QitCLEdBekR2QixFQXlEa0Q7QUFDOUMsYUFBTyxJQUFJckMsT0FBSixDQUFrQixJQUFsQixFQUF3QnFDLEdBQXhCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUEvREE7QUFBQTtBQUFBLDZCQWlFSS9CLEdBakVKLEVBa0VJVyxXQWxFSixFQW1FSTtBQUNBLGFBQU8sSUFBSU0sUUFBSixDQUFtQixJQUFuQixFQUF5QmpCLEdBQXpCLEVBQThCVyxXQUE5QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBekVBO0FBQUE7QUFBQTtBQUFBLDZGQTJFSXFCLFFBM0VKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTZFVUMsZ0JBQUFBLFNBN0VWLEdBNkVzQixxQkFBQUQsUUFBUSxNQUFSLENBQUFBLFFBQVEsRUFBSyxVQUFDcEMsT0FBRCxFQUFhO0FBQzFDLHNCQUFNc0MsUUFBUSxHQUFHQyxLQUFLLEVBQXRCO0FBQ0F2QyxrQkFBQUEsT0FBTyxDQUFDUSxRQUFSLEdBQW1COEIsUUFBUSxDQUFDMUIsT0FBNUI7QUFDQSx5QkFBTzBCLFFBQVA7QUFDRCxpQkFKeUIsQ0E3RTlCO0FBQUE7QUFBQSx1QkFrRnNCLEtBQUt0QyxPQUFMLENBQWdDO0FBQ2hERyxrQkFBQUEsTUFBTSxFQUFFLE1BRHdDO0FBRWhEQyxrQkFBQUEsR0FBRyxFQUFFLEtBQUtFLGFBQUwsQ0FBbUIsZ0JBQW5CLENBRjJDO0FBR2hERCxrQkFBQUEsSUFBSSxFQUFFO0FBQ0ptQyxvQkFBQUEsYUFBYSxFQUFFLHFCQUFBSixRQUFRLE1BQVIsQ0FBQUEsUUFBUSxFQUFLLFVBQUNwQyxPQUFEO0FBQUEsNkJBQWFBLE9BQU8sQ0FBQ3lDLFdBQVIsRUFBYjtBQUFBLHFCQUFMO0FBRG5CO0FBSDBDLGlCQUFoQyxDQWxGdEI7O0FBQUE7QUFrRlVDLGdCQUFBQSxHQWxGVjs7QUF5RkkscURBQUFBLEdBQUcsQ0FBQ0MsT0FBSixrQkFBb0IsVUFBQ0MsTUFBRCxFQUFTQyxDQUFULEVBQWU7QUFDakMsc0JBQU1QLFFBQVEsR0FBR0QsU0FBUyxDQUFDUSxDQUFELENBQTFCOztBQUNBLHNCQUFJRCxNQUFNLENBQUNFLFVBQVAsSUFBcUIsR0FBekIsRUFBOEI7QUFDNUJSLG9CQUFBQSxRQUFRLENBQUNTLE1BQVQsQ0FBZ0JILE1BQU0sQ0FBQ0EsTUFBdkI7QUFDRCxtQkFGRCxNQUVPO0FBQ0xOLG9CQUFBQSxRQUFRLENBQUNVLE9BQVQsQ0FBaUJKLE1BQU0sQ0FBQ0EsTUFBeEI7QUFDRDtBQUNGLGlCQVBEOztBQXpGSixrREFpR1dGLEdBakdYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFxR0EsU0FBU0gsS0FBVCxHQUFvQjtBQUNsQixNQUFJVSxRQUF5QyxHQUFHLG9CQUFNLENBQUUsQ0FBeEQ7O0FBQ0EsTUFBSUMsT0FBeUIsR0FBRyxtQkFBTSxDQUFFLENBQXhDOztBQUNBLE1BQU10QyxPQUFPLEdBQUcsYUFBZSxVQUFDb0MsT0FBRCxFQUFVRCxNQUFWLEVBQXFCO0FBQ2xERSxJQUFBQSxRQUFRLEdBQUdELE9BQVg7QUFDQUUsSUFBQUEsT0FBTyxHQUFHSCxNQUFWO0FBQ0QsR0FIZSxDQUFoQjtBQUlBLFNBQU87QUFDTG5DLElBQUFBLE9BQU8sRUFBUEEsT0FESztBQUVMb0MsSUFBQUEsT0FBTyxFQUFFQyxRQUZKO0FBR0xGLElBQUFBLE1BQU0sRUFBRUc7QUFISCxHQUFQO0FBS0Q7QUFFRDs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdEQsY0FBYyxDQUFDLFNBQUQsRUFBWSxVQUFDOEIsSUFBRDtBQUFBLFNBQVUsSUFBSUQsT0FBSixDQUFZQyxJQUFaLENBQVY7QUFBQSxDQUFaLENBQWQ7QUFFQSxlQUFlRCxPQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgQ2hhdHRlciBSRVNUIEFQSSBjYWxsc1xuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBTY2hlbWEgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBpc09iamVjdCB9IGZyb20gJy4uL3V0aWwvZnVuY3Rpb24nO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIENoYXR0ZXJSZXF1ZXN0UGFyYW1zID0gT21pdDxIdHRwUmVxdWVzdCwgJ2JvZHknPiAmIHtcbiAgYm9keT86IHN0cmluZyB8IG9iamVjdCB8IG51bGw7XG59O1xuXG5leHBvcnQgdHlwZSBCYXRjaFJlcXVlc3RQYXJhbXMgPSB7XG4gIG1ldGhvZDogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgcmljaElucHV0PzogYW55O1xufTtcblxudHlwZSBCYXRjaFJlcXVlc3RUdXBwbGU8UyBleHRlbmRzIFNjaGVtYSwgUlQgZXh0ZW5kcyBhbnlbXT4gPSB7XG4gIFtLIGluIGtleW9mIFJUXTogUmVxdWVzdDxTLCBSVFtLXT47XG59O1xuXG50eXBlIEJhdGNoUmVzdWx0VHVwcGxlPFJUIGV4dGVuZHMgYW55W10+ID0ge1xuICBbSyBpbiBrZXlvZiBSVF06IHtcbiAgICBzdGF0dXNDb2RlOiBudW1iZXI7XG4gICAgcmVzdWx0OiBSVFtLXTtcbiAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIEJhdGNoUmVzcG9uc2U8UlQgZXh0ZW5kcyBhbnlbXT4gPSB7XG4gIGhhc0Vycm9yczogYm9vbGVhbjtcbiAgcmVzdWx0czogQmF0Y2hSZXN1bHRUdXBwbGU8UlQ+O1xufTtcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIEEgY2xhc3MgcmVwcmVzZW50aW5nIGNoYXR0ZXIgQVBJIHJlcXVlc3RcbiAqL1xuY2xhc3MgUmVxdWVzdDxTIGV4dGVuZHMgU2NoZW1hLCBSPiB7XG4gIF9jaGF0dGVyOiBDaGF0dGVyPFM+O1xuICBfcmVxdWVzdDogQ2hhdHRlclJlcXVlc3RQYXJhbXM7XG4gIF9wcm9taXNlOiBQcm9taXNlPFI+IHwgdW5kZWZpbmVkO1xuXG4gIGNvbnN0cnVjdG9yKGNoYXR0ZXI6IENoYXR0ZXI8Uz4sIHJlcXVlc3Q6IENoYXR0ZXJSZXF1ZXN0UGFyYW1zKSB7XG4gICAgdGhpcy5fY2hhdHRlciA9IGNoYXR0ZXI7XG4gICAgdGhpcy5fcmVxdWVzdCA9IHJlcXVlc3Q7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgcGFyYW1ldGVycyBpbiBiYXRjaCByZXF1ZXN0IGZvcm1cbiAgICovXG4gIGJhdGNoUGFyYW1zKCkge1xuICAgIGNvbnN0IHsgbWV0aG9kLCB1cmwsIGJvZHkgfSA9IHRoaXMuX3JlcXVlc3Q7XG4gICAgcmV0dXJuIHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIHVybDogdGhpcy5fY2hhdHRlci5fbm9ybWFsaXplVXJsKHVybCksXG4gICAgICAuLi4odHlwZW9mIGJvZHkgIT09ICd1bmRlZmluZWQnID8geyByaWNoSW5wdXQ6IGJvZHkgfSA6IHt9KSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHBhcmFtZXRlcnMgaW4gYmF0Y2ggcmVxdWVzdCBmb3JtXG4gICAqXG4gICAqIEBtZXRob2QgQ2hhdHRlcn5SZXF1ZXN0I3Byb21pc2VcbiAgICogQHJldHVybnMge1Byb21pc2UuPENoYXR0ZXJ+UmVxdWVzdFJlc3VsdD59XG4gICAqL1xuICBwcm9taXNlKCkge1xuICAgIHJldHVybiAoXG4gICAgICB0aGlzLl9wcm9taXNlIHx8ICh0aGlzLl9wcm9taXNlID0gdGhpcy5fY2hhdHRlci5fcmVxdWVzdCh0aGlzLl9yZXF1ZXN0KSlcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgTm9kZS5qcyBTdHJlYW0gb2JqZWN0IGZvciByZXF1ZXN0XG4gICAqXG4gICAqIEBtZXRob2QgQ2hhdHRlcn5SZXF1ZXN0I3N0cmVhbVxuICAgKiBAcmV0dXJucyB7c3RyZWFtLlN0cmVhbX1cbiAgICovXG4gIHN0cmVhbSgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2hhdHRlci5fcmVxdWVzdDxSPih0aGlzLl9yZXF1ZXN0KS5zdHJlYW0oKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9taXNlL0ErIGludGVyZmFjZVxuICAgKiBodHRwOi8vcHJvbWlzZXMtYXBsdXMuZ2l0aHViLmlvL3Byb21pc2VzLXNwZWMvXG4gICAqXG4gICAqIERlbGVnYXRlIHRvIGRlZmVycmVkIHByb21pc2UsIHJldHVybiBwcm9taXNlIGluc3RhbmNlIGZvciBiYXRjaCByZXN1bHRcbiAgICovXG4gIHRoZW48VT4oXG4gICAgb25SZXNvbHZlPzogKHZhbHVlOiBSKSA9PiBVIHwgUHJvbWlzZUxpa2U8VT4sXG4gICAgb25SZWplY3Q/OiAoZTogYW55KSA9PiBVIHwgUHJvbWlzZUxpa2U8VT4sXG4gICkge1xuICAgIHJldHVybiB0aGlzLnByb21pc2UoKS50aGVuKG9uUmVzb2x2ZSwgb25SZWplY3QpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFwcHBlbmRRdWVyeVBhcmFtc1RvVXJsKFxuICB1cmw6IHN0cmluZyxcbiAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbikge1xuICBpZiAocXVlcnlQYXJhbXMpIHtcbiAgICBjb25zdCBxc3RyaW5nID0gT2JqZWN0LmtleXMocXVlcnlQYXJhbXMpXG4gICAgICAubWFwKFxuICAgICAgICAobmFtZSkgPT5cbiAgICAgICAgICBgJHtuYW1lfT0ke2VuY29kZVVSSUNvbXBvbmVudChTdHJpbmcocXVlcnlQYXJhbXNbbmFtZV0gPz8gJycpKX1gLFxuICAgICAgKVxuICAgICAgLmpvaW4oJyYnKTtcbiAgICB1cmwgKz0gKHVybC5pbmRleE9mKCc/JykgPiAwID8gJyYnIDogJz8nKSArIHFzdHJpbmc7XG4gIH1cbiAgcmV0dXJuIHVybDtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuZXhwb3J0IGNsYXNzIFJlc291cmNlPFMgZXh0ZW5kcyBTY2hlbWEsIFI+IGV4dGVuZHMgUmVxdWVzdDxTLCBSPiB7XG4gIF91cmw6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIGNoYXR0ZXI6IENoYXR0ZXI8Uz4sXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbiAgKSB7XG4gICAgc3VwZXIoY2hhdHRlciwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHVybDogYXBwcGVuZFF1ZXJ5UGFyYW1zVG9VcmwodXJsLCBxdWVyeVBhcmFtcyksXG4gICAgfSk7XG4gICAgdGhpcy5fdXJsID0gdGhpcy5fcmVxdWVzdC51cmw7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IHJlc291cmNlXG4gICAqL1xuICBjcmVhdGU8UjEgPSBhbnk+KGRhdGE6IHN0cmluZyB8IG9iamVjdCB8IG51bGwpIHtcbiAgICByZXR1cm4gdGhpcy5fY2hhdHRlci5yZXF1ZXN0PFIxPih7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybDogdGhpcy5fdXJsLFxuICAgICAgYm9keTogZGF0YSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSByZXNvdXJjZSBjb250ZW50XG4gICAqL1xuICByZXRyaWV2ZTxSMSA9IFI+KCkge1xuICAgIHJldHVybiB0aGlzLl9jaGF0dGVyLnJlcXVlc3Q8UjE+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICB1cmw6IHRoaXMuX3VybCxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGUgc3BlY2lmaWVkIHJlc291cmNlXG4gICAqL1xuICB1cGRhdGU8UjEgPSBhbnk+KGRhdGE6IG9iamVjdCkge1xuICAgIHJldHVybiB0aGlzLl9jaGF0dGVyLnJlcXVlc3Q8UjE+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiB0aGlzLl91cmwsXG4gICAgICBib2R5OiBkYXRhLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSBzcGVjaWZpZWQgcmVzb3VyY2VcbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NoYXR0ZXIucmVxdWVzdDx2b2lkPih7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgdXJsOiB0aGlzLl91cmwsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBSZXNvdXJjZSNkZXN0cm95KClcbiAgICovXG4gIGRlbGV0ZSA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBSZXNvdXJjZSNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBBUEkgY2xhc3MgZm9yIENoYXR0ZXIgUkVTVCBBUEkgY2FsbFxuICovXG5leHBvcnQgY2xhc3MgQ2hhdHRlcjxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmRpbmcgcmVxdWVzdCB0byBBUEkgZW5kcG9pbnRcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZXF1ZXN0PFI+KHJlcV86IENoYXR0ZXJSZXF1ZXN0UGFyYW1zKSB7XG4gICAgY29uc3QgeyBtZXRob2QsIHVybDogdXJsXywgaGVhZGVyczogaGVhZGVyc18sIGJvZHk6IGJvZHlfIH0gPSByZXFfO1xuICAgIGxldCBoZWFkZXJzID0gaGVhZGVyc18gPz8ge307XG4gICAgbGV0IGJvZHk7XG4gICAgaWYgKC9eKHB1dHxwb3N0fHBhdGNoKSQvaS50ZXN0KG1ldGhvZCkpIHtcbiAgICAgIGlmIChpc09iamVjdChib2R5XykpIHtcbiAgICAgICAgaGVhZGVycyA9IHtcbiAgICAgICAgICAuLi5oZWFkZXJzXyxcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9O1xuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoYm9keV8pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYm9keSA9IGJvZHlfO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB1cmwgPSB0aGlzLl9ub3JtYWxpemVVcmwodXJsXyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPih7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzLFxuICAgICAgYm9keSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb252ZXJ0IHBhdGggdG8gc2l0ZSByb290IHJlbGF0aXZlIHVybFxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX25vcm1hbGl6ZVVybCh1cmw6IHN0cmluZykge1xuICAgIGlmICh1cmwuaW5kZXhPZignL2NoYXR0ZXIvJykgPT09IDAgfHwgdXJsLmluZGV4T2YoJy9jb25uZWN0LycpID09PSAwKSB7XG4gICAgICByZXR1cm4gJy9zZXJ2aWNlcy9kYXRhL3YnICsgdGhpcy5fY29ubi52ZXJzaW9uICsgdXJsO1xuICAgIH0gZWxzZSBpZiAoL15cXC92W1xcZF0rXFwuW1xcZF0rXFwvLy50ZXN0KHVybCkpIHtcbiAgICAgIHJldHVybiAnL3NlcnZpY2VzL2RhdGEnICsgdXJsO1xuICAgIH0gZWxzZSBpZiAodXJsLmluZGV4T2YoJy9zZXJ2aWNlcy8nKSAhPT0gMCAmJiB1cmxbMF0gPT09ICcvJykge1xuICAgICAgcmV0dXJuICcvc2VydmljZXMvZGF0YS92JyArIHRoaXMuX2Nvbm4udmVyc2lvbiArICcvY2hhdHRlcicgKyB1cmw7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB1cmw7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIE1ha2UgYSByZXF1ZXN0IGZvciBjaGF0dGVyIEFQSSByZXNvdXJjZVxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4ocmVxOiBDaGF0dGVyUmVxdWVzdFBhcmFtcykge1xuICAgIHJldHVybiBuZXcgUmVxdWVzdDxTLCBSPih0aGlzLCByZXEpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1ha2UgYSByZXNvdXJjZSByZXF1ZXN0IHRvIGNoYXR0ZXIgQVBJXG4gICAqL1xuICByZXNvdXJjZTxSID0gdW5rbm93bj4oXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgcXVlcnlQYXJhbXM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbCB9IHwgbnVsbCxcbiAgKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNvdXJjZTxTLCBSPih0aGlzLCB1cmwsIHF1ZXJ5UGFyYW1zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNYWtlIGEgYmF0Y2ggcmVxdWVzdCB0byBjaGF0dGVyIEFQSVxuICAgKi9cbiAgYXN5bmMgYmF0Y2g8UlQgZXh0ZW5kcyBhbnlbXT4oXG4gICAgcmVxdWVzdHM6IEJhdGNoUmVxdWVzdFR1cHBsZTxTLCBSVD4sXG4gICk6IFByb21pc2U8QmF0Y2hSZXNwb25zZTxSVD4+IHtcbiAgICBjb25zdCBkZWZlcnJlZHMgPSByZXF1ZXN0cy5tYXAoKHJlcXVlc3QpID0+IHtcbiAgICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICAgIHJlcXVlc3QuX3Byb21pc2UgPSBkZWZlcnJlZC5wcm9taXNlO1xuICAgICAgcmV0dXJuIGRlZmVycmVkO1xuICAgIH0pO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdDxCYXRjaFJlc3BvbnNlPFJUPj4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHRoaXMuX25vcm1hbGl6ZVVybCgnL2Nvbm5lY3QvYmF0Y2gnKSxcbiAgICAgIGJvZHk6IHtcbiAgICAgICAgYmF0Y2hSZXF1ZXN0czogcmVxdWVzdHMubWFwKChyZXF1ZXN0KSA9PiByZXF1ZXN0LmJhdGNoUGFyYW1zKCkpLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXMucmVzdWx0cy5mb3JFYWNoKChyZXN1bHQsIGkpID0+IHtcbiAgICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXJyZWRzW2ldO1xuICAgICAgaWYgKHJlc3VsdC5zdGF0dXNDb2RlID49IDQwMCkge1xuICAgICAgICBkZWZlcnJlZC5yZWplY3QocmVzdWx0LnJlc3VsdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkZWZlcnJlZC5yZXNvbHZlKHJlc3VsdC5yZXN1bHQpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiByZXM7XG4gIH1cbn1cblxuZnVuY3Rpb24gZGVmZXI8VD4oKSB7XG4gIGxldCByZXNvbHZlXzogKHI6IFQgfCBQcm9taXNlTGlrZTxUPikgPT4gdm9pZCA9ICgpID0+IHt9O1xuICBsZXQgcmVqZWN0XzogKGU6IGFueSkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHJlc29sdmVfID0gcmVzb2x2ZTtcbiAgICByZWplY3RfID0gcmVqZWN0O1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBwcm9taXNlLFxuICAgIHJlc29sdmU6IHJlc29sdmVfLFxuICAgIHJlamVjdDogcmVqZWN0XyxcbiAgfTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKlxuICogUmVnaXN0ZXIgaG9vayBpbiBjb25uZWN0aW9uIGluc3RhbnRpYXRpb24gZm9yIGR5bmFtaWNhbGx5IGFkZGluZyB0aGlzIEFQSSBtb2R1bGUgZmVhdHVyZXNcbiAqL1xucmVnaXN0ZXJNb2R1bGUoJ2NoYXR0ZXInLCAoY29ubikgPT4gbmV3IENoYXR0ZXIoY29ubikpO1xuXG5leHBvcnQgZGVmYXVsdCBDaGF0dGVyO1xuIl19