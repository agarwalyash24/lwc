import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import "core-js/modules/es.function.name";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.replace";
import "core-js/modules/es.string.split";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context6; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context6 = Object.prototype.toString.call(o)).call(_context6, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

import fs from 'fs-extra';
import xml2js from 'xml2js';
import { castTypeUsingSchema } from '../../soap';
import { isMapObject } from '../../util/function';
/**
 *
 */

var WSDLRestrictionSchema = {
  $: {
    base: 'string'
  },
  enumeration: [{
    $: {
      value: 'string'
    }
  }],
  'xsd:enumeration': [{
    $: {
      value: 'string'
    }
  }]
};
var WSDLSimpleTypeSchema = {
  $: {
    name: 'string'
  },
  restriction: WSDLRestrictionSchema,
  'xsd:restriction': WSDLRestrictionSchema
};
var WSDLElementSchema = {
  $: {
    name: 'string',
    type: 'string',
    minOccurs: '?number',
    maxOccurs: '?string',
    nillable: '?boolean'
  }
};
var WSDLSequenceSchema = {
  element: ['?', WSDLElementSchema],
  'xsd:element': ['?', WSDLElementSchema]
};
var WSDLExtensionSchema = {
  $: {
    base: 'string'
  },
  sequence: {
    '?': WSDLSequenceSchema
  },
  'xsd:sequence': {
    '?': WSDLSequenceSchema
  }
};
var WSDLComplexContentSchema = {
  extension: {
    '?': WSDLExtensionSchema
  },
  'xsd:extension': {
    '?': WSDLExtensionSchema
  }
};
var WSDLComplexTypeSchema = {
  $: {
    name: 'string'
  },
  sequence: {
    '?': WSDLSequenceSchema
  },
  'xsd:sequence': {
    '?': WSDLSequenceSchema
  },
  complexContent: {
    '?': WSDLComplexContentSchema
  },
  'xsd:complexContent': {
    '?': WSDLComplexContentSchema
  }
};
var WSDLSchemaSchema = {
  $: 'any',
  complexType: ['?', 'any'],
  simpleType: ['?', 'any'],
  'xsd:complexType': ['?', 'any'],
  'xsd:simpleType': ['?', 'any']
};
var WSDLSchema = {
  definitions: {
    $: 'any',
    types: {
      schema: ['?', WSDLSchemaSchema],
      'xsd:schema': ['?', WSDLSchemaSchema]
    },
    message: ['any'],
    portType: {
      $: 'any',
      operation: ['any']
    },
    binding: {
      $: 'any',
      operation: ['any']
    },
    service: {
      $: 'any',
      documentation: 'string',
      operation: ['any']
    }
  }
};
/**
 *
 */

/**
 *
 */
function toJsType(xsdType, simpleTypes) {
  switch (xsdType) {
    case 'xsd:boolean':
      return 'boolean';

    case 'xsd:string':
    case 'xsd:date':
    case 'xsd:dateTime':
    case 'xsd:time':
    case 'xsd:base64Binary':
      return 'string';

    case 'xsd:int':
    case 'xsd:long':
    case 'xsd:double':
      return 'number';

    case 'xsd:anyType':
      return 'any';

    default:
      {
        var _xsdType$split = xsdType.split(':'),
            _xsdType$split2 = _slicedToArray(_xsdType$split, 2),
            ns = _xsdType$split2[0],
            _type = _xsdType$split2[1];

        if (simpleTypes[_type]) {
          return simpleTypes[_type];
        }

        if (ns) {
          return _type;
        }

        return xsdType;
      }
  }
}
/**
 *
 */


function readWSDLFile(_x) {
  return _readWSDLFile.apply(this, arguments);
}
/**
 *
 */


function _readWSDLFile() {
  _readWSDLFile = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(filePath) {
    var xmlData, json;
    return _regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return fs.readFile(filePath, 'utf8');

          case 2:
            xmlData = _context.sent;
            _context.next = 5;
            return xml2js.parseStringPromise(xmlData, {
              explicitArray: false
            });

          case 5:
            json = _context.sent;
            return _context.abrupt("return", castTypeUsingSchema(json, WSDLSchema));

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _readWSDLFile.apply(this, arguments);
}

function getTypeInfo(el, simpleTypes) {
  var type = toJsType(el.$.type, simpleTypes);
  var isArray = el.$.maxOccurs === 'unbounded';
  var nillable = !isArray && el.$.minOccurs === 0 || el.$.nillable;
  return isArray ? nillable ? ['?', type] : [type] : nillable ? "?".concat(type) : type;
}
/**
 *
 */


function extractComplexTypes(wsdl) {
  var _ref, _types$schema, _ref3, _types$schema2;

  console.log(wsdl.definitions.types['xsd:schema']);
  var schemas = {};
  var simpleTypes = {};
  var types = wsdl.definitions.types;

  var _iterator = _createForOfIteratorHelper((_ref = (_types$schema = types.schema) !== null && _types$schema !== void 0 ? _types$schema : types['xsd:schema']) !== null && _ref !== void 0 ? _ref : []),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var _ref2, _sc$simpleType;

      var sc = _step.value;

      var _iterator3 = _createForOfIteratorHelper((_ref2 = (_sc$simpleType = sc.simpleType) !== null && _sc$simpleType !== void 0 ? _sc$simpleType : sc['xsd:simpleType']) !== null && _ref2 !== void 0 ? _ref2 : []),
          _step3;

      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var _simpleType$restricti;

          var st = _step3.value;
          var simpleType = castTypeUsingSchema(st, WSDLSimpleTypeSchema);
          var rs = (_simpleType$restricti = simpleType.restriction) !== null && _simpleType$restricti !== void 0 ? _simpleType$restricti : simpleType['xsd:restriction'];
          var base = rs.$.base.split(':')[1];
          simpleTypes[simpleType.$.name] = base;
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  console.log({
    simpleTypes: simpleTypes
  });

  var _iterator2 = _createForOfIteratorHelper((_ref3 = (_types$schema2 = types.schema) !== null && _types$schema2 !== void 0 ? _types$schema2 : types['xsd:schema']) !== null && _ref3 !== void 0 ? _ref3 : []),
      _step2;

  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var _ref4, _sc$complexType;

      var _sc = _step2.value;

      var _iterator4 = _createForOfIteratorHelper((_ref4 = (_sc$complexType = _sc.complexType) !== null && _sc$complexType !== void 0 ? _sc$complexType : _sc['xsd:complexType']) !== null && _ref4 !== void 0 ? _ref4 : []),
          _step4;

      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var _complexType$sequence, _seq$element, _complexType$complexC;

          var ct = _step4.value;
          var complexType = castTypeUsingSchema(ct, WSDLComplexTypeSchema);
          var schema = {
            type: complexType.$.name,
            props: {}
          };
          var seq = (_complexType$sequence = complexType.sequence) !== null && _complexType$sequence !== void 0 ? _complexType$sequence : complexType['xsd:sequence'];
          var els = (_seq$element = seq === null || seq === void 0 ? void 0 : seq.element) !== null && _seq$element !== void 0 ? _seq$element : seq === null || seq === void 0 ? void 0 : seq['xsd:element'];

          var _iterator5 = _createForOfIteratorHelper(els !== null && els !== void 0 ? els : []),
              _step5;

          try {
            for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
              var _el = _step5.value;
              schema.props[_el.$.name] = getTypeInfo(_el, simpleTypes);
            }
          } catch (err) {
            _iterator5.e(err);
          } finally {
            _iterator5.f();
          }

          var cc = (_complexType$complexC = complexType.complexContent) !== null && _complexType$complexC !== void 0 ? _complexType$complexC : complexType['xsd:complexContent'];

          if (cc) {
            var _cc$extension;

            var extension = (_cc$extension = cc.extension) !== null && _cc$extension !== void 0 ? _cc$extension : cc['xsd:extension'];

            if (extension) {
              var _extension$sequence, _seq$element2;

              schema.extends = extension.$.base.split(':')[1];

              var _seq = (_extension$sequence = extension.sequence) !== null && _extension$sequence !== void 0 ? _extension$sequence : extension['xsd:sequence'];

              var _els = (_seq$element2 = _seq === null || _seq === void 0 ? void 0 : _seq.element) !== null && _seq$element2 !== void 0 ? _seq$element2 : _seq === null || _seq === void 0 ? void 0 : _seq['xsd:element'];

              var _iterator6 = _createForOfIteratorHelper(_els !== null && _els !== void 0 ? _els : []),
                  _step6;

              try {
                for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                  var el = _step6.value;
                  schema.props[el.$.name] = getTypeInfo(el, simpleTypes);
                }
              } catch (err) {
                _iterator6.e(err);
              } finally {
                _iterator6.f();
              }
            }
          }

          schemas[complexType.$.name] = schema;
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }

  return schemas;
}
/**
 *
 */


var GENERATED_MESSAGE_COMMENT = "/**\n * This file is generated from WSDL file by wsdl2schema.ts.\n * Do not modify directly.\n * To generate the file, run \"ts-node path/to/wsdl2schema.ts path/to/wsdl.xml path/to/schema.ts\"\n */\n";
/**
 *
 */

function dumpSchema(_x2, _x3) {
  return _dumpSchema.apply(this, arguments);
}
/**
 *
 */


function _dumpSchema() {
  _dumpSchema = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(schemas, outFile) {
    var out, print, println, writeSchema, writeTypeDef, writeTypeDefs;
    return _regeneratorRuntime.wrap(function _callee2$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            writeTypeDefs = function _writeTypeDefs(schemas) {
              for (var _i2 = 0, _Object$keys3 = _Object$keys(schemas); _i2 < _Object$keys3.length; _i2++) {
                var _name2 = _Object$keys3[_i2];
                var schema = schemas[_name2];
                print("export type ".concat(_name2, " = "));
                writeTypeDef(schema, schemas);
                println(';');
                println();
              }

              println('export type ApiSchemaTypes = {');

              for (var _i3 = 0, _Object$keys4 = _Object$keys(schemas); _i3 < _Object$keys4.length; _i3++) {
                var _context3;

                var _name3 = _Object$keys4[_i3];
                println(_concatInstanceProperty(_context3 = "".concat(_name3, ": ")).call(_context3, _name3, ";"), 2);
              }

              println('};');
            };

            writeTypeDef = function _writeTypeDef(o, schemas) {
              var indent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

              if (typeof o === 'string') {
                print(o);
              } else if (isMapObject(o)) {
                if ('type' in o && 'props' in o) {
                  if ('extends' in o && typeof o.extends === 'string') {
                    print("".concat(o.extends, " & "));
                  }

                  writeTypeDef(o.props, schemas, indent);
                  return;
                }

                var keys = _Object$keys(o);

                if (keys.length > 0) {
                  println('{');

                  for (var _i = 0, _Object$keys2 = _Object$keys(o); _i < _Object$keys2.length; _i++) {
                    var _context2;

                    var prop = _Object$keys2[_i];
                    var value = o[prop];
                    var nillable = false;
                    var isArray = false;

                    if (_Array$isArray(value)) {
                      isArray = true;
                      var len = value.length;

                      if (len === 2 && value[0] === '?') {
                        nillable = true;
                        value = value[1];
                      } else {
                        value = value[0];
                      }
                    } else if (isMapObject(value)) {
                      if ('?' in value) {
                        nillable = true;
                        value = value['?'];
                      }
                    }

                    if (typeof value === 'string' && value[0] === '?') {
                      nillable = true;
                      value = value.substring(1);
                    }

                    print(_concatInstanceProperty(_context2 = "".concat(prop)).call(_context2, nillable ? '?' : '', ": "), indent + 2);
                    writeTypeDef(value, schemas, indent + 2);

                    if (isArray) {
                      print('[]');
                    }

                    if (nillable) {
                      print(' | null | undefined');
                    }

                    println(';');
                  }

                  print('}', indent);
                } else {
                  print('{}');
                }
              }
            };

            writeSchema = function _writeSchema(o) {
              var indent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

              if (indent > 20) {
                print("'any'");
                return;
              }

              if (_Array$isArray(o)) {
                print('[');
                var i = 0;

                var _iterator7 = _createForOfIteratorHelper(o),
                    _step7;

                try {
                  for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                    var co = _step7.value;

                    if (i > 0) {
                      print(', ');
                    }

                    writeSchema(co, indent);
                    i++;
                  }
                } catch (err) {
                  _iterator7.e(err);
                } finally {
                  _iterator7.f();
                }

                print(']');
              } else if (isMapObject(o)) {
                var keys = _Object$keys(o);

                if (keys.length > 0) {
                  println('{');

                  var _iterator8 = _createForOfIteratorHelper(keys),
                      _step8;

                  try {
                    for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
                      var _name = _step8.value;
                      var _co = o[_name];
                      var nameId = /^[\w_$]+$/.test(_name) ? _name : "'".concat(_name, "'");
                      print("".concat(nameId, ": "), indent + 2);
                      writeSchema(_co, indent + 2);
                      println(',');
                    }
                  } catch (err) {
                    _iterator8.e(err);
                  } finally {
                    _iterator8.f();
                  }

                  print('}', indent);
                } else {
                  print('{}');
                }
              } else {
                print(_JSON$stringify(o).replace(/"/g, "'"));
              }
            };

            out = fs.createWriteStream(outFile, 'utf8');

            print = function print(str) {
              var indent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

              for (var i = 0; i < indent; i++) {
                out.write(' ');
              }

              out.write(str);
            };

            println = function println() {
              var str = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var indent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
              print(str + '\n', indent);
            };

            return _context4.abrupt("return", new _Promise(function (resolve, reject) {
              out.on('error', reject);
              out.on('finish', function () {
                return resolve();
              });
              println(GENERATED_MESSAGE_COMMENT);
              print('export const ApiSchemas = ');
              writeSchema(schemas);
              println(' as const;');
              println();
              writeTypeDefs(schemas);
              out.end();
            }));

          case 7:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee2);
  }));
  return _dumpSchema.apply(this, arguments);
}

function main() {
  return _main.apply(this, arguments);
}

function _main() {
  _main = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
    var wsdlFilePath, outFilePath, wsdl, schemas;
    return _regeneratorRuntime.wrap(function _callee3$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            wsdlFilePath = process.argv[2];

            if (wsdlFilePath) {
              _context5.next = 4;
              break;
            }

            console.error('No input WSDL file is specified.');
            return _context5.abrupt("return");

          case 4:
            outFilePath = process.argv[3];

            if (wsdlFilePath) {
              _context5.next = 8;
              break;
            }

            console.error('No output typescript schema file is specified.');
            return _context5.abrupt("return");

          case 8:
            _context5.next = 10;
            return readWSDLFile(wsdlFilePath);

          case 10:
            wsdl = _context5.sent;
            schemas = extractComplexTypes(wsdl);
            dumpSchema(schemas, outFilePath);

          case 13:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee3);
  }));
  return _main.apply(this, arguments);
}

main();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9hcGkvd3NkbC93c2RsMnNjaGVtYS50cyJdLCJuYW1lcyI6WyJmcyIsInhtbDJqcyIsImNhc3RUeXBlVXNpbmdTY2hlbWEiLCJpc01hcE9iamVjdCIsIldTRExSZXN0cmljdGlvblNjaGVtYSIsIiQiLCJiYXNlIiwiZW51bWVyYXRpb24iLCJ2YWx1ZSIsIldTRExTaW1wbGVUeXBlU2NoZW1hIiwibmFtZSIsInJlc3RyaWN0aW9uIiwiV1NETEVsZW1lbnRTY2hlbWEiLCJ0eXBlIiwibWluT2NjdXJzIiwibWF4T2NjdXJzIiwibmlsbGFibGUiLCJXU0RMU2VxdWVuY2VTY2hlbWEiLCJlbGVtZW50IiwiV1NETEV4dGVuc2lvblNjaGVtYSIsInNlcXVlbmNlIiwiV1NETENvbXBsZXhDb250ZW50U2NoZW1hIiwiZXh0ZW5zaW9uIiwiV1NETENvbXBsZXhUeXBlU2NoZW1hIiwiY29tcGxleENvbnRlbnQiLCJXU0RMU2NoZW1hU2NoZW1hIiwiY29tcGxleFR5cGUiLCJzaW1wbGVUeXBlIiwiV1NETFNjaGVtYSIsImRlZmluaXRpb25zIiwidHlwZXMiLCJzY2hlbWEiLCJtZXNzYWdlIiwicG9ydFR5cGUiLCJvcGVyYXRpb24iLCJiaW5kaW5nIiwic2VydmljZSIsImRvY3VtZW50YXRpb24iLCJ0b0pzVHlwZSIsInhzZFR5cGUiLCJzaW1wbGVUeXBlcyIsInNwbGl0IiwibnMiLCJyZWFkV1NETEZpbGUiLCJmaWxlUGF0aCIsInJlYWRGaWxlIiwieG1sRGF0YSIsInBhcnNlU3RyaW5nUHJvbWlzZSIsImV4cGxpY2l0QXJyYXkiLCJqc29uIiwiZ2V0VHlwZUluZm8iLCJlbCIsImlzQXJyYXkiLCJleHRyYWN0Q29tcGxleFR5cGVzIiwid3NkbCIsImNvbnNvbGUiLCJsb2ciLCJzY2hlbWFzIiwic2MiLCJzdCIsInJzIiwiY3QiLCJwcm9wcyIsInNlcSIsImVscyIsImNjIiwiZXh0ZW5kcyIsIkdFTkVSQVRFRF9NRVNTQUdFX0NPTU1FTlQiLCJkdW1wU2NoZW1hIiwib3V0RmlsZSIsIndyaXRlU2NoZW1hIiwid3JpdGVUeXBlRGVmIiwid3JpdGVUeXBlRGVmcyIsInByaW50IiwicHJpbnRsbiIsIm8iLCJpbmRlbnQiLCJrZXlzIiwibGVuZ3RoIiwicHJvcCIsImxlbiIsInN1YnN0cmluZyIsImkiLCJjbyIsIm5hbWVJZCIsInRlc3QiLCJyZXBsYWNlIiwib3V0IiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJzdHIiLCJ3cml0ZSIsInJlc29sdmUiLCJyZWplY3QiLCJvbiIsImVuZCIsIm1haW4iLCJ3c2RsRmlsZVBhdGgiLCJwcm9jZXNzIiwiYXJndiIsImVycm9yIiwib3V0RmlsZVBhdGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxPQUFPQSxFQUFQLE1BQWUsVUFBZjtBQUNBLE9BQU9DLE1BQVAsTUFBbUIsUUFBbkI7QUFDQSxTQUFTQyxtQkFBVCxRQUFvQyxZQUFwQztBQUVBLFNBQVNDLFdBQVQsUUFBNEIscUJBQTVCO0FBRUE7QUFDQTtBQUNBOztBQUNBLElBQU1DLHFCQUFxQixHQUFHO0FBQzVCQyxFQUFBQSxDQUFDLEVBQUU7QUFBRUMsSUFBQUEsSUFBSSxFQUFFO0FBQVIsR0FEeUI7QUFFNUJDLEVBQUFBLFdBQVcsRUFBRSxDQUNYO0FBQ0VGLElBQUFBLENBQUMsRUFBRTtBQUFFRyxNQUFBQSxLQUFLLEVBQUU7QUFBVDtBQURMLEdBRFcsQ0FGZTtBQU81QixxQkFBbUIsQ0FDakI7QUFDRUgsSUFBQUEsQ0FBQyxFQUFFO0FBQUVHLE1BQUFBLEtBQUssRUFBRTtBQUFUO0FBREwsR0FEaUI7QUFQUyxDQUE5QjtBQWNBLElBQU1DLG9CQUFvQixHQUFHO0FBQzNCSixFQUFBQSxDQUFDLEVBQUU7QUFBRUssSUFBQUEsSUFBSSxFQUFFO0FBQVIsR0FEd0I7QUFFM0JDLEVBQUFBLFdBQVcsRUFBRVAscUJBRmM7QUFHM0IscUJBQW1CQTtBQUhRLENBQTdCO0FBTUEsSUFBTVEsaUJBQWlCLEdBQUc7QUFDeEJQLEVBQUFBLENBQUMsRUFBRTtBQUNESyxJQUFBQSxJQUFJLEVBQUUsUUFETDtBQUVERyxJQUFBQSxJQUFJLEVBQUUsUUFGTDtBQUdEQyxJQUFBQSxTQUFTLEVBQUUsU0FIVjtBQUlEQyxJQUFBQSxTQUFTLEVBQUUsU0FKVjtBQUtEQyxJQUFBQSxRQUFRLEVBQUU7QUFMVDtBQURxQixDQUExQjtBQVVBLElBQU1DLGtCQUFrQixHQUFHO0FBQ3pCQyxFQUFBQSxPQUFPLEVBQUUsQ0FBQyxHQUFELEVBQU1OLGlCQUFOLENBRGdCO0FBRXpCLGlCQUFlLENBQUMsR0FBRCxFQUFNQSxpQkFBTjtBQUZVLENBQTNCO0FBS0EsSUFBTU8sbUJBQW1CLEdBQUc7QUFDMUJkLEVBQUFBLENBQUMsRUFBRTtBQUFFQyxJQUFBQSxJQUFJLEVBQUU7QUFBUixHQUR1QjtBQUUxQmMsRUFBQUEsUUFBUSxFQUFFO0FBQUUsU0FBS0g7QUFBUCxHQUZnQjtBQUcxQixrQkFBZ0I7QUFBRSxTQUFLQTtBQUFQO0FBSFUsQ0FBNUI7QUFNQSxJQUFNSSx3QkFBd0IsR0FBRztBQUMvQkMsRUFBQUEsU0FBUyxFQUFFO0FBQUUsU0FBS0g7QUFBUCxHQURvQjtBQUUvQixtQkFBaUI7QUFBRSxTQUFLQTtBQUFQO0FBRmMsQ0FBakM7QUFLQSxJQUFNSSxxQkFBcUIsR0FBRztBQUM1QmxCLEVBQUFBLENBQUMsRUFBRTtBQUFFSyxJQUFBQSxJQUFJLEVBQUU7QUFBUixHQUR5QjtBQUU1QlUsRUFBQUEsUUFBUSxFQUFFO0FBQUUsU0FBS0g7QUFBUCxHQUZrQjtBQUc1QixrQkFBZ0I7QUFBRSxTQUFLQTtBQUFQLEdBSFk7QUFJNUJPLEVBQUFBLGNBQWMsRUFBRTtBQUFFLFNBQUtIO0FBQVAsR0FKWTtBQUs1Qix3QkFBc0I7QUFBRSxTQUFLQTtBQUFQO0FBTE0sQ0FBOUI7QUFRQSxJQUFNSSxnQkFBZ0IsR0FBRztBQUN2QnBCLEVBQUFBLENBQUMsRUFBRSxLQURvQjtBQUV2QnFCLEVBQUFBLFdBQVcsRUFBRSxDQUFDLEdBQUQsRUFBTSxLQUFOLENBRlU7QUFHdkJDLEVBQUFBLFVBQVUsRUFBRSxDQUFDLEdBQUQsRUFBTSxLQUFOLENBSFc7QUFJdkIscUJBQW1CLENBQUMsR0FBRCxFQUFNLEtBQU4sQ0FKSTtBQUt2QixvQkFBa0IsQ0FBQyxHQUFELEVBQU0sS0FBTjtBQUxLLENBQXpCO0FBUUEsSUFBTUMsVUFBVSxHQUFHO0FBQ2pCQyxFQUFBQSxXQUFXLEVBQUU7QUFDWHhCLElBQUFBLENBQUMsRUFBRSxLQURRO0FBRVh5QixJQUFBQSxLQUFLLEVBQUU7QUFDTEMsTUFBQUEsTUFBTSxFQUFFLENBQUMsR0FBRCxFQUFNTixnQkFBTixDQURIO0FBRUwsb0JBQWMsQ0FBQyxHQUFELEVBQU1BLGdCQUFOO0FBRlQsS0FGSTtBQU1YTyxJQUFBQSxPQUFPLEVBQUUsQ0FBQyxLQUFELENBTkU7QUFPWEMsSUFBQUEsUUFBUSxFQUFFO0FBQ1I1QixNQUFBQSxDQUFDLEVBQUUsS0FESztBQUVSNkIsTUFBQUEsU0FBUyxFQUFFLENBQUMsS0FBRDtBQUZILEtBUEM7QUFXWEMsSUFBQUEsT0FBTyxFQUFFO0FBQ1A5QixNQUFBQSxDQUFDLEVBQUUsS0FESTtBQUVQNkIsTUFBQUEsU0FBUyxFQUFFLENBQUMsS0FBRDtBQUZKLEtBWEU7QUFlWEUsSUFBQUEsT0FBTyxFQUFFO0FBQ1AvQixNQUFBQSxDQUFDLEVBQUUsS0FESTtBQUVQZ0MsTUFBQUEsYUFBYSxFQUFFLFFBRlI7QUFHUEgsTUFBQUEsU0FBUyxFQUFFLENBQUMsS0FBRDtBQUhKO0FBZkU7QUFESSxDQUFuQjtBQXdCQTtBQUNBO0FBQ0E7O0FBU0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0ksUUFBVCxDQUFrQkMsT0FBbEIsRUFBbUNDLFdBQW5DLEVBQTRFO0FBQzFFLFVBQVFELE9BQVI7QUFDRSxTQUFLLGFBQUw7QUFDRSxhQUFPLFNBQVA7O0FBQ0YsU0FBSyxZQUFMO0FBQ0EsU0FBSyxVQUFMO0FBQ0EsU0FBSyxjQUFMO0FBQ0EsU0FBSyxVQUFMO0FBQ0EsU0FBSyxrQkFBTDtBQUNFLGFBQU8sUUFBUDs7QUFDRixTQUFLLFNBQUw7QUFDQSxTQUFLLFVBQUw7QUFDQSxTQUFLLFlBQUw7QUFDRSxhQUFPLFFBQVA7O0FBQ0YsU0FBSyxhQUFMO0FBQ0UsYUFBTyxLQUFQOztBQUNGO0FBQVM7QUFBQSw2QkFDWUEsT0FBTyxDQUFDRSxLQUFSLENBQWMsR0FBZCxDQURaO0FBQUE7QUFBQSxZQUNBQyxFQURBO0FBQUEsWUFDSTdCLEtBREo7O0FBRVAsWUFBSTJCLFdBQVcsQ0FBQzNCLEtBQUQsQ0FBZixFQUF1QjtBQUNyQixpQkFBTzJCLFdBQVcsQ0FBQzNCLEtBQUQsQ0FBbEI7QUFDRDs7QUFDRCxZQUFJNkIsRUFBSixFQUFRO0FBQ04saUJBQU83QixLQUFQO0FBQ0Q7O0FBQ0QsZUFBTzBCLE9BQVA7QUFDRDtBQXhCSDtBQTBCRDtBQUVEO0FBQ0E7QUFDQTs7O1NBQ2VJLFk7OztBQVFmO0FBQ0E7QUFDQTs7OzsyRUFWQSxpQkFBNEJDLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQ3dCNUMsRUFBRSxDQUFDNkMsUUFBSCxDQUFZRCxRQUFaLEVBQXNCLE1BQXRCLENBRHhCOztBQUFBO0FBQ1FFLFlBQUFBLE9BRFI7QUFBQTtBQUFBLG1CQUVxQjdDLE1BQU0sQ0FBQzhDLGtCQUFQLENBQTBCRCxPQUExQixFQUFtQztBQUNwREUsY0FBQUEsYUFBYSxFQUFFO0FBRHFDLGFBQW5DLENBRnJCOztBQUFBO0FBRVFDLFlBQUFBLElBRlI7QUFBQSw2Q0FLUy9DLG1CQUFtQixDQUFDK0MsSUFBRCxFQUFPckIsVUFBUCxDQUw1Qjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBV0EsU0FBU3NCLFdBQVQsQ0FBcUJDLEVBQXJCLEVBQXNDWCxXQUF0QyxFQUErRTtBQUM3RSxNQUFJM0IsSUFBSSxHQUFHeUIsUUFBUSxDQUFDYSxFQUFFLENBQUM5QyxDQUFILENBQUtRLElBQU4sRUFBWTJCLFdBQVosQ0FBbkI7QUFDQSxNQUFNWSxPQUFPLEdBQUdELEVBQUUsQ0FBQzlDLENBQUgsQ0FBS1UsU0FBTCxLQUFtQixXQUFuQztBQUNBLE1BQU1DLFFBQVEsR0FBSSxDQUFDb0MsT0FBRCxJQUFZRCxFQUFFLENBQUM5QyxDQUFILENBQUtTLFNBQUwsS0FBbUIsQ0FBaEMsSUFBc0NxQyxFQUFFLENBQUM5QyxDQUFILENBQUtXLFFBQTVEO0FBQ0EsU0FBT29DLE9BQU8sR0FDVnBDLFFBQVEsR0FDTixDQUFDLEdBQUQsRUFBTUgsSUFBTixDQURNLEdBRU4sQ0FBQ0EsSUFBRCxDQUhRLEdBSVZHLFFBQVEsY0FDSkgsSUFESSxJQUVSQSxJQU5KO0FBT0Q7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVN3QyxtQkFBVCxDQUE2QkMsSUFBN0IsRUFBeUM7QUFBQTs7QUFDdkNDLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRixJQUFJLENBQUN6QixXQUFMLENBQWlCQyxLQUFqQixDQUF1QixZQUF2QixDQUFaO0FBQ0EsTUFBSTJCLE9BQTBDLEdBQUcsRUFBakQ7QUFDQSxNQUFNakIsV0FBdUMsR0FBRyxFQUFoRDtBQUNBLE1BQU1WLEtBQUssR0FBR3dCLElBQUksQ0FBQ3pCLFdBQUwsQ0FBaUJDLEtBQS9COztBQUp1QyxzRUFLdEJBLEtBQUssQ0FBQ0MsTUFMZ0IseURBS05ELEtBQUssQ0FBQyxZQUFELENBTEMsdUNBS2lCLEVBTGpCO0FBQUE7O0FBQUE7QUFLdkMsd0RBQTREO0FBQUE7O0FBQUEsVUFBakQ0QixFQUFpRDs7QUFBQSw2RUFDekNBLEVBQUUsQ0FBQy9CLFVBRHNDLDJEQUN4QitCLEVBQUUsQ0FBQyxnQkFBRCxDQURzQix5Q0FDQSxFQURBO0FBQUE7O0FBQUE7QUFDMUQsK0RBQThEO0FBQUE7O0FBQUEsY0FBbkRDLEVBQW1EO0FBQzVELGNBQU1oQyxVQUEwQixHQUFHekIsbUJBQW1CLENBQ3BEeUQsRUFEb0QsRUFFcERsRCxvQkFGb0QsQ0FBdEQ7QUFJQSxjQUFNbUQsRUFBRSw0QkFBR2pDLFVBQVUsQ0FBQ2hCLFdBQWQseUVBQTZCZ0IsVUFBVSxDQUFDLGlCQUFELENBQS9DO0FBQ0EsY0FBTXJCLElBQUksR0FBR3NELEVBQUUsQ0FBQ3ZELENBQUgsQ0FBS0MsSUFBTCxDQUFVbUMsS0FBVixDQUFnQixHQUFoQixFQUFxQixDQUFyQixDQUFiO0FBQ0FELFVBQUFBLFdBQVcsQ0FBQ2IsVUFBVSxDQUFDdEIsQ0FBWCxDQUFhSyxJQUFkLENBQVgsR0FBaUNKLElBQWpDO0FBQ0Q7QUFUeUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVUzRDtBQWZzQztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQWdCdkNpRCxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWTtBQUFFaEIsSUFBQUEsV0FBVyxFQUFYQTtBQUFGLEdBQVo7O0FBaEJ1Qyx5RUFpQnRCVixLQUFLLENBQUNDLE1BakJnQiwyREFpQk5ELEtBQUssQ0FBQyxZQUFELENBakJDLHlDQWlCaUIsRUFqQmpCO0FBQUE7O0FBQUE7QUFpQnZDLDJEQUE0RDtBQUFBOztBQUFBLFVBQWpENEIsR0FBaUQ7O0FBQUEsOEVBQ3pDQSxHQUFFLENBQUNoQyxXQURzQyw2REFDdkJnQyxHQUFFLENBQUMsaUJBQUQsQ0FEcUIseUNBQ0UsRUFERjtBQUFBOztBQUFBO0FBQzFELCtEQUFnRTtBQUFBOztBQUFBLGNBQXJERyxFQUFxRDtBQUM5RCxjQUFNbkMsV0FBNEIsR0FBR3hCLG1CQUFtQixDQUN0RDJELEVBRHNELEVBRXREdEMscUJBRnNELENBQXhEO0FBSUEsY0FBTVEsTUFJTCxHQUFHO0FBQ0ZsQixZQUFBQSxJQUFJLEVBQUVhLFdBQVcsQ0FBQ3JCLENBQVosQ0FBY0ssSUFEbEI7QUFFRm9ELFlBQUFBLEtBQUssRUFBRTtBQUZMLFdBSko7QUFRQSxjQUFNQyxHQUFHLDRCQUFHckMsV0FBVyxDQUFDTixRQUFmLHlFQUEyQk0sV0FBVyxDQUFDLGNBQUQsQ0FBL0M7QUFDQSxjQUFNc0MsR0FBRyxtQkFBR0QsR0FBSCxhQUFHQSxHQUFILHVCQUFHQSxHQUFHLENBQUU3QyxPQUFSLHVEQUFtQjZDLEdBQW5CLGFBQW1CQSxHQUFuQix1QkFBbUJBLEdBQUcsQ0FBRyxhQUFILENBQS9COztBQWQ4RCxzREFlN0NDLEdBZjZDLGFBZTdDQSxHQWY2QyxjQWU3Q0EsR0FmNkMsR0FldEMsRUFmc0M7QUFBQTs7QUFBQTtBQWU5RCxtRUFBNEI7QUFBQSxrQkFBakJiLEdBQWlCO0FBQzFCcEIsY0FBQUEsTUFBTSxDQUFDK0IsS0FBUCxDQUFhWCxHQUFFLENBQUM5QyxDQUFILENBQUtLLElBQWxCLElBQTBCd0MsV0FBVyxDQUFDQyxHQUFELEVBQUtYLFdBQUwsQ0FBckM7QUFDRDtBQWpCNkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFrQjlELGNBQU15QixFQUFFLDRCQUNOdkMsV0FBVyxDQUFDRixjQUROLHlFQUN3QkUsV0FBVyxDQUFDLG9CQUFELENBRDNDOztBQUVBLGNBQUl1QyxFQUFKLEVBQVE7QUFBQTs7QUFDTixnQkFBTTNDLFNBQVMsb0JBQUcyQyxFQUFFLENBQUMzQyxTQUFOLHlEQUFtQjJDLEVBQUUsQ0FBQyxlQUFELENBQXBDOztBQUNBLGdCQUFJM0MsU0FBSixFQUFlO0FBQUE7O0FBQ2JTLGNBQUFBLE1BQU0sQ0FBQ21DLE9BQVAsR0FBaUI1QyxTQUFTLENBQUNqQixDQUFWLENBQVlDLElBQVosQ0FBaUJtQyxLQUFqQixDQUF1QixHQUF2QixFQUE0QixDQUE1QixDQUFqQjs7QUFDQSxrQkFBTXNCLElBQUcsMEJBQUd6QyxTQUFTLENBQUNGLFFBQWIscUVBQXlCRSxTQUFTLENBQUMsY0FBRCxDQUEzQzs7QUFDQSxrQkFBTTBDLElBQUcsb0JBQUdELElBQUgsYUFBR0EsSUFBSCx1QkFBR0EsSUFBRyxDQUFFN0MsT0FBUix5REFBbUI2QyxJQUFuQixhQUFtQkEsSUFBbkIsdUJBQW1CQSxJQUFHLENBQUcsYUFBSCxDQUEvQjs7QUFIYSwwREFJSUMsSUFKSixhQUlJQSxJQUpKLGNBSUlBLElBSkosR0FJVyxFQUpYO0FBQUE7O0FBQUE7QUFJYix1RUFBNEI7QUFBQSxzQkFBakJiLEVBQWlCO0FBQzFCcEIsa0JBQUFBLE1BQU0sQ0FBQytCLEtBQVAsQ0FBYVgsRUFBRSxDQUFDOUMsQ0FBSCxDQUFLSyxJQUFsQixJQUEwQndDLFdBQVcsQ0FBQ0MsRUFBRCxFQUFLWCxXQUFMLENBQXJDO0FBQ0Q7QUFOWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT2Q7QUFDRjs7QUFDRGlCLFVBQUFBLE9BQU8sQ0FBQy9CLFdBQVcsQ0FBQ3JCLENBQVosQ0FBY0ssSUFBZixDQUFQLEdBQThCcUIsTUFBOUI7QUFDRDtBQWpDeUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWtDM0Q7QUFuRHNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBb0R2QyxTQUFPMEIsT0FBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxJQUFNVSx5QkFBeUIsNE1BQS9CO0FBT0E7QUFDQTtBQUNBOztTQUNlQyxVOzs7QUFxSWY7QUFDQTtBQUNBOzs7O3lFQXZJQSxrQkFBMEJYLE9BQTFCLEVBQTREWSxPQUE1RDtBQUFBLDZCQXVCV0MsV0F2QlgsRUEyRFdDLFlBM0RYLEVBcUhXQyxhQXJIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBcUhXQSxZQUFBQSxhQXJIWCwyQkFxSHlCZixPQXJIekIsRUFxSHFFO0FBQ2pFLGdEQUFtQixhQUFZQSxPQUFaLENBQW5CLHFDQUF5QztBQUFwQyxvQkFBTS9DLE1BQUkscUJBQVY7QUFDSCxvQkFBTXFCLE1BQU0sR0FBRzBCLE9BQU8sQ0FBQy9DLE1BQUQsQ0FBdEI7QUFDQStELGdCQUFBQSxLQUFLLHVCQUFnQi9ELE1BQWhCLFNBQUw7QUFDQTZELGdCQUFBQSxZQUFZLENBQUN4QyxNQUFELEVBQVMwQixPQUFULENBQVo7QUFDQWlCLGdCQUFBQSxPQUFPLENBQUMsR0FBRCxDQUFQO0FBQ0FBLGdCQUFBQSxPQUFPO0FBQ1I7O0FBQ0RBLGNBQUFBLE9BQU8sQ0FBQyxnQ0FBRCxDQUFQOztBQUNBLGdEQUFtQixhQUFZakIsT0FBWixDQUFuQixxQ0FBeUM7QUFBQTs7QUFBcEMsb0JBQU0vQyxNQUFJLHFCQUFWO0FBQ0hnRSxnQkFBQUEsT0FBTywrQ0FBSWhFLE1BQUoseUJBQWFBLE1BQWIsUUFBc0IsQ0FBdEIsQ0FBUDtBQUNEOztBQUNEZ0UsY0FBQUEsT0FBTyxDQUFDLElBQUQsQ0FBUDtBQUNELGFBbElIOztBQTJEV0gsWUFBQUEsWUEzRFgsMEJBNERJSSxDQTVESixFQTZESWxCLE9BN0RKLEVBK0RJO0FBQUEsa0JBREFtQixNQUNBLHVFQURpQixDQUNqQjs7QUFDQSxrQkFBSSxPQUFPRCxDQUFQLEtBQWEsUUFBakIsRUFBMkI7QUFDekJGLGdCQUFBQSxLQUFLLENBQUNFLENBQUQsQ0FBTDtBQUNELGVBRkQsTUFFTyxJQUFJeEUsV0FBVyxDQUFDd0UsQ0FBRCxDQUFmLEVBQW9CO0FBQ3pCLG9CQUFJLFVBQVVBLENBQVYsSUFBZSxXQUFXQSxDQUE5QixFQUFpQztBQUMvQixzQkFBSSxhQUFhQSxDQUFiLElBQWtCLE9BQU9BLENBQUMsQ0FBQ1QsT0FBVCxLQUFxQixRQUEzQyxFQUFxRDtBQUNuRE8sb0JBQUFBLEtBQUssV0FBSUUsQ0FBQyxDQUFDVCxPQUFOLFNBQUw7QUFDRDs7QUFDREssa0JBQUFBLFlBQVksQ0FBQ0ksQ0FBQyxDQUFDYixLQUFILEVBQVVMLE9BQVYsRUFBbUJtQixNQUFuQixDQUFaO0FBQ0E7QUFDRDs7QUFDRCxvQkFBTUMsSUFBSSxHQUFHLGFBQVlGLENBQVosQ0FBYjs7QUFDQSxvQkFBSUUsSUFBSSxDQUFDQyxNQUFMLEdBQWMsQ0FBbEIsRUFBcUI7QUFDbkJKLGtCQUFBQSxPQUFPLENBQUMsR0FBRCxDQUFQOztBQUNBLG1EQUFtQixhQUFZQyxDQUFaLENBQW5CLG1DQUFtQztBQUFBOztBQUE5Qix3QkFBTUksSUFBSSxvQkFBVjtBQUNILHdCQUFJdkUsS0FBVSxHQUFHbUUsQ0FBQyxDQUFDSSxJQUFELENBQWxCO0FBQ0Esd0JBQUkvRCxRQUFRLEdBQUcsS0FBZjtBQUNBLHdCQUFJb0MsT0FBTyxHQUFHLEtBQWQ7O0FBQ0Esd0JBQUksZUFBYzVDLEtBQWQsQ0FBSixFQUEwQjtBQUN4QjRDLHNCQUFBQSxPQUFPLEdBQUcsSUFBVjtBQUNBLDBCQUFNNEIsR0FBRyxHQUFHeEUsS0FBSyxDQUFDc0UsTUFBbEI7O0FBQ0EsMEJBQUlFLEdBQUcsS0FBSyxDQUFSLElBQWF4RSxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQWEsR0FBOUIsRUFBbUM7QUFDakNRLHdCQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNBUix3QkFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUMsQ0FBRCxDQUFiO0FBQ0QsdUJBSEQsTUFHTztBQUNMQSx3QkFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUMsQ0FBRCxDQUFiO0FBQ0Q7QUFDRixxQkFURCxNQVNPLElBQUlMLFdBQVcsQ0FBQ0ssS0FBRCxDQUFmLEVBQXdCO0FBQzdCLDBCQUFJLE9BQU9BLEtBQVgsRUFBa0I7QUFDaEJRLHdCQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNBUix3QkFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUMsR0FBRCxDQUFiO0FBQ0Q7QUFDRjs7QUFDRCx3QkFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQWpCLElBQTZCQSxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQWEsR0FBOUMsRUFBbUQ7QUFDakRRLHNCQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNBUixzQkFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUN5RSxTQUFOLENBQWdCLENBQWhCLENBQVI7QUFDRDs7QUFDRFIsb0JBQUFBLEtBQUssK0NBQUlNLElBQUosbUJBQVcvRCxRQUFRLEdBQUcsR0FBSCxHQUFTLEVBQTVCLFNBQW9DNEQsTUFBTSxHQUFHLENBQTdDLENBQUw7QUFDQUwsb0JBQUFBLFlBQVksQ0FBQy9ELEtBQUQsRUFBUWlELE9BQVIsRUFBaUJtQixNQUFNLEdBQUcsQ0FBMUIsQ0FBWjs7QUFDQSx3QkFBSXhCLE9BQUosRUFBYTtBQUNYcUIsc0JBQUFBLEtBQUssQ0FBQyxJQUFELENBQUw7QUFDRDs7QUFDRCx3QkFBSXpELFFBQUosRUFBYztBQUNaeUQsc0JBQUFBLEtBQUssQ0FBQyxxQkFBRCxDQUFMO0FBQ0Q7O0FBQ0RDLG9CQUFBQSxPQUFPLENBQUMsR0FBRCxDQUFQO0FBQ0Q7O0FBQ0RELGtCQUFBQSxLQUFLLENBQUMsR0FBRCxFQUFNRyxNQUFOLENBQUw7QUFDRCxpQkFwQ0QsTUFvQ087QUFDTEgsa0JBQUFBLEtBQUssQ0FBQyxJQUFELENBQUw7QUFDRDtBQUNGO0FBQ0YsYUFuSEg7O0FBdUJXSCxZQUFBQSxXQXZCWCx5QkF1QnVCSyxDQXZCdkIsRUF1Qm1EO0FBQUEsa0JBQXBCQyxNQUFvQix1RUFBSCxDQUFHOztBQUMvQyxrQkFBSUEsTUFBTSxHQUFHLEVBQWIsRUFBaUI7QUFDZkgsZ0JBQUFBLEtBQUssQ0FBQyxPQUFELENBQUw7QUFDQTtBQUNEOztBQUNELGtCQUFJLGVBQWNFLENBQWQsQ0FBSixFQUFzQjtBQUNwQkYsZ0JBQUFBLEtBQUssQ0FBQyxHQUFELENBQUw7QUFDQSxvQkFBSVMsQ0FBQyxHQUFHLENBQVI7O0FBRm9CLDREQUdIUCxDQUhHO0FBQUE7O0FBQUE7QUFHcEIseUVBQW9CO0FBQUEsd0JBQVRRLEVBQVM7O0FBQ2xCLHdCQUFJRCxDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1RULHNCQUFBQSxLQUFLLENBQUMsSUFBRCxDQUFMO0FBQ0Q7O0FBQ0RILG9CQUFBQSxXQUFXLENBQUNhLEVBQUQsRUFBS1AsTUFBTCxDQUFYO0FBQ0FNLG9CQUFBQSxDQUFDO0FBQ0Y7QUFUbUI7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFVcEJULGdCQUFBQSxLQUFLLENBQUMsR0FBRCxDQUFMO0FBQ0QsZUFYRCxNQVdPLElBQUl0RSxXQUFXLENBQUN3RSxDQUFELENBQWYsRUFBb0I7QUFDekIsb0JBQU1FLElBQUksR0FBRyxhQUFZRixDQUFaLENBQWI7O0FBQ0Esb0JBQUlFLElBQUksQ0FBQ0MsTUFBTCxHQUFjLENBQWxCLEVBQXFCO0FBQ25CSixrQkFBQUEsT0FBTyxDQUFDLEdBQUQsQ0FBUDs7QUFEbUIsOERBRUFHLElBRkE7QUFBQTs7QUFBQTtBQUVuQiwyRUFBeUI7QUFBQSwwQkFBZG5FLEtBQWM7QUFDdkIsMEJBQU15RSxHQUFFLEdBQUdSLENBQUMsQ0FBQ2pFLEtBQUQsQ0FBWjtBQUNBLDBCQUFNMEUsTUFBTSxHQUFHLFlBQVlDLElBQVosQ0FBaUIzRSxLQUFqQixJQUF5QkEsS0FBekIsY0FBb0NBLEtBQXBDLE1BQWY7QUFDQStELHNCQUFBQSxLQUFLLFdBQUlXLE1BQUosU0FBZ0JSLE1BQU0sR0FBRyxDQUF6QixDQUFMO0FBQ0FOLHNCQUFBQSxXQUFXLENBQUNhLEdBQUQsRUFBS1AsTUFBTSxHQUFHLENBQWQsQ0FBWDtBQUNBRixzQkFBQUEsT0FBTyxDQUFDLEdBQUQsQ0FBUDtBQUNEO0FBUmtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBU25CRCxrQkFBQUEsS0FBSyxDQUFDLEdBQUQsRUFBTUcsTUFBTixDQUFMO0FBQ0QsaUJBVkQsTUFVTztBQUNMSCxrQkFBQUEsS0FBSyxDQUFDLElBQUQsQ0FBTDtBQUNEO0FBQ0YsZUFmTSxNQWVBO0FBQ0xBLGdCQUFBQSxLQUFLLENBQUMsZ0JBQWVFLENBQWYsRUFBa0JXLE9BQWxCLENBQTBCLElBQTFCLEVBQWdDLEdBQWhDLENBQUQsQ0FBTDtBQUNEO0FBQ0YsYUF6REg7O0FBQ1FDLFlBQUFBLEdBRFIsR0FDY3ZGLEVBQUUsQ0FBQ3dGLGlCQUFILENBQXFCbkIsT0FBckIsRUFBOEIsTUFBOUIsQ0FEZDs7QUFFUUksWUFBQUEsS0FGUixHQUVnQixTQUFSQSxLQUFRLENBQUNnQixHQUFELEVBQXFDO0FBQUEsa0JBQXZCYixNQUF1Qix1RUFBTixDQUFNOztBQUNqRCxtQkFBSyxJQUFJTSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHTixNQUFwQixFQUE0Qk0sQ0FBQyxFQUE3QixFQUFpQztBQUMvQkssZ0JBQUFBLEdBQUcsQ0FBQ0csS0FBSixDQUFVLEdBQVY7QUFDRDs7QUFDREgsY0FBQUEsR0FBRyxDQUFDRyxLQUFKLENBQVVELEdBQVY7QUFDRCxhQVBIOztBQVFRZixZQUFBQSxPQVJSLEdBUWtCLFNBQVZBLE9BQVUsR0FBMEM7QUFBQSxrQkFBekNlLEdBQXlDLHVFQUEzQixFQUEyQjtBQUFBLGtCQUF2QmIsTUFBdUIsdUVBQU4sQ0FBTTtBQUN4REgsY0FBQUEsS0FBSyxDQUFDZ0IsR0FBRyxHQUFHLElBQVAsRUFBYWIsTUFBYixDQUFMO0FBQ0QsYUFWSDs7QUFBQSw4Q0FXUyxhQUFrQixVQUFDZSxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDNUNMLGNBQUFBLEdBQUcsQ0FBQ00sRUFBSixDQUFPLE9BQVAsRUFBZ0JELE1BQWhCO0FBQ0FMLGNBQUFBLEdBQUcsQ0FBQ00sRUFBSixDQUFPLFFBQVAsRUFBaUI7QUFBQSx1QkFBTUYsT0FBTyxFQUFiO0FBQUEsZUFBakI7QUFDQWpCLGNBQUFBLE9BQU8sQ0FBQ1AseUJBQUQsQ0FBUDtBQUNBTSxjQUFBQSxLQUFLLENBQUMsNEJBQUQsQ0FBTDtBQUNBSCxjQUFBQSxXQUFXLENBQUNiLE9BQUQsQ0FBWDtBQUNBaUIsY0FBQUEsT0FBTyxDQUFDLFlBQUQsQ0FBUDtBQUNBQSxjQUFBQSxPQUFPO0FBQ1BGLGNBQUFBLGFBQWEsQ0FBQ2YsT0FBRCxDQUFiO0FBQ0E4QixjQUFBQSxHQUFHLENBQUNPLEdBQUo7QUFDRCxhQVZNLENBWFQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRzs7OztTQXdJZUMsSTs7Ozs7bUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1FDLFlBQUFBLFlBRFIsR0FDdUJDLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLENBQWIsQ0FEdkI7O0FBQUEsZ0JBRU9GLFlBRlA7QUFBQTtBQUFBO0FBQUE7O0FBR0l6QyxZQUFBQSxPQUFPLENBQUM0QyxLQUFSLENBQWMsa0NBQWQ7QUFISjs7QUFBQTtBQU1RQyxZQUFBQSxXQU5SLEdBTXNCSCxPQUFPLENBQUNDLElBQVIsQ0FBYSxDQUFiLENBTnRCOztBQUFBLGdCQU9PRixZQVBQO0FBQUE7QUFBQTtBQUFBOztBQVFJekMsWUFBQUEsT0FBTyxDQUFDNEMsS0FBUixDQUFjLGdEQUFkO0FBUko7O0FBQUE7QUFBQTtBQUFBLG1CQVdxQnhELFlBQVksQ0FBQ3FELFlBQUQsQ0FYakM7O0FBQUE7QUFXUTFDLFlBQUFBLElBWFI7QUFZUUcsWUFBQUEsT0FaUixHQVlrQkosbUJBQW1CLENBQUNDLElBQUQsQ0FackM7QUFhRWMsWUFBQUEsVUFBVSxDQUFDWCxPQUFELEVBQVUyQyxXQUFWLENBQVY7O0FBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRzs7OztBQWdCQUwsSUFBSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBmcyBmcm9tICdmcy1leHRyYSc7XG5pbXBvcnQgeG1sMmpzIGZyb20gJ3htbDJqcyc7XG5pbXBvcnQgeyBjYXN0VHlwZVVzaW5nU2NoZW1hIH0gZnJvbSAnLi4vLi4vc29hcCc7XG5pbXBvcnQgeyBTb2FwU2NoZW1hRWxlbWVudFR5cGUsIFNvYXBTY2hlbWFEZWYgfSBmcm9tICcuLi8uLi90eXBlcyc7XG5pbXBvcnQgeyBpc01hcE9iamVjdCB9IGZyb20gJy4uLy4uL3V0aWwvZnVuY3Rpb24nO1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IFdTRExSZXN0cmljdGlvblNjaGVtYSA9IHtcbiAgJDogeyBiYXNlOiAnc3RyaW5nJyB9LFxuICBlbnVtZXJhdGlvbjogW1xuICAgIHtcbiAgICAgICQ6IHsgdmFsdWU6ICdzdHJpbmcnIH0sXG4gICAgfSxcbiAgXSxcbiAgJ3hzZDplbnVtZXJhdGlvbic6IFtcbiAgICB7XG4gICAgICAkOiB7IHZhbHVlOiAnc3RyaW5nJyB9LFxuICAgIH0sXG4gIF0sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBXU0RMU2ltcGxlVHlwZVNjaGVtYSA9IHtcbiAgJDogeyBuYW1lOiAnc3RyaW5nJyB9LFxuICByZXN0cmljdGlvbjogV1NETFJlc3RyaWN0aW9uU2NoZW1hLFxuICAneHNkOnJlc3RyaWN0aW9uJzogV1NETFJlc3RyaWN0aW9uU2NoZW1hLFxufSBhcyBjb25zdDtcblxuY29uc3QgV1NETEVsZW1lbnRTY2hlbWEgPSB7XG4gICQ6IHtcbiAgICBuYW1lOiAnc3RyaW5nJyxcbiAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICBtaW5PY2N1cnM6ICc/bnVtYmVyJyxcbiAgICBtYXhPY2N1cnM6ICc/c3RyaW5nJyxcbiAgICBuaWxsYWJsZTogJz9ib29sZWFuJyxcbiAgfSxcbn0gYXMgY29uc3Q7XG5cbmNvbnN0IFdTRExTZXF1ZW5jZVNjaGVtYSA9IHtcbiAgZWxlbWVudDogWyc/JywgV1NETEVsZW1lbnRTY2hlbWFdLFxuICAneHNkOmVsZW1lbnQnOiBbJz8nLCBXU0RMRWxlbWVudFNjaGVtYV0sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBXU0RMRXh0ZW5zaW9uU2NoZW1hID0ge1xuICAkOiB7IGJhc2U6ICdzdHJpbmcnIH0sXG4gIHNlcXVlbmNlOiB7ICc/JzogV1NETFNlcXVlbmNlU2NoZW1hIH0sXG4gICd4c2Q6c2VxdWVuY2UnOiB7ICc/JzogV1NETFNlcXVlbmNlU2NoZW1hIH0sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBXU0RMQ29tcGxleENvbnRlbnRTY2hlbWEgPSB7XG4gIGV4dGVuc2lvbjogeyAnPyc6IFdTRExFeHRlbnNpb25TY2hlbWEgfSxcbiAgJ3hzZDpleHRlbnNpb24nOiB7ICc/JzogV1NETEV4dGVuc2lvblNjaGVtYSB9LFxufSBhcyBjb25zdDtcblxuY29uc3QgV1NETENvbXBsZXhUeXBlU2NoZW1hID0ge1xuICAkOiB7IG5hbWU6ICdzdHJpbmcnIH0sXG4gIHNlcXVlbmNlOiB7ICc/JzogV1NETFNlcXVlbmNlU2NoZW1hIH0sXG4gICd4c2Q6c2VxdWVuY2UnOiB7ICc/JzogV1NETFNlcXVlbmNlU2NoZW1hIH0sXG4gIGNvbXBsZXhDb250ZW50OiB7ICc/JzogV1NETENvbXBsZXhDb250ZW50U2NoZW1hIH0sXG4gICd4c2Q6Y29tcGxleENvbnRlbnQnOiB7ICc/JzogV1NETENvbXBsZXhDb250ZW50U2NoZW1hIH0sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBXU0RMU2NoZW1hU2NoZW1hID0ge1xuICAkOiAnYW55JyxcbiAgY29tcGxleFR5cGU6IFsnPycsICdhbnknXSxcbiAgc2ltcGxlVHlwZTogWyc/JywgJ2FueSddLFxuICAneHNkOmNvbXBsZXhUeXBlJzogWyc/JywgJ2FueSddLFxuICAneHNkOnNpbXBsZVR5cGUnOiBbJz8nLCAnYW55J10sXG59IGFzIGNvbnN0O1xuXG5jb25zdCBXU0RMU2NoZW1hID0ge1xuICBkZWZpbml0aW9uczoge1xuICAgICQ6ICdhbnknLFxuICAgIHR5cGVzOiB7XG4gICAgICBzY2hlbWE6IFsnPycsIFdTRExTY2hlbWFTY2hlbWFdLFxuICAgICAgJ3hzZDpzY2hlbWEnOiBbJz8nLCBXU0RMU2NoZW1hU2NoZW1hXSxcbiAgICB9LFxuICAgIG1lc3NhZ2U6IFsnYW55J10sXG4gICAgcG9ydFR5cGU6IHtcbiAgICAgICQ6ICdhbnknLFxuICAgICAgb3BlcmF0aW9uOiBbJ2FueSddLFxuICAgIH0sXG4gICAgYmluZGluZzoge1xuICAgICAgJDogJ2FueScsXG4gICAgICBvcGVyYXRpb246IFsnYW55J10sXG4gICAgfSxcbiAgICBzZXJ2aWNlOiB7XG4gICAgICAkOiAnYW55JyxcbiAgICAgIGRvY3VtZW50YXRpb246ICdzdHJpbmcnLFxuICAgICAgb3BlcmF0aW9uOiBbJ2FueSddLFxuICAgIH0sXG4gIH0sXG59IGFzIGNvbnN0O1xuXG4vKipcbiAqXG4gKi9cbnR5cGUgV1NETCA9IFNvYXBTY2hlbWFFbGVtZW50VHlwZTx0eXBlb2YgV1NETFNjaGVtYT47XG5cbnR5cGUgV1NETEVsZW1lbnQgPSBTb2FwU2NoZW1hRWxlbWVudFR5cGU8dHlwZW9mIFdTRExFbGVtZW50U2NoZW1hPjtcblxudHlwZSBXU0RMU2ltcGxlVHlwZSA9IFNvYXBTY2hlbWFFbGVtZW50VHlwZTx0eXBlb2YgV1NETFNpbXBsZVR5cGVTY2hlbWE+O1xuXG50eXBlIFdTRExDb21wbGV4VHlwZSA9IFNvYXBTY2hlbWFFbGVtZW50VHlwZTx0eXBlb2YgV1NETENvbXBsZXhUeXBlU2NoZW1hPjtcblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiB0b0pzVHlwZSh4c2RUeXBlOiBzdHJpbmcsIHNpbXBsZVR5cGVzOiB7IFt0eXBlOiBzdHJpbmddOiBzdHJpbmcgfSkge1xuICBzd2l0Y2ggKHhzZFR5cGUpIHtcbiAgICBjYXNlICd4c2Q6Ym9vbGVhbic6XG4gICAgICByZXR1cm4gJ2Jvb2xlYW4nO1xuICAgIGNhc2UgJ3hzZDpzdHJpbmcnOlxuICAgIGNhc2UgJ3hzZDpkYXRlJzpcbiAgICBjYXNlICd4c2Q6ZGF0ZVRpbWUnOlxuICAgIGNhc2UgJ3hzZDp0aW1lJzpcbiAgICBjYXNlICd4c2Q6YmFzZTY0QmluYXJ5JzpcbiAgICAgIHJldHVybiAnc3RyaW5nJztcbiAgICBjYXNlICd4c2Q6aW50JzpcbiAgICBjYXNlICd4c2Q6bG9uZyc6XG4gICAgY2FzZSAneHNkOmRvdWJsZSc6XG4gICAgICByZXR1cm4gJ251bWJlcic7XG4gICAgY2FzZSAneHNkOmFueVR5cGUnOlxuICAgICAgcmV0dXJuICdhbnknO1xuICAgIGRlZmF1bHQ6IHtcbiAgICAgIGNvbnN0IFtucywgdHlwZV0gPSB4c2RUeXBlLnNwbGl0KCc6Jyk7XG4gICAgICBpZiAoc2ltcGxlVHlwZXNbdHlwZV0pIHtcbiAgICAgICAgcmV0dXJuIHNpbXBsZVR5cGVzW3R5cGVdO1xuICAgICAgfVxuICAgICAgaWYgKG5zKSB7XG4gICAgICAgIHJldHVybiB0eXBlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHhzZFR5cGU7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVhZFdTRExGaWxlKGZpbGVQYXRoOiBzdHJpbmcpIHtcbiAgY29uc3QgeG1sRGF0YSA9IGF3YWl0IGZzLnJlYWRGaWxlKGZpbGVQYXRoLCAndXRmOCcpO1xuICBjb25zdCBqc29uID0gYXdhaXQgeG1sMmpzLnBhcnNlU3RyaW5nUHJvbWlzZSh4bWxEYXRhLCB7XG4gICAgZXhwbGljaXRBcnJheTogZmFsc2UsXG4gIH0pO1xuICByZXR1cm4gY2FzdFR5cGVVc2luZ1NjaGVtYShqc29uLCBXU0RMU2NoZW1hKSBhcyBXU0RMO1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIGdldFR5cGVJbmZvKGVsOiBXU0RMRWxlbWVudCwgc2ltcGxlVHlwZXM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9KSB7XG4gIGxldCB0eXBlID0gdG9Kc1R5cGUoZWwuJC50eXBlLCBzaW1wbGVUeXBlcyk7XG4gIGNvbnN0IGlzQXJyYXkgPSBlbC4kLm1heE9jY3VycyA9PT0gJ3VuYm91bmRlZCc7XG4gIGNvbnN0IG5pbGxhYmxlID0gKCFpc0FycmF5ICYmIGVsLiQubWluT2NjdXJzID09PSAwKSB8fCBlbC4kLm5pbGxhYmxlO1xuICByZXR1cm4gaXNBcnJheVxuICAgID8gbmlsbGFibGVcbiAgICAgID8gWyc/JywgdHlwZV1cbiAgICAgIDogW3R5cGVdXG4gICAgOiBuaWxsYWJsZVxuICAgID8gYD8ke3R5cGV9YFxuICAgIDogdHlwZTtcbn1cblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q29tcGxleFR5cGVzKHdzZGw6IFdTREwpIHtcbiAgY29uc29sZS5sb2cod3NkbC5kZWZpbml0aW9ucy50eXBlc1sneHNkOnNjaGVtYSddKTtcbiAgbGV0IHNjaGVtYXM6IHsgW25hbWU6IHN0cmluZ106IFNvYXBTY2hlbWFEZWYgfSA9IHt9O1xuICBjb25zdCBzaW1wbGVUeXBlczogeyBbdHlwZTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fTtcbiAgY29uc3QgdHlwZXMgPSB3c2RsLmRlZmluaXRpb25zLnR5cGVzO1xuICBmb3IgKGNvbnN0IHNjIG9mIHR5cGVzLnNjaGVtYSA/PyB0eXBlc1sneHNkOnNjaGVtYSddID8/IFtdKSB7XG4gICAgZm9yIChjb25zdCBzdCBvZiBzYy5zaW1wbGVUeXBlID8/IHNjWyd4c2Q6c2ltcGxlVHlwZSddID8/IFtdKSB7XG4gICAgICBjb25zdCBzaW1wbGVUeXBlOiBXU0RMU2ltcGxlVHlwZSA9IGNhc3RUeXBlVXNpbmdTY2hlbWEoXG4gICAgICAgIHN0LFxuICAgICAgICBXU0RMU2ltcGxlVHlwZVNjaGVtYSxcbiAgICAgICk7XG4gICAgICBjb25zdCBycyA9IHNpbXBsZVR5cGUucmVzdHJpY3Rpb24gPz8gc2ltcGxlVHlwZVsneHNkOnJlc3RyaWN0aW9uJ107XG4gICAgICBjb25zdCBiYXNlID0gcnMuJC5iYXNlLnNwbGl0KCc6JylbMV07XG4gICAgICBzaW1wbGVUeXBlc1tzaW1wbGVUeXBlLiQubmFtZV0gPSBiYXNlO1xuICAgIH1cbiAgfVxuICBjb25zb2xlLmxvZyh7IHNpbXBsZVR5cGVzIH0pO1xuICBmb3IgKGNvbnN0IHNjIG9mIHR5cGVzLnNjaGVtYSA/PyB0eXBlc1sneHNkOnNjaGVtYSddID8/IFtdKSB7XG4gICAgZm9yIChjb25zdCBjdCBvZiBzYy5jb21wbGV4VHlwZSA/PyBzY1sneHNkOmNvbXBsZXhUeXBlJ10gPz8gW10pIHtcbiAgICAgIGNvbnN0IGNvbXBsZXhUeXBlOiBXU0RMQ29tcGxleFR5cGUgPSBjYXN0VHlwZVVzaW5nU2NoZW1hKFxuICAgICAgICBjdCxcbiAgICAgICAgV1NETENvbXBsZXhUeXBlU2NoZW1hLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHNjaGVtYToge1xuICAgICAgICB0eXBlOiBzdHJpbmc7XG4gICAgICAgIGV4dGVuZHM/OiBzdHJpbmc7XG4gICAgICAgIHByb3BzOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfTtcbiAgICAgIH0gPSB7XG4gICAgICAgIHR5cGU6IGNvbXBsZXhUeXBlLiQubmFtZSxcbiAgICAgICAgcHJvcHM6IHt9LFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHNlcSA9IGNvbXBsZXhUeXBlLnNlcXVlbmNlID8/IGNvbXBsZXhUeXBlWyd4c2Q6c2VxdWVuY2UnXTtcbiAgICAgIGNvbnN0IGVscyA9IHNlcT8uZWxlbWVudCA/PyBzZXE/LlsneHNkOmVsZW1lbnQnXTtcbiAgICAgIGZvciAoY29uc3QgZWwgb2YgZWxzID8/IFtdKSB7XG4gICAgICAgIHNjaGVtYS5wcm9wc1tlbC4kLm5hbWVdID0gZ2V0VHlwZUluZm8oZWwsIHNpbXBsZVR5cGVzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNjID1cbiAgICAgICAgY29tcGxleFR5cGUuY29tcGxleENvbnRlbnQgPz8gY29tcGxleFR5cGVbJ3hzZDpjb21wbGV4Q29udGVudCddO1xuICAgICAgaWYgKGNjKSB7XG4gICAgICAgIGNvbnN0IGV4dGVuc2lvbiA9IGNjLmV4dGVuc2lvbiA/PyBjY1sneHNkOmV4dGVuc2lvbiddO1xuICAgICAgICBpZiAoZXh0ZW5zaW9uKSB7XG4gICAgICAgICAgc2NoZW1hLmV4dGVuZHMgPSBleHRlbnNpb24uJC5iYXNlLnNwbGl0KCc6JylbMV07XG4gICAgICAgICAgY29uc3Qgc2VxID0gZXh0ZW5zaW9uLnNlcXVlbmNlID8/IGV4dGVuc2lvblsneHNkOnNlcXVlbmNlJ107XG4gICAgICAgICAgY29uc3QgZWxzID0gc2VxPy5lbGVtZW50ID8/IHNlcT8uWyd4c2Q6ZWxlbWVudCddO1xuICAgICAgICAgIGZvciAoY29uc3QgZWwgb2YgZWxzID8/IFtdKSB7XG4gICAgICAgICAgICBzY2hlbWEucHJvcHNbZWwuJC5uYW1lXSA9IGdldFR5cGVJbmZvKGVsLCBzaW1wbGVUeXBlcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBzY2hlbWFzW2NvbXBsZXhUeXBlLiQubmFtZV0gPSBzY2hlbWE7XG4gICAgfVxuICB9XG4gIHJldHVybiBzY2hlbWFzO1xufVxuXG4vKipcbiAqXG4gKi9cbmNvbnN0IEdFTkVSQVRFRF9NRVNTQUdFX0NPTU1FTlQgPSBgLyoqXG4gKiBUaGlzIGZpbGUgaXMgZ2VuZXJhdGVkIGZyb20gV1NETCBmaWxlIGJ5IHdzZGwyc2NoZW1hLnRzLlxuICogRG8gbm90IG1vZGlmeSBkaXJlY3RseS5cbiAqIFRvIGdlbmVyYXRlIHRoZSBmaWxlLCBydW4gXCJ0cy1ub2RlIHBhdGgvdG8vd3NkbDJzY2hlbWEudHMgcGF0aC90by93c2RsLnhtbCBwYXRoL3RvL3NjaGVtYS50c1wiXG4gKi9cbmA7XG5cbi8qKlxuICpcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZHVtcFNjaGVtYShzY2hlbWFzOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSwgb3V0RmlsZTogc3RyaW5nKSB7XG4gIGNvbnN0IG91dCA9IGZzLmNyZWF0ZVdyaXRlU3RyZWFtKG91dEZpbGUsICd1dGY4Jyk7XG4gIGNvbnN0IHByaW50ID0gKHN0cjogc3RyaW5nLCBpbmRlbnQ6IG51bWJlciA9IDApID0+IHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluZGVudDsgaSsrKSB7XG4gICAgICBvdXQud3JpdGUoJyAnKTtcbiAgICB9XG4gICAgb3V0LndyaXRlKHN0cik7XG4gIH07XG4gIGNvbnN0IHByaW50bG4gPSAoc3RyOiBzdHJpbmcgPSAnJywgaW5kZW50OiBudW1iZXIgPSAwKSA9PiB7XG4gICAgcHJpbnQoc3RyICsgJ1xcbicsIGluZGVudCk7XG4gIH07XG4gIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgb3V0Lm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgb3V0Lm9uKCdmaW5pc2gnLCAoKSA9PiByZXNvbHZlKCkpO1xuICAgIHByaW50bG4oR0VORVJBVEVEX01FU1NBR0VfQ09NTUVOVCk7XG4gICAgcHJpbnQoJ2V4cG9ydCBjb25zdCBBcGlTY2hlbWFzID0gJyk7XG4gICAgd3JpdGVTY2hlbWEoc2NoZW1hcyk7XG4gICAgcHJpbnRsbignIGFzIGNvbnN0OycpO1xuICAgIHByaW50bG4oKTtcbiAgICB3cml0ZVR5cGVEZWZzKHNjaGVtYXMpO1xuICAgIG91dC5lbmQoKTtcbiAgfSk7XG5cbiAgZnVuY3Rpb24gd3JpdGVTY2hlbWEobzogYW55LCBpbmRlbnQ6IG51bWJlciA9IDApIHtcbiAgICBpZiAoaW5kZW50ID4gMjApIHtcbiAgICAgIHByaW50KFwiJ2FueSdcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KG8pKSB7XG4gICAgICBwcmludCgnWycpO1xuICAgICAgbGV0IGkgPSAwO1xuICAgICAgZm9yIChjb25zdCBjbyBvZiBvKSB7XG4gICAgICAgIGlmIChpID4gMCkge1xuICAgICAgICAgIHByaW50KCcsICcpO1xuICAgICAgICB9XG4gICAgICAgIHdyaXRlU2NoZW1hKGNvLCBpbmRlbnQpO1xuICAgICAgICBpKys7XG4gICAgICB9XG4gICAgICBwcmludCgnXScpO1xuICAgIH0gZWxzZSBpZiAoaXNNYXBPYmplY3QobykpIHtcbiAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvKTtcbiAgICAgIGlmIChrZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgcHJpbnRsbigneycpO1xuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2Yga2V5cykge1xuICAgICAgICAgIGNvbnN0IGNvID0gb1tuYW1lXTtcbiAgICAgICAgICBjb25zdCBuYW1lSWQgPSAvXltcXHdfJF0rJC8udGVzdChuYW1lKSA/IG5hbWUgOiBgJyR7bmFtZX0nYDtcbiAgICAgICAgICBwcmludChgJHtuYW1lSWR9OiBgLCBpbmRlbnQgKyAyKTtcbiAgICAgICAgICB3cml0ZVNjaGVtYShjbywgaW5kZW50ICsgMik7XG4gICAgICAgICAgcHJpbnRsbignLCcpO1xuICAgICAgICB9XG4gICAgICAgIHByaW50KCd9JywgaW5kZW50KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHByaW50KCd7fScpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBwcmludChKU09OLnN0cmluZ2lmeShvKS5yZXBsYWNlKC9cIi9nLCBcIidcIikpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHdyaXRlVHlwZURlZihcbiAgICBvOiBhbnksXG4gICAgc2NoZW1hczogeyBbbmFtZTogc3RyaW5nXTogU29hcFNjaGVtYURlZiB9LFxuICAgIGluZGVudDogbnVtYmVyID0gMCxcbiAgKSB7XG4gICAgaWYgKHR5cGVvZiBvID09PSAnc3RyaW5nJykge1xuICAgICAgcHJpbnQobyk7XG4gICAgfSBlbHNlIGlmIChpc01hcE9iamVjdChvKSkge1xuICAgICAgaWYgKCd0eXBlJyBpbiBvICYmICdwcm9wcycgaW4gbykge1xuICAgICAgICBpZiAoJ2V4dGVuZHMnIGluIG8gJiYgdHlwZW9mIG8uZXh0ZW5kcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICBwcmludChgJHtvLmV4dGVuZHN9ICYgYCk7XG4gICAgICAgIH1cbiAgICAgICAgd3JpdGVUeXBlRGVmKG8ucHJvcHMsIHNjaGVtYXMsIGluZGVudCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvKTtcbiAgICAgIGlmIChrZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgcHJpbnRsbigneycpO1xuICAgICAgICBmb3IgKGNvbnN0IHByb3Agb2YgT2JqZWN0LmtleXMobykpIHtcbiAgICAgICAgICBsZXQgdmFsdWU6IGFueSA9IG9bcHJvcF07XG4gICAgICAgICAgbGV0IG5pbGxhYmxlID0gZmFsc2U7XG4gICAgICAgICAgbGV0IGlzQXJyYXkgPSBmYWxzZTtcbiAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGlzQXJyYXkgPSB0cnVlO1xuICAgICAgICAgICAgY29uc3QgbGVuID0gdmFsdWUubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKGxlbiA9PT0gMiAmJiB2YWx1ZVswXSA9PT0gJz8nKSB7XG4gICAgICAgICAgICAgIG5pbGxhYmxlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZVsxXTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHZhbHVlID0gdmFsdWVbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChpc01hcE9iamVjdCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGlmICgnPycgaW4gdmFsdWUpIHtcbiAgICAgICAgICAgICAgbmlsbGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgICB2YWx1ZSA9IHZhbHVlWyc/J107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIHZhbHVlWzBdID09PSAnPycpIHtcbiAgICAgICAgICAgIG5pbGxhYmxlID0gdHJ1ZTtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuc3Vic3RyaW5nKDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBwcmludChgJHtwcm9wfSR7bmlsbGFibGUgPyAnPycgOiAnJ306IGAsIGluZGVudCArIDIpO1xuICAgICAgICAgIHdyaXRlVHlwZURlZih2YWx1ZSwgc2NoZW1hcywgaW5kZW50ICsgMik7XG4gICAgICAgICAgaWYgKGlzQXJyYXkpIHtcbiAgICAgICAgICAgIHByaW50KCdbXScpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAobmlsbGFibGUpIHtcbiAgICAgICAgICAgIHByaW50KCcgfCBudWxsIHwgdW5kZWZpbmVkJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHByaW50bG4oJzsnKTtcbiAgICAgICAgfVxuICAgICAgICBwcmludCgnfScsIGluZGVudCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwcmludCgne30nKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiB3cml0ZVR5cGVEZWZzKHNjaGVtYXM6IHsgW25hbWU6IHN0cmluZ106IFNvYXBTY2hlbWFEZWYgfSkge1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhzY2hlbWFzKSkge1xuICAgICAgY29uc3Qgc2NoZW1hID0gc2NoZW1hc1tuYW1lXTtcbiAgICAgIHByaW50KGBleHBvcnQgdHlwZSAke25hbWV9ID0gYCk7XG4gICAgICB3cml0ZVR5cGVEZWYoc2NoZW1hLCBzY2hlbWFzKTtcbiAgICAgIHByaW50bG4oJzsnKTtcbiAgICAgIHByaW50bG4oKTtcbiAgICB9XG4gICAgcHJpbnRsbignZXhwb3J0IHR5cGUgQXBpU2NoZW1hVHlwZXMgPSB7Jyk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKHNjaGVtYXMpKSB7XG4gICAgICBwcmludGxuKGAke25hbWV9OiAke25hbWV9O2AsIDIpO1xuICAgIH1cbiAgICBwcmludGxuKCd9OycpO1xuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuYXN5bmMgZnVuY3Rpb24gbWFpbigpIHtcbiAgY29uc3Qgd3NkbEZpbGVQYXRoID0gcHJvY2Vzcy5hcmd2WzJdO1xuICBpZiAoIXdzZGxGaWxlUGF0aCkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ05vIGlucHV0IFdTREwgZmlsZSBpcyBzcGVjaWZpZWQuJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IG91dEZpbGVQYXRoID0gcHJvY2Vzcy5hcmd2WzNdO1xuICBpZiAoIXdzZGxGaWxlUGF0aCkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ05vIG91dHB1dCB0eXBlc2NyaXB0IHNjaGVtYSBmaWxlIGlzIHNwZWNpZmllZC4nKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgd3NkbCA9IGF3YWl0IHJlYWRXU0RMRmlsZSh3c2RsRmlsZVBhdGgpO1xuICBjb25zdCBzY2hlbWFzID0gZXh0cmFjdENvbXBsZXhUeXBlcyh3c2RsKTtcbiAgZHVtcFNjaGVtYShzY2hlbWFzLCBvdXRGaWxlUGF0aCk7XG59XG5cbm1haW4oKTtcbiJdfQ==