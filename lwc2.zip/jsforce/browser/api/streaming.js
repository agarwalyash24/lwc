import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context3; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context3 = Object.prototype.toString.call(o)).call(_context3, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * @file Manages Streaming APIs
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Client, Subscription } from 'faye';
import { registerModule } from '../jsforce';
import * as StreamingExtension from './streaming/extension';
/**
 *
 */

export { Client, Subscription };
/*--------------------------------------------*/

/**
 * Streaming API topic class
 */

var Topic = /*#__PURE__*/function () {
  function Topic(streaming, name) {
    _classCallCheck(this, Topic);

    _defineProperty(this, "_streaming", void 0);

    _defineProperty(this, "name", void 0);

    this._streaming = streaming;
    this.name = name;
  }
  /**
   * Subscribe listener to topic
   */


  _createClass(Topic, [{
    key: "subscribe",
    value: function subscribe(listener) {
      return this._streaming.subscribe(this.name, listener);
    }
    /**
     * Unsubscribe listener from topic
     */

  }, {
    key: "unsubscribe",
    value: function unsubscribe(subscr) {
      this._streaming.unsubscribe(this.name, subscr);

      return this;
    }
  }]);

  return Topic;
}();
/*--------------------------------------------*/

/**
 * Streaming API Generic Streaming Channel
 */


var Channel = /*#__PURE__*/function () {
  function Channel(streaming, name) {
    _classCallCheck(this, Channel);

    _defineProperty(this, "_streaming", void 0);

    _defineProperty(this, "_id", void 0);

    _defineProperty(this, "name", void 0);

    this._streaming = streaming;
    this.name = name;
  }
  /**
   * Subscribe to channel
   */


  _createClass(Channel, [{
    key: "subscribe",
    value: function subscribe(listener) {
      return this._streaming.subscribe(this.name, listener);
    }
  }, {
    key: "unsubscribe",
    value: function unsubscribe(subscr) {
      this._streaming.unsubscribe(this.name, subscr);

      return this;
    }
  }, {
    key: "push",
    value: function () {
      var _push = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(events) {
        var isArray, pushEvents, conn, id, channelUrl, rets;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                isArray = _Array$isArray(events);
                pushEvents = _Array$isArray(events) ? events : [events];
                conn = this._streaming._conn;

                if (!this._id) {
                  this._id = conn.sobject('StreamingChannel').findOne({
                    Name: this.name
                  }, ['Id']).then(function (rec) {
                    return rec === null || rec === void 0 ? void 0 : rec.Id;
                  });
                }

                _context.next = 6;
                return this._id;

              case 6:
                id = _context.sent;

                if (id) {
                  _context.next = 9;
                  break;
                }

                throw new Error("No streaming channel available for name: ".concat(this.name));

              case 9:
                channelUrl = "/sobjects/StreamingChannel/".concat(id, "/push");
                _context.next = 12;
                return conn.requestPost(channelUrl, {
                  pushEvents: pushEvents
                });

              case 12:
                rets = _context.sent;
                return _context.abrupt("return", isArray ? rets : rets[0]);

              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function push(_x) {
        return _push.apply(this, arguments);
      }

      return push;
    }()
  }]);

  return Channel;
}();
/*--------------------------------------------*/

/**
 * Streaming API class
 */


export var Streaming = /*#__PURE__*/function (_EventEmitter) {
  _inherits(Streaming, _EventEmitter);

  var _super = _createSuper(Streaming);

  /**
   *
   */
  function Streaming(conn) {
    var _this;

    _classCallCheck(this, Streaming);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_conn", void 0);

    _defineProperty(_assertThisInitialized(_this), "_topics", {});

    _defineProperty(_assertThisInitialized(_this), "_fayeClients", {});

    _this._conn = conn;
    return _this;
  }
  /* @private */


  _createClass(Streaming, [{
    key: "_createClient",
    value: function _createClient(forChannelName, extensions) {
      var _context2;

      // forChannelName is advisory, for an API workaround. It does not restrict or select the channel.
      var needsReplayFix = typeof forChannelName === 'string' && _indexOfInstanceProperty(forChannelName).call(forChannelName, '/u/') === 0;
      var endpointUrl = [this._conn.instanceUrl, // special endpoint "/cometd/replay/xx.x" is only available in 36.0.
      // See https://releasenotes.docs.salesforce.com/en-us/summer16/release-notes/rn_api_streaming_classic_replay.htm
      'cometd' + (needsReplayFix === true && this._conn.version === '36.0' ? '/replay' : ''), this._conn.version].join('/');
      var fayeClient = new Client(endpointUrl, {});
      fayeClient.setHeader('Authorization', 'OAuth ' + this._conn.accessToken);

      if (_Array$isArray(extensions)) {
        var _iterator = _createForOfIteratorHelper(extensions),
            _step;

        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var extension = _step.value;
            fayeClient.addExtension(extension);
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      } // prevent streaming API server error


      var dispatcher = fayeClient._dispatcher;

      if (_indexOfInstanceProperty(_context2 = dispatcher.getConnectionTypes()).call(_context2, 'callback-polling') === -1) {
        dispatcher.selectTransport('long-polling');
        dispatcher._transport.batching = false;
      }

      return fayeClient;
    }
    /** @private **/

  }, {
    key: "_getFayeClient",
    value: function _getFayeClient(channelName) {
      var isGeneric = _indexOfInstanceProperty(channelName).call(channelName, '/u/') === 0;
      var clientType = isGeneric ? 'generic' : 'pushTopic';

      if (!this._fayeClients[clientType]) {
        this._fayeClients[clientType] = this._createClient(channelName);
      }

      return this._fayeClients[clientType];
    }
    /**
     * Get named topic
     */

  }, {
    key: "topic",
    value: function topic(name) {
      this._topics = this._topics || {};
      var topic = this._topics[name] = this._topics[name] || new Topic(this, name);
      return topic;
    }
    /**
     * Get channel for channel name
     */

  }, {
    key: "channel",
    value: function channel(name) {
      return new Channel(this, name);
    }
    /**
     * Subscribe topic/channel
     */

  }, {
    key: "subscribe",
    value: function subscribe(name, listener) {
      var channelName = _indexOfInstanceProperty(name).call(name, '/') === 0 ? name : '/topic/' + name;

      var fayeClient = this._getFayeClient(channelName);

      return fayeClient.subscribe(channelName, listener);
    }
    /**
     * Unsubscribe topic
     */

  }, {
    key: "unsubscribe",
    value: function unsubscribe(name, subscription) {
      var channelName = _indexOfInstanceProperty(name).call(name, '/') === 0 ? name : '/topic/' + name;

      var fayeClient = this._getFayeClient(channelName);

      fayeClient.unsubscribe(channelName, subscription);
      return this;
    }
    /**
     * Create a Streaming client, optionally with extensions
     *
     * See Faye docs for implementation details: https://faye.jcoglan.com/browser/extensions.html
     *
     * Example usage:
     *
     * ```javascript
     * const jsforce = require('jsforce');
     *
     * // Establish a Salesforce connection. (Details elided)
     * const conn = new jsforce.Connection({ … });
     *
     * const fayeClient = conn.streaming.createClient();
     *
     * const subscription = fayeClient.subscribe(channel, data => {
     *   console.log('topic received data', data);
     * });
     *
     * subscription.cancel();
     * ```
     *
     * Example with extensions, using Replay & Auth Failure extensions in a server-side Node.js app:
     *
     * ```javascript
     * const jsforce = require('jsforce');
     * const { StreamingExtension } = require('jsforce/api/streaming');
     *
     * // Establish a Salesforce connection. (Details elided)
     * const conn = new jsforce.Connection({ … });
     *
     * const channel = "/event/My_Event__e";
     * const replayId = -2; // -2 is all retained events
     *
     * const exitCallback = () => process.exit(1);
     * const authFailureExt = new StreamingExtension.AuthFailure(exitCallback);
     *
     * const replayExt = new StreamingExtension.Replay(channel, replayId);
     *
     * const fayeClient = conn.streaming.createClient([
     *   authFailureExt,
     *   replayExt
     * ]);
     *
     * const subscription = fayeClient.subscribe(channel, data => {
     *   console.log('topic received data', data);
     * });
     *
     * subscription.cancel();
     * ```
     */

  }, {
    key: "createClient",
    value: function createClient(extensions) {
      return this._createClient(null, extensions);
    }
  }]);

  return Streaming;
}(EventEmitter);
export { StreamingExtension };
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('streaming', function (conn) {
  return new Streaming(conn);
});
export default Streaming;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvc3RyZWFtaW5nLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsIkNsaWVudCIsIlN1YnNjcmlwdGlvbiIsInJlZ2lzdGVyTW9kdWxlIiwiU3RyZWFtaW5nRXh0ZW5zaW9uIiwiVG9waWMiLCJzdHJlYW1pbmciLCJuYW1lIiwiX3N0cmVhbWluZyIsImxpc3RlbmVyIiwic3Vic2NyaWJlIiwic3Vic2NyIiwidW5zdWJzY3JpYmUiLCJDaGFubmVsIiwiZXZlbnRzIiwiaXNBcnJheSIsInB1c2hFdmVudHMiLCJjb25uIiwiX2Nvbm4iLCJfaWQiLCJzb2JqZWN0IiwiZmluZE9uZSIsIk5hbWUiLCJ0aGVuIiwicmVjIiwiSWQiLCJpZCIsIkVycm9yIiwiY2hhbm5lbFVybCIsInJlcXVlc3RQb3N0IiwicmV0cyIsIlN0cmVhbWluZyIsImZvckNoYW5uZWxOYW1lIiwiZXh0ZW5zaW9ucyIsIm5lZWRzUmVwbGF5Rml4IiwiZW5kcG9pbnRVcmwiLCJpbnN0YW5jZVVybCIsInZlcnNpb24iLCJqb2luIiwiZmF5ZUNsaWVudCIsInNldEhlYWRlciIsImFjY2Vzc1Rva2VuIiwiZXh0ZW5zaW9uIiwiYWRkRXh0ZW5zaW9uIiwiZGlzcGF0Y2hlciIsIl9kaXNwYXRjaGVyIiwiZ2V0Q29ubmVjdGlvblR5cGVzIiwic2VsZWN0VHJhbnNwb3J0IiwiX3RyYW5zcG9ydCIsImJhdGNoaW5nIiwiY2hhbm5lbE5hbWUiLCJpc0dlbmVyaWMiLCJjbGllbnRUeXBlIiwiX2ZheWVDbGllbnRzIiwiX2NyZWF0ZUNsaWVudCIsIl90b3BpY3MiLCJ0b3BpYyIsIl9nZXRGYXllQ2xpZW50Iiwic3Vic2NyaXB0aW9uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsU0FBU0MsTUFBVCxFQUFpQkMsWUFBakIsUUFBcUMsTUFBckM7QUFDQSxTQUFTQyxjQUFULFFBQStCLFlBQS9CO0FBR0EsT0FBTyxLQUFLQyxrQkFBWixNQUFvQyx1QkFBcEM7QUFFQTtBQUNBO0FBQ0E7O0FBOEJBLFNBQVNILE1BQVQsRUFBaUJDLFlBQWpCO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztJQUNNRyxLO0FBSUosaUJBQVlDLFNBQVosRUFBcUNDLElBQXJDLEVBQW1EO0FBQUE7O0FBQUE7O0FBQUE7O0FBQ2pELFNBQUtDLFVBQUwsR0FBa0JGLFNBQWxCO0FBQ0EsU0FBS0MsSUFBTCxHQUFZQSxJQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7Ozs7OzhCQUNZRSxRLEVBQWdFO0FBQ3hFLGFBQU8sS0FBS0QsVUFBTCxDQUFnQkUsU0FBaEIsQ0FBMEIsS0FBS0gsSUFBL0IsRUFBcUNFLFFBQXJDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7OztnQ0FDY0UsTSxFQUFzQjtBQUNoQyxXQUFLSCxVQUFMLENBQWdCSSxXQUFoQixDQUE0QixLQUFLTCxJQUFqQyxFQUF1Q0ksTUFBdkM7O0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7Ozs7O0FBR0g7O0FBQ0E7QUFDQTtBQUNBOzs7SUFDTUUsTztBQUtKLG1CQUFZUCxTQUFaLEVBQXFDQyxJQUFyQyxFQUFtRDtBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUNqRCxTQUFLQyxVQUFMLEdBQWtCRixTQUFsQjtBQUNBLFNBQUtDLElBQUwsR0FBWUEsSUFBWjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7Ozs4QkFDWUUsUSxFQUFrQztBQUMxQyxhQUFPLEtBQUtELFVBQUwsQ0FBZ0JFLFNBQWhCLENBQTBCLEtBQUtILElBQS9CLEVBQXFDRSxRQUFyQyxDQUFQO0FBQ0Q7OztnQ0FFV0UsTSxFQUFzQjtBQUNoQyxXQUFLSCxVQUFMLENBQWdCSSxXQUFoQixDQUE0QixLQUFLTCxJQUFqQyxFQUF1Q0ksTUFBdkM7O0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7Ozs7NEZBSVVHLE07Ozs7OztBQUNIQyxnQkFBQUEsTyxHQUFVLGVBQWNELE1BQWQsQztBQUNWRSxnQkFBQUEsVSxHQUFhLGVBQWNGLE1BQWQsSUFBd0JBLE1BQXhCLEdBQWlDLENBQUNBLE1BQUQsQztBQUM5Q0csZ0JBQUFBLEksR0FBb0IsS0FBS1QsVUFBTCxDQUFnQlUsSzs7QUFDMUMsb0JBQUksQ0FBQyxLQUFLQyxHQUFWLEVBQWU7QUFDYix1QkFBS0EsR0FBTCxHQUFXRixJQUFJLENBQ1pHLE9BRFEsQ0FDQSxrQkFEQSxFQUVSQyxPQUZRLENBRUE7QUFBRUMsb0JBQUFBLElBQUksRUFBRSxLQUFLZjtBQUFiLG1CQUZBLEVBRXFCLENBQUMsSUFBRCxDQUZyQixFQUdSZ0IsSUFIUSxDQUdILFVBQUNDLEdBQUQ7QUFBQSwyQkFBU0EsR0FBVCxhQUFTQSxHQUFULHVCQUFTQSxHQUFHLENBQUVDLEVBQWQ7QUFBQSxtQkFIRyxDQUFYO0FBSUQ7Ozt1QkFDZ0IsS0FBS04sRzs7O0FBQWhCTyxnQkFBQUEsRTs7b0JBQ0RBLEU7Ozs7O3NCQUNHLElBQUlDLEtBQUosb0RBQXNELEtBQUtwQixJQUEzRCxFOzs7QUFFRnFCLGdCQUFBQSxVLHdDQUEyQ0YsRTs7dUJBQzlCVCxJQUFJLENBQUNZLFdBQUwsQ0FBb0NELFVBQXBDLEVBQWdEO0FBQ2pFWixrQkFBQUEsVUFBVSxFQUFWQTtBQURpRSxpQkFBaEQsQzs7O0FBQWJjLGdCQUFBQSxJO2lEQUdDZixPQUFPLEdBQUdlLElBQUgsR0FBVUEsSUFBSSxDQUFDLENBQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJaEM7O0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFhQyxTQUFiO0FBQUE7O0FBQUE7O0FBS0U7QUFDRjtBQUNBO0FBQ0UscUJBQVlkLElBQVosRUFBaUM7QUFBQTs7QUFBQTs7QUFDL0I7O0FBRCtCOztBQUFBLDhEQU5lLEVBTWY7O0FBQUEsbUVBTGdCLEVBS2hCOztBQUUvQixVQUFLQyxLQUFMLEdBQWFELElBQWI7QUFGK0I7QUFHaEM7QUFFRDs7O0FBYkY7QUFBQTtBQUFBLGtDQWNnQmUsY0FkaEIsRUFjZ0RDLFVBZGhELEVBY29FO0FBQUE7O0FBQ2hFO0FBQ0EsVUFBTUMsY0FBYyxHQUNsQixPQUFPRixjQUFQLEtBQTBCLFFBQTFCLElBQXNDLHlCQUFBQSxjQUFjLE1BQWQsQ0FBQUEsY0FBYyxFQUFTLEtBQVQsQ0FBZCxLQUFrQyxDQUQxRTtBQUVBLFVBQU1HLFdBQVcsR0FBRyxDQUNsQixLQUFLakIsS0FBTCxDQUFXa0IsV0FETyxFQUVsQjtBQUNBO0FBQ0Esa0JBQ0dGLGNBQWMsS0FBSyxJQUFuQixJQUEyQixLQUFLaEIsS0FBTCxDQUFXbUIsT0FBWCxLQUF1QixNQUFsRCxHQUNHLFNBREgsR0FFRyxFQUhOLENBSmtCLEVBUWxCLEtBQUtuQixLQUFMLENBQVdtQixPQVJPLEVBU2xCQyxJQVRrQixDQVNiLEdBVGEsQ0FBcEI7QUFVQSxVQUFNQyxVQUFVLEdBQUcsSUFBSXRDLE1BQUosQ0FBV2tDLFdBQVgsRUFBd0IsRUFBeEIsQ0FBbkI7QUFDQUksTUFBQUEsVUFBVSxDQUFDQyxTQUFYLENBQXFCLGVBQXJCLEVBQXNDLFdBQVcsS0FBS3RCLEtBQUwsQ0FBV3VCLFdBQTVEOztBQUNBLFVBQUksZUFBY1IsVUFBZCxDQUFKLEVBQStCO0FBQUEsbURBQ0xBLFVBREs7QUFBQTs7QUFBQTtBQUM3Qiw4REFBb0M7QUFBQSxnQkFBekJTLFNBQXlCO0FBQ2xDSCxZQUFBQSxVQUFVLENBQUNJLFlBQVgsQ0FBd0JELFNBQXhCO0FBQ0Q7QUFINEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUk5QixPQXBCK0QsQ0FxQmhFOzs7QUFDQSxVQUFNRSxVQUFVLEdBQUlMLFVBQUQsQ0FBb0JNLFdBQXZDOztBQUNBLFVBQUkscUNBQUFELFVBQVUsQ0FBQ0Usa0JBQVgsb0JBQXdDLGtCQUF4QyxNQUFnRSxDQUFDLENBQXJFLEVBQXdFO0FBQ3RFRixRQUFBQSxVQUFVLENBQUNHLGVBQVgsQ0FBMkIsY0FBM0I7QUFDQUgsUUFBQUEsVUFBVSxDQUFDSSxVQUFYLENBQXNCQyxRQUF0QixHQUFpQyxLQUFqQztBQUNEOztBQUNELGFBQU9WLFVBQVA7QUFDRDtBQUVEOztBQTVDRjtBQUFBO0FBQUEsbUNBNkNpQlcsV0E3Q2pCLEVBNkNzQztBQUNsQyxVQUFNQyxTQUFTLEdBQUcseUJBQUFELFdBQVcsTUFBWCxDQUFBQSxXQUFXLEVBQVMsS0FBVCxDQUFYLEtBQStCLENBQWpEO0FBQ0EsVUFBTUUsVUFBVSxHQUFHRCxTQUFTLEdBQUcsU0FBSCxHQUFlLFdBQTNDOztBQUNBLFVBQUksQ0FBQyxLQUFLRSxZQUFMLENBQWtCRCxVQUFsQixDQUFMLEVBQW9DO0FBQ2xDLGFBQUtDLFlBQUwsQ0FBa0JELFVBQWxCLElBQWdDLEtBQUtFLGFBQUwsQ0FBbUJKLFdBQW5CLENBQWhDO0FBQ0Q7O0FBQ0QsYUFBTyxLQUFLRyxZQUFMLENBQWtCRCxVQUFsQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBeERBO0FBQUE7QUFBQSwwQkF5RG1DN0MsSUF6RG5DLEVBeUQ4RDtBQUMxRCxXQUFLZ0QsT0FBTCxHQUFlLEtBQUtBLE9BQUwsSUFBZ0IsRUFBL0I7QUFDQSxVQUFNQyxLQUFLLEdBQUksS0FBS0QsT0FBTCxDQUFhaEQsSUFBYixJQUNiLEtBQUtnRCxPQUFMLENBQWFoRCxJQUFiLEtBQXNCLElBQUlGLEtBQUosQ0FBZ0IsSUFBaEIsRUFBc0JFLElBQXRCLENBRHhCO0FBRUEsYUFBT2lELEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFsRUE7QUFBQTtBQUFBLDRCQW1FVWpELElBbkVWLEVBbUV3QjtBQUNwQixhQUFPLElBQUlNLE9BQUosQ0FBWSxJQUFaLEVBQWtCTixJQUFsQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBekVBO0FBQUE7QUFBQSw4QkEwRVlBLElBMUVaLEVBMEUwQkUsUUExRTFCLEVBMEU0RDtBQUN4RCxVQUFNeUMsV0FBVyxHQUFHLHlCQUFBM0MsSUFBSSxNQUFKLENBQUFBLElBQUksRUFBUyxHQUFULENBQUosS0FBc0IsQ0FBdEIsR0FBMEJBLElBQTFCLEdBQWlDLFlBQVlBLElBQWpFOztBQUNBLFVBQU1nQyxVQUFVLEdBQUcsS0FBS2tCLGNBQUwsQ0FBb0JQLFdBQXBCLENBQW5COztBQUNBLGFBQU9YLFVBQVUsQ0FBQzdCLFNBQVgsQ0FBcUJ3QyxXQUFyQixFQUFrQ3pDLFFBQWxDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFsRkE7QUFBQTtBQUFBLGdDQW1GY0YsSUFuRmQsRUFtRjRCbUQsWUFuRjVCLEVBbUZ3RDtBQUNwRCxVQUFNUixXQUFXLEdBQUcseUJBQUEzQyxJQUFJLE1BQUosQ0FBQUEsSUFBSSxFQUFTLEdBQVQsQ0FBSixLQUFzQixDQUF0QixHQUEwQkEsSUFBMUIsR0FBaUMsWUFBWUEsSUFBakU7O0FBQ0EsVUFBTWdDLFVBQVUsR0FBRyxLQUFLa0IsY0FBTCxDQUFvQlAsV0FBcEIsQ0FBbkI7O0FBQ0FYLE1BQUFBLFVBQVUsQ0FBQzNCLFdBQVgsQ0FBdUJzQyxXQUF2QixFQUFvQ1EsWUFBcEM7QUFDQSxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUE1SUE7QUFBQTtBQUFBLGlDQTZJZXpCLFVBN0lmLEVBNklrQztBQUM5QixhQUFPLEtBQUtxQixhQUFMLENBQW1CLElBQW5CLEVBQXlCckIsVUFBekIsQ0FBUDtBQUNEO0FBL0lIOztBQUFBO0FBQUEsRUFBaURqQyxZQUFqRDtBQWtKQSxTQUFTSSxrQkFBVDtBQUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQUQsY0FBYyxDQUFDLFdBQUQsRUFBYyxVQUFDYyxJQUFEO0FBQUEsU0FBVSxJQUFJYyxTQUFKLENBQWNkLElBQWQsQ0FBVjtBQUFBLENBQWQsQ0FBZDtBQUVBLGVBQWVjLFNBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU3RyZWFtaW5nIEFQSXNcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgQ2xpZW50LCBTdWJzY3JpcHRpb24gfSBmcm9tICdmYXllJztcbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFJlY29yZCwgU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0ICogYXMgU3RyZWFtaW5nRXh0ZW5zaW9uIGZyb20gJy4vc3RyZWFtaW5nL2V4dGVuc2lvbic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU3RyZWFtaW5nTWVzc2FnZTxSIGV4dGVuZHMgUmVjb3JkPiA9IHtcbiAgZXZlbnQ6IHtcbiAgICB0eXBlOiBzdHJpbmc7XG4gICAgY3JlYXRlZERhdGU6IHN0cmluZztcbiAgICByZXBsYXlJZDogbnVtYmVyO1xuICB9O1xuICBzb2JqZWN0OiBSO1xufTtcblxuZXhwb3J0IHR5cGUgR2VuZXJpY1N0cmVhbWluZ01lc3NhZ2UgPSB7XG4gIGV2ZW50OiB7XG4gICAgY3JlYXRlZERhdGU6IHN0cmluZztcbiAgICByZXBsYXlJZDogbnVtYmVyO1xuICB9O1xuICBwYXlsb2FkOiBzdHJpbmc7XG59O1xuXG5leHBvcnQgdHlwZSBQdXNoRXZlbnQgPSB7XG4gIHBheWxvYWQ6IHN0cmluZztcbiAgdXNlcklkczogc3RyaW5nW107XG59O1xuXG5leHBvcnQgdHlwZSBQdXNoRXZlbnRSZXN1bHQgPSB7XG4gIGZhbm91dENvdW50OiBudW1iZXI7XG4gIHVzZXJPbmxpbmVTdGF0dXM6IHtcbiAgICBbdXNlcklkOiBzdHJpbmddOiBib29sZWFuO1xuICB9O1xufTtcblxuZXhwb3J0IHsgQ2xpZW50LCBTdWJzY3JpcHRpb24gfTtcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFN0cmVhbWluZyBBUEkgdG9waWMgY2xhc3NcbiAqL1xuY2xhc3MgVG9waWM8UyBleHRlbmRzIFNjaGVtYSwgUiBleHRlbmRzIFJlY29yZD4ge1xuICBfc3RyZWFtaW5nOiBTdHJlYW1pbmc8Uz47XG4gIG5hbWU6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihzdHJlYW1pbmc6IFN0cmVhbWluZzxTPiwgbmFtZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fc3RyZWFtaW5nID0gc3RyZWFtaW5nO1xuICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gIH1cblxuICAvKipcbiAgICogU3Vic2NyaWJlIGxpc3RlbmVyIHRvIHRvcGljXG4gICAqL1xuICBzdWJzY3JpYmUobGlzdGVuZXI6IChtZXNzYWdlOiBTdHJlYW1pbmdNZXNzYWdlPFI+KSA9PiB2b2lkKTogU3Vic2NyaXB0aW9uIHtcbiAgICByZXR1cm4gdGhpcy5fc3RyZWFtaW5nLnN1YnNjcmliZSh0aGlzLm5hbWUsIGxpc3RlbmVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZSBsaXN0ZW5lciBmcm9tIHRvcGljXG4gICAqL1xuICB1bnN1YnNjcmliZShzdWJzY3I6IFN1YnNjcmlwdGlvbikge1xuICAgIHRoaXMuX3N0cmVhbWluZy51bnN1YnNjcmliZSh0aGlzLm5hbWUsIHN1YnNjcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFN0cmVhbWluZyBBUEkgR2VuZXJpYyBTdHJlYW1pbmcgQ2hhbm5lbFxuICovXG5jbGFzcyBDaGFubmVsPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX3N0cmVhbWluZzogU3RyZWFtaW5nPFM+O1xuICBfaWQ6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB8IHVuZGVmaW5lZDtcbiAgbmFtZTogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHN0cmVhbWluZzogU3RyZWFtaW5nPFM+LCBuYW1lOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9zdHJlYW1pbmcgPSBzdHJlYW1pbmc7XG4gICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gY2hhbm5lbFxuICAgKi9cbiAgc3Vic2NyaWJlKGxpc3RlbmVyOiBGdW5jdGlvbik6IFN1YnNjcmlwdGlvbiB7XG4gICAgcmV0dXJuIHRoaXMuX3N0cmVhbWluZy5zdWJzY3JpYmUodGhpcy5uYW1lLCBsaXN0ZW5lcik7XG4gIH1cblxuICB1bnN1YnNjcmliZShzdWJzY3I6IFN1YnNjcmlwdGlvbikge1xuICAgIHRoaXMuX3N0cmVhbWluZy51bnN1YnNjcmliZSh0aGlzLm5hbWUsIHN1YnNjcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBwdXNoKGV2ZW50czogUHVzaEV2ZW50KTogUHJvbWlzZTxQdXNoRXZlbnRSZXN1bHQ+O1xuICBwdXNoKGV2ZW50czogUHVzaEV2ZW50KTogUHJvbWlzZTxQdXNoRXZlbnRSZXN1bHRbXT47XG4gIGFzeW5jIHB1c2goZXZlbnRzOiBQdXNoRXZlbnQgfCBQdXNoRXZlbnRbXSkge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KGV2ZW50cyk7XG4gICAgY29uc3QgcHVzaEV2ZW50cyA9IEFycmF5LmlzQXJyYXkoZXZlbnRzKSA/IGV2ZW50cyA6IFtldmVudHNdO1xuICAgIGNvbnN0IGNvbm46IENvbm5lY3Rpb24gPSAodGhpcy5fc3RyZWFtaW5nLl9jb25uIGFzIHVua25vd24pIGFzIENvbm5lY3Rpb247XG4gICAgaWYgKCF0aGlzLl9pZCkge1xuICAgICAgdGhpcy5faWQgPSBjb25uXG4gICAgICAgIC5zb2JqZWN0KCdTdHJlYW1pbmdDaGFubmVsJylcbiAgICAgICAgLmZpbmRPbmUoeyBOYW1lOiB0aGlzLm5hbWUgfSwgWydJZCddKVxuICAgICAgICAudGhlbigocmVjKSA9PiByZWM/LklkKTtcbiAgICB9XG4gICAgY29uc3QgaWQgPSBhd2FpdCB0aGlzLl9pZDtcbiAgICBpZiAoIWlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYE5vIHN0cmVhbWluZyBjaGFubmVsIGF2YWlsYWJsZSBmb3IgbmFtZTogJHt0aGlzLm5hbWV9YCk7XG4gICAgfVxuICAgIGNvbnN0IGNoYW5uZWxVcmwgPSBgL3NvYmplY3RzL1N0cmVhbWluZ0NoYW5uZWwvJHtpZH0vcHVzaGA7XG4gICAgY29uc3QgcmV0cyA9IGF3YWl0IGNvbm4ucmVxdWVzdFBvc3Q8UHVzaEV2ZW50UmVzdWx0W10+KGNoYW5uZWxVcmwsIHtcbiAgICAgIHB1c2hFdmVudHMsXG4gICAgfSk7XG4gICAgcmV0dXJuIGlzQXJyYXkgPyByZXRzIDogcmV0c1swXTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogU3RyZWFtaW5nIEFQSSBjbGFzc1xuICovXG5leHBvcnQgY2xhc3MgU3RyZWFtaW5nPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIF90b3BpY3M6IHsgW25hbWU6IHN0cmluZ106IFRvcGljPFMsIFJlY29yZD4gfSA9IHt9O1xuICBfZmF5ZUNsaWVudHM6IHsgW2NsaWVudFR5cGU6IHN0cmluZ106IENsaWVudCB9ID0ge307XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qIEBwcml2YXRlICovXG4gIF9jcmVhdGVDbGllbnQoZm9yQ2hhbm5lbE5hbWU/OiBzdHJpbmcgfCBudWxsLCBleHRlbnNpb25zPzogYW55W10pIHtcbiAgICAvLyBmb3JDaGFubmVsTmFtZSBpcyBhZHZpc29yeSwgZm9yIGFuIEFQSSB3b3JrYXJvdW5kLiBJdCBkb2VzIG5vdCByZXN0cmljdCBvciBzZWxlY3QgdGhlIGNoYW5uZWwuXG4gICAgY29uc3QgbmVlZHNSZXBsYXlGaXggPVxuICAgICAgdHlwZW9mIGZvckNoYW5uZWxOYW1lID09PSAnc3RyaW5nJyAmJiBmb3JDaGFubmVsTmFtZS5pbmRleE9mKCcvdS8nKSA9PT0gMDtcbiAgICBjb25zdCBlbmRwb2ludFVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uaW5zdGFuY2VVcmwsXG4gICAgICAvLyBzcGVjaWFsIGVuZHBvaW50IFwiL2NvbWV0ZC9yZXBsYXkveHgueFwiIGlzIG9ubHkgYXZhaWxhYmxlIGluIDM2LjAuXG4gICAgICAvLyBTZWUgaHR0cHM6Ly9yZWxlYXNlbm90ZXMuZG9jcy5zYWxlc2ZvcmNlLmNvbS9lbi11cy9zdW1tZXIxNi9yZWxlYXNlLW5vdGVzL3JuX2FwaV9zdHJlYW1pbmdfY2xhc3NpY19yZXBsYXkuaHRtXG4gICAgICAnY29tZXRkJyArXG4gICAgICAgIChuZWVkc1JlcGxheUZpeCA9PT0gdHJ1ZSAmJiB0aGlzLl9jb25uLnZlcnNpb24gPT09ICczNi4wJ1xuICAgICAgICAgID8gJy9yZXBsYXknXG4gICAgICAgICAgOiAnJyksXG4gICAgICB0aGlzLl9jb25uLnZlcnNpb24sXG4gICAgXS5qb2luKCcvJyk7XG4gICAgY29uc3QgZmF5ZUNsaWVudCA9IG5ldyBDbGllbnQoZW5kcG9pbnRVcmwsIHt9KTtcbiAgICBmYXllQ2xpZW50LnNldEhlYWRlcignQXV0aG9yaXphdGlvbicsICdPQXV0aCAnICsgdGhpcy5fY29ubi5hY2Nlc3NUb2tlbik7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoZXh0ZW5zaW9ucykpIHtcbiAgICAgIGZvciAoY29uc3QgZXh0ZW5zaW9uIG9mIGV4dGVuc2lvbnMpIHtcbiAgICAgICAgZmF5ZUNsaWVudC5hZGRFeHRlbnNpb24oZXh0ZW5zaW9uKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gcHJldmVudCBzdHJlYW1pbmcgQVBJIHNlcnZlciBlcnJvclxuICAgIGNvbnN0IGRpc3BhdGNoZXIgPSAoZmF5ZUNsaWVudCBhcyBhbnkpLl9kaXNwYXRjaGVyO1xuICAgIGlmIChkaXNwYXRjaGVyLmdldENvbm5lY3Rpb25UeXBlcygpLmluZGV4T2YoJ2NhbGxiYWNrLXBvbGxpbmcnKSA9PT0gLTEpIHtcbiAgICAgIGRpc3BhdGNoZXIuc2VsZWN0VHJhbnNwb3J0KCdsb25nLXBvbGxpbmcnKTtcbiAgICAgIGRpc3BhdGNoZXIuX3RyYW5zcG9ydC5iYXRjaGluZyA9IGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gZmF5ZUNsaWVudDtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqKi9cbiAgX2dldEZheWVDbGllbnQoY2hhbm5lbE5hbWU6IHN0cmluZykge1xuICAgIGNvbnN0IGlzR2VuZXJpYyA9IGNoYW5uZWxOYW1lLmluZGV4T2YoJy91LycpID09PSAwO1xuICAgIGNvbnN0IGNsaWVudFR5cGUgPSBpc0dlbmVyaWMgPyAnZ2VuZXJpYycgOiAncHVzaFRvcGljJztcbiAgICBpZiAoIXRoaXMuX2ZheWVDbGllbnRzW2NsaWVudFR5cGVdKSB7XG4gICAgICB0aGlzLl9mYXllQ2xpZW50c1tjbGllbnRUeXBlXSA9IHRoaXMuX2NyZWF0ZUNsaWVudChjaGFubmVsTmFtZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9mYXllQ2xpZW50c1tjbGllbnRUeXBlXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgbmFtZWQgdG9waWNcbiAgICovXG4gIHRvcGljPFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+KG5hbWU6IHN0cmluZyk6IFRvcGljPFMsIFI+IHtcbiAgICB0aGlzLl90b3BpY3MgPSB0aGlzLl90b3BpY3MgfHwge307XG4gICAgY29uc3QgdG9waWMgPSAodGhpcy5fdG9waWNzW25hbWVdID1cbiAgICAgIHRoaXMuX3RvcGljc1tuYW1lXSB8fCBuZXcgVG9waWM8UywgUj4odGhpcywgbmFtZSkpO1xuICAgIHJldHVybiB0b3BpYyBhcyBUb3BpYzxTLCBSPjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgY2hhbm5lbCBmb3IgY2hhbm5lbCBuYW1lXG4gICAqL1xuICBjaGFubmVsKG5hbWU6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgQ2hhbm5lbCh0aGlzLCBuYW1lKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG9waWMvY2hhbm5lbFxuICAgKi9cbiAgc3Vic2NyaWJlKG5hbWU6IHN0cmluZywgbGlzdGVuZXI6IEZ1bmN0aW9uKTogU3Vic2NyaXB0aW9uIHtcbiAgICBjb25zdCBjaGFubmVsTmFtZSA9IG5hbWUuaW5kZXhPZignLycpID09PSAwID8gbmFtZSA6ICcvdG9waWMvJyArIG5hbWU7XG4gICAgY29uc3QgZmF5ZUNsaWVudCA9IHRoaXMuX2dldEZheWVDbGllbnQoY2hhbm5lbE5hbWUpO1xuICAgIHJldHVybiBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsTmFtZSwgbGlzdGVuZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVuc3Vic2NyaWJlIHRvcGljXG4gICAqL1xuICB1bnN1YnNjcmliZShuYW1lOiBzdHJpbmcsIHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uKSB7XG4gICAgY29uc3QgY2hhbm5lbE5hbWUgPSBuYW1lLmluZGV4T2YoJy8nKSA9PT0gMCA/IG5hbWUgOiAnL3RvcGljLycgKyBuYW1lO1xuICAgIGNvbnN0IGZheWVDbGllbnQgPSB0aGlzLl9nZXRGYXllQ2xpZW50KGNoYW5uZWxOYW1lKTtcbiAgICBmYXllQ2xpZW50LnVuc3Vic2NyaWJlKGNoYW5uZWxOYW1lLCBzdWJzY3JpcHRpb24pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIFN0cmVhbWluZyBjbGllbnQsIG9wdGlvbmFsbHkgd2l0aCBleHRlbnNpb25zXG4gICAqXG4gICAqIFNlZSBGYXllIGRvY3MgZm9yIGltcGxlbWVudGF0aW9uIGRldGFpbHM6IGh0dHBzOi8vZmF5ZS5qY29nbGFuLmNvbS9icm93c2VyL2V4dGVuc2lvbnMuaHRtbFxuICAgKlxuICAgKiBFeGFtcGxlIHVzYWdlOlxuICAgKlxuICAgKiBgYGBqYXZhc2NyaXB0XG4gICAqIGNvbnN0IGpzZm9yY2UgPSByZXF1aXJlKCdqc2ZvcmNlJyk7XG4gICAqXG4gICAqIC8vIEVzdGFibGlzaCBhIFNhbGVzZm9yY2UgY29ubmVjdGlvbi4gKERldGFpbHMgZWxpZGVkKVxuICAgKiBjb25zdCBjb25uID0gbmV3IGpzZm9yY2UuQ29ubmVjdGlvbih7IOKApiB9KTtcbiAgICpcbiAgICogY29uc3QgZmF5ZUNsaWVudCA9IGNvbm4uc3RyZWFtaW5nLmNyZWF0ZUNsaWVudCgpO1xuICAgKlxuICAgKiBjb25zdCBzdWJzY3JpcHRpb24gPSBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsLCBkYXRhID0+IHtcbiAgICogICBjb25zb2xlLmxvZygndG9waWMgcmVjZWl2ZWQgZGF0YScsIGRhdGEpO1xuICAgKiB9KTtcbiAgICpcbiAgICogc3Vic2NyaXB0aW9uLmNhbmNlbCgpO1xuICAgKiBgYGBcbiAgICpcbiAgICogRXhhbXBsZSB3aXRoIGV4dGVuc2lvbnMsIHVzaW5nIFJlcGxheSAmIEF1dGggRmFpbHVyZSBleHRlbnNpb25zIGluIGEgc2VydmVyLXNpZGUgTm9kZS5qcyBhcHA6XG4gICAqXG4gICAqIGBgYGphdmFzY3JpcHRcbiAgICogY29uc3QganNmb3JjZSA9IHJlcXVpcmUoJ2pzZm9yY2UnKTtcbiAgICogY29uc3QgeyBTdHJlYW1pbmdFeHRlbnNpb24gfSA9IHJlcXVpcmUoJ2pzZm9yY2UvYXBpL3N0cmVhbWluZycpO1xuICAgKlxuICAgKiAvLyBFc3RhYmxpc2ggYSBTYWxlc2ZvcmNlIGNvbm5lY3Rpb24uIChEZXRhaWxzIGVsaWRlZClcbiAgICogY29uc3QgY29ubiA9IG5ldyBqc2ZvcmNlLkNvbm5lY3Rpb24oeyDigKYgfSk7XG4gICAqXG4gICAqIGNvbnN0IGNoYW5uZWwgPSBcIi9ldmVudC9NeV9FdmVudF9fZVwiO1xuICAgKiBjb25zdCByZXBsYXlJZCA9IC0yOyAvLyAtMiBpcyBhbGwgcmV0YWluZWQgZXZlbnRzXG4gICAqXG4gICAqIGNvbnN0IGV4aXRDYWxsYmFjayA9ICgpID0+IHByb2Nlc3MuZXhpdCgxKTtcbiAgICogY29uc3QgYXV0aEZhaWx1cmVFeHQgPSBuZXcgU3RyZWFtaW5nRXh0ZW5zaW9uLkF1dGhGYWlsdXJlKGV4aXRDYWxsYmFjayk7XG4gICAqXG4gICAqIGNvbnN0IHJlcGxheUV4dCA9IG5ldyBTdHJlYW1pbmdFeHRlbnNpb24uUmVwbGF5KGNoYW5uZWwsIHJlcGxheUlkKTtcbiAgICpcbiAgICogY29uc3QgZmF5ZUNsaWVudCA9IGNvbm4uc3RyZWFtaW5nLmNyZWF0ZUNsaWVudChbXG4gICAqICAgYXV0aEZhaWx1cmVFeHQsXG4gICAqICAgcmVwbGF5RXh0XG4gICAqIF0pO1xuICAgKlxuICAgKiBjb25zdCBzdWJzY3JpcHRpb24gPSBmYXllQ2xpZW50LnN1YnNjcmliZShjaGFubmVsLCBkYXRhID0+IHtcbiAgICogICBjb25zb2xlLmxvZygndG9waWMgcmVjZWl2ZWQgZGF0YScsIGRhdGEpO1xuICAgKiB9KTtcbiAgICpcbiAgICogc3Vic2NyaXB0aW9uLmNhbmNlbCgpO1xuICAgKiBgYGBcbiAgICovXG4gIGNyZWF0ZUNsaWVudChleHRlbnNpb25zOiBhbnlbXSkge1xuICAgIHJldHVybiB0aGlzLl9jcmVhdGVDbGllbnQobnVsbCwgZXh0ZW5zaW9ucyk7XG4gIH1cbn1cblxuZXhwb3J0IHsgU3RyZWFtaW5nRXh0ZW5zaW9uIH07XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdzdHJlYW1pbmcnLCAoY29ubikgPT4gbmV3IFN0cmVhbWluZyhjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IFN0cmVhbWluZztcbiJdfQ==