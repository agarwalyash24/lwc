import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context12; _forEachInstanceProperty(_context12 = ownKeys(Object(source), true)).call(_context12, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context13; _forEachInstanceProperty(_context13 = ownKeys(Object(source))).call(_context13, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context11; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context11 = Object.prototype.toString.call(o)).call(_context11, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * @file Salesforce SOAP API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import SOAP from '../soap';
import { ApiSchemas } from './soap/schema';
/**
 *
 */

function toSoapRecord(records) {
  var _context;

  return _mapInstanceProperty(_context = _Array$isArray(records) ? records : [records]).call(_context, function (record) {
    var _context2;

    var type = record.type,
        attributes = record.attributes,
        rec = _objectWithoutProperties(record, ["type", "attributes"]);

    var t = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type);

    if (!t) {
      throw new Error('Given record is not including sObject type information');
    }

    var fieldsToNull = _filterInstanceProperty(_context2 = _Object$keys(rec)).call(_context2, function (field) {
      return record[field] === null;
    });

    var _iterator = _createForOfIteratorHelper(fieldsToNull),
        _step;

    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var field = _step.value;
        delete rec[field];
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }

    return fieldsToNull.length > 0 ? _objectSpread({
      type: t,
      fieldsToNull: fieldsToNull
    }, rec) : _objectSpread({
      type: t
    }, rec);
  });
}
/**
 * API class for Partner SOAP call
 */


export var SoapApi = /*#__PURE__*/function () {
  function SoapApi(conn) {
    _classCallCheck(this, SoapApi);

    _defineProperty(this, "_conn", void 0);

    this._conn = conn;
  }
  /**
   * Call SOAP Api (Partner) endpoint
   * @private
   */


  _createClass(SoapApi, [{
    key: "_invoke",
    value: function () {
      var _invoke2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, message, schema) {
        var _context3;

        var soapEndpoint, res;
        return _regeneratorRuntime.wrap(function _callee$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                soapEndpoint = new SOAP(this._conn, {
                  xmlns: 'urn:partner.soap.sforce.com',
                  endpointUrl: _concatInstanceProperty(_context3 = "".concat(this._conn.instanceUrl, "/services/Soap/u/")).call(_context3, this._conn.version)
                });
                _context4.next = 3;
                return soapEndpoint.invoke(method, message, schema ? {
                  result: schema
                } : undefined, ApiSchemas);

              case 3:
                res = _context4.sent;
                return _context4.abrupt("return", res.result);

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee, this);
      }));

      function _invoke(_x, _x2, _x3) {
        return _invoke2.apply(this, arguments);
      }

      return _invoke;
    }()
    /**
     * Converts a Lead into an Account, Contact, or (optionally) an Opportunity.
     */

  }, {
    key: "convertLead",
    value: function () {
      var _convertLead = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(leadConverts) {
        var schema;
        return _regeneratorRuntime.wrap(function _callee2$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                schema = _Array$isArray(leadConverts) ? [ApiSchemas.LeadConvertResult] : ApiSchemas.LeadConvertResult;
                return _context5.abrupt("return", this._invoke('convertLead', {
                  leadConverts: leadConverts
                }, schema));

              case 2:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee2, this);
      }));

      function convertLead(_x4) {
        return _convertLead.apply(this, arguments);
      }

      return convertLead;
    }()
    /**
     * Merge up to three records into one
     */

  }, {
    key: "merge",
    value: function () {
      var _merge = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(mergeRequests) {
        var schema;
        return _regeneratorRuntime.wrap(function _callee3$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                schema = _Array$isArray(mergeRequests) ? [ApiSchemas.MergeResult] : ApiSchemas.MergeResult;
                return _context6.abrupt("return", this._invoke('merge', {
                  mergeRequests: mergeRequests
                }, schema));

              case 2:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee3, this);
      }));

      function merge(_x5) {
        return _merge.apply(this, arguments);
      }

      return merge;
    }()
    /**
     * Delete records from the recycle bin immediately
     */

  }, {
    key: "emptyRecycleBin",
    value: function () {
      var _emptyRecycleBin = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(ids) {
        return _regeneratorRuntime.wrap(function _callee4$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                return _context7.abrupt("return", this._invoke('emptyRecycleBin', {
                  ids: ids
                }, [ApiSchemas.EmptyRecycleBinResult]));

              case 1:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee4, this);
      }));

      function emptyRecycleBin(_x6) {
        return _emptyRecycleBin.apply(this, arguments);
      }

      return emptyRecycleBin;
    }()
    /**
     * Returns information about the standard and custom apps available to the logged-in user
     */

  }, {
    key: "describeTabs",
    value: function () {
      var _describeTabs = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        return _regeneratorRuntime.wrap(function _callee5$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                return _context8.abrupt("return", this._invoke('describeTabs', {}, [ApiSchemas.DescribeTabSetResult]));

              case 1:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee5, this);
      }));

      function describeTabs() {
        return _describeTabs.apply(this, arguments);
      }

      return describeTabs;
    }()
    /**
     * Retrieves the current system timestamp (Coordinated Universal Time (UTC) time zone) from the API
     */

  }, {
    key: "getServerTimestamp",
    value: function () {
      var _getServerTimestamp = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
        return _regeneratorRuntime.wrap(function _callee6$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                return _context9.abrupt("return", this._invoke('getServerTimestamp', {}, ApiSchemas.GetServerTimestampResult));

              case 1:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee6, this);
      }));

      function getServerTimestamp() {
        return _getServerTimestamp.apply(this, arguments);
      }

      return getServerTimestamp;
    }()
    /**
     * Retrieves personal information for the user associated with the current session
     */

  }, {
    key: "getUserInfo",
    value: function () {
      var _getUserInfo = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7() {
        return _regeneratorRuntime.wrap(function _callee7$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                return _context10.abrupt("return", this._invoke('getUserInfo', {}, ApiSchemas.GetUserInfoResult));

              case 1:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee7, this);
      }));

      function getUserInfo() {
        return _getUserInfo.apply(this, arguments);
      }

      return getUserInfo;
    }()
    /**
     * Sets the specified user’s password to the specified value
     */

  }, {
    key: "setPassword",
    value: function setPassword(userId, password) {
      return this._invoke('setPassword', {
        userId: userId,
        password: password
      }, 'string');
    }
    /**
     * Resets the specified user’s password
     */

  }, {
    key: "resetPassword",
    value: function resetPassword(userId) {
      return this._invoke('resetPassword', {
        userId: userId
      }, ApiSchemas.ResetPasswordResult);
    }
    /**
     * Adds one or more new records to your organization’s data
     */

  }, {
    key: "create",
    value: function create(sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('create', args, schema);
    }
    /**
     * Updates one or more existing records in your organization’s data.
     */

  }, {
    key: "update",
    value: function update(sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('update', args, schema);
    }
    /**
     * Creates new records and updates existing records in your organization’s data.
     */

  }, {
    key: "upsert",
    value: function upsert(externalIdFieldName, sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.UpsertResult] : ApiSchemas.UpsertResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:externalIDFieldName': externalIdFieldName,
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('upsert', args, schema);
    }
    /**
     * Deletes one or more records from your organization’s data
     */

  }, {
    key: "delete",
    value: function _delete(ids) {
      var schema = _Array$isArray(ids) ? [ApiSchemas.DeleteResult] : ApiSchemas.DeleteResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:ids': ids
      };
      return this._invoke('delete', args, schema);
    }
  }]);

  return SoapApi;
}();
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('soap', function (conn) {
  return new SoapApi(conn);
});
export default SoapApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvc29hcC50cyJdLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsIlNPQVAiLCJBcGlTY2hlbWFzIiwidG9Tb2FwUmVjb3JkIiwicmVjb3JkcyIsInJlY29yZCIsInR5cGUiLCJhdHRyaWJ1dGVzIiwicmVjIiwidCIsIkVycm9yIiwiZmllbGRzVG9OdWxsIiwiZmllbGQiLCJsZW5ndGgiLCJTb2FwQXBpIiwiY29ubiIsIl9jb25uIiwibWV0aG9kIiwibWVzc2FnZSIsInNjaGVtYSIsInNvYXBFbmRwb2ludCIsInhtbG5zIiwiZW5kcG9pbnRVcmwiLCJpbnN0YW5jZVVybCIsInZlcnNpb24iLCJpbnZva2UiLCJyZXN1bHQiLCJ1bmRlZmluZWQiLCJyZXMiLCJsZWFkQ29udmVydHMiLCJMZWFkQ29udmVydFJlc3VsdCIsIl9pbnZva2UiLCJtZXJnZVJlcXVlc3RzIiwiTWVyZ2VSZXN1bHQiLCJpZHMiLCJFbXB0eVJlY3ljbGVCaW5SZXN1bHQiLCJEZXNjcmliZVRhYlNldFJlc3VsdCIsIkdldFNlcnZlclRpbWVzdGFtcFJlc3VsdCIsIkdldFVzZXJJbmZvUmVzdWx0IiwidXNlcklkIiwicGFzc3dvcmQiLCJSZXNldFBhc3N3b3JkUmVzdWx0Iiwic09iamVjdHMiLCJTYXZlUmVzdWx0IiwiYXJncyIsImV4dGVybmFsSWRGaWVsZE5hbWUiLCJVcHNlcnRSZXN1bHQiLCJEZWxldGVSZXN1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLGNBQVQsUUFBK0IsWUFBL0I7QUFFQSxPQUFPQyxJQUFQLE1BQWlCLFNBQWpCO0FBRUEsU0FDRUMsVUFERixRQWNPLGVBZFA7QUFnQkE7QUFDQTtBQUNBOztBQUNBLFNBQVNDLFlBQVQsQ0FBc0JDLE9BQXRCLEVBQXFFO0FBQUE7O0FBQ25FLFNBQU8sZ0NBQUMsZUFBY0EsT0FBZCxJQUF5QkEsT0FBekIsR0FBbUMsQ0FBQ0EsT0FBRCxDQUFwQyxpQkFBbUQsVUFBQ0MsTUFBRCxFQUFZO0FBQUE7O0FBQUEsUUFDNURDLElBRDRELEdBQy9CRCxNQUQrQixDQUM1REMsSUFENEQ7QUFBQSxRQUN0REMsVUFEc0QsR0FDL0JGLE1BRCtCLENBQ3RERSxVQURzRDtBQUFBLFFBQ3ZDQyxHQUR1Qyw0QkFDL0JILE1BRCtCOztBQUVwRSxRQUFNSSxDQUFDLEdBQUdILElBQUksS0FBSUMsVUFBSixhQUFJQSxVQUFKLHVCQUFJQSxVQUFVLENBQUVELElBQWhCLENBQWQ7O0FBQ0EsUUFBSSxDQUFDRyxDQUFMLEVBQVE7QUFDTixZQUFNLElBQUlDLEtBQUosQ0FBVSx3REFBVixDQUFOO0FBQ0Q7O0FBQ0QsUUFBTUMsWUFBWSxHQUFHLGlEQUFZSCxHQUFaLG1CQUNuQixVQUFDSSxLQUFEO0FBQUEsYUFBV1AsTUFBTSxDQUFDTyxLQUFELENBQU4sS0FBa0IsSUFBN0I7QUFBQSxLQURtQixDQUFyQjs7QUFOb0UsK0NBU2hERCxZQVRnRDtBQUFBOztBQUFBO0FBU3BFLDBEQUFrQztBQUFBLFlBQXZCQyxLQUF1QjtBQUNoQyxlQUFPSixHQUFHLENBQUNJLEtBQUQsQ0FBVjtBQUNEO0FBWG1FO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBWXBFLFdBQU9ELFlBQVksQ0FBQ0UsTUFBYixHQUFzQixDQUF0QjtBQUNEUCxNQUFBQSxJQUFJLEVBQUVHLENBREw7QUFDUUUsTUFBQUEsWUFBWSxFQUFaQTtBQURSLE9BQ3lCSCxHQUR6QjtBQUVERixNQUFBQSxJQUFJLEVBQUVHO0FBRkwsT0FFV0QsR0FGWCxDQUFQO0FBR0QsR0FmTSxDQUFQO0FBZ0JEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxXQUFhTSxPQUFiO0FBR0UsbUJBQVlDLElBQVosRUFBaUM7QUFBQTs7QUFBQTs7QUFDL0IsU0FBS0MsS0FBTCxHQUFhRCxJQUFiO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBVkE7QUFBQTtBQUFBO0FBQUEsK0ZBWUlFLE1BWkosRUFhSUMsT0FiSixFQWNJQyxNQWRKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWdCVUMsZ0JBQUFBLFlBaEJWLEdBZ0J5QixJQUFJbkIsSUFBSixDQUFTLEtBQUtlLEtBQWQsRUFBcUI7QUFDeENLLGtCQUFBQSxLQUFLLEVBQUUsNkJBRGlDO0FBRXhDQyxrQkFBQUEsV0FBVyxnREFBSyxLQUFLTixLQUFMLENBQVdPLFdBQWhCLHdDQUErQyxLQUFLUCxLQUFMLENBQVdRLE9BQTFEO0FBRjZCLGlCQUFyQixDQWhCekI7QUFBQTtBQUFBLHVCQW9Cc0JKLFlBQVksQ0FBQ0ssTUFBYixDQUNoQlIsTUFEZ0IsRUFFaEJDLE9BRmdCLEVBR2hCQyxNQUFNLEdBQUk7QUFBRU8sa0JBQUFBLE1BQU0sRUFBRVA7QUFBVixpQkFBSixHQUF3Q1EsU0FIOUIsRUFJaEJ6QixVQUpnQixDQXBCdEI7O0FBQUE7QUFvQlUwQixnQkFBQUEsR0FwQlY7QUFBQSxrREEwQldBLEdBQUcsQ0FBQ0YsTUExQmY7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE2QkU7QUFDRjtBQUNBOztBQS9CQTtBQUFBO0FBQUE7QUFBQSxvR0F3Q0lHLFlBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTBDVVYsZ0JBQUFBLE1BMUNWLEdBMENtQixlQUFjVSxZQUFkLElBQ1gsQ0FBQzNCLFVBQVUsQ0FBQzRCLGlCQUFaLENBRFcsR0FFWDVCLFVBQVUsQ0FBQzRCLGlCQTVDbkI7QUFBQSxrREE2Q1csS0FBS0MsT0FBTCxDQUFhLGFBQWIsRUFBNEI7QUFBRUYsa0JBQUFBLFlBQVksRUFBWkE7QUFBRixpQkFBNUIsRUFBOENWLE1BQTlDLENBN0NYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZ0RFO0FBQ0Y7QUFDQTs7QUFsREE7QUFBQTtBQUFBO0FBQUEsOEZBd0RjYSxhQXhEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5RFViLGdCQUFBQSxNQXpEVixHQXlEbUIsZUFBY2EsYUFBZCxJQUNYLENBQUM5QixVQUFVLENBQUMrQixXQUFaLENBRFcsR0FFWC9CLFVBQVUsQ0FBQytCLFdBM0RuQjtBQUFBLGtEQTREVyxLQUFLRixPQUFMLENBQWEsT0FBYixFQUFzQjtBQUFFQyxrQkFBQUEsYUFBYSxFQUFiQTtBQUFGLGlCQUF0QixFQUF5Q2IsTUFBekMsQ0E1RFg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUErREU7QUFDRjtBQUNBOztBQWpFQTtBQUFBO0FBQUE7QUFBQSx3R0FrRXdCZSxHQWxFeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtEQW1FVyxLQUFLSCxPQUFMLENBQWEsaUJBQWIsRUFBZ0M7QUFBRUcsa0JBQUFBLEdBQUcsRUFBSEE7QUFBRixpQkFBaEMsRUFBeUMsQ0FDOUNoQyxVQUFVLENBQUNpQyxxQkFEbUMsQ0FBekMsQ0FuRVg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3RUU7QUFDRjtBQUNBOztBQTFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0RBNEVXLEtBQUtKLE9BQUwsQ0FBYSxjQUFiLEVBQTZCLEVBQTdCLEVBQWlDLENBQUM3QixVQUFVLENBQUNrQyxvQkFBWixDQUFqQyxDQTVFWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQStFRTtBQUNGO0FBQ0E7O0FBakZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrREFtRlcsS0FBS0wsT0FBTCxDQUNMLG9CQURLLEVBRUwsRUFGSyxFQUdMN0IsVUFBVSxDQUFDbUMsd0JBSE4sQ0FuRlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUEwRkU7QUFDRjtBQUNBOztBQTVGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbURBOEZXLEtBQUtOLE9BQUwsQ0FBYSxhQUFiLEVBQTRCLEVBQTVCLEVBQWdDN0IsVUFBVSxDQUFDb0MsaUJBQTNDLENBOUZYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaUdFO0FBQ0Y7QUFDQTs7QUFuR0E7QUFBQTtBQUFBLGdDQW9HY0MsTUFwR2QsRUFvRzhCQyxRQXBHOUIsRUFvR2lFO0FBQzdELGFBQU8sS0FBS1QsT0FBTCxDQUFhLGFBQWIsRUFBNEI7QUFBRVEsUUFBQUEsTUFBTSxFQUFOQSxNQUFGO0FBQVVDLFFBQUFBLFFBQVEsRUFBUkE7QUFBVixPQUE1QixFQUFrRCxRQUFsRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBMUdBO0FBQUE7QUFBQSxrQ0EyR2dCRCxNQTNHaEIsRUEyRzhEO0FBQzFELGFBQU8sS0FBS1IsT0FBTCxDQUNMLGVBREssRUFFTDtBQUFFUSxRQUFBQSxNQUFNLEVBQU5BO0FBQUYsT0FGSyxFQUdMckMsVUFBVSxDQUFDdUMsbUJBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBOztBQXJIQTtBQUFBO0FBQUEsMkJBeUhTQyxRQXpIVCxFQXlIc0M7QUFDbEMsVUFBTXZCLE1BQU0sR0FBRyxlQUFjdUIsUUFBZCxJQUNYLENBQUN4QyxVQUFVLENBQUN5QyxVQUFaLENBRFcsR0FFWHpDLFVBQVUsQ0FBQ3lDLFVBRmY7QUFHQSxVQUFNQyxJQUFJLEdBQUc7QUFDWCxrQkFBVSw2QkFEQztBQUVYLHNCQUFjLGlDQUZIO0FBR1gsd0JBQWdCekMsWUFBWSxDQUFDdUMsUUFBRDtBQUhqQixPQUFiO0FBS0EsYUFBTyxLQUFLWCxPQUFMLENBQWEsUUFBYixFQUF1QmEsSUFBdkIsRUFBNkJ6QixNQUE3QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBdklBO0FBQUE7QUFBQSwyQkEySVN1QixRQTNJVCxFQTJJc0M7QUFDbEMsVUFBTXZCLE1BQU0sR0FBRyxlQUFjdUIsUUFBZCxJQUNYLENBQUN4QyxVQUFVLENBQUN5QyxVQUFaLENBRFcsR0FFWHpDLFVBQVUsQ0FBQ3lDLFVBRmY7QUFHQSxVQUFNQyxJQUFJLEdBQUc7QUFDWCxrQkFBVSw2QkFEQztBQUVYLHNCQUFjLGlDQUZIO0FBR1gsd0JBQWdCekMsWUFBWSxDQUFDdUMsUUFBRDtBQUhqQixPQUFiO0FBS0EsYUFBTyxLQUFLWCxPQUFMLENBQWEsUUFBYixFQUF1QmEsSUFBdkIsRUFBNkJ6QixNQUE3QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBekpBO0FBQUE7QUFBQSwyQkFtS1MwQixtQkFuS1QsRUFtS3NDSCxRQW5LdEMsRUFtS21FO0FBQy9ELFVBQU12QixNQUFNLEdBQUcsZUFBY3VCLFFBQWQsSUFDWCxDQUFDeEMsVUFBVSxDQUFDNEMsWUFBWixDQURXLEdBRVg1QyxVQUFVLENBQUM0QyxZQUZmO0FBR0EsVUFBTUYsSUFBSSxHQUFHO0FBQ1gsa0JBQVUsNkJBREM7QUFFWCxzQkFBYyxpQ0FGSDtBQUdYLG1DQUEyQkMsbUJBSGhCO0FBSVgsd0JBQWdCMUMsWUFBWSxDQUFDdUMsUUFBRDtBQUpqQixPQUFiO0FBTUEsYUFBTyxLQUFLWCxPQUFMLENBQWEsUUFBYixFQUF1QmEsSUFBdkIsRUFBNkJ6QixNQUE3QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbExBO0FBQUE7QUFBQSw0QkFzTFNlLEdBdExULEVBc0xpQztBQUM3QixVQUFNZixNQUFNLEdBQUcsZUFBY2UsR0FBZCxJQUNYLENBQUNoQyxVQUFVLENBQUM2QyxZQUFaLENBRFcsR0FFWDdDLFVBQVUsQ0FBQzZDLFlBRmY7QUFHQSxVQUFNSCxJQUFJLEdBQUc7QUFDWCxrQkFBVSw2QkFEQztBQUVYLHNCQUFjLGlDQUZIO0FBR1gsbUJBQVdWO0FBSEEsT0FBYjtBQUtBLGFBQU8sS0FBS0gsT0FBTCxDQUFhLFFBQWIsRUFBdUJhLElBQXZCLEVBQTZCekIsTUFBN0IsQ0FBUDtBQUNEO0FBaE1IOztBQUFBO0FBQUE7QUFtTUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBbkIsY0FBYyxDQUFDLE1BQUQsRUFBUyxVQUFDZSxJQUFEO0FBQUEsU0FBVSxJQUFJRCxPQUFKLENBQVlDLElBQVosQ0FBVjtBQUFBLENBQVQsQ0FBZDtBQUVBLGVBQWVELE9BQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIFNhbGVzZm9yY2UgU09BUCBBUElcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyByZWdpc3Rlck1vZHVsZSB9IGZyb20gJy4uL2pzZm9yY2UnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgU09BUCBmcm9tICcuLi9zb2FwJztcbmltcG9ydCB7IFNjaGVtYSwgUmVjb3JkLCBTb2FwU2NoZW1hRGVmLCBTb2FwU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgQXBpU2NoZW1hcyxcbiAgTGVhZENvbnZlcnQsXG4gIExlYWRDb252ZXJ0UmVzdWx0LFxuICBNZXJnZVJlcXVlc3QsXG4gIE1lcmdlUmVzdWx0LFxuICBFbXB0eVJlY3ljbGVCaW5SZXN1bHQsXG4gIERlc2NyaWJlVGFiU2V0UmVzdWx0LFxuICBHZXRTZXJ2ZXJUaW1lc3RhbXBSZXN1bHQsXG4gIEdldFVzZXJJbmZvUmVzdWx0LFxuICBSZXNldFBhc3N3b3JkUmVzdWx0LFxuICBTYXZlUmVzdWx0LFxuICBVcHNlcnRSZXN1bHQsXG4gIERlbGV0ZVJlc3VsdCxcbn0gZnJvbSAnLi9zb2FwL3NjaGVtYSc7XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gdG9Tb2FwUmVjb3JkKHJlY29yZHM6IFJlY29yZCB8IFJlY29yZFtdKTogUmVjb3JkIHwgUmVjb3JkW10ge1xuICByZXR1cm4gKEFycmF5LmlzQXJyYXkocmVjb3JkcykgPyByZWNvcmRzIDogW3JlY29yZHNdKS5tYXAoKHJlY29yZCkgPT4ge1xuICAgIGNvbnN0IHsgdHlwZSwgYXR0cmlidXRlcywgLi4ucmVjIH0gPSByZWNvcmQ7XG4gICAgY29uc3QgdCA9IHR5cGUgfHwgYXR0cmlidXRlcz8udHlwZTtcbiAgICBpZiAoIXQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignR2l2ZW4gcmVjb3JkIGlzIG5vdCBpbmNsdWRpbmcgc09iamVjdCB0eXBlIGluZm9ybWF0aW9uJyk7XG4gICAgfVxuICAgIGNvbnN0IGZpZWxkc1RvTnVsbCA9IE9iamVjdC5rZXlzKHJlYykuZmlsdGVyKFxuICAgICAgKGZpZWxkKSA9PiByZWNvcmRbZmllbGRdID09PSBudWxsLFxuICAgICk7XG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBmaWVsZHNUb051bGwpIHtcbiAgICAgIGRlbGV0ZSByZWNbZmllbGRdO1xuICAgIH1cbiAgICByZXR1cm4gZmllbGRzVG9OdWxsLmxlbmd0aCA+IDBcbiAgICAgID8geyB0eXBlOiB0LCBmaWVsZHNUb051bGwsIC4uLnJlYyB9XG4gICAgICA6IHsgdHlwZTogdCwgLi4ucmVjIH07XG4gIH0pO1xufVxuXG4vKipcbiAqIEFQSSBjbGFzcyBmb3IgUGFydG5lciBTT0FQIGNhbGxcbiAqL1xuZXhwb3J0IGNsYXNzIFNvYXBBcGk8UyBleHRlbmRzIFNjaGVtYT4ge1xuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcblxuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBTT0FQIEFwaSAoUGFydG5lcikgZW5kcG9pbnRcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIF9pbnZva2UoXG4gICAgbWV0aG9kOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogb2JqZWN0LFxuICAgIHNjaGVtYTogU29hcFNjaGVtYSB8IFNvYXBTY2hlbWFEZWYsXG4gICkge1xuICAgIGNvbnN0IHNvYXBFbmRwb2ludCA9IG5ldyBTT0FQKHRoaXMuX2Nvbm4sIHtcbiAgICAgIHhtbG5zOiAndXJuOnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgIGVuZHBvaW50VXJsOiBgJHt0aGlzLl9jb25uLmluc3RhbmNlVXJsfS9zZXJ2aWNlcy9Tb2FwL3UvJHt0aGlzLl9jb25uLnZlcnNpb259YCxcbiAgICB9KTtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBzb2FwRW5kcG9pbnQuaW52b2tlKFxuICAgICAgbWV0aG9kLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHNjaGVtYSA/ICh7IHJlc3VsdDogc2NoZW1hIH0gYXMgU29hcFNjaGVtYSkgOiB1bmRlZmluZWQsXG4gICAgICBBcGlTY2hlbWFzLFxuICAgICk7XG4gICAgcmV0dXJuIHJlcy5yZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogQ29udmVydHMgYSBMZWFkIGludG8gYW4gQWNjb3VudCwgQ29udGFjdCwgb3IgKG9wdGlvbmFsbHkpIGFuIE9wcG9ydHVuaXR5LlxuICAgKi9cbiAgY29udmVydExlYWQoXG4gICAgbGVhZENvbnZlcnRzOiBQYXJ0aWFsPExlYWRDb252ZXJ0PltdLFxuICApOiBQcm9taXNlPExlYWRDb252ZXJ0UmVzdWx0W10+O1xuICBjb252ZXJ0TGVhZChsZWFkQ29udmVydDogUGFydGlhbDxMZWFkQ29udmVydD4pOiBQcm9taXNlPExlYWRDb252ZXJ0UmVzdWx0PjtcbiAgY29udmVydExlYWQoXG4gICAgbGVhZENvbnZlcnQ6IFBhcnRpYWw8TGVhZENvbnZlcnQ+IHwgUGFydGlhbDxMZWFkQ29udmVydD5bXSxcbiAgKTogUHJvbWlzZTxMZWFkQ29udmVydFJlc3VsdCB8IExlYWRDb252ZXJ0UmVzdWx0W10+O1xuICBhc3luYyBjb252ZXJ0TGVhZChcbiAgICBsZWFkQ29udmVydHM6IFBhcnRpYWw8TGVhZENvbnZlcnQ+IHwgUGFydGlhbDxMZWFkQ29udmVydD5bXSxcbiAgKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShsZWFkQ29udmVydHMpXG4gICAgICA/IFtBcGlTY2hlbWFzLkxlYWRDb252ZXJ0UmVzdWx0XVxuICAgICAgOiBBcGlTY2hlbWFzLkxlYWRDb252ZXJ0UmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ2NvbnZlcnRMZWFkJywgeyBsZWFkQ29udmVydHMgfSwgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNZXJnZSB1cCB0byB0aHJlZSByZWNvcmRzIGludG8gb25lXG4gICAqL1xuICBtZXJnZShtZXJnZVJlcXVlc3RzOiBQYXJ0aWFsPE1lcmdlUmVxdWVzdD5bXSk6IFByb21pc2U8TWVyZ2VSZXN1bHRbXT47XG4gIG1lcmdlKG1lcmdlUmVxdWVzdDogUGFydGlhbDxNZXJnZVJlcXVlc3Q+KTogUHJvbWlzZTxNZXJnZVJlc3VsdD47XG4gIG1lcmdlKFxuICAgIG1lcmdlUmVxdWVzdDogUGFydGlhbDxNZXJnZVJlcXVlc3Q+IHwgUGFydGlhbDxNZXJnZVJlcXVlc3Q+W10sXG4gICk6IFByb21pc2U8TWVyZ2VSZXN1bHQgfCBNZXJnZVJlc3VsdFtdPjtcbiAgYXN5bmMgbWVyZ2UobWVyZ2VSZXF1ZXN0czogUGFydGlhbDxNZXJnZVJlcXVlc3Q+IHwgUGFydGlhbDxNZXJnZVJlcXVlc3Q+W10pIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KG1lcmdlUmVxdWVzdHMpXG4gICAgICA/IFtBcGlTY2hlbWFzLk1lcmdlUmVzdWx0XVxuICAgICAgOiBBcGlTY2hlbWFzLk1lcmdlUmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ21lcmdlJywgeyBtZXJnZVJlcXVlc3RzIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogRGVsZXRlIHJlY29yZHMgZnJvbSB0aGUgcmVjeWNsZSBiaW4gaW1tZWRpYXRlbHlcbiAgICovXG4gIGFzeW5jIGVtcHR5UmVjeWNsZUJpbihpZHM6IHN0cmluZ1tdKTogUHJvbWlzZTxFbXB0eVJlY3ljbGVCaW5SZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdlbXB0eVJlY3ljbGVCaW4nLCB7IGlkcyB9LCBbXG4gICAgICBBcGlTY2hlbWFzLkVtcHR5UmVjeWNsZUJpblJlc3VsdCxcbiAgICBdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGluZm9ybWF0aW9uIGFib3V0IHRoZSBzdGFuZGFyZCBhbmQgY3VzdG9tIGFwcHMgYXZhaWxhYmxlIHRvIHRoZSBsb2dnZWQtaW4gdXNlclxuICAgKi9cbiAgYXN5bmMgZGVzY3JpYmVUYWJzKCk6IFByb21pc2U8RGVzY3JpYmVUYWJTZXRSZXN1bHRbXT4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ2Rlc2NyaWJlVGFicycsIHt9LCBbQXBpU2NoZW1hcy5EZXNjcmliZVRhYlNldFJlc3VsdF0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyB0aGUgY3VycmVudCBzeXN0ZW0gdGltZXN0YW1wIChDb29yZGluYXRlZCBVbml2ZXJzYWwgVGltZSAoVVRDKSB0aW1lIHpvbmUpIGZyb20gdGhlIEFQSVxuICAgKi9cbiAgYXN5bmMgZ2V0U2VydmVyVGltZXN0YW1wKCk6IFByb21pc2U8R2V0U2VydmVyVGltZXN0YW1wUmVzdWx0PiB7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZShcbiAgICAgICdnZXRTZXJ2ZXJUaW1lc3RhbXAnLFxuICAgICAge30sXG4gICAgICBBcGlTY2hlbWFzLkdldFNlcnZlclRpbWVzdGFtcFJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBwZXJzb25hbCBpbmZvcm1hdGlvbiBmb3IgdGhlIHVzZXIgYXNzb2NpYXRlZCB3aXRoIHRoZSBjdXJyZW50IHNlc3Npb25cbiAgICovXG4gIGFzeW5jIGdldFVzZXJJbmZvKCk6IFByb21pc2U8R2V0VXNlckluZm9SZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdnZXRVc2VySW5mbycsIHt9LCBBcGlTY2hlbWFzLkdldFVzZXJJbmZvUmVzdWx0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBzcGVjaWZpZWQgdXNlcuKAmXMgcGFzc3dvcmQgdG8gdGhlIHNwZWNpZmllZCB2YWx1ZVxuICAgKi9cbiAgc2V0UGFzc3dvcmQodXNlcklkOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3NldFBhc3N3b3JkJywgeyB1c2VySWQsIHBhc3N3b3JkIH0sICdzdHJpbmcnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXNldHMgdGhlIHNwZWNpZmllZCB1c2Vy4oCZcyBwYXNzd29yZFxuICAgKi9cbiAgcmVzZXRQYXNzd29yZCh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8UmVzZXRQYXNzd29yZFJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAncmVzZXRQYXNzd29yZCcsXG4gICAgICB7IHVzZXJJZCB9LFxuICAgICAgQXBpU2NoZW1hcy5SZXNldFBhc3N3b3JkUmVzdWx0LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBvbmUgb3IgbW9yZSBuZXcgcmVjb3JkcyB0byB5b3VyIG9yZ2FuaXphdGlvbuKAmXMgZGF0YVxuICAgKi9cbiAgY3JlYXRlKHNPYmplY3Q6IFJlY29yZFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICBjcmVhdGUoc09iamVjdDogUmVjb3JkKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgY3JlYXRlKHNPYmplY3RzOiBSZWNvcmQgfCBSZWNvcmRbXSk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIGNyZWF0ZShzT2JqZWN0czogUmVjb3JkIHwgUmVjb3JkW10pIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KHNPYmplY3RzKVxuICAgICAgPyBbQXBpU2NoZW1hcy5TYXZlUmVzdWx0XVxuICAgICAgOiBBcGlTY2hlbWFzLlNhdmVSZXN1bHQ7XG4gICAgY29uc3QgYXJncyA9IHtcbiAgICAgICdAeG1sbnMnOiAndXJuOnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgICdAeG1sbnM6bnMxJzogJ3NvYmplY3QucGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgJ25zMTpzT2JqZWN0cyc6IHRvU29hcFJlY29yZChzT2JqZWN0cyksXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdjcmVhdGUnLCBhcmdzLCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgb25lIG9yIG1vcmUgZXhpc3RpbmcgcmVjb3JkcyBpbiB5b3VyIG9yZ2FuaXphdGlvbuKAmXMgZGF0YS5cbiAgICovXG4gIHVwZGF0ZShzT2JqZWN0OiBSZWNvcmRbXSk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlKHNPYmplY3Q6IFJlY29yZCk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIHVwZGF0ZShzT2JqZWN0czogUmVjb3JkIHwgUmVjb3JkW10pOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICB1cGRhdGUoc09iamVjdHM6IFJlY29yZCB8IFJlY29yZFtdKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShzT2JqZWN0cylcbiAgICAgID8gW0FwaVNjaGVtYXMuU2F2ZVJlc3VsdF1cbiAgICAgIDogQXBpU2NoZW1hcy5TYXZlUmVzdWx0O1xuICAgIGNvbnN0IGFyZ3MgPSB7XG4gICAgICAnQHhtbG5zJzogJ3VybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnQHhtbG5zOm5zMSc6ICdzb2JqZWN0LnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgICduczE6c09iamVjdHMnOiB0b1NvYXBSZWNvcmQoc09iamVjdHMpLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgndXBkYXRlJywgYXJncywgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIG5ldyByZWNvcmRzIGFuZCB1cGRhdGVzIGV4aXN0aW5nIHJlY29yZHMgaW4geW91ciBvcmdhbml6YXRpb27igJlzIGRhdGEuXG4gICAqL1xuICB1cHNlcnQoXG4gICAgZXh0ZXJuYWxJZEZpZWxkTmFtZTogc3RyaW5nLFxuICAgIHNPYmplY3RzOiBSZWNvcmRbXSxcbiAgKTogUHJvbWlzZTxVcHNlcnRSZXN1bHRbXT47XG4gIHVwc2VydChleHRlcm5hbElkRmllbGROYW1lOiBzdHJpbmcsIHNPYmplY3Q6IFJlY29yZCk6IFByb21pc2U8VXBzZXJ0UmVzdWx0PjtcbiAgdXBzZXJ0KFxuICAgIGV4dGVybmFsSWRGaWVsZE5hbWU6IHN0cmluZyxcbiAgICBzT2JqZWN0czogUmVjb3JkIHwgUmVjb3JkW10sXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0IHwgVXBzZXJ0UmVzdWx0W10+O1xuICB1cHNlcnQoZXh0ZXJuYWxJZEZpZWxkTmFtZTogc3RyaW5nLCBzT2JqZWN0czogUmVjb3JkIHwgUmVjb3JkW10pIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KHNPYmplY3RzKVxuICAgICAgPyBbQXBpU2NoZW1hcy5VcHNlcnRSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuVXBzZXJ0UmVzdWx0O1xuICAgIGNvbnN0IGFyZ3MgPSB7XG4gICAgICAnQHhtbG5zJzogJ3VybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnQHhtbG5zOm5zMSc6ICdzb2JqZWN0LnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgICduczE6ZXh0ZXJuYWxJREZpZWxkTmFtZSc6IGV4dGVybmFsSWRGaWVsZE5hbWUsXG4gICAgICAnbnMxOnNPYmplY3RzJzogdG9Tb2FwUmVjb3JkKHNPYmplY3RzKSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3Vwc2VydCcsIGFyZ3MsIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogRGVsZXRlcyBvbmUgb3IgbW9yZSByZWNvcmRzIGZyb20geW91ciBvcmdhbml6YXRpb27igJlzIGRhdGFcbiAgICovXG4gIGRlbGV0ZShpZHM6IHN0cmluZyB8IHN0cmluZ1tdKTogUHJvbWlzZTxEZWxldGVSZXN1bHRbXT47XG4gIGRlbGV0ZShpZDogc3RyaW5nKTogUHJvbWlzZTxEZWxldGVSZXN1bHQ+O1xuICBkZWxldGUoaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSk6IFByb21pc2U8RGVsZXRlUmVzdWx0IHwgRGVsZXRlUmVzdWx0W10+O1xuICBkZWxldGUoaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSkge1xuICAgIGNvbnN0IHNjaGVtYSA9IEFycmF5LmlzQXJyYXkoaWRzKVxuICAgICAgPyBbQXBpU2NoZW1hcy5EZWxldGVSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuRGVsZXRlUmVzdWx0O1xuICAgIGNvbnN0IGFyZ3MgPSB7XG4gICAgICAnQHhtbG5zJzogJ3VybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnQHhtbG5zOm5zMSc6ICdzb2JqZWN0LnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgICduczE6aWRzJzogaWRzLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnZGVsZXRlJywgYXJncywgc2NoZW1hKTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qXG4gKiBSZWdpc3RlciBob29rIGluIGNvbm5lY3Rpb24gaW5zdGFudGlhdGlvbiBmb3IgZHluYW1pY2FsbHkgYWRkaW5nIHRoaXMgQVBJIG1vZHVsZSBmZWF0dXJlc1xuICovXG5yZWdpc3Rlck1vZHVsZSgnc29hcCcsIChjb25uKSA9PiBuZXcgU29hcEFwaShjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IFNvYXBBcGk7XG4iXX0=