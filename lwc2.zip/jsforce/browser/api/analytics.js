import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.join";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; _forEachInstanceProperty(_context = ownKeys(Object(source), true)).call(_context, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source))).call(_context2, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Analytics API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import { ReportMetadata, ReportExecuteResult, ReportRetrieveResult, ReportDescribeResult, ReportInfo, ReportInstanceInfo, DashboardMetadata, DashboardResult, DashboardStatusResult, DashboardRefreshResult, DashboardInfo } from './analytics/types';

/*----------------------------------------------------------------------------------*/
export { ReportMetadata, ReportExecuteResult, ReportRetrieveResult, ReportDescribeResult, ReportInfo, ReportInstanceInfo, DashboardMetadata, DashboardResult, DashboardStatusResult, DashboardRefreshResult, DashboardInfo };

/*----------------------------------------------------------------------------------*/

/**
 * Report object class in Analytics API
 */
export var ReportInstance = /*#__PURE__*/function () {
  /**
   *
   */
  function ReportInstance(report, id) {
    _classCallCheck(this, ReportInstance);

    _defineProperty(this, "_report", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    this._report = report;
    this._conn = report._conn;
    this.id = id;
  }
  /**
   * Retrieve report result asynchronously executed
   */


  _createClass(ReportInstance, [{
    key: "retrieve",
    value: function retrieve() {
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this._report.id, 'instances', this.id].join('/');
      return this._conn.request(url);
    }
  }]);

  return ReportInstance;
}();
/*----------------------------------------------------------------------------------*/

/**
 * Report object class in Analytics API
 */

export var Report = /*#__PURE__*/function () {
  /**
   *
   */
  function Report(conn, id) {
    _classCallCheck(this, Report);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    _defineProperty(this, "run", this.execute);

    _defineProperty(this, "exec", this.execute);

    this._conn = conn;
    this.id = id;
  }
  /**
   * Describe report metadata
   */


  _createClass(Report, [{
    key: "describe",
    value: function describe() {
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'describe'].join('/');
      return this._conn.request(url);
    }
    /**
     * Destroy a report
     */

  }, {
    key: "destroy",
    value: function destroy() {
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id].join('/');
      return this._conn.request({
        method: 'DELETE',
        url: url
      });
    }
    /**
     * Synonym of Analytics~Report#destroy()
     */

  }, {
    key: "clone",

    /**
     * Clones a given report
     */
    value: function clone(name) {
      var url = [this._conn._baseUrl(), 'analytics', 'reports'].join('/') + '?cloneId=' + this.id;
      var config = {
        reportMetadata: {
          name: name
        }
      };
      return this._conn.request({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/json'
        },
        body: _JSON$stringify(config)
      });
    }
    /**
     * Explain plan for executing report
     */

  }, {
    key: "explain",
    value: function explain() {
      var url = '/query/?explain=' + this.id;
      return this._conn.request(url);
    }
    /**
     * Run report synchronously
     */

  }, {
    key: "execute",
    value: function execute() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id].join('/') + '?includeDetails=' + (options.details ? 'true' : 'false');
      return this._conn.request(_objectSpread({
        url: url
      }, options.metadata ? {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: _JSON$stringify(options.metadata)
      } : {
        method: 'GET'
      }));
    }
    /**
     * Synonym of Analytics~Report#execute()
     */

  }, {
    key: "executeAsync",

    /**
     * Run report asynchronously
     */
    value: function executeAsync() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'instances'].join('/') + (options.details ? '?includeDetails=true' : '');
      return this._conn.request(_objectSpread({
        method: 'POST',
        url: url
      }, options.metadata ? {
        headers: {
          'Content-Type': 'application/json'
        },
        body: _JSON$stringify(options.metadata)
      } : {
        body: ''
      }));
    }
    /**
     * Get report instance for specified instance ID
     */

  }, {
    key: "instance",
    value: function instance(id) {
      return new ReportInstance(this, id);
    }
    /**
     * List report instances which had been executed asynchronously
     */

  }, {
    key: "instances",
    value: function instances() {
      var url = [this._conn._baseUrl(), 'analytics', 'reports', this.id, 'instances'].join('/');
      return this._conn.request(url);
    }
  }]);

  return Report;
}();
/*----------------------------------------------------------------------------------*/

/**
 * Dashboard object class in the Analytics API
 */

export var Dashboard = /*#__PURE__*/function () {
  /**
   *
   */
  function Dashboard(conn, id) {
    _classCallCheck(this, Dashboard);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    this._conn = conn;
    this.id = id;
  }
  /**
   * Describe dashboard metadata
   *
   * @method Analytics~Dashboard#describe
   * @param {Callback.<Analytics-DashboardMetadata>} [callback] - Callback function
   * @returns {Promise.<Analytics-DashboardMetadata>}
   */


  _createClass(Dashboard, [{
    key: "describe",
    value: function describe() {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id, 'describe'].join('/');
      return this._conn.request(url);
    }
    /**
     * Get details about dashboard components
     */

  }, {
    key: "components",
    value: function components(componentIds) {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
      var config = {
        componentIds: _Array$isArray(componentIds) ? componentIds : typeof componentIds === 'string' ? [componentIds] : undefined
      };
      return this._conn.request({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/json'
        },
        body: _JSON$stringify(config)
      });
    }
    /**
     * Get dashboard status
     */

  }, {
    key: "status",
    value: function status() {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id, 'status'].join('/');
      return this._conn.request(url);
    }
    /**
     * Refresh a dashboard
     */

  }, {
    key: "refresh",
    value: function refresh() {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
      return this._conn.request({
        method: 'PUT',
        url: url,
        body: ''
      });
    }
    /**
     * Clone a dashboard
     */

  }, {
    key: "clone",
    value: function clone(config, folderId) {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards'].join('/') + '?cloneId=' + this.id;

      if (typeof config === 'string') {
        config = {
          name: config,
          folderId: folderId
        };
      }

      return this._conn.request({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/json'
        },
        body: _JSON$stringify(config)
      });
    }
    /**
     * Destroy a dashboard
     */

  }, {
    key: "destroy",
    value: function destroy() {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards', this.id].join('/');
      return this._conn.request({
        method: 'DELETE',
        url: url
      });
    }
    /**
     * Synonym of Analytics~Dashboard#destroy()
     */

  }]);

  return Dashboard;
}();
/*----------------------------------------------------------------------------------*/

/**
 * API class for Analytics API
 */

export var Analytics = /*#__PURE__*/function () {
  /**
   *
   */
  function Analytics(conn) {
    _classCallCheck(this, Analytics);

    _defineProperty(this, "_conn", void 0);

    this._conn = conn;
  }
  /**
   * Get report object of Analytics API
   */


  _createClass(Analytics, [{
    key: "report",
    value: function report(id) {
      return new Report(this._conn, id);
    }
    /**
     * Get recent report list
     */

  }, {
    key: "reports",
    value: function reports() {
      var url = [this._conn._baseUrl(), 'analytics', 'reports'].join('/');
      return this._conn.request(url);
    }
    /**
     * Get dashboard object of Analytics API
     */

  }, {
    key: "dashboard",
    value: function dashboard(id) {
      return new Dashboard(this._conn, id);
    }
    /**
     * Get recent dashboard list
     */

  }, {
    key: "dashboards",
    value: function dashboards() {
      var url = [this._conn._baseUrl(), 'analytics', 'dashboards'].join('/');
      return this._conn.request(url);
    }
  }]);

  return Analytics;
}();
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('analytics', function (conn) {
  return new Analytics(conn);
});
export default Analytics;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYW5hbHl0aWNzLnRzIl0sIm5hbWVzIjpbInJlZ2lzdGVyTW9kdWxlIiwiUmVwb3J0TWV0YWRhdGEiLCJSZXBvcnRFeGVjdXRlUmVzdWx0IiwiUmVwb3J0UmV0cmlldmVSZXN1bHQiLCJSZXBvcnREZXNjcmliZVJlc3VsdCIsIlJlcG9ydEluZm8iLCJSZXBvcnRJbnN0YW5jZUluZm8iLCJEYXNoYm9hcmRNZXRhZGF0YSIsIkRhc2hib2FyZFJlc3VsdCIsIkRhc2hib2FyZFN0YXR1c1Jlc3VsdCIsIkRhc2hib2FyZFJlZnJlc2hSZXN1bHQiLCJEYXNoYm9hcmRJbmZvIiwiUmVwb3J0SW5zdGFuY2UiLCJyZXBvcnQiLCJpZCIsIl9yZXBvcnQiLCJfY29ubiIsInVybCIsIl9iYXNlVXJsIiwiam9pbiIsInJlcXVlc3QiLCJSZXBvcnQiLCJjb25uIiwiZGVzdHJveSIsImV4ZWN1dGUiLCJtZXRob2QiLCJuYW1lIiwiY29uZmlnIiwicmVwb3J0TWV0YWRhdGEiLCJoZWFkZXJzIiwiYm9keSIsIm9wdGlvbnMiLCJkZXRhaWxzIiwibWV0YWRhdGEiLCJEYXNoYm9hcmQiLCJjb21wb25lbnRJZHMiLCJ1bmRlZmluZWQiLCJmb2xkZXJJZCIsIkFuYWx5dGljcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsY0FBVCxRQUErQixZQUEvQjtBQUdBLFNBQ0VDLGNBREYsRUFFRUMsbUJBRkYsRUFHRUMsb0JBSEYsRUFJRUMsb0JBSkYsRUFLRUMsVUFMRixFQU1FQyxrQkFORixFQU9FQyxpQkFQRixFQVFFQyxlQVJGLEVBU0VDLHFCQVRGLEVBVUVDLHNCQVZGLEVBV0VDLGFBWEYsUUFZTyxtQkFaUDs7QUFlQTtBQUNBLFNBQ0VWLGNBREYsRUFFRUMsbUJBRkYsRUFHRUMsb0JBSEYsRUFJRUMsb0JBSkYsRUFLRUMsVUFMRixFQU1FQyxrQkFORixFQU9FQyxpQkFQRixFQVFFQyxlQVJGLEVBU0VDLHFCQVRGLEVBVUVDLHNCQVZGLEVBV0VDLGFBWEY7O0FBcUJBOztBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQWFDLGNBQWI7QUFLRTtBQUNGO0FBQ0E7QUFDRSwwQkFBWUMsTUFBWixFQUErQkMsRUFBL0IsRUFBMkM7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFDekMsU0FBS0MsT0FBTCxHQUFlRixNQUFmO0FBQ0EsU0FBS0csS0FBTCxHQUFhSCxNQUFNLENBQUNHLEtBQXBCO0FBQ0EsU0FBS0YsRUFBTCxHQUFVQSxFQUFWO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQWhCQTtBQUFBO0FBQUEsK0JBaUI0QztBQUN4QyxVQUFNRyxHQUFHLEdBQUcsQ0FDVixLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixTQUhVLEVBSVYsS0FBS0gsT0FBTCxDQUFhRCxFQUpILEVBS1YsV0FMVSxFQU1WLEtBQUtBLEVBTkssRUFPVkssSUFQVSxDQU9MLEdBUEssQ0FBWjtBQVFBLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQXlDSCxHQUF6QyxDQUFQO0FBQ0Q7QUEzQkg7O0FBQUE7QUFBQTtBQThCQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsV0FBYUksTUFBYjtBQUlFO0FBQ0Y7QUFDQTtBQUNFLGtCQUFZQyxJQUFaLEVBQWlDUixFQUFqQyxFQUE2QztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9DQWdDcEMsS0FBS1MsT0FoQytCOztBQUFBLGlDQXFDdkMsS0FBS0EsT0FyQ2tDOztBQUFBLGlDQXVGdkMsS0FBS0MsT0F2RmtDOztBQUFBLGtDQTRGdEMsS0FBS0EsT0E1RmlDOztBQUMzQyxTQUFLUixLQUFMLEdBQWFNLElBQWI7QUFDQSxTQUFLUixFQUFMLEdBQVVBLEVBQVY7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBZEE7QUFBQTtBQUFBLCtCQWU0QztBQUN4QyxVQUFJRyxHQUFHLEdBQUcsQ0FDUixLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFEUSxFQUVSLFdBRlEsRUFHUixTQUhRLEVBSVIsS0FBS0osRUFKRyxFQUtSLFVBTFEsRUFNUkssSUFOUSxDQU1ILEdBTkcsQ0FBVjtBQU9BLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQXlDSCxHQUF6QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBNUJBO0FBQUE7QUFBQSw4QkE2QjJCO0FBQ3ZCLFVBQU1BLEdBQUcsR0FBRyxDQUFDLEtBQUtELEtBQUwsQ0FBV0UsUUFBWCxFQUFELEVBQXdCLFdBQXhCLEVBQXFDLFNBQXJDLEVBQWdELEtBQUtKLEVBQXJELEVBQXlESyxJQUF6RCxDQUNWLEdBRFUsQ0FBWjtBQUdBLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQXlCO0FBQUVLLFFBQUFBLE1BQU0sRUFBRSxRQUFWO0FBQW9CUixRQUFBQSxHQUFHLEVBQUhBO0FBQXBCLE9BQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0Q0E7QUFBQTs7QUE4Q0U7QUFDRjtBQUNBO0FBaERBLDBCQWlEUVMsSUFqRFIsRUFpRHFEO0FBQ2pELFVBQU1ULEdBQUcsR0FDUCxDQUFDLEtBQUtELEtBQUwsQ0FBV0UsUUFBWCxFQUFELEVBQXdCLFdBQXhCLEVBQXFDLFNBQXJDLEVBQWdEQyxJQUFoRCxDQUFxRCxHQUFyRCxJQUNBLFdBREEsR0FFQSxLQUFLTCxFQUhQO0FBSUEsVUFBTWEsTUFBTSxHQUFHO0FBQUVDLFFBQUFBLGNBQWMsRUFBRTtBQUFFRixVQUFBQSxJQUFJLEVBQUpBO0FBQUY7QUFBbEIsT0FBZjtBQUNBLGFBQU8sS0FBS1YsS0FBTCxDQUFXSSxPQUFYLENBQXlDO0FBQzlDSyxRQUFBQSxNQUFNLEVBQUUsTUFEc0M7QUFFOUNSLFFBQUFBLEdBQUcsRUFBSEEsR0FGOEM7QUFHOUNZLFFBQUFBLE9BQU8sRUFBRTtBQUFFLDBCQUFnQjtBQUFsQixTQUhxQztBQUk5Q0MsUUFBQUEsSUFBSSxFQUFFLGdCQUFlSCxNQUFmO0FBSndDLE9BQXpDLENBQVA7QUFNRDtBQUVEO0FBQ0Y7QUFDQTs7QUFqRUE7QUFBQTtBQUFBLDhCQWtFeUM7QUFDckMsVUFBTVYsR0FBRyxHQUFHLHFCQUFxQixLQUFLSCxFQUF0QztBQUNBLGFBQU8sS0FBS0UsS0FBTCxDQUFXSSxPQUFYLENBQXVDSCxHQUF2QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBekVBO0FBQUE7QUFBQSw4QkEwRTRFO0FBQUEsVUFBbEVjLE9BQWtFLHVFQUFsQyxFQUFrQztBQUN4RSxVQUFNZCxHQUFHLEdBQ1AsQ0FBQyxLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxTQUFyQyxFQUFnRCxLQUFLSixFQUFyRCxFQUF5REssSUFBekQsQ0FBOEQsR0FBOUQsSUFDQSxrQkFEQSxJQUVDWSxPQUFPLENBQUNDLE9BQVIsR0FBa0IsTUFBbEIsR0FBMkIsT0FGNUIsQ0FERjtBQUlBLGFBQU8sS0FBS2hCLEtBQUwsQ0FBV0ksT0FBWDtBQUNMSCxRQUFBQSxHQUFHLEVBQUhBO0FBREssU0FFRGMsT0FBTyxDQUFDRSxRQUFSLEdBQ0E7QUFDRVIsUUFBQUEsTUFBTSxFQUFFLE1BRFY7QUFFRUksUUFBQUEsT0FBTyxFQUFFO0FBQUUsMEJBQWdCO0FBQWxCLFNBRlg7QUFHRUMsUUFBQUEsSUFBSSxFQUFFLGdCQUFlQyxPQUFPLENBQUNFLFFBQXZCO0FBSFIsT0FEQSxHQU1BO0FBQUVSLFFBQUFBLE1BQU0sRUFBRTtBQUFWLE9BUkMsRUFBUDtBQVVEO0FBRUQ7QUFDRjtBQUNBOztBQTdGQTtBQUFBOztBQXFHRTtBQUNGO0FBQ0E7QUF2R0EsbUNBMEdpQztBQUFBLFVBRDdCTSxPQUM2Qix1RUFERyxFQUNIO0FBQzdCLFVBQU1kLEdBQUcsR0FDUCxDQUNFLEtBQUtELEtBQUwsQ0FBV0UsUUFBWCxFQURGLEVBRUUsV0FGRixFQUdFLFNBSEYsRUFJRSxLQUFLSixFQUpQLEVBS0UsV0FMRixFQU1FSyxJQU5GLENBTU8sR0FOUCxLQU1lWSxPQUFPLENBQUNDLE9BQVIsR0FBa0Isc0JBQWxCLEdBQTJDLEVBTjFELENBREY7QUFRQSxhQUFPLEtBQUtoQixLQUFMLENBQVdJLE9BQVg7QUFDTEssUUFBQUEsTUFBTSxFQUFFLE1BREg7QUFFTFIsUUFBQUEsR0FBRyxFQUFIQTtBQUZLLFNBR0RjLE9BQU8sQ0FBQ0UsUUFBUixHQUNBO0FBQ0VKLFFBQUFBLE9BQU8sRUFBRTtBQUFFLDBCQUFnQjtBQUFsQixTQURYO0FBRUVDLFFBQUFBLElBQUksRUFBRSxnQkFBZUMsT0FBTyxDQUFDRSxRQUF2QjtBQUZSLE9BREEsR0FLQTtBQUFFSCxRQUFBQSxJQUFJLEVBQUU7QUFBUixPQVJDLEVBQVA7QUFVRDtBQUVEO0FBQ0Y7QUFDQTs7QUFqSUE7QUFBQTtBQUFBLDZCQWtJV2hCLEVBbElYLEVBa0l1QjtBQUNuQixhQUFPLElBQUlGLGNBQUosQ0FBbUIsSUFBbkIsRUFBeUJFLEVBQXpCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF4SUE7QUFBQTtBQUFBLGdDQXlJNkM7QUFDekMsVUFBTUcsR0FBRyxHQUFHLENBQ1YsS0FBS0QsS0FBTCxDQUFXRSxRQUFYLEVBRFUsRUFFVixXQUZVLEVBR1YsU0FIVSxFQUlWLEtBQUtKLEVBSkssRUFLVixXQUxVLEVBTVZLLElBTlUsQ0FNTCxHQU5LLENBQVo7QUFPQSxhQUFPLEtBQUtILEtBQUwsQ0FBV0ksT0FBWCxDQUF5Q0gsR0FBekMsQ0FBUDtBQUNEO0FBbEpIOztBQUFBO0FBQUE7QUFxSkE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQWFpQixTQUFiO0FBSUU7QUFDRjtBQUNBO0FBQ0UscUJBQVlaLElBQVosRUFBaUNSLEVBQWpDLEVBQTZDO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsb0NBcUhwQyxLQUFLUyxPQXJIK0I7O0FBQUEsaUNBMEh2QyxLQUFLQSxPQTFIa0M7O0FBQzNDLFNBQUtQLEtBQUwsR0FBYU0sSUFBYjtBQUNBLFNBQUtSLEVBQUwsR0FBVUEsRUFBVjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQWxCQTtBQUFBO0FBQUEsK0JBbUJ5QztBQUNyQyxVQUFNRyxHQUFHLEdBQUcsQ0FDVixLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixZQUhVLEVBSVYsS0FBS0osRUFKSyxFQUtWLFVBTFUsRUFNVkssSUFOVSxDQU1MLEdBTkssQ0FBWjtBQU9BLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQXNDSCxHQUF0QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBaENBO0FBQUE7QUFBQSwrQkFpQ2FrQixZQWpDYixFQWlDeUU7QUFDckUsVUFBTWxCLEdBQUcsR0FBRyxDQUNWLEtBQUtELEtBQUwsQ0FBV0UsUUFBWCxFQURVLEVBRVYsV0FGVSxFQUdWLFlBSFUsRUFJVixLQUFLSixFQUpLLEVBS1ZLLElBTFUsQ0FLTCxHQUxLLENBQVo7QUFNQSxVQUFNUSxNQUFNLEdBQUc7QUFDYlEsUUFBQUEsWUFBWSxFQUFFLGVBQWNBLFlBQWQsSUFDVkEsWUFEVSxHQUVWLE9BQU9BLFlBQVAsS0FBd0IsUUFBeEIsR0FDQSxDQUFDQSxZQUFELENBREEsR0FFQUM7QUFMUyxPQUFmO0FBT0EsYUFBTyxLQUFLcEIsS0FBTCxDQUFXSSxPQUFYLENBQW9DO0FBQ3pDSyxRQUFBQSxNQUFNLEVBQUUsTUFEaUM7QUFFekNSLFFBQUFBLEdBQUcsRUFBSEEsR0FGeUM7QUFHekNZLFFBQUFBLE9BQU8sRUFBRTtBQUFFLDBCQUFnQjtBQUFsQixTQUhnQztBQUl6Q0MsUUFBQUEsSUFBSSxFQUFFLGdCQUFlSCxNQUFmO0FBSm1DLE9BQXBDLENBQVA7QUFNRDtBQUVEO0FBQ0Y7QUFDQTs7QUF6REE7QUFBQTtBQUFBLDZCQTBEMkM7QUFDdkMsVUFBTVYsR0FBRyxHQUFHLENBQ1YsS0FBS0QsS0FBTCxDQUFXRSxRQUFYLEVBRFUsRUFFVixXQUZVLEVBR1YsWUFIVSxFQUlWLEtBQUtKLEVBSkssRUFLVixRQUxVLEVBTVZLLElBTlUsQ0FNTCxHQU5LLENBQVo7QUFPQSxhQUFPLEtBQUtILEtBQUwsQ0FBV0ksT0FBWCxDQUEwQ0gsR0FBMUMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXZFQTtBQUFBO0FBQUEsOEJBd0U2QztBQUN6QyxVQUFNQSxHQUFHLEdBQUcsQ0FDVixLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixZQUhVLEVBSVYsS0FBS0osRUFKSyxFQUtWSyxJQUxVLENBS0wsR0FMSyxDQUFaO0FBTUEsYUFBTyxLQUFLSCxLQUFMLENBQVdJLE9BQVgsQ0FBMkM7QUFDaERLLFFBQUFBLE1BQU0sRUFBRSxLQUR3QztBQUVoRFIsUUFBQUEsR0FBRyxFQUFIQSxHQUZnRDtBQUdoRGEsUUFBQUEsSUFBSSxFQUFFO0FBSDBDLE9BQTNDLENBQVA7QUFLRDtBQUVEO0FBQ0Y7QUFDQTs7QUF4RkE7QUFBQTtBQUFBLDBCQTBGSUgsTUExRkosRUEyRklVLFFBM0ZKLEVBNEZnQztBQUM1QixVQUFNcEIsR0FBRyxHQUNQLENBQUMsS0FBS0QsS0FBTCxDQUFXRSxRQUFYLEVBQUQsRUFBd0IsV0FBeEIsRUFBcUMsWUFBckMsRUFBbURDLElBQW5ELENBQXdELEdBQXhELElBQ0EsV0FEQSxHQUVBLEtBQUtMLEVBSFA7O0FBSUEsVUFBSSxPQUFPYSxNQUFQLEtBQWtCLFFBQXRCLEVBQWdDO0FBQzlCQSxRQUFBQSxNQUFNLEdBQUc7QUFBRUQsVUFBQUEsSUFBSSxFQUFFQyxNQUFSO0FBQWdCVSxVQUFBQSxRQUFRLEVBQVJBO0FBQWhCLFNBQVQ7QUFDRDs7QUFDRCxhQUFPLEtBQUtyQixLQUFMLENBQVdJLE9BQVgsQ0FBc0M7QUFDM0NLLFFBQUFBLE1BQU0sRUFBRSxNQURtQztBQUUzQ1IsUUFBQUEsR0FBRyxFQUFIQSxHQUYyQztBQUczQ1ksUUFBQUEsT0FBTyxFQUFFO0FBQUUsMEJBQWdCO0FBQWxCLFNBSGtDO0FBSTNDQyxRQUFBQSxJQUFJLEVBQUUsZ0JBQWVILE1BQWY7QUFKcUMsT0FBdEMsQ0FBUDtBQU1EO0FBRUQ7QUFDRjtBQUNBOztBQTlHQTtBQUFBO0FBQUEsOEJBK0cyQjtBQUN2QixVQUFNVixHQUFHLEdBQUcsQ0FDVixLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFEVSxFQUVWLFdBRlUsRUFHVixZQUhVLEVBSVYsS0FBS0osRUFKSyxFQUtWSyxJQUxVLENBS0wsR0FMSyxDQUFaO0FBTUEsYUFBTyxLQUFLSCxLQUFMLENBQVdJLE9BQVgsQ0FBeUI7QUFBRUssUUFBQUEsTUFBTSxFQUFFLFFBQVY7QUFBb0JSLFFBQUFBLEdBQUcsRUFBSEE7QUFBcEIsT0FBekIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTNIQTs7QUFBQTtBQUFBO0FBb0lBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhcUIsU0FBYjtBQUdFO0FBQ0Y7QUFDQTtBQUNFLHFCQUFZaEIsSUFBWixFQUFpQztBQUFBOztBQUFBOztBQUMvQixTQUFLTixLQUFMLEdBQWFNLElBQWI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBWkE7QUFBQTtBQUFBLDJCQWFTUixFQWJULEVBYXFCO0FBQ2pCLGFBQU8sSUFBSU8sTUFBSixDQUFXLEtBQUtMLEtBQWhCLEVBQXVCRixFQUF2QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbkJBO0FBQUE7QUFBQSw4QkFvQlk7QUFDUixVQUFNRyxHQUFHLEdBQUcsQ0FBQyxLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxTQUFyQyxFQUFnREMsSUFBaEQsQ0FBcUQsR0FBckQsQ0FBWjtBQUNBLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQWlDSCxHQUFqQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBM0JBO0FBQUE7QUFBQSw4QkE0QllILEVBNUJaLEVBNEJ3QjtBQUNwQixhQUFPLElBQUlvQixTQUFKLENBQWMsS0FBS2xCLEtBQW5CLEVBQTBCRixFQUExQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbENBO0FBQUE7QUFBQSxpQ0FtQ2U7QUFDWCxVQUFJRyxHQUFHLEdBQUcsQ0FBQyxLQUFLRCxLQUFMLENBQVdFLFFBQVgsRUFBRCxFQUF3QixXQUF4QixFQUFxQyxZQUFyQyxFQUFtREMsSUFBbkQsQ0FBd0QsR0FBeEQsQ0FBVjtBQUNBLGFBQU8sS0FBS0gsS0FBTCxDQUFXSSxPQUFYLENBQW9DSCxHQUFwQyxDQUFQO0FBQ0Q7QUF0Q0g7O0FBQUE7QUFBQTtBQXlDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FqQixjQUFjLENBQUMsV0FBRCxFQUFjLFVBQUNzQixJQUFEO0FBQUEsU0FBVSxJQUFJZ0IsU0FBSixDQUFjaEIsSUFBZCxDQUFWO0FBQUEsQ0FBZCxDQUFkO0FBRUEsZUFBZWdCLFNBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU2FsZXNmb3JjZSBBbmFseXRpY3MgQVBJXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgUmVwb3J0TWV0YWRhdGEsXG4gIFJlcG9ydEV4ZWN1dGVSZXN1bHQsXG4gIFJlcG9ydFJldHJpZXZlUmVzdWx0LFxuICBSZXBvcnREZXNjcmliZVJlc3VsdCxcbiAgUmVwb3J0SW5mbyxcbiAgUmVwb3J0SW5zdGFuY2VJbmZvLFxuICBEYXNoYm9hcmRNZXRhZGF0YSxcbiAgRGFzaGJvYXJkUmVzdWx0LFxuICBEYXNoYm9hcmRTdGF0dXNSZXN1bHQsXG4gIERhc2hib2FyZFJlZnJlc2hSZXN1bHQsXG4gIERhc2hib2FyZEluZm8sXG59IGZyb20gJy4vYW5hbHl0aWNzL3R5cGVzJztcbmltcG9ydCB7IFF1ZXJ5RXhwbGFpblJlc3VsdCB9IGZyb20gJy4uL3F1ZXJ5JztcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbmV4cG9ydCB7XG4gIFJlcG9ydE1ldGFkYXRhLFxuICBSZXBvcnRFeGVjdXRlUmVzdWx0LFxuICBSZXBvcnRSZXRyaWV2ZVJlc3VsdCxcbiAgUmVwb3J0RGVzY3JpYmVSZXN1bHQsXG4gIFJlcG9ydEluZm8sXG4gIFJlcG9ydEluc3RhbmNlSW5mbyxcbiAgRGFzaGJvYXJkTWV0YWRhdGEsXG4gIERhc2hib2FyZFJlc3VsdCxcbiAgRGFzaGJvYXJkU3RhdHVzUmVzdWx0LFxuICBEYXNoYm9hcmRSZWZyZXNoUmVzdWx0LFxuICBEYXNoYm9hcmRJbmZvLFxufTtcblxuZXhwb3J0IHR5cGUgUmVwb3J0RXhlY3V0ZU9wdGlvbnMgPSB7XG4gIGRldGFpbHM/OiBib29sZWFuO1xuICBtZXRhZGF0YT86IHtcbiAgICByZXBvcnRNZXRhZGF0YTogUGFydGlhbDxSZXBvcnRNZXRhZGF0YT47XG4gIH07XG59O1xuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBSZXBvcnQgb2JqZWN0IGNsYXNzIGluIEFuYWx5dGljcyBBUElcbiAqL1xuZXhwb3J0IGNsYXNzIFJlcG9ydEluc3RhbmNlPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX3JlcG9ydDogUmVwb3J0PFM+O1xuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcbiAgaWQ6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKHJlcG9ydDogUmVwb3J0PFM+LCBpZDogc3RyaW5nKSB7XG4gICAgdGhpcy5fcmVwb3J0ID0gcmVwb3J0O1xuICAgIHRoaXMuX2Nvbm4gPSByZXBvcnQuX2Nvbm47XG4gICAgdGhpcy5pZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHJlcG9ydCByZXN1bHQgYXN5bmNocm9ub3VzbHkgZXhlY3V0ZWRcbiAgICovXG4gIHJldHJpZXZlKCk6IFByb21pc2U8UmVwb3J0UmV0cmlldmVSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdyZXBvcnRzJyxcbiAgICAgIHRoaXMuX3JlcG9ydC5pZCxcbiAgICAgICdpbnN0YW5jZXMnLFxuICAgICAgdGhpcy5pZCxcbiAgICBdLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydFJldHJpZXZlUmVzdWx0Pih1cmwpO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFJlcG9ydCBvYmplY3QgY2xhc3MgaW4gQW5hbHl0aWNzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgUmVwb3J0PFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIGlkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBpZDogc3RyaW5nKSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5pZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIHJlcG9ydCBtZXRhZGF0YVxuICAgKi9cbiAgZGVzY3JpYmUoKTogUHJvbWlzZTxSZXBvcnREZXNjcmliZVJlc3VsdD4ge1xuICAgIHZhciB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdyZXBvcnRzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgICAnZGVzY3JpYmUnLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8UmVwb3J0RGVzY3JpYmVSZXN1bHQ+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveSBhIHJlcG9ydFxuICAgKi9cbiAgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fY29ubi5fYmFzZVVybCgpLCAnYW5hbHl0aWNzJywgJ3JlcG9ydHMnLCB0aGlzLmlkXS5qb2luKFxuICAgICAgJy8nLFxuICAgICk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDx2b2lkPih7IG1ldGhvZDogJ0RFTEVURScsIHVybCB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFuYWx5dGljc35SZXBvcnQjZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQW5hbHl0aWNzflJlcG9ydCNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogQ2xvbmVzIGEgZ2l2ZW4gcmVwb3J0XG4gICAqL1xuICBjbG9uZShuYW1lOiBzdHJpbmcpOiBQcm9taXNlPFJlcG9ydERlc2NyaWJlUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID1cbiAgICAgIFt0aGlzLl9jb25uLl9iYXNlVXJsKCksICdhbmFseXRpY3MnLCAncmVwb3J0cyddLmpvaW4oJy8nKSArXG4gICAgICAnP2Nsb25lSWQ9JyArXG4gICAgICB0aGlzLmlkO1xuICAgIGNvbnN0IGNvbmZpZyA9IHsgcmVwb3J0TWV0YWRhdGE6IHsgbmFtZSB9IH07XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSZXBvcnREZXNjcmliZVJlc3VsdD4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGNvbmZpZyksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRXhwbGFpbiBwbGFuIGZvciBleGVjdXRpbmcgcmVwb3J0XG4gICAqL1xuICBleHBsYWluKCk6IFByb21pc2U8UXVlcnlFeHBsYWluUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gJy9xdWVyeS8/ZXhwbGFpbj0nICsgdGhpcy5pZDtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFF1ZXJ5RXhwbGFpblJlc3VsdD4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSdW4gcmVwb3J0IHN5bmNocm9ub3VzbHlcbiAgICovXG4gIGV4ZWN1dGUob3B0aW9uczogUmVwb3J0RXhlY3V0ZU9wdGlvbnMgPSB7fSk6IFByb21pc2U8UmVwb3J0RXhlY3V0ZVJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9XG4gICAgICBbdGhpcy5fY29ubi5fYmFzZVVybCgpLCAnYW5hbHl0aWNzJywgJ3JlcG9ydHMnLCB0aGlzLmlkXS5qb2luKCcvJykgK1xuICAgICAgJz9pbmNsdWRlRGV0YWlscz0nICtcbiAgICAgIChvcHRpb25zLmRldGFpbHMgPyAndHJ1ZScgOiAnZmFsc2UnKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydEV4ZWN1dGVSZXN1bHQ+KHtcbiAgICAgIHVybCxcbiAgICAgIC4uLihvcHRpb25zLm1ldGFkYXRhXG4gICAgICAgID8ge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG9wdGlvbnMubWV0YWRhdGEpLFxuICAgICAgICAgIH1cbiAgICAgICAgOiB7IG1ldGhvZDogJ0dFVCcgfSksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBBbmFseXRpY3N+UmVwb3J0I2V4ZWN1dGUoKVxuICAgKi9cbiAgcnVuID0gdGhpcy5leGVjdXRlO1xuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFuYWx5dGljc35SZXBvcnQjZXhlY3V0ZSgpXG4gICAqL1xuICBleGVjID0gdGhpcy5leGVjdXRlO1xuXG4gIC8qKlxuICAgKiBSdW4gcmVwb3J0IGFzeW5jaHJvbm91c2x5XG4gICAqL1xuICBleGVjdXRlQXN5bmMoXG4gICAgb3B0aW9uczogUmVwb3J0RXhlY3V0ZU9wdGlvbnMgPSB7fSxcbiAgKTogUHJvbWlzZTxSZXBvcnRJbnN0YW5jZUluZm8+IHtcbiAgICBjb25zdCB1cmwgPVxuICAgICAgW1xuICAgICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAgICdhbmFseXRpY3MnLFxuICAgICAgICAncmVwb3J0cycsXG4gICAgICAgIHRoaXMuaWQsXG4gICAgICAgICdpbnN0YW5jZXMnLFxuICAgICAgXS5qb2luKCcvJykgKyAob3B0aW9ucy5kZXRhaWxzID8gJz9pbmNsdWRlRGV0YWlscz10cnVlJyA6ICcnKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydEluc3RhbmNlSW5mbz4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICAuLi4ob3B0aW9ucy5tZXRhZGF0YVxuICAgICAgICA/IHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkob3B0aW9ucy5tZXRhZGF0YSksXG4gICAgICAgICAgfVxuICAgICAgICA6IHsgYm9keTogJycgfSksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlcG9ydCBpbnN0YW5jZSBmb3Igc3BlY2lmaWVkIGluc3RhbmNlIElEXG4gICAqL1xuICBpbnN0YW5jZShpZDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIG5ldyBSZXBvcnRJbnN0YW5jZSh0aGlzLCBpZCk7XG4gIH1cblxuICAvKipcbiAgICogTGlzdCByZXBvcnQgaW5zdGFuY2VzIHdoaWNoIGhhZCBiZWVuIGV4ZWN1dGVkIGFzeW5jaHJvbm91c2x5XG4gICAqL1xuICBpbnN0YW5jZXMoKTogUHJvbWlzZTxSZXBvcnRJbnN0YW5jZUluZm9bXT4ge1xuICAgIGNvbnN0IHVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICdhbmFseXRpY3MnLFxuICAgICAgJ3JlcG9ydHMnLFxuICAgICAgdGhpcy5pZCxcbiAgICAgICdpbnN0YW5jZXMnLFxuICAgIF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8UmVwb3J0SW5zdGFuY2VJbmZvW10+KHVybCk7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogRGFzaGJvYXJkIG9iamVjdCBjbGFzcyBpbiB0aGUgQW5hbHl0aWNzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgRGFzaGJvYXJkPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIGlkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBpZDogc3RyaW5nKSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5pZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIGRhc2hib2FyZCBtZXRhZGF0YVxuICAgKlxuICAgKiBAbWV0aG9kIEFuYWx5dGljc35EYXNoYm9hcmQjZGVzY3JpYmVcbiAgICogQHBhcmFtIHtDYWxsYmFjay48QW5hbHl0aWNzLURhc2hib2FyZE1ldGFkYXRhPn0gW2NhbGxiYWNrXSAtIENhbGxiYWNrIGZ1bmN0aW9uXG4gICAqIEByZXR1cm5zIHtQcm9taXNlLjxBbmFseXRpY3MtRGFzaGJvYXJkTWV0YWRhdGE+fVxuICAgKi9cbiAgZGVzY3JpYmUoKTogUHJvbWlzZTxEYXNoYm9hcmRNZXRhZGF0YT4ge1xuICAgIGNvbnN0IHVybCA9IFtcbiAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICdhbmFseXRpY3MnLFxuICAgICAgJ2Rhc2hib2FyZHMnLFxuICAgICAgdGhpcy5pZCxcbiAgICAgICdkZXNjcmliZScsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxEYXNoYm9hcmRNZXRhZGF0YT4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZGV0YWlscyBhYm91dCBkYXNoYm9hcmQgY29tcG9uZW50c1xuICAgKi9cbiAgY29tcG9uZW50cyhjb21wb25lbnRJZHM/OiBzdHJpbmcgfCBzdHJpbmdbXSk6IFByb21pc2U8RGFzaGJvYXJkUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAnZGFzaGJvYXJkcycsXG4gICAgICB0aGlzLmlkLFxuICAgIF0uam9pbignLycpO1xuICAgIGNvbnN0IGNvbmZpZyA9IHtcbiAgICAgIGNvbXBvbmVudElkczogQXJyYXkuaXNBcnJheShjb21wb25lbnRJZHMpXG4gICAgICAgID8gY29tcG9uZW50SWRzXG4gICAgICAgIDogdHlwZW9mIGNvbXBvbmVudElkcyA9PT0gJ3N0cmluZydcbiAgICAgICAgPyBbY29tcG9uZW50SWRzXVxuICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8RGFzaGJvYXJkUmVzdWx0Pih7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoY29uZmlnKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZGFzaGJvYXJkIHN0YXR1c1xuICAgKi9cbiAgc3RhdHVzKCk6IFByb21pc2U8RGFzaGJvYXJkU3RhdHVzUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ2FuYWx5dGljcycsXG4gICAgICAnZGFzaGJvYXJkcycsXG4gICAgICB0aGlzLmlkLFxuICAgICAgJ3N0YXR1cycsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxEYXNoYm9hcmRTdGF0dXNSZXN1bHQ+KHVybCk7XG4gIH1cblxuICAvKipcbiAgICogUmVmcmVzaCBhIGRhc2hib2FyZFxuICAgKi9cbiAgcmVmcmVzaCgpOiBQcm9taXNlPERhc2hib2FyZFJlZnJlc2hSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdkYXNoYm9hcmRzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxEYXNoYm9hcmRSZWZyZXNoUmVzdWx0Pih7XG4gICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogJycsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvbmUgYSBkYXNoYm9hcmRcbiAgICovXG4gIGNsb25lKFxuICAgIGNvbmZpZzogeyBuYW1lOiBzdHJpbmc7IGZvbGRlcklkPzogc3RyaW5nIH0gfCBzdHJpbmcsXG4gICAgZm9sZGVySWQ/OiBzdHJpbmcsXG4gICk6IFByb21pc2U8RGFzaGJvYXJkTWV0YWRhdGE+IHtcbiAgICBjb25zdCB1cmwgPVxuICAgICAgW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJ2FuYWx5dGljcycsICdkYXNoYm9hcmRzJ10uam9pbignLycpICtcbiAgICAgICc/Y2xvbmVJZD0nICtcbiAgICAgIHRoaXMuaWQ7XG4gICAgaWYgKHR5cGVvZiBjb25maWcgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25maWcgPSB7IG5hbWU6IGNvbmZpZywgZm9sZGVySWQgfTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxEYXNoYm9hcmRNZXRhZGF0YT4oe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmwsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGNvbmZpZyksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveSBhIGRhc2hib2FyZFxuICAgKi9cbiAgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1cmwgPSBbXG4gICAgICB0aGlzLl9jb25uLl9iYXNlVXJsKCksXG4gICAgICAnYW5hbHl0aWNzJyxcbiAgICAgICdkYXNoYm9hcmRzJyxcbiAgICAgIHRoaXMuaWQsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDx2b2lkPih7IG1ldGhvZDogJ0RFTEVURScsIHVybCB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFuYWx5dGljc35EYXNoYm9hcmQjZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQW5hbHl0aWNzfkRhc2hib2FyZCNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogQVBJIGNsYXNzIGZvciBBbmFseXRpY3MgQVBJXG4gKi9cbmV4cG9ydCBjbGFzcyBBbmFseXRpY3M8UyBleHRlbmRzIFNjaGVtYT4ge1xuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgcmVwb3J0IG9iamVjdCBvZiBBbmFseXRpY3MgQVBJXG4gICAqL1xuICByZXBvcnQoaWQ6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgUmVwb3J0KHRoaXMuX2Nvbm4sIGlkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgcmVjZW50IHJlcG9ydCBsaXN0XG4gICAqL1xuICByZXBvcnRzKCkge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9jb25uLl9iYXNlVXJsKCksICdhbmFseXRpY3MnLCAncmVwb3J0cyddLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFJlcG9ydEluZm9bXT4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZGFzaGJvYXJkIG9iamVjdCBvZiBBbmFseXRpY3MgQVBJXG4gICAqL1xuICBkYXNoYm9hcmQoaWQ6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgRGFzaGJvYXJkKHRoaXMuX2Nvbm4sIGlkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgcmVjZW50IGRhc2hib2FyZCBsaXN0XG4gICAqL1xuICBkYXNoYm9hcmRzKCkge1xuICAgIHZhciB1cmwgPSBbdGhpcy5fY29ubi5fYmFzZVVybCgpLCAnYW5hbHl0aWNzJywgJ2Rhc2hib2FyZHMnXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxEYXNoYm9hcmRJbmZvW10+KHVybCk7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKlxuICogUmVnaXN0ZXIgaG9vayBpbiBjb25uZWN0aW9uIGluc3RhbnRpYXRpb24gZm9yIGR5bmFtaWNhbGx5IGFkZGluZyB0aGlzIEFQSSBtb2R1bGUgZmVhdHVyZXNcbiAqL1xucmVnaXN0ZXJNb2R1bGUoJ2FuYWx5dGljcycsIChjb25uKSA9PiBuZXcgQW5hbHl0aWNzKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgQW5hbHl0aWNzO1xuIl19