import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 * @file Manages Salesforce Apex REST endpoint calls
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';

/**
 * API class for Apex REST endpoint call
 */
export var Apex = /*#__PURE__*/function () {
  /**
   *
   */
  function Apex(conn) {
    _classCallCheck(this, Apex);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "del", this.delete);

    this._conn = conn;
  }
  /* @private */


  _createClass(Apex, [{
    key: "_baseUrl",
    value: function _baseUrl() {
      return "".concat(this._conn.instanceUrl, "/services/apexrest");
    }
    /**
     * @private
     */

  }, {
    key: "_createRequestParams",
    value: function _createRequestParams(method, path, body) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var headers = _typeof(options.headers) === 'object' ? options.headers : {};

      if (!/^(GET|DELETE)$/i.test(method)) {
        headers['content-type'] = 'application/json';
      }

      var params = {
        method: method,
        url: this._baseUrl() + path,
        headers: headers
      };

      if (body) {
        params.body = _JSON$stringify(body);
      }

      return params;
    }
    /**
     * Call Apex REST service in GET request
     */

  }, {
    key: "get",
    value: function get(path, options) {
      return this._conn.request(this._createRequestParams('GET', path, undefined, options));
    }
    /**
     * Call Apex REST service in POST request
     */

  }, {
    key: "post",
    value: function post(path, body, options) {
      var params = this._createRequestParams('POST', path, body, options);

      return this._conn.request(params);
    }
    /**
     * Call Apex REST service in PUT request
     */

  }, {
    key: "put",
    value: function put(path, body, options) {
      var params = this._createRequestParams('PUT', path, body, options);

      return this._conn.request(params);
    }
    /**
     * Call Apex REST service in PATCH request
     */

  }, {
    key: "patch",
    value: function patch(path, body, options) {
      var params = this._createRequestParams('PATCH', path, body, options);

      return this._conn.request(params);
    }
    /**
     * Call Apex REST service in DELETE request
     */

  }, {
    key: "delete",
    value: function _delete(path, options) {
      return this._conn.request(this._createRequestParams('DELETE', path, undefined, options));
    }
    /**
     * Synonym of Apex#delete()
     */

  }]);

  return Apex;
}();
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('apex', function (conn) {
  return new Apex(conn);
});
export default Apex;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYXBleC50cyJdLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsIkFwZXgiLCJjb25uIiwiZGVsZXRlIiwiX2Nvbm4iLCJpbnN0YW5jZVVybCIsIm1ldGhvZCIsInBhdGgiLCJib2R5Iiwib3B0aW9ucyIsImhlYWRlcnMiLCJ0ZXN0IiwicGFyYW1zIiwidXJsIiwiX2Jhc2VVcmwiLCJyZXF1ZXN0IiwiX2NyZWF0ZVJlcXVlc3RQYXJhbXMiLCJ1bmRlZmluZWQiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsY0FBVCxRQUErQixZQUEvQjs7QUFJQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxJQUFiO0FBR0U7QUFDRjtBQUNBO0FBQ0UsZ0JBQVlDLElBQVosRUFBaUM7QUFBQTs7QUFBQTs7QUFBQSxpQ0ErRTNCLEtBQUtDLE1BL0VzQjs7QUFDL0IsU0FBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0Q7QUFFRDs7O0FBVkY7QUFBQTtBQUFBLCtCQVdhO0FBQ1QsdUJBQVUsS0FBS0UsS0FBTCxDQUFXQyxXQUFyQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWpCQTtBQUFBO0FBQUEseUNBbUJJQyxNQW5CSixFQW9CSUMsSUFwQkosRUFxQklDLElBckJKLEVBdUJpQjtBQUFBLFVBRGJDLE9BQ2EsdUVBRG1DLEVBQ25DO0FBQ2IsVUFBTUMsT0FBK0IsR0FDbkMsUUFBT0QsT0FBTyxDQUFDQyxPQUFmLE1BQTJCLFFBQTNCLEdBQXNDRCxPQUFPLENBQUNDLE9BQTlDLEdBQXdELEVBRDFEOztBQUVBLFVBQUksQ0FBQyxrQkFBa0JDLElBQWxCLENBQXVCTCxNQUF2QixDQUFMLEVBQXFDO0FBQ25DSSxRQUFBQSxPQUFPLENBQUMsY0FBRCxDQUFQLEdBQTBCLGtCQUExQjtBQUNEOztBQUNELFVBQU1FLE1BQW1CLEdBQUc7QUFDMUJOLFFBQUFBLE1BQU0sRUFBTkEsTUFEMEI7QUFFMUJPLFFBQUFBLEdBQUcsRUFBRSxLQUFLQyxRQUFMLEtBQWtCUCxJQUZHO0FBRzFCRyxRQUFBQSxPQUFPLEVBQVBBO0FBSDBCLE9BQTVCOztBQUtBLFVBQUlGLElBQUosRUFBVTtBQUNSSSxRQUFBQSxNQUFNLENBQUNKLElBQVAsR0FBYyxnQkFBZUEsSUFBZixDQUFkO0FBQ0Q7O0FBQ0QsYUFBT0ksTUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTFDQTtBQUFBO0FBQUEsd0JBMkNtQkwsSUEzQ25CLEVBMkNpQ0UsT0EzQ2pDLEVBMkNtRDtBQUMvQyxhQUFPLEtBQUtMLEtBQUwsQ0FBV1csT0FBWCxDQUNMLEtBQUtDLG9CQUFMLENBQTBCLEtBQTFCLEVBQWlDVCxJQUFqQyxFQUF1Q1UsU0FBdkMsRUFBa0RSLE9BQWxELENBREssQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBOztBQW5EQTtBQUFBO0FBQUEseUJBb0RvQkYsSUFwRHBCLEVBb0RrQ0MsSUFwRGxDLEVBb0RpREMsT0FwRGpELEVBb0RtRTtBQUMvRCxVQUFNRyxNQUFNLEdBQUcsS0FBS0ksb0JBQUwsQ0FBMEIsTUFBMUIsRUFBa0NULElBQWxDLEVBQXdDQyxJQUF4QyxFQUE4Q0MsT0FBOUMsQ0FBZjs7QUFDQSxhQUFPLEtBQUtMLEtBQUwsQ0FBV1csT0FBWCxDQUFzQkgsTUFBdEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTNEQTtBQUFBO0FBQUEsd0JBNERtQkwsSUE1RG5CLEVBNERpQ0MsSUE1RGpDLEVBNERnREMsT0E1RGhELEVBNERrRTtBQUM5RCxVQUFNRyxNQUFNLEdBQUcsS0FBS0ksb0JBQUwsQ0FBMEIsS0FBMUIsRUFBaUNULElBQWpDLEVBQXVDQyxJQUF2QyxFQUE2Q0MsT0FBN0MsQ0FBZjs7QUFDQSxhQUFPLEtBQUtMLEtBQUwsQ0FBV1csT0FBWCxDQUFzQkgsTUFBdEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQW5FQTtBQUFBO0FBQUEsMEJBb0VxQkwsSUFwRXJCLEVBb0VtQ0MsSUFwRW5DLEVBb0VrREMsT0FwRWxELEVBb0VvRTtBQUNoRSxVQUFNRyxNQUFNLEdBQUcsS0FBS0ksb0JBQUwsQ0FBMEIsT0FBMUIsRUFBbUNULElBQW5DLEVBQXlDQyxJQUF6QyxFQUErQ0MsT0FBL0MsQ0FBZjs7QUFDQSxhQUFPLEtBQUtMLEtBQUwsQ0FBV1csT0FBWCxDQUFzQkgsTUFBdEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTNFQTtBQUFBO0FBQUEsNEJBNEVzQkwsSUE1RXRCLEVBNEVvQ0UsT0E1RXBDLEVBNEVzRDtBQUNsRCxhQUFPLEtBQUtMLEtBQUwsQ0FBV1csT0FBWCxDQUNMLEtBQUtDLG9CQUFMLENBQTBCLFFBQTFCLEVBQW9DVCxJQUFwQyxFQUEwQ1UsU0FBMUMsRUFBcURSLE9BQXJELENBREssQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBOztBQXBGQTs7QUFBQTtBQUFBO0FBd0ZBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQVQsY0FBYyxDQUFDLE1BQUQsRUFBUyxVQUFDRSxJQUFEO0FBQUEsU0FBVSxJQUFJRCxJQUFKLENBQVNDLElBQVQsQ0FBVjtBQUFBLENBQVQsQ0FBZDtBQUVBLGVBQWVELElBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU2FsZXNmb3JjZSBBcGV4IFJFU1QgZW5kcG9pbnQgY2FsbHNcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyByZWdpc3Rlck1vZHVsZSB9IGZyb20gJy4uL2pzZm9yY2UnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBIdHRwUmVxdWVzdCwgSHR0cE1ldGhvZHMsIFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzJztcblxuLyoqXG4gKiBBUEkgY2xhc3MgZm9yIEFwZXggUkVTVCBlbmRwb2ludCBjYWxsXG4gKi9cbmV4cG9ydCBjbGFzcyBBcGV4PFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gIH1cblxuICAvKiBAcHJpdmF0ZSAqL1xuICBfYmFzZVVybCgpIHtcbiAgICByZXR1cm4gYCR7dGhpcy5fY29ubi5pbnN0YW5jZVVybH0vc2VydmljZXMvYXBleHJlc3RgO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfY3JlYXRlUmVxdWVzdFBhcmFtcyhcbiAgICBtZXRob2Q6IEh0dHBNZXRob2RzLFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBib2R5PzogT2JqZWN0LFxuICAgIG9wdGlvbnM6IHsgaGVhZGVycz86IEh0dHBSZXF1ZXN0WydoZWFkZXJzJ10gfSA9IHt9LFxuICApOiBIdHRwUmVxdWVzdCB7XG4gICAgY29uc3QgaGVhZGVyczogSHR0cFJlcXVlc3RbJ2hlYWRlcnMnXSA9XG4gICAgICB0eXBlb2Ygb3B0aW9ucy5oZWFkZXJzID09PSAnb2JqZWN0JyA/IG9wdGlvbnMuaGVhZGVycyA6IHt9O1xuICAgIGlmICghL14oR0VUfERFTEVURSkkL2kudGVzdChtZXRob2QpKSB7XG4gICAgICBoZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcbiAgICB9XG4gICAgY29uc3QgcGFyYW1zOiBIdHRwUmVxdWVzdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIHVybDogdGhpcy5fYmFzZVVybCgpICsgcGF0aCxcbiAgICAgIGhlYWRlcnMsXG4gICAgfTtcbiAgICBpZiAoYm9keSkge1xuICAgICAgcGFyYW1zLmJvZHkgPSBKU09OLnN0cmluZ2lmeShib2R5KTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmFtcztcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIEFwZXggUkVTVCBzZXJ2aWNlIGluIEdFVCByZXF1ZXN0XG4gICAqL1xuICBnZXQ8UiA9IHVua25vd24+KHBhdGg6IHN0cmluZywgb3B0aW9ucz86IE9iamVjdCkge1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3Q8Uj4oXG4gICAgICB0aGlzLl9jcmVhdGVSZXF1ZXN0UGFyYW1zKCdHRVQnLCBwYXRoLCB1bmRlZmluZWQsIG9wdGlvbnMpLFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBBcGV4IFJFU1Qgc2VydmljZSBpbiBQT1NUIHJlcXVlc3RcbiAgICovXG4gIHBvc3Q8UiA9IHVua25vd24+KHBhdGg6IHN0cmluZywgYm9keT86IE9iamVjdCwgb3B0aW9ucz86IE9iamVjdCkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHRoaXMuX2NyZWF0ZVJlcXVlc3RQYXJhbXMoJ1BPU1QnLCBwYXRoLCBib2R5LCBvcHRpb25zKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHBhcmFtcyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBBcGV4IFJFU1Qgc2VydmljZSBpbiBQVVQgcmVxdWVzdFxuICAgKi9cbiAgcHV0PFIgPSB1bmtub3duPihwYXRoOiBzdHJpbmcsIGJvZHk/OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCBwYXJhbXMgPSB0aGlzLl9jcmVhdGVSZXF1ZXN0UGFyYW1zKCdQVVQnLCBwYXRoLCBib2R5LCBvcHRpb25zKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHBhcmFtcyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBBcGV4IFJFU1Qgc2VydmljZSBpbiBQQVRDSCByZXF1ZXN0XG4gICAqL1xuICBwYXRjaDxSID0gdW5rbm93bj4ocGF0aDogc3RyaW5nLCBib2R5PzogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcGFyYW1zID0gdGhpcy5fY3JlYXRlUmVxdWVzdFBhcmFtcygnUEFUQ0gnLCBwYXRoLCBib2R5LCBvcHRpb25zKTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHBhcmFtcyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBBcGV4IFJFU1Qgc2VydmljZSBpbiBERUxFVEUgcmVxdWVzdFxuICAgKi9cbiAgZGVsZXRlPFIgPSB1bmtub3duPihwYXRoOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KFxuICAgICAgdGhpcy5fY3JlYXRlUmVxdWVzdFBhcmFtcygnREVMRVRFJywgcGF0aCwgdW5kZWZpbmVkLCBvcHRpb25zKSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQXBleCNkZWxldGUoKVxuICAgKi9cbiAgZGVsID0gdGhpcy5kZWxldGU7XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdhcGV4JywgKGNvbm4pID0+IG5ldyBBcGV4KGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgQXBleDtcbiJdfQ==