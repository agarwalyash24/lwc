import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 *
 */
import { getLogger } from './util/logger';

/**
 *
 */
export var SessionRefreshDelegate = /*#__PURE__*/function () {
  function SessionRefreshDelegate(conn, refreshFn) {
    _classCallCheck(this, SessionRefreshDelegate);

    _defineProperty(this, "_refreshFn", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "_lastRefreshedAt", undefined);

    _defineProperty(this, "_refreshPromise", undefined);

    this._conn = conn;
    this._logger = conn._logLevel ? SessionRefreshDelegate._logger.createInstance(conn._logLevel) : SessionRefreshDelegate._logger;
    this._refreshFn = refreshFn;
  }
  /**
   * Refresh access token
   * @private
   */


  _createClass(SessionRefreshDelegate, [{
    key: "refresh",
    value: function () {
      var _refresh = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(since) {
        var _this = this;

        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this._lastRefreshedAt && this._lastRefreshedAt > since)) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return");

              case 2:
                if (!this._refreshPromise) {
                  _context.next = 6;
                  break;
                }

                _context.next = 5;
                return this._refreshPromise;

              case 5:
                return _context.abrupt("return");

              case 6:
                _context.prev = 6;

                this._logger.info('<refresh token>');

                this._refreshPromise = new _Promise(function (resolve, reject) {
                  _this._refreshFn(_this._conn, function (err, accessToken, res) {
                    if (!err) {
                      _this._logger.debug('Connection refresh completed.');

                      _this._conn.accessToken = accessToken;

                      _this._conn.emit('refresh', accessToken, res);

                      resolve();
                    } else {
                      reject(err);
                    }
                  });
                });
                _context.next = 11;
                return this._refreshPromise;

              case 11:
                this._logger.info('<refresh complete>');

              case 12:
                _context.prev = 12;
                this._refreshPromise = undefined;
                this._lastRefreshedAt = _Date$now();
                return _context.finish(12);

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[6,, 12, 16]]);
      }));

      function refresh(_x) {
        return _refresh.apply(this, arguments);
      }

      return refresh;
    }()
  }, {
    key: "isRefreshing",
    value: function isRefreshing() {
      return !!this._refreshPromise;
    }
  }, {
    key: "waitRefresh",
    value: function () {
      var _waitRefresh = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                return _context2.abrupt("return", this._refreshPromise);

              case 1:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function waitRefresh() {
        return _waitRefresh.apply(this, arguments);
      }

      return waitRefresh;
    }()
  }]);

  return SessionRefreshDelegate;
}();

_defineProperty(SessionRefreshDelegate, "_logger", getLogger('session-refresh-delegate'));

export default SessionRefreshDelegate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zZXNzaW9uLXJlZnJlc2gtZGVsZWdhdGUudHMiXSwibmFtZXMiOlsiZ2V0TG9nZ2VyIiwiU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSIsImNvbm4iLCJyZWZyZXNoRm4iLCJ1bmRlZmluZWQiLCJfY29ubiIsIl9sb2dnZXIiLCJfbG9nTGV2ZWwiLCJjcmVhdGVJbnN0YW5jZSIsIl9yZWZyZXNoRm4iLCJzaW5jZSIsIl9sYXN0UmVmcmVzaGVkQXQiLCJfcmVmcmVzaFByb21pc2UiLCJpbmZvIiwicmVzb2x2ZSIsInJlamVjdCIsImVyciIsImFjY2Vzc1Rva2VuIiwicmVzIiwiZGVidWciLCJlbWl0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxTQUFULFFBQWtDLGVBQWxDOztBQWFBO0FBQ0E7QUFDQTtBQUNBLFdBQWFDLHNCQUFiO0FBU0Usa0NBQVlDLElBQVosRUFBaUNDLFNBQWpDLEVBQW1FO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsOENBSHpCQyxTQUd5Qjs7QUFBQSw2Q0FGbkJBLFNBRW1COztBQUNqRSxTQUFLQyxLQUFMLEdBQWFILElBQWI7QUFDQSxTQUFLSSxPQUFMLEdBQWVKLElBQUksQ0FBQ0ssU0FBTCxHQUNYTixzQkFBc0IsQ0FBQ0ssT0FBdkIsQ0FBK0JFLGNBQS9CLENBQThDTixJQUFJLENBQUNLLFNBQW5ELENBRFcsR0FFWE4sc0JBQXNCLENBQUNLLE9BRjNCO0FBR0EsU0FBS0csVUFBTCxHQUFrQk4sU0FBbEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7QUFwQkE7QUFBQTtBQUFBO0FBQUEsK0ZBcUJnQk8sS0FyQmhCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF1QlEsS0FBS0MsZ0JBQUwsSUFBeUIsS0FBS0EsZ0JBQUwsR0FBd0JELEtBdkJ6RDtBQUFBO0FBQUE7QUFBQTs7QUFBQTs7QUFBQTtBQUFBLHFCQTBCUSxLQUFLRSxlQTFCYjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVCQTJCWSxLQUFLQSxlQTNCakI7O0FBQUE7QUFBQTs7QUFBQTtBQUFBOztBQStCTSxxQkFBS04sT0FBTCxDQUFhTyxJQUFiLENBQWtCLGlCQUFsQjs7QUFDQSxxQkFBS0QsZUFBTCxHQUF1QixhQUFZLFVBQUNFLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUN0RCxrQkFBQSxLQUFJLENBQUNOLFVBQUwsQ0FBZ0IsS0FBSSxDQUFDSixLQUFyQixFQUE0QixVQUFDVyxHQUFELEVBQU1DLFdBQU4sRUFBbUJDLEdBQW5CLEVBQTJCO0FBQ3JELHdCQUFJLENBQUNGLEdBQUwsRUFBVTtBQUNSLHNCQUFBLEtBQUksQ0FBQ1YsT0FBTCxDQUFhYSxLQUFiLENBQW1CLCtCQUFuQjs7QUFDQSxzQkFBQSxLQUFJLENBQUNkLEtBQUwsQ0FBV1ksV0FBWCxHQUF5QkEsV0FBekI7O0FBQ0Esc0JBQUEsS0FBSSxDQUFDWixLQUFMLENBQVdlLElBQVgsQ0FBZ0IsU0FBaEIsRUFBMkJILFdBQTNCLEVBQXdDQyxHQUF4Qzs7QUFDQUosc0JBQUFBLE9BQU87QUFDUixxQkFMRCxNQUtPO0FBQ0xDLHNCQUFBQSxNQUFNLENBQUNDLEdBQUQsQ0FBTjtBQUNEO0FBQ0YsbUJBVEQ7QUFVRCxpQkFYc0IsQ0FBdkI7QUFoQ047QUFBQSx1QkE0Q1ksS0FBS0osZUE1Q2pCOztBQUFBO0FBNkNNLHFCQUFLTixPQUFMLENBQWFPLElBQWIsQ0FBa0Isb0JBQWxCOztBQTdDTjtBQUFBO0FBK0NNLHFCQUFLRCxlQUFMLEdBQXVCUixTQUF2QjtBQUNBLHFCQUFLTyxnQkFBTCxHQUF3QixXQUF4QjtBQWhETjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FvRDBCO0FBQ3RCLGFBQU8sQ0FBQyxDQUFDLEtBQUtDLGVBQWQ7QUFDRDtBQXRESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0RBeURXLEtBQUtBLGVBekRoQjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7O2dCQUFhWCxzQixhQUNjRCxTQUFTLENBQUMsMEJBQUQsQzs7QUE0RHBDLGVBQWVDLHNCQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBnZXRMb2dnZXIsIExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgQ2FsbGJhY2ssIFNjaGVtYSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFRva2VuUmVzcG9uc2UgfSBmcm9tICcuL29hdXRoMic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU2Vzc2lvblJlZnJlc2hGdW5jPFMgZXh0ZW5kcyBTY2hlbWE+ID0gKFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikgPT4gdm9pZDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIHN0YXRpYyBfbG9nZ2VyOiBMb2dnZXIgPSBnZXRMb2dnZXIoJ3Nlc3Npb24tcmVmcmVzaC1kZWxlZ2F0ZScpO1xuXG4gIHByaXZhdGUgX3JlZnJlc2hGbjogU2Vzc2lvblJlZnJlc2hGdW5jPFM+O1xuICBwcml2YXRlIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBwcml2YXRlIF9sb2dnZXI6IExvZ2dlcjtcbiAgcHJpdmF0ZSBfbGFzdFJlZnJlc2hlZEF0OiBudW1iZXIgfCB2b2lkID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF9yZWZyZXNoUHJvbWlzZTogUHJvbWlzZTx2b2lkPiB8IHZvaWQgPSB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgcmVmcmVzaEZuOiBTZXNzaW9uUmVmcmVzaEZ1bmM8Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgICB0aGlzLl9sb2dnZXIgPSBjb25uLl9sb2dMZXZlbFxuICAgICAgPyBTZXNzaW9uUmVmcmVzaERlbGVnYXRlLl9sb2dnZXIuY3JlYXRlSW5zdGFuY2UoY29ubi5fbG9nTGV2ZWwpXG4gICAgICA6IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUuX2xvZ2dlcjtcbiAgICB0aGlzLl9yZWZyZXNoRm4gPSByZWZyZXNoRm47XG4gIH1cblxuICAvKipcbiAgICogUmVmcmVzaCBhY2Nlc3MgdG9rZW5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIHJlZnJlc2goc2luY2U6IG51bWJlcikge1xuICAgIC8vIENhbGxiYWNrIGltbWVkaWF0ZWx5IFdoZW4gcmVmcmVzaGVkIGFmdGVyIGRlc2lnbmF0ZWQgdGltZVxuICAgIGlmICh0aGlzLl9sYXN0UmVmcmVzaGVkQXQgJiYgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID4gc2luY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3JlZnJlc2hQcm9taXNlKSB7XG4gICAgICBhd2FpdCB0aGlzLl9yZWZyZXNoUHJvbWlzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuX2xvZ2dlci5pbmZvKCc8cmVmcmVzaCB0b2tlbj4nKTtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICB0aGlzLl9yZWZyZXNoRm4odGhpcy5fY29ubiwgKGVyciwgYWNjZXNzVG9rZW4sIHJlcykgPT4ge1xuICAgICAgICAgIGlmICghZXJyKSB7XG4gICAgICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ0Nvbm5lY3Rpb24gcmVmcmVzaCBjb21wbGV0ZWQuJyk7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmFjY2Vzc1Rva2VuID0gYWNjZXNzVG9rZW47XG4gICAgICAgICAgICB0aGlzLl9jb25uLmVtaXQoJ3JlZnJlc2gnLCBhY2Nlc3NUb2tlbiwgcmVzKTtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gICAgICB0aGlzLl9sb2dnZXIuaW5mbygnPHJlZnJlc2ggY29tcGxldGU+Jyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID0gRGF0ZS5ub3coKTtcbiAgICB9XG4gIH1cblxuICBpc1JlZnJlc2hpbmcoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cblxuICBhc3luYyB3YWl0UmVmcmVzaCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTtcbiJdfQ==