import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 * @file Represents Salesforce QuickAction
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */

/**
 * type definitions
 */

/**
 * A class for quick action
 */
export var QuickAction = /*#__PURE__*/function () {
  /**
   *
   */
  function QuickAction(conn, path) {
    _classCallCheck(this, QuickAction);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_path", void 0);

    this._conn = conn;
    this._path = path;
  }
  /**
   * Describe the action's information (including layout, etc.)
   */


  _createClass(QuickAction, [{
    key: "describe",
    value: function () {
      var _describe = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = "".concat(this._path, "/describe");
                _context.next = 3;
                return this._conn.request(url);

              case 3:
                body = _context.sent;
                return _context.abrupt("return", body);

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function describe() {
        return _describe.apply(this, arguments);
      }

      return describe;
    }()
    /**
     * Retrieve default field values in the action (for given record, if specified)
     */

  }, {
    key: "defaultValues",
    value: function () {
      var _defaultValues = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(contextId) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                url = "".concat(this._path, "/defaultValues");

                if (contextId) {
                  url += "/".concat(contextId);
                }

                _context2.next = 4;
                return this._conn.request(url);

              case 4:
                body = _context2.sent;
                return _context2.abrupt("return", body);

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function defaultValues(_x) {
        return _defaultValues.apply(this, arguments);
      }

      return defaultValues;
    }()
    /**
     * Execute the action for given context Id and record information
     */

  }, {
    key: "execute",
    value: function () {
      var _execute = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(contextId, record) {
        var requestBody, resBody;
        return _regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                requestBody = {
                  contextId: contextId,
                  record: record
                };
                _context3.next = 3;
                return this._conn.requestPost(this._path, requestBody);

              case 3:
                resBody = _context3.sent;
                return _context3.abrupt("return", resBody);

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function execute(_x2, _x3) {
        return _execute.apply(this, arguments);
      }

      return execute;
    }()
  }]);

  return QuickAction;
}();
export default QuickAction;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9xdWljay1hY3Rpb24udHMiXSwibmFtZXMiOlsiUXVpY2tBY3Rpb24iLCJjb25uIiwicGF0aCIsIl9jb25uIiwiX3BhdGgiLCJ1cmwiLCJyZXF1ZXN0IiwiYm9keSIsImNvbnRleHRJZCIsInJlY29yZCIsInJlcXVlc3RCb2R5IiwicmVxdWVzdFBvc3QiLCJyZXNCb2R5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBU0E7QUFDQTtBQUNBOztBQVlBO0FBQ0E7QUFDQTtBQUNBLFdBQWFBLFdBQWI7QUFJRTtBQUNGO0FBQ0E7QUFDRSx1QkFBWUMsSUFBWixFQUFpQ0MsSUFBakMsRUFBK0M7QUFBQTs7QUFBQTs7QUFBQTs7QUFDN0MsU0FBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0EsU0FBS0csS0FBTCxHQUFhRixJQUFiO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQWRBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWdCVUcsZ0JBQUFBLEdBaEJWLGFBZ0JtQixLQUFLRCxLQWhCeEI7QUFBQTtBQUFBLHVCQWlCdUIsS0FBS0QsS0FBTCxDQUFXRyxPQUFYLENBQW1CRCxHQUFuQixDQWpCdkI7O0FBQUE7QUFpQlVFLGdCQUFBQSxJQWpCVjtBQUFBLGlEQWtCV0EsSUFsQlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFxQkU7QUFDRjtBQUNBOztBQXZCQTtBQUFBO0FBQUE7QUFBQSxzR0F3QnNCQyxTQXhCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeUJRSCxnQkFBQUEsR0F6QlIsYUF5QmlCLEtBQUtELEtBekJ0Qjs7QUEwQkksb0JBQUlJLFNBQUosRUFBZTtBQUNiSCxrQkFBQUEsR0FBRyxlQUFRRyxTQUFSLENBQUg7QUFDRDs7QUE1Qkw7QUFBQSx1QkE2QnVCLEtBQUtMLEtBQUwsQ0FBV0csT0FBWCxDQUFtQkQsR0FBbkIsQ0E3QnZCOztBQUFBO0FBNkJVRSxnQkFBQUEsSUE3QlY7QUFBQSxrREE4QldBLElBOUJYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaUNFO0FBQ0Y7QUFDQTs7QUFuQ0E7QUFBQTtBQUFBO0FBQUEsZ0dBb0NnQkMsU0FwQ2hCLEVBb0NtQ0MsTUFwQ25DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFDVUMsZ0JBQUFBLFdBckNWLEdBcUN3QjtBQUFFRixrQkFBQUEsU0FBUyxFQUFUQSxTQUFGO0FBQWFDLGtCQUFBQSxNQUFNLEVBQU5BO0FBQWIsaUJBckN4QjtBQUFBO0FBQUEsdUJBc0MwQixLQUFLTixLQUFMLENBQVdRLFdBQVgsQ0FBdUIsS0FBS1AsS0FBNUIsRUFBbUNNLFdBQW5DLENBdEMxQjs7QUFBQTtBQXNDVUUsZ0JBQUFBLE9BdENWO0FBQUEsa0RBdUNXQSxPQXZDWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUEyQ0EsZUFBZVosV0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgUmVwcmVzZW50cyBTYWxlc2ZvcmNlIFF1aWNrQWN0aW9uXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCB7XG4gIERlc2NyaWJlUXVpY2tBY3Rpb25EZXRhaWxSZXN1bHQsXG4gIFJlY29yZCxcbiAgT3B0aW9uYWwsXG4gIFNjaGVtYSxcbn0gZnJvbSAnLi90eXBlcyc7XG5cbi8qKlxuICogdHlwZSBkZWZpbml0aW9uc1xuICovXG5leHBvcnQgdHlwZSBRdWlja0FjdGlvbkRlZmF1bHRWYWx1ZXMgPSB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfTtcblxuZXhwb3J0IHR5cGUgUXVpY2tBY3Rpb25SZXN1bHQgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIGZlZWRJdGVtSWRzOiBPcHRpb25hbDxzdHJpbmdbXT47XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIGNyZWF0ZWQ6IGJvb2xlYW47XG4gIGNvbnRleHRJZDogc3RyaW5nO1xuICBlcnJvcnM6IE9iamVjdFtdO1xufTtcblxuLyoqXG4gKiBBIGNsYXNzIGZvciBxdWljayBhY3Rpb25cbiAqL1xuZXhwb3J0IGNsYXNzIFF1aWNrQWN0aW9uPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIF9wYXRoOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBwYXRoOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgICB0aGlzLl9wYXRoID0gcGF0aDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXNjcmliZSB0aGUgYWN0aW9uJ3MgaW5mb3JtYXRpb24gKGluY2x1ZGluZyBsYXlvdXQsIGV0Yy4pXG4gICAqL1xuICBhc3luYyBkZXNjcmliZSgpOiBQcm9taXNlPERlc2NyaWJlUXVpY2tBY3Rpb25EZXRhaWxSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBgJHt0aGlzLl9wYXRofS9kZXNjcmliZWA7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMuX2Nvbm4ucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlUXVpY2tBY3Rpb25EZXRhaWxSZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgZGVmYXVsdCBmaWVsZCB2YWx1ZXMgaW4gdGhlIGFjdGlvbiAoZm9yIGdpdmVuIHJlY29yZCwgaWYgc3BlY2lmaWVkKVxuICAgKi9cbiAgYXN5bmMgZGVmYXVsdFZhbHVlcyhjb250ZXh0SWQ/OiBzdHJpbmcpOiBQcm9taXNlPFF1aWNrQWN0aW9uRGVmYXVsdFZhbHVlcz4ge1xuICAgIGxldCB1cmwgPSBgJHt0aGlzLl9wYXRofS9kZWZhdWx0VmFsdWVzYDtcbiAgICBpZiAoY29udGV4dElkKSB7XG4gICAgICB1cmwgKz0gYC8ke2NvbnRleHRJZH1gO1xuICAgIH1cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgUXVpY2tBY3Rpb25EZWZhdWx0VmFsdWVzO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgdGhlIGFjdGlvbiBmb3IgZ2l2ZW4gY29udGV4dCBJZCBhbmQgcmVjb3JkIGluZm9ybWF0aW9uXG4gICAqL1xuICBhc3luYyBleGVjdXRlKGNvbnRleHRJZDogc3RyaW5nLCByZWNvcmQ6IFJlY29yZCk6IFByb21pc2U8UXVpY2tBY3Rpb25SZXN1bHQ+IHtcbiAgICBjb25zdCByZXF1ZXN0Qm9keSA9IHsgY29udGV4dElkLCByZWNvcmQgfTtcbiAgICBjb25zdCByZXNCb2R5ID0gYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0UG9zdCh0aGlzLl9wYXRoLCByZXF1ZXN0Qm9keSk7XG4gICAgcmV0dXJuIHJlc0JvZHkgYXMgUXVpY2tBY3Rpb25SZXN1bHQ7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgUXVpY2tBY3Rpb247XG4iXX0=