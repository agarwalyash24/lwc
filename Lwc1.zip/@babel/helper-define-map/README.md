# @babel/helper-define-map

> Helper function to define a map

See our website [@babel/helper-define-map](https://babeljs.io/docs/en/babel-helper-define-map) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-define-map
```

or using yarn:

```sh
yarn add @babel/helper-define-map
```
